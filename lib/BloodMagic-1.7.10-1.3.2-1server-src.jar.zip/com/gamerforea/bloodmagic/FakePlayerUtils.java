package com.gamerforea.bloodmagic;

import com.gamerforea.wgew.cauldron.event.CauldronBlockBreakEvent;
import com.gamerforea.wgew.cauldron.event.CauldronEntityDamageByEntityEvent;
import com.mojang.authlib.GameProfile;
import java.lang.ref.WeakReference;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.common.util.FakePlayerFactory;
import org.bukkit.Bukkit;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public final class FakePlayerUtils {

   private static WeakReference player = new WeakReference((Object)null);


   private static WeakReference createNewPlayer(World world) {
      return new WeakReference(createFakePlayer(new GameProfile(UUID.fromString("7848634b-5a36-4eeb-8775-2d1d8dd7882e"), "[BloodMagic]"), world));
   }

   public static final FakePlayer getPlayer(World world) {
      if(player.get() == null) {
         player = createNewPlayer(world);
      } else {
         ((FakePlayer)player.get()).worldObj = world;
      }

      return (FakePlayer)player.get();
   }

   public static FakePlayer createFakePlayer(GameProfile profile, World world) {
      return FakePlayerFactory.get((WorldServer)world, profile);
   }

   public static BlockBreakEvent callBlockBreakEvent(int x, int y, int z, EntityPlayer player) {
      CauldronBlockBreakEvent event = new CauldronBlockBreakEvent(player, x, y, z);
      Bukkit.getServer().getPluginManager().callEvent(event);
      return event.getBukkitEvent();
   }

   public static EntityDamageByEntityEvent callEntityDamageByEntityEvent(Entity damager, Entity damagee, DamageCause cause, double damage) {
      CauldronEntityDamageByEntityEvent event = new CauldronEntityDamageByEntityEvent(damager, damagee, cause, damage);
      Bukkit.getServer().getPluginManager().callEvent(event);
      return event.getBukkitEvent();
   }

   public static boolean notCanBreak(EntityPlayer player, int x, int y, int z) {
      return callBlockBreakEvent(x, y, z, player).isCancelled();
   }

   public static boolean notCanDamage(Entity damager, Entity damagee) {
      return callEntityDamageByEntityEvent(damager, damagee, DamageCause.ENTITY_ATTACK, 1.0D).isCancelled();
   }

}
