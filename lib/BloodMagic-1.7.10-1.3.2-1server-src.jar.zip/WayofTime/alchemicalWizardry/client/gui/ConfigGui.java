package WayofTime.alchemicalWizardry.client.gui;

import WayofTime.alchemicalWizardry.BloodMagicConfiguration;
import cpw.mods.fml.client.config.GuiConfig;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.common.config.ConfigElement;

public class ConfigGui extends GuiConfig {

   public ConfigGui(GuiScreen parentScreen) {
      super(parentScreen, getConfigElements(parentScreen), "AWWayofTime", false, false, "Blood Magic Configuration");
   }

   private static List getConfigElements(GuiScreen parent) {
      ArrayList list = new ArrayList();
      list.add(new ConfigElement(BloodMagicConfiguration.config.getCategory("clientsettings".toLowerCase())));
      list.add(new ConfigElement(BloodMagicConfiguration.config.getCategory("dungeon loot chances".toLowerCase())));
      list.add(new ConfigElement(BloodMagicConfiguration.config.getCategory("meteor".toLowerCase())));
      list.add(new ConfigElement(BloodMagicConfiguration.config.getCategory("orecrushing".toLowerCase())));
      list.add(new ConfigElement(BloodMagicConfiguration.config.getCategory("potion id".toLowerCase())));
      list.add(new ConfigElement(BloodMagicConfiguration.config.getCategory("wellofsufferingblacklist".toLowerCase())));
      list.add(new ConfigElement(BloodMagicConfiguration.config.getCategory("wimpysettings".toLowerCase())));
      list.add(new ConfigElement(BloodMagicConfiguration.config.getCategory("ritual blacklist".toLowerCase())));
      list.add(new ConfigElement(BloodMagicConfiguration.config.getCategory("teleposer blacklist".toLowerCase())));
      list.add(new ConfigElement(BloodMagicConfiguration.config.getCategory("demon configs".toLowerCase())));
      return list;
   }
}
