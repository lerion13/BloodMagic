package WayofTime.alchemicalWizardry.client;

import net.minecraft.client.settings.KeyBinding;

public class KeyBindings {

   public static KeyBinding omegaTest;


   public static void init() {}
}
