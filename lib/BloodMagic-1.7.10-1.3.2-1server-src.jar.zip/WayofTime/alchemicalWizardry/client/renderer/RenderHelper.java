package WayofTime.alchemicalWizardry.client.renderer;

import WayofTime.alchemicalWizardry.api.alchemy.energy.IReagentHandler;
import WayofTime.alchemicalWizardry.api.alchemy.energy.Reagent;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentContainerInfo;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentRegistry;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentStack;
import WayofTime.alchemicalWizardry.api.spell.APISpellHelper;
import WayofTime.alchemicalWizardry.client.renderer.HUDElement;
import WayofTime.alchemicalWizardry.common.items.armour.OmegaArmour;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityClientPlayerMP;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IIcon;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraftforge.common.util.ForgeDirection;
import org.lwjgl.opengl.GL11;

public class RenderHelper {

   public static boolean showEquippedItem = true;
   public static boolean enableItemName = false;
   public static boolean enabled = true;
   public static boolean showInChat = true;
   public static int lpBarX = 12;
   public static int lpBarY = 75;
   public static int zLevel = 0;
   private static int xOffsetDefault = 50;
   public static int xOffset = xOffsetDefault;
   private static int yOffsetDefault = 2;
   public static int yOffset = yOffsetDefault;
   private static int yOffsetBottomCenterDefault = 41;
   public static int yOffsetBottomCenter = yOffsetBottomCenterDefault;
   private static boolean applyXOffsetToCenterDefault = true;
   public static boolean applyXOffsetToCenter = applyXOffsetToCenterDefault;
   private static boolean applyYOffsetToMiddleDefault = false;
   public static boolean applyYOffsetToMiddle = applyYOffsetToMiddleDefault;
   public static String listMode = "horizontal";
   public static String alignMode = "bottomcenter";
   private static ScaledResolution scaledResolution;


   public static boolean onTickInGame(Minecraft mc) {
      if(enabled && (mc.inGameHasFocus || mc.currentScreen == null || mc.currentScreen instanceof GuiChat && showInChat) && !mc.gameSettings.showDebugInfo) {
         EntityClientPlayerMP player = mc.thePlayer;
         player.getEntityData();
         WorldClient world = mc.theWorld;
         if(SpellHelper.canPlayerSeeAlchemy(player)) {
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            scaledResolution = new ScaledResolution(mc, mc.displayWidth, mc.displayHeight);
            displayArmorStatus(mc);
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         }

         ItemStack stack = player.inventory.armorItemInSlot(2);
         int maxHP;
         if(stack != null && stack.getItem() instanceof OmegaArmour) {
            maxHP = (int)APISpellHelper.getPlayerMaxReagentAmount(player);
            if(maxHP > 0) {
               float val = APISpellHelper.getPlayerCurrentReagentAmount(player);
               ReagentStack reagentStack = new ReagentStack(APISpellHelper.getPlayerReagentType(player), (int)val);
               if(reagentStack != null && reagentStack.amount > 0) {
                  renderTestHUD(mc, reagentStack, maxHP);
               }
            }
         }

         if(SpellHelper.canPlayerSeeLPBar(player)) {
            maxHP = APISpellHelper.getPlayerMaxLPTag(player);
            if(maxHP > 1) {
               renderLPHUD(mc, APISpellHelper.getPlayerLPTag(player), maxHP);
            }
         }

         float maxHP1 = APISpellHelper.getCurrentAdditionalMaxHP(player);
         if(maxHP1 > 0.0F) {
            renderHPHUD(mc, APISpellHelper.getCurrentAdditionalHP(player), maxHP1);
         }
      }

      return true;
   }

   private static void renderLPHUD(Minecraft mc, int lpAmount, int maxAmount) {
      GL11.glPushMatrix();
      byte xSize = 32;
      byte ySize = 32;
      int amount = Math.max((int)(256.0D * ((double)(maxAmount - lpAmount) / (double)maxAmount)), 0);
      int x = (lpBarX - xSize / 2) * 8;
      int y = (lpBarY - ySize / 2) * 8;
      ResourceLocation test2 = new ResourceLocation("alchemicalwizardry", "textures/gui/container1.png");
      GL11.glColor4f(1.0F, 0.0F, 0.0F, 1.0F);
      mc.getTextureManager().bindTexture(test2);
      GL11.glScalef(0.125F, 0.125F, 0.125F);
      drawTexturedModalRect(x, y + amount, 0, amount, 256.0D, (double)(256 - amount));
      ResourceLocation test = new ResourceLocation("alchemicalwizardry", "textures/gui/lpVial.png");
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      mc.getTextureManager().bindTexture(test);
      drawTexturedModalRect(x, y, 0, 0, 256.0D, 256.0D);
      GL11.glPopMatrix();
   }

   private static void renderHPHUD(Minecraft mc, float hpAmount, float maxAmount) {
      GL11.glPushMatrix();
      byte xSize = 32;
      byte ySize = 32;
      int amount = Math.max((int)(256.0D * ((double)hpAmount / (double)maxAmount)), 0);
      int x = (lpBarX + 8 - xSize / 2) * 8;
      int y = (lpBarY + 32 - ySize / 2) * 8;
      ResourceLocation test2 = new ResourceLocation("alchemicalwizardry", "textures/gui/HPBar2.png");
      GL11.glColor4f(1.0F, 0.0F, 0.0F, 1.0F);
      mc.getTextureManager().bindTexture(test2);
      GL11.glScalef(0.125F, 0.125F, 0.125F);
      drawTexturedModalRect(x, y, amount, 0, (double)amount, 256.0D);
      ResourceLocation test = new ResourceLocation("alchemicalwizardry", "textures/gui/HPBar1.png");
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      mc.getTextureManager().bindTexture(test);
      drawTexturedModalRect(x, y, 0, 0, 256.0D, 256.0D);
      GL11.glPopMatrix();
   }

   private static List getHUDElements(Minecraft mc) {
      ArrayList elements = new ArrayList();
      MovingObjectPosition movingobjectposition = mc.objectMouseOver;
      WorldClient world = mc.theWorld;
      if(movingobjectposition == null) {
         return elements;
      } else {
         if(movingobjectposition.typeOfHit == MovingObjectType.BLOCK) {
            int x = movingobjectposition.blockX;
            int y = movingobjectposition.blockY;
            int z = movingobjectposition.blockZ;
            TileEntity tile = world.getTileEntity(x, y, z);
            if(!(tile instanceof IReagentHandler)) {
               return elements;
            }

            IReagentHandler relay = (IReagentHandler)tile;
            ReagentContainerInfo[] infos = relay.getContainerInfo(ForgeDirection.getOrientation(movingobjectposition.sideHit));
            if(infos != null) {
               ReagentContainerInfo[] arr$ = infos;
               int len$ = infos.length;

               for(int i$ = 0; i$ < len$; ++i$) {
                  ReagentContainerInfo info = arr$[i$];
                  if(info != null && info.reagent != null && info.reagent.reagent != null) {
                     ItemStack itemStack = ReagentRegistry.getItemForReagent(info.reagent.reagent);
                     if(itemStack != null) {
                        elements.add(new HUDElement(itemStack, 16, 16, 2, info.reagent.amount));
                     }
                  }
               }
            }
         }

         return elements;
      }
   }

   private static int getX(int width) {
      return alignMode.toLowerCase().contains("center")?scaledResolution.getScaledWidth() / 2 - width / 2 + (applyXOffsetToCenter?xOffset:0):(alignMode.toLowerCase().contains("right")?scaledResolution.getScaledWidth() - width - xOffset:xOffset);
   }

   private static int getY(int rowCount, int height) {
      return alignMode.toLowerCase().contains("middle")?scaledResolution.getScaledHeight() / 2 - rowCount * height / 2 + (applyYOffsetToMiddle?yOffset:0):(!alignMode.equalsIgnoreCase("bottomleft") && !alignMode.equalsIgnoreCase("bottomright")?(alignMode.equalsIgnoreCase("bottomcenter")?scaledResolution.getScaledHeight() - rowCount * height - yOffsetBottomCenter:yOffset):scaledResolution.getScaledHeight() - rowCount * height - yOffset);
   }

   private static int getElementsWidth(List elements) {
      int r = 0;

      HUDElement he;
      for(Iterator i$ = elements.iterator(); i$.hasNext(); r += he.width()) {
         he = (HUDElement)i$.next();
      }

      return r;
   }

   public static void drawTexturedModalRect(int p_73729_1_, int p_73729_2_, int p_73729_3_, int p_73729_4_, double p_73729_5_, double p_73729_6_) {
      float f = 0.00390625F;
      float f1 = 0.00390625F;
      Tessellator tessellator = Tessellator.instance;
      tessellator.startDrawingQuads();
      tessellator.addVertexWithUV((double)(p_73729_1_ + 0), (double)p_73729_2_ + p_73729_6_, (double)zLevel, (double)((float)(p_73729_3_ + 0) * f), (double)((float)((double)p_73729_4_ + p_73729_6_) * f1));
      tessellator.addVertexWithUV((double)p_73729_1_ + p_73729_5_, (double)p_73729_2_ + p_73729_6_, (double)zLevel, (double)((float)((double)p_73729_3_ + p_73729_5_) * f), (double)((float)((double)p_73729_4_ + p_73729_6_) * f1));
      tessellator.addVertexWithUV((double)p_73729_1_ + p_73729_5_, (double)(p_73729_2_ + 0), (double)zLevel, (double)((float)((double)p_73729_3_ + p_73729_5_) * f), (double)((float)(p_73729_4_ + 0) * f1));
      tessellator.addVertexWithUV((double)(p_73729_1_ + 0), (double)(p_73729_2_ + 0), (double)zLevel, (double)((float)(p_73729_3_ + 0) * f), (double)((float)(p_73729_4_ + 0) * f1));
      tessellator.draw();
   }

   private static void renderTestHUD(Minecraft mc, ReagentStack reagentStack, int maxAmount) {
      GL11.glPushMatrix();
      Reagent reagent = reagentStack.reagent;
      byte xSize = 32;
      byte ySize = 32;
      int amount = Math.max((int)(256.0D * ((double)(maxAmount - reagentStack.amount) / (double)maxAmount)), 0);
      int x = (lpBarX + 16 - xSize / 2) * 8;
      int y = (lpBarY - ySize / 2) * 8;
      GL11.glScalef(0.125F, 0.125F, 0.125F);
      ResourceLocation test2 = new ResourceLocation("alchemicalwizardry", "textures/gui/container1.png");
      GL11.glColor4f((float)reagent.getColourRed() / 255.0F, (float)reagent.getColourGreen() / 255.0F, (float)reagent.getColourBlue() / 255.0F, 1.0F);
      mc.getTextureManager().bindTexture(test2);
      drawTexturedModalRect(x, y + amount, 0, amount, 256.0D, (double)(256 - amount));
      ResourceLocation test = new ResourceLocation("alchemicalwizardry", "textures/gui/container.png");
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      mc.getTextureManager().bindTexture(test);
      drawTexturedModalRect(x, y, 0, 0, 256.0D, 256.0D);
      GL11.glPopMatrix();
   }

   public static void renderIcon(int p_94149_1_, int p_94149_2_, IIcon p_94149_3_, int p_94149_4_, int p_94149_5_) {
      Tessellator tessellator = Tessellator.instance;
      tessellator.startDrawingQuads();
      tessellator.addVertexWithUV((double)(p_94149_1_ + 0), (double)(p_94149_2_ + p_94149_5_), (double)zLevel, (double)p_94149_3_.getMinU(), (double)p_94149_3_.getMaxV());
      tessellator.addVertexWithUV((double)(p_94149_1_ + p_94149_4_), (double)(p_94149_2_ + p_94149_5_), (double)zLevel, (double)p_94149_3_.getMaxU(), (double)p_94149_3_.getMaxV());
      tessellator.addVertexWithUV((double)(p_94149_1_ + p_94149_4_), (double)(p_94149_2_ + 0), (double)zLevel, (double)p_94149_3_.getMaxU(), (double)p_94149_3_.getMinV());
      tessellator.addVertexWithUV((double)(p_94149_1_ + 0), (double)(p_94149_2_ + 0), (double)zLevel, (double)p_94149_3_.getMinU(), (double)p_94149_3_.getMinV());
      tessellator.draw();
   }

   private static void displayArmorStatus(Minecraft mc) {
      List elements = getHUDElements(mc);
      if(elements.size() > 0) {
         int yOffset = enableItemName?18:16;
         int totalWidth;
         if(listMode.equalsIgnoreCase("vertical")) {
            totalWidth = getY(elements.size(), yOffset);

            for(Iterator yBase = elements.iterator(); yBase.hasNext(); totalWidth += yOffset) {
               HUDElement xBase = (HUDElement)yBase.next();
               xBase.renderToHud(alignMode.toLowerCase().contains("right")?getX(0):getX(xBase.width()), totalWidth);
            }
         } else if(listMode.equalsIgnoreCase("horizontal")) {
            totalWidth = getElementsWidth(elements);
            int yBase1 = getY(1, yOffset);
            int xBase1 = getX(totalWidth);
            int prevX = 0;

            HUDElement e;
            for(Iterator i$ = elements.iterator(); i$.hasNext(); prevX += e.width()) {
               e = (HUDElement)i$.next();
               e.renderToHud(xBase1 + prevX + (alignMode.toLowerCase().contains("right")?e.width():0), yBase1);
            }
         } else if(listMode.equalsIgnoreCase("compound")) {
            ;
         }
      }

   }

}
