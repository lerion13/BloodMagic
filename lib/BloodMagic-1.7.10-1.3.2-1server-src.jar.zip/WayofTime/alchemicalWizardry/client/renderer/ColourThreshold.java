package WayofTime.alchemicalWizardry.client.renderer;

import java.util.Iterator;
import java.util.List;

public class ColourThreshold implements Comparable {

   public int threshold;
   public String colorCode;


   public ColourThreshold(int t, String c) {
      this.threshold = t;
      this.colorCode = c;
   }

   public String toString() {
      return this.threshold + ", " + this.colorCode;
   }

   public int compareTo(ColourThreshold o) {
      return this.threshold > o.threshold?1:(this.threshold < o.threshold?-1:0);
   }

   public static String getColorCode(List colorList, int value) {
      Iterator i$ = colorList.iterator();

      ColourThreshold ct;
      do {
         if(!i$.hasNext()) {
            return "f";
         }

         ct = (ColourThreshold)i$.next();
      } while(value > ct.threshold);

      return ct.colorCode;
   }
}
