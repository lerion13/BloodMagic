package WayofTime.alchemicalWizardry.client.renderer;

import WayofTime.alchemicalWizardry.BloodMagicConfiguration;
import WayofTime.alchemicalWizardry.client.renderer.ColourThreshold;
import WayofTime.alchemicalWizardry.client.renderer.HUDUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.item.ItemStack;
import org.lwjgl.opengl.GL11;

public class HUDElement {

   public final ItemStack itemStack;
   public final int iconW;
   public final int iconH;
   public final int padW;
   public final int value;
   private int elementW;
   private int elementH;
   private String itemName = "";
   private int itemNameW;
   private String itemDamage = "";
   private int itemDamageW;
   private Minecraft mc = Minecraft.getMinecraft();
   private static final int offset = 5;
   public boolean enableItemName = false;
   public boolean showValue = true;
   public boolean showDamageOverlay = false;
   public boolean showItemCount = false;
   static RenderItem itemRenderer = new RenderItem();


   public HUDElement(ItemStack itemStack, int iconW, int iconH, int padW, int value) {
      this.itemStack = itemStack;
      this.iconW = iconW;
      this.iconH = iconH;
      this.padW = padW;
      this.value = value;
      this.initSize();
   }

   public int width() {
      return this.elementW;
   }

   public int height() {
      return this.elementH;
   }

   private void initSize() {
      this.elementH = this.enableItemName?Math.max(Minecraft.getMinecraft().fontRenderer.FONT_HEIGHT * 2, this.iconH):Math.max(this.mc.fontRenderer.FONT_HEIGHT, this.iconH);
      if(this.itemStack != null) {
         boolean damage = true;
         boolean maxDamage = true;
         if(this.showValue) {
            int maxDamage1 = this.itemStack.getMaxDamage() + 1;
            int damage1 = maxDamage1 - this.itemStack.getItemDamageForDisplay();
            boolean showSpecialValue = true;
            boolean showValue = false;
            boolean showPercent = false;
            boolean showMaxDamage = true;
            boolean thresholdPercent = true;
            if(showSpecialValue) {
               this.itemDamage = "§" + ColourThreshold.getColorCode(BloodMagicConfiguration.colorList, thresholdPercent?damage1 * 100 / maxDamage1:damage1) + this.value;
            } else if(showValue) {
               this.itemDamage = "§" + ColourThreshold.getColorCode(BloodMagicConfiguration.colorList, thresholdPercent?damage1 * 100 / maxDamage1:damage1) + damage1 + (showMaxDamage?"/" + maxDamage1:"");
            } else if(showPercent) {
               this.itemDamage = "§" + ColourThreshold.getColorCode(BloodMagicConfiguration.colorList, thresholdPercent?damage1 * 100 / maxDamage1:damage1) + damage1 * 100 / maxDamage1 + "%";
            }
         }

         this.itemDamageW = this.mc.fontRenderer.getStringWidth(HUDUtils.stripCtrl(this.itemDamage));
         this.elementW = this.padW + this.iconW + this.padW + this.itemDamageW + 5;
         if(this.enableItemName) {
            this.itemName = this.itemStack.getDisplayName();
            this.elementW = this.padW + this.iconW + this.padW + Math.max(this.mc.fontRenderer.getStringWidth(HUDUtils.stripCtrl(this.itemName)), this.itemDamageW);
         }

         this.itemNameW = this.mc.fontRenderer.getStringWidth(HUDUtils.stripCtrl(this.itemName));
      }

   }

   public void renderToHud(int x, int y) {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glEnable('\u803a');
      net.minecraft.client.renderer.RenderHelper.enableStandardItemLighting();
      net.minecraft.client.renderer.RenderHelper.enableGUIStandardItemLighting();
      itemRenderer.zLevel = 200.0F;
      boolean toRight = true;
      if(toRight) {
         itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.getTextureManager(), this.itemStack, x - (this.iconW + this.padW), y);
         HUDUtils.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.itemStack, x - (this.iconW + this.padW), y, this.showDamageOverlay, this.showItemCount);
         net.minecraft.client.renderer.RenderHelper.disableStandardItemLighting();
         GL11.glDisable('\u803a');
         GL11.glDisable(3042);
         this.mc.fontRenderer.drawStringWithShadow(this.itemName + "§r", x - (this.padW + this.iconW + this.padW) - this.itemNameW, y, 16777215);
         this.mc.fontRenderer.drawStringWithShadow(this.itemDamage + "§r", x - (this.padW + this.iconW + this.padW) - this.itemDamageW, y + (this.enableItemName?this.elementH / 2:this.elementH / 4), 16777215);
      } else {
         itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.getTextureManager(), this.itemStack, x, y);
         HUDUtils.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.itemStack, x, y, this.showDamageOverlay, this.showItemCount);
         net.minecraft.client.renderer.RenderHelper.disableStandardItemLighting();
         GL11.glDisable('\u803a');
         GL11.glDisable(3042);
         this.mc.fontRenderer.drawStringWithShadow(this.itemName + "§r", x + this.iconW + this.padW, y, 16777215);
         this.mc.fontRenderer.drawStringWithShadow(this.itemDamage + "§r", x + this.iconW + this.padW, y + (this.enableItemName?this.elementH / 2:this.elementH / 4), 16777215);
      }

      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
   }

}
