package WayofTime.alchemicalWizardry.client.nei;

import WayofTime.alchemicalWizardry.api.altarRecipeRegistry.AltarRecipe;
import WayofTime.alchemicalWizardry.api.altarRecipeRegistry.AltarRecipeRegistry;
import codechicken.nei.NEIServerUtils;
import codechicken.nei.PositionedStack;
import codechicken.nei.recipe.GuiRecipe;
import codechicken.nei.recipe.TemplateRecipeHandler;
import codechicken.nei.recipe.TemplateRecipeHandler.CachedRecipe;
import codechicken.nei.recipe.TemplateRecipeHandler.RecipeTransferRect;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.StatCollector;
import org.lwjgl.input.Mouse;

public class NEIAltarRecipeHandler extends TemplateRecipeHandler {

   public void loadCraftingRecipes(String outputId, Object ... results) {
      if(outputId.equals("alchemicalwizardry.altar") && this.getClass() == NEIAltarRecipeHandler.class) {
         Iterator i$ = AltarRecipeRegistry.altarRecipes.iterator();

         while(i$.hasNext()) {
            AltarRecipe recipe = (AltarRecipe)i$.next();
            if(recipe != null && recipe.result != null) {
               this.arecipes.add(new NEIAltarRecipeHandler.CachedAltarRecipe(recipe));
            }
         }
      } else {
         super.loadCraftingRecipes(outputId, results);
      }

   }

   public void loadCraftingRecipes(ItemStack result) {
      Iterator i$ = AltarRecipeRegistry.altarRecipes.iterator();

      while(i$.hasNext()) {
         AltarRecipe recipe = (AltarRecipe)i$.next();
         if(NEIServerUtils.areStacksSameTypeCrafting(recipe.result, result) && recipe != null && recipe.result != null) {
            this.arecipes.add(new NEIAltarRecipeHandler.CachedAltarRecipe(recipe));
         }
      }

   }

   public void loadUsageRecipes(ItemStack ingredient) {
      Iterator i$ = AltarRecipeRegistry.altarRecipes.iterator();

      while(i$.hasNext()) {
         AltarRecipe recipe = (AltarRecipe)i$.next();
         if(NEIServerUtils.areStacksSameTypeCrafting(recipe.requiredItem, ingredient) && recipe != null && recipe.result != null) {
            this.arecipes.add(new NEIAltarRecipeHandler.CachedAltarRecipe(recipe));
         }
      }

   }

   public Point getMouse(int width, int height) {
      Point mousepos = getMousePosition();
      int guiLeft = (width - 176) / 2;
      int guiTop = (height - 166) / 2;
      Point relMouse = new Point(mousepos.x - guiLeft, mousepos.y - guiTop);
      return relMouse;
   }

   public int getGuiWidth(GuiRecipe gui) {
      try {
         Field e = gui.getClass().getField("width");
         return ((Integer)e.get(gui)).intValue();
      } catch (NoSuchFieldException var5) {
         try {
            Field e2 = gui.getClass().getField("field_146294_l");
            return ((Integer)e2.get(gui)).intValue();
         } catch (Exception var4) {
            return 0;
         }
      } catch (Exception var6) {
         var6.printStackTrace();
         return 0;
      }
   }

   public int getGuiHeight(GuiRecipe gui) {
      try {
         Field e = gui.getClass().getField("height");
         return ((Integer)e.get(gui)).intValue();
      } catch (NoSuchFieldException var5) {
         try {
            Field e2 = gui.getClass().getField("field_146295_m");
            return ((Integer)e2.get(gui)).intValue();
         } catch (Exception var4) {
            return 0;
         }
      } catch (Exception var6) {
         var6.printStackTrace();
         return 0;
      }
   }

   public void drawExtras(int id) {
      NEIAltarRecipeHandler.CachedAltarRecipe recipe = (NEIAltarRecipeHandler.CachedAltarRecipe)this.arecipes.get(id);
      Minecraft.getMinecraft().fontRenderer.drawString("§7" + StatCollector.translateToLocal("bm.string.tier") + ": " + recipe.tier, 78, 5, 0);
      Minecraft.getMinecraft().fontRenderer.drawString("§7LP: " + recipe.lp_amount, 78, 15, 0);
   }

   public List handleTooltip(GuiRecipe gui, List currenttip, int id) {
      currenttip = super.handleTooltip(gui, currenttip, id);
      Point mouse = this.getMouse(this.getGuiWidth(gui), this.getGuiHeight(gui));
      NEIAltarRecipeHandler.CachedAltarRecipe recipe = (NEIAltarRecipeHandler.CachedAltarRecipe)this.arecipes.get(id);
      int yLow = id % 2 == 0?38:102;
      int yHigh = id % 2 == 0?72:136;
      if(mouse.x >= 19 && mouse.x <= 80 && mouse.y >= yLow && mouse.y <= yHigh) {
         currenttip.add(StatCollector.translateToLocal("bm.string.consume") + ": " + recipe.consumption + "LP/t");
         currenttip.add(StatCollector.translateToLocal("bm.string.drain") + ": " + recipe.drain + "LP/t");
      }

      return currenttip;
   }

   public String getOverlayIdentifier() {
      return "altarrecipes";
   }

   public void loadTransferRects() {
      this.transferRects.add(new RecipeTransferRect(new Rectangle(90, 32, 22, 16), "alchemicalwizardry.altar", new Object[0]));
   }

   public String getRecipeName() {
      return "          " + StatCollector.translateToLocal("tile.bloodAltar.name");
   }

   public String getGuiTexture() {
      return (new ResourceLocation("alchemicalwizardry", "gui/nei/altar.png")).toString();
   }

   public static Point getMousePosition() {
      Dimension size = displaySize();
      Dimension res = displayRes();
      return new Point(Mouse.getX() * size.width / res.width, size.height - Mouse.getY() * size.height / res.height - 1);
   }

   public static Dimension displaySize() {
      Minecraft mc = Minecraft.getMinecraft();
      ScaledResolution res = new ScaledResolution(mc, mc.displayWidth, mc.displayHeight);
      return new Dimension(res.getScaledWidth(), res.getScaledHeight());
   }

   public static Dimension displayRes() {
      Minecraft mc = Minecraft.getMinecraft();
      return new Dimension(mc.displayWidth, mc.displayHeight);
   }

   public class CachedAltarRecipe extends CachedRecipe {

      PositionedStack input;
      PositionedStack output;
      int tier;
      int lp_amount;
      int consumption;
      int drain;


      public CachedAltarRecipe(AltarRecipe recipe) {
         super(NEIAltarRecipeHandler.this);
         this.input = new PositionedStack(recipe.requiredItem, 38, 2, false);
         this.output = new PositionedStack(recipe.result, 132, 32, false);
         this.tier = recipe.minTier;
         this.lp_amount = recipe.liquidRequired;
         this.consumption = recipe.consumptionRate;
         this.drain = recipe.drainRate;
      }

      public PositionedStack getIngredient() {
         return this.input;
      }

      public PositionedStack getResult() {
         return this.output;
      }
   }
}
