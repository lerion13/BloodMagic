package WayofTime.alchemicalWizardry.client.nei;

import WayofTime.alchemicalWizardry.api.bindingRegistry.BindingRecipe;
import WayofTime.alchemicalWizardry.api.bindingRegistry.BindingRegistry;
import codechicken.nei.NEIServerUtils;
import codechicken.nei.PositionedStack;
import codechicken.nei.recipe.TemplateRecipeHandler;
import codechicken.nei.recipe.TemplateRecipeHandler.CachedRecipe;
import codechicken.nei.recipe.TemplateRecipeHandler.RecipeTransferRect;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;

public class NEIBindingRitualHandler extends TemplateRecipeHandler {

   public void loadCraftingRecipes(String outputId, Object ... results) {
      if(outputId.equals("alchemicalwizardry.binding") && this.getClass() == NEIBindingRitualHandler.class) {
         Iterator i$ = BindingRegistry.bindingRecipes.iterator();

         while(i$.hasNext()) {
            BindingRecipe recipe = (BindingRecipe)i$.next();
            if(recipe != null && recipe.outputItem != null) {
               this.arecipes.add(new NEIBindingRitualHandler.CachedBindingRecipe(recipe));
            }
         }
      } else {
         super.loadCraftingRecipes(outputId, results);
      }

   }

   public void loadCraftingRecipes(ItemStack result) {
      Iterator i$ = BindingRegistry.bindingRecipes.iterator();

      while(i$.hasNext()) {
         BindingRecipe recipe = (BindingRecipe)i$.next();
         if(NEIServerUtils.areStacksSameTypeCrafting(recipe.outputItem, result) && recipe != null && recipe.outputItem != null) {
            this.arecipes.add(new NEIBindingRitualHandler.CachedBindingRecipe(recipe));
         }
      }

   }

   public void loadUsageRecipes(ItemStack ingredient) {
      Iterator i$ = BindingRegistry.bindingRecipes.iterator();

      while(i$.hasNext()) {
         BindingRecipe recipe = (BindingRecipe)i$.next();
         if(NEIServerUtils.areStacksSameTypeCrafting(recipe.requiredItem, ingredient) && recipe != null && recipe.outputItem != null) {
            this.arecipes.add(new NEIBindingRitualHandler.CachedBindingRecipe(recipe));
         }
      }

   }

   public String getOverlayIdentifier() {
      return "bindingritual";
   }

   public void loadTransferRects() {
      this.transferRects.add(new RecipeTransferRect(new Rectangle(90, 32, 22, 16), "alchemicalwizardry.bindingritual", new Object[0]));
   }

   public String getRecipeName() {
      return "Binding Ritual";
   }

   public String getGuiTexture() {
      return (new ResourceLocation("alchemicalwizardry", "gui/nei/bindingRitual.png")).toString();
   }

   public static Point getMousePosition() {
      Dimension size = displaySize();
      Dimension res = displayRes();
      return new Point(Mouse.getX() * size.width / res.width, size.height - Mouse.getY() * size.height / res.height - 1);
   }

   public static Dimension displaySize() {
      Minecraft mc = Minecraft.getMinecraft();
      ScaledResolution res = new ScaledResolution(mc, mc.displayWidth, mc.displayHeight);
      return new Dimension(res.getScaledWidth(), res.getScaledHeight());
   }

   public static Dimension displayRes() {
      Minecraft mc = Minecraft.getMinecraft();
      return new Dimension(mc.displayWidth, mc.displayHeight);
   }

   public class CachedBindingRecipe extends CachedRecipe {

      PositionedStack input;
      PositionedStack output;


      public CachedBindingRecipe(BindingRecipe recipe) {
         super(NEIBindingRitualHandler.this);
         this.input = new PositionedStack(recipe.requiredItem, 37, 21, false);
         this.output = new PositionedStack(recipe.outputItem, 110, 21, false);
      }

      public PositionedStack getIngredient() {
         return this.input;
      }

      public PositionedStack getResult() {
         return this.output;
      }
   }
}
