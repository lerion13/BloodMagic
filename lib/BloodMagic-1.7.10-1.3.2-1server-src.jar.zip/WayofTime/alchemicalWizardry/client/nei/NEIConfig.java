package WayofTime.alchemicalWizardry.client.nei;

import WayofTime.alchemicalWizardry.client.nei.NEIAlchemyRecipeHandler;
import WayofTime.alchemicalWizardry.client.nei.NEIAltarRecipeHandler;
import WayofTime.alchemicalWizardry.client.nei.NEIBindingRitualHandler;
import WayofTime.alchemicalWizardry.client.nei.NEIBloodOrbShapedHandler;
import WayofTime.alchemicalWizardry.client.nei.NEIBloodOrbShapelessHandler;
import codechicken.nei.api.API;
import codechicken.nei.api.IConfigureNEI;
import java.util.ArrayList;

public class NEIConfig implements IConfigureNEI {

   public static ArrayList bloodOrbs = new ArrayList();


   public void loadConfig() {
      API.registerRecipeHandler(new NEIAlchemyRecipeHandler());
      API.registerUsageHandler(new NEIAlchemyRecipeHandler());
      API.registerRecipeHandler(new NEIAltarRecipeHandler());
      API.registerUsageHandler(new NEIAltarRecipeHandler());
      API.registerRecipeHandler(new NEIBloodOrbShapedHandler());
      API.registerUsageHandler(new NEIBloodOrbShapedHandler());
      API.registerRecipeHandler(new NEIBloodOrbShapelessHandler());
      API.registerUsageHandler(new NEIBloodOrbShapelessHandler());
      API.registerRecipeHandler(new NEIBindingRitualHandler());
      API.registerUsageHandler(new NEIBindingRitualHandler());
   }

   public String getName() {
      return "Blood Magic NEI";
   }

   public String getVersion() {
      return "1.3";
   }

}
