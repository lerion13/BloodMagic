package WayofTime.alchemicalWizardry.client.nei;

import WayofTime.alchemicalWizardry.api.items.ShapelessBloodOrbRecipe;
import WayofTime.alchemicalWizardry.api.items.interfaces.IBloodOrb;
import WayofTime.alchemicalWizardry.client.nei.NEIConfig;
import codechicken.nei.NEIServerUtils;
import codechicken.nei.PositionedStack;
import codechicken.nei.recipe.ShapelessRecipeHandler;
import codechicken.nei.recipe.ShapelessRecipeHandler.CachedShapelessRecipe;
import codechicken.nei.recipe.TemplateRecipeHandler.RecipeTransferRect;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.util.StatCollector;

public class NEIBloodOrbShapelessHandler extends ShapelessRecipeHandler {

   public void loadCraftingRecipes(String outputId, Object ... results) {
      if(outputId.equals("crafting") && this.getClass() == NEIBloodOrbShapelessHandler.class) {
         List allrecipes = CraftingManager.getInstance().getRecipeList();
         Iterator i$ = allrecipes.iterator();

         while(i$.hasNext()) {
            IRecipe irecipe = (IRecipe)i$.next();
            NEIBloodOrbShapelessHandler.CachedBloodOrbRecipe recipe = null;
            if(irecipe instanceof ShapelessBloodOrbRecipe) {
               recipe = this.forgeShapelessRecipe((ShapelessBloodOrbRecipe)irecipe);
            }

            if(recipe != null) {
               this.arecipes.add(recipe);
            }
         }
      } else {
         super.loadCraftingRecipes(outputId, results);
      }

   }

   public void loadCraftingRecipes(ItemStack result) {
      List allrecipes = CraftingManager.getInstance().getRecipeList();
      Iterator i$ = allrecipes.iterator();

      while(i$.hasNext()) {
         IRecipe irecipe = (IRecipe)i$.next();
         if(NEIServerUtils.areStacksSameTypeCrafting(irecipe.getRecipeOutput(), result)) {
            NEIBloodOrbShapelessHandler.CachedBloodOrbRecipe recipe = null;
            if(irecipe instanceof ShapelessBloodOrbRecipe) {
               recipe = this.forgeShapelessRecipe((ShapelessBloodOrbRecipe)irecipe);
            }

            if(recipe != null) {
               this.arecipes.add(recipe);
            }
         }
      }

   }

   public void loadUsageRecipes(ItemStack ingredient) {
      List allrecipes = CraftingManager.getInstance().getRecipeList();
      Iterator i$ = allrecipes.iterator();

      while(i$.hasNext()) {
         IRecipe irecipe = (IRecipe)i$.next();
         NEIBloodOrbShapelessHandler.CachedBloodOrbRecipe recipe = null;
         if(irecipe instanceof ShapelessBloodOrbRecipe) {
            recipe = this.forgeShapelessRecipe((ShapelessBloodOrbRecipe)irecipe);
         }

         if(recipe != null && recipe.contains(recipe.ingredients, ingredient)) {
            recipe.setIngredientPermutation(recipe.ingredients, ingredient);
            this.arecipes.add(recipe);
         }
      }

   }

   public NEIBloodOrbShapelessHandler.CachedBloodOrbRecipe forgeShapelessRecipe(ShapelessBloodOrbRecipe recipe) {
      ArrayList items = recipe.getInput();
      Iterator i$ = items.iterator();

      Object item;
      do {
         if(!i$.hasNext()) {
            return new NEIBloodOrbShapelessHandler.CachedBloodOrbRecipe(items, recipe.getRecipeOutput());
         }

         item = i$.next();
      } while(!(item instanceof List) || !((List)item).isEmpty());

      return null;
   }

   public void loadTransferRects() {
      this.transferRects.add(new RecipeTransferRect(new Rectangle(84, 23, 24, 18), "crafting", new Object[0]));
   }

   public String getOverlayIdentifier() {
      return "crafting";
   }

   public String getRecipeName() {
      return StatCollector.translateToLocal("bm.string.crafting.orb.shapeless");
   }

   public class CachedBloodOrbRecipe extends CachedShapelessRecipe {

      public CachedBloodOrbRecipe(ArrayList items, ItemStack recipeOutput) {
         super(NEIBloodOrbShapelessHandler.this, items, recipeOutput);
      }

      public void setIngredients(List items) {
         this.ingredients.clear();

         for(int ingred = 0; ingred < items.size(); ++ingred) {
            Object o = items.get(ingred);
            if(o instanceof ItemStack) {
               PositionedStack orbs = new PositionedStack(items.get(ingred), 25 + NEIBloodOrbShapelessHandler.this.stackorder[ingred][0] * 18, 6 + NEIBloodOrbShapelessHandler.this.stackorder[ingred][1] * 18);
               orbs.setMaxSize(1);
               this.ingredients.add(orbs);
            } else if(o instanceof Integer) {
               ArrayList var7 = new ArrayList();
               Iterator stack = NEIConfig.bloodOrbs.iterator();

               while(stack.hasNext()) {
                  Item item = (Item)stack.next();
                  if(((IBloodOrb)item).getOrbLevel() >= ((Integer)o).intValue()) {
                     var7.add(new ItemStack(item));
                  }
               }

               PositionedStack var8 = new PositionedStack(var7, 25 + NEIBloodOrbShapelessHandler.this.stackorder[ingred][0] * 18, 6 + NEIBloodOrbShapelessHandler.this.stackorder[ingred][1] * 18);
               var8.setMaxSize(1);
               this.ingredients.add(var8);
            }
         }

      }
   }
}
