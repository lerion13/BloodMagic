package WayofTime.alchemicalWizardry.client.nei;

import WayofTime.alchemicalWizardry.api.alchemy.AlchemyRecipe;
import WayofTime.alchemicalWizardry.api.alchemy.AlchemyRecipeRegistry;
import WayofTime.alchemicalWizardry.api.items.interfaces.IBloodOrb;
import WayofTime.alchemicalWizardry.client.nei.NEIConfig;
import WayofTime.alchemicalWizardry.common.tileEntity.gui.GuiWritingTable;
import codechicken.nei.ItemList;
import codechicken.nei.NEIServerUtils;
import codechicken.nei.PositionedStack;
import codechicken.nei.recipe.TemplateRecipeHandler;
import codechicken.nei.recipe.TemplateRecipeHandler.CachedRecipe;
import codechicken.nei.recipe.TemplateRecipeHandler.RecipeTransferRect;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.StatCollector;

public class NEIAlchemyRecipeHandler extends TemplateRecipeHandler {

   public TemplateRecipeHandler newInstance() {
      Iterator i$ = ItemList.items.iterator();

      while(i$.hasNext()) {
         ItemStack item = (ItemStack)i$.next();
         if(item != null && item.getItem() instanceof IBloodOrb) {
            NEIConfig.bloodOrbs.add(item.getItem());
         }
      }

      return super.newInstance();
   }

   public String getOverlayIdentifier() {
      return "alchemicalwizardry.alchemy";
   }

   public void loadTransferRects() {
      this.transferRects.add(new RecipeTransferRect(new Rectangle(134, 22, 16, 24), "alchemicalwizardry.alchemy", new Object[0]));
   }

   public Class getGuiClass() {
      return GuiWritingTable.class;
   }

   public void loadCraftingRecipes(String outputId, Object ... results) {
      if(outputId.equals("alchemicalwizardry.alchemy") && this.getClass() == NEIAlchemyRecipeHandler.class) {
         Iterator i$ = AlchemyRecipeRegistry.recipes.iterator();

         while(i$.hasNext()) {
            AlchemyRecipe recipe = (AlchemyRecipe)i$.next();
            if(recipe.getResult() != null) {
               this.arecipes.add(new NEIAlchemyRecipeHandler.CachedAlchemyRecipe(recipe));
            }
         }
      } else {
         super.loadCraftingRecipes(outputId, results);
      }

   }

   public void loadCraftingRecipes(ItemStack result) {
      Iterator i$ = AlchemyRecipeRegistry.recipes.iterator();

      while(i$.hasNext()) {
         AlchemyRecipe recipe = (AlchemyRecipe)i$.next();
         if(recipe != null) {
            ItemStack output = recipe.getResult();
            if(NEIServerUtils.areStacksSameTypeCrafting(result, recipe.getResult())) {
               this.arecipes.add(new NEIAlchemyRecipeHandler.CachedAlchemyRecipe(recipe));
            }
         }
      }

   }

   public void loadUsageRecipes(ItemStack ingredient) {
      Iterator i$;
      AlchemyRecipe recipe;
      if(ingredient.getItem() instanceof IBloodOrb) {
         i$ = AlchemyRecipeRegistry.recipes.iterator();

         while(i$.hasNext()) {
            recipe = (AlchemyRecipe)i$.next();
            if(recipe != null && ((IBloodOrb)ingredient.getItem()).getOrbLevel() >= recipe.getOrbLevel()) {
               this.arecipes.add(new NEIAlchemyRecipeHandler.CachedAlchemyRecipe(recipe, ingredient));
            }
         }
      } else {
         i$ = AlchemyRecipeRegistry.recipes.iterator();

         while(i$.hasNext()) {
            recipe = (AlchemyRecipe)i$.next();
            if(recipe != null) {
               ItemStack[] stacks = recipe.getRecipe();
               ItemStack[] arr$ = stacks;
               int len$ = stacks.length;

               for(int i$1 = 0; i$1 < len$; ++i$1) {
                  ItemStack stack = arr$[i$1];
                  if(NEIServerUtils.areStacksSameTypeCrafting(stack, ingredient)) {
                     this.arecipes.add(new NEIAlchemyRecipeHandler.CachedAlchemyRecipe(recipe));
                     break;
                  }
               }
            }
         }
      }

   }

   public void drawExtras(int id) {
      NEIAlchemyRecipeHandler.CachedAlchemyRecipe cache = (NEIAlchemyRecipeHandler.CachedAlchemyRecipe)this.arecipes.get(id);
      Minecraft.getMinecraft().fontRenderer.drawString("§7" + cache.lp + "LP", this.getLPX(cache.lp), 34, 0);
   }

   public int getLPX(int lp) {
      return lp < 10?122:(lp < 100?122:(lp < 1000?130:(lp < 10000?127:(lp < 100000?124:122))));
   }

   public String getRecipeName() {
      return StatCollector.translateToLocal("tile.blockWritingTable.name");
   }

   public String getGuiTexture() {
      return (new ResourceLocation("alchemicalwizardry", "gui/nei/alchemy.png")).toString();
   }

   public class CachedAlchemyRecipe extends CachedRecipe {

      ArrayList orbs;
      PositionedStack output;
      List inputs;
      int lp;


      public CachedAlchemyRecipe(AlchemyRecipe recipe, ItemStack orb) {
         this(recipe);
         this.orbs = new ArrayList();
         this.orbs.add(new NEIAlchemyRecipeHandler.CachedAlchemyRecipe.BloodOrbs(orb));
      }

      public CachedAlchemyRecipe(AlchemyRecipe recipe) {
         super(NEIAlchemyRecipeHandler.this);
         ArrayList inputs = new ArrayList();
         ItemStack[] stacks = recipe.getRecipe();
         if(stacks.length > 0) {
            inputs.add(new PositionedStack(stacks[0], 76, 3));
         }

         if(stacks.length > 1) {
            inputs.add(new PositionedStack(stacks[1], 51, 19));
         }

         if(stacks.length > 2) {
            inputs.add(new PositionedStack(stacks[2], 101, 19));
         }

         if(stacks.length > 3) {
            inputs.add(new PositionedStack(stacks[3], 64, 47));
         }

         if(stacks.length > 4) {
            inputs.add(new PositionedStack(stacks[4], 88, 47));
         }

         this.inputs = inputs;
         this.output = new PositionedStack(recipe.getResult(), 76, 25);
         this.lp = recipe.getAmountNeeded() * 100;
         this.orbs = new ArrayList();
         Iterator i$ = NEIConfig.bloodOrbs.iterator();

         while(i$.hasNext()) {
            Item orb = (Item)i$.next();
            if(((IBloodOrb)orb).getOrbLevel() >= recipe.getOrbLevel()) {
               this.orbs.add(new NEIAlchemyRecipeHandler.CachedAlchemyRecipe.BloodOrbs(new ItemStack(orb)));
            }
         }

      }

      public List getIngredients() {
         return this.inputs;
      }

      public PositionedStack getResult() {
         return this.output;
      }

      public PositionedStack getOtherStack() {
         return this.orbs != null && this.orbs.size() > 0?((NEIAlchemyRecipeHandler.CachedAlchemyRecipe.BloodOrbs)this.orbs.get(NEIAlchemyRecipeHandler.this.cycleticks / 48 % this.orbs.size())).stack:null;
      }

      public class BloodOrbs {

         public PositionedStack stack;


         public BloodOrbs(ItemStack orb) {
            this.stack = new PositionedStack(orb, 136, 47, false);
         }
      }
   }
}
