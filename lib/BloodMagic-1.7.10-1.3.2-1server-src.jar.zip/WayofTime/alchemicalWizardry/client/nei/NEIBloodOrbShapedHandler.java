package WayofTime.alchemicalWizardry.client.nei;

import WayofTime.alchemicalWizardry.api.items.ShapedBloodOrbRecipe;
import WayofTime.alchemicalWizardry.api.items.interfaces.IBloodOrb;
import WayofTime.alchemicalWizardry.client.nei.NEIConfig;
import codechicken.nei.NEIServerUtils;
import codechicken.nei.PositionedStack;
import codechicken.nei.recipe.ShapedRecipeHandler;
import codechicken.nei.recipe.ShapedRecipeHandler.CachedShapedRecipe;
import codechicken.nei.recipe.TemplateRecipeHandler.RecipeTransferRect;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.util.StatCollector;

public class NEIBloodOrbShapedHandler extends ShapedRecipeHandler {

   public void loadCraftingRecipes(String outputId, Object ... results) {
      if(outputId.equals("crafting") && this.getClass() == NEIBloodOrbShapedHandler.class) {
         Iterator i$ = CraftingManager.getInstance().getRecipeList().iterator();

         while(i$.hasNext()) {
            IRecipe irecipe = (IRecipe)i$.next();
            if(irecipe instanceof ShapedBloodOrbRecipe) {
               NEIBloodOrbShapedHandler.CachedBloodOrbRecipe recipe = this.forgeShapedRecipe((ShapedBloodOrbRecipe)irecipe);
               if(recipe != null) {
                  recipe.computeVisuals();
                  this.arecipes.add(recipe);
               }
            }
         }
      } else {
         super.loadCraftingRecipes(outputId, results);
      }

   }

   public void loadCraftingRecipes(ItemStack result) {
      Iterator i$ = CraftingManager.getInstance().getRecipeList().iterator();

      while(i$.hasNext()) {
         IRecipe irecipe = (IRecipe)i$.next();
         if(irecipe instanceof ShapedBloodOrbRecipe) {
            NEIBloodOrbShapedHandler.CachedBloodOrbRecipe recipe = this.forgeShapedRecipe((ShapedBloodOrbRecipe)irecipe);
            if(recipe != null && NEIServerUtils.areStacksSameTypeCrafting(recipe.result.item, result)) {
               recipe.computeVisuals();
               this.arecipes.add(recipe);
            }
         }
      }

   }

   public void loadUsageRecipes(ItemStack ingredient) {
      Iterator i$ = CraftingManager.getInstance().getRecipeList().iterator();

      while(i$.hasNext()) {
         IRecipe irecipe = (IRecipe)i$.next();
         NEIBloodOrbShapedHandler.CachedBloodOrbRecipe recipe = null;
         if(irecipe instanceof ShapedBloodOrbRecipe) {
            recipe = this.forgeShapedRecipe((ShapedBloodOrbRecipe)irecipe);
         }

         if(recipe != null && recipe.contains(recipe.ingredients, ingredient.getItem())) {
            recipe.computeVisuals();
            if(recipe.contains(recipe.ingredients, ingredient)) {
               recipe.setIngredientPermutation(recipe.ingredients, ingredient);
               this.arecipes.add(recipe);
            }
         }
      }

   }

   private NEIBloodOrbShapedHandler.CachedBloodOrbRecipe forgeShapedRecipe(ShapedBloodOrbRecipe recipe) {
      int width;
      int height;
      try {
         width = recipe.width;
         height = recipe.height;
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }

      Object[] items = recipe.getInput();
      Object[] arr$ = items;
      int len$ = items.length;

      for(int i$ = 0; i$ < len$; ++i$) {
         Object item = arr$[i$];
         if(item instanceof List && ((List)item).isEmpty()) {
            return null;
         }
      }

      return new NEIBloodOrbShapedHandler.CachedBloodOrbRecipe(width, height, items, recipe.getRecipeOutput());
   }

   public void loadTransferRects() {
      this.transferRects.add(new RecipeTransferRect(new Rectangle(84, 23, 24, 18), "crafting", new Object[0]));
   }

   public String getRecipeName() {
      return StatCollector.translateToLocal("bm.string.crafting.orb.shaped");
   }

   public class CachedBloodOrbRecipe extends CachedShapedRecipe {

      public CachedBloodOrbRecipe(int width, int height, Object[] items, ItemStack out) {
         super(NEIBloodOrbShapedHandler.this, width, height, items, out);
      }

      public void setIngredients(int width, int height, Object[] items) {
         for(int x = 0; x < width; ++x) {
            for(int y = 0; y < height; ++y) {
               if(items[y * width + x] != null) {
                  Object o = items[y * width + x];
                  if(o instanceof ItemStack) {
                     PositionedStack var10 = new PositionedStack(items[y * width + x], 25 + x * 18, 6 + y * 18, false);
                     var10.setMaxSize(1);
                     this.ingredients.add(var10);
                  } else if(o instanceof Integer) {
                     ArrayList orbs = new ArrayList();
                     Iterator stack = NEIConfig.bloodOrbs.iterator();

                     while(stack.hasNext()) {
                        Item item = (Item)stack.next();
                        if(((IBloodOrb)item).getOrbLevel() >= ((Integer)o).intValue()) {
                           orbs.add(new ItemStack(item));
                        }
                     }

                     PositionedStack var11 = new PositionedStack(orbs, 25 + x * 18, 6 + y * 18, false);
                     var11.setMaxSize(1);
                     this.ingredients.add(var11);
                  }
               }
            }
         }

      }
   }
}
