package WayofTime.alchemicalWizardry.client;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.ModBlocks;
import WayofTime.alchemicalWizardry.client.renderer.RenderHelper;
import cpw.mods.fml.client.FMLClientHandler;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.eventhandler.Event.Result;
import cpw.mods.fml.common.gameevent.InputEvent.KeyInputEvent;
import cpw.mods.fml.common.gameevent.TickEvent.Phase;
import cpw.mods.fml.common.gameevent.TickEvent.RenderTickEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityClientPlayerMP;
import net.minecraftforge.client.event.RenderBlockOverlayEvent;
import net.minecraftforge.client.event.RenderBlockOverlayEvent.OverlayType;
import net.minecraftforge.client.event.sound.SoundEvent;

public class ClientEventHandler {

   private Minecraft mcClient = FMLClientHandler.instance().getClient();


   @SubscribeEvent
   public void onKeyInput(KeyInputEvent event) {}

   @SubscribeEvent
   public void onPlayerSoundEvent(SoundEvent event) {
      if(Minecraft.getMinecraft() != null) {
         EntityClientPlayerMP player = Minecraft.getMinecraft().thePlayer;
         if(player != null && player.isPotionActive(AlchemicalWizardry.customPotionDeaf)) {
            event.setResult(Result.DENY);
            if(event.isCancelable()) {
               event.setCanceled(true);
            }
         }
      }

   }

   @SubscribeEvent
   public void onOverlayEvent(RenderBlockOverlayEvent event) {
      if(event.overlayType == OverlayType.WATER && event.player.isPotionActive(AlchemicalWizardry.customPotionAmphibian.id) && event.isCancelable()) {
         event.setCanceled(true);
      }

      if(event.blockForOverlay == ModBlocks.blockMimic && event.isCancelable()) {
         event.setCanceled(true);
      }

   }

   @SubscribeEvent
   public void onTick(RenderTickEvent event) {
      if(!event.phase.equals(Phase.START)) {
         if(!RenderHelper.onTickInGame(this.mcClient)) {
            ;
         }

      }
   }
}
