package WayofTime.alchemicalWizardry.common.entity.mob;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.ModItems;
import WayofTime.alchemicalWizardry.common.EntityAITargetAggro;
import WayofTime.alchemicalWizardry.common.entity.mob.EntityDemon;
import WayofTime.alchemicalWizardry.common.entity.projectile.FireProjectile;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IRangedAttackMob;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIArrowAttack;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIFollowOwner;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIOwnerHurtByTarget;
import net.minecraft.entity.ai.EntityAIOwnerHurtTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.pathfinding.PathEntity;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class EntityWingedFireDemon extends EntityDemon implements IRangedAttackMob {

   private EntityAIArrowAttack aiArrowAttack = new EntityAIArrowAttack(this, 1.0D, 40, 40, 15.0F);
   private EntityAIAttackOnCollide aiAttackOnCollide = new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.2D, false);
   private static float maxTamedHealth = 100.0F;
   private static float maxUntamedHealth = 200.0F;


   public EntityWingedFireDemon(World par1World) {
      super(par1World, AlchemicalWizardry.entityWingedFireDemonID);
      this.setSize(0.7F, 1.8F);
      this.getNavigator().setAvoidsWater(true);
      super.tasks.addTask(1, new EntityAISwimming(this));
      super.tasks.addTask(2, super.aiSit);
      super.tasks.addTask(3, new EntityAIFollowOwner(this, 1.0D, 10.0F, 2.0F));
      super.tasks.addTask(4, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(5, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(6, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIOwnerHurtByTarget(this));
      super.targetTasks.addTask(2, new EntityAIOwnerHurtTarget(this));
      super.targetTasks.addTask(3, new EntityAIHurtByTarget(this, true));
      super.targetTasks.addTask(4, new EntityAITargetAggro(this, EntityPlayer.class, 0, false));
      this.setAggro(false);
      this.setTamed(false);
      if(par1World != null && !par1World.isRemote) {
         this.setCombatTask();
      }

      super.isImmuneToFire = true;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.30000001192092896D);
      if(this.isTamed()) {
         this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue((double)maxTamedHealth);
      } else {
         this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue((double)maxUntamedHealth);
      }

   }

   public boolean isAIEnabled() {
      return true;
   }

   public void setAttackTarget(EntityLivingBase par1EntityLivingBase) {
      super.setAttackTarget(par1EntityLivingBase);
      if(par1EntityLivingBase == null) {
         this.setAngry(false);
      } else if(!this.isTamed()) {
         this.setAngry(true);
      }

   }

   protected void updateAITick() {
      super.dataWatcher.updateObject(18, Float.valueOf(this.getHealth()));
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(18, new Float(this.getHealth()));
      super.dataWatcher.addObject(19, new Byte((byte)0));
   }

   protected void playStepSound(int par1, int par2, int par3, int par4) {
      this.playSound("mob.zombie.step", 0.15F, 1.0F);
   }

   public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
      super.writeEntityToNBT(par1NBTTagCompound);
      par1NBTTagCompound.setBoolean("Angry", this.isAngry());
   }

   public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
      super.readEntityFromNBT(par1NBTTagCompound);
      this.setAngry(par1NBTTagCompound.getBoolean("Angry"));
      this.setCombatTask();
   }

   protected String getLivingSound() {
      return "mob.blaze.breathe";
   }

   protected String getHurtSound() {
      return "mob.blaze.hit";
   }

   protected String getDeathSound() {
      return "mob.blaze.death";
   }

   protected float getSoundVolume() {
      return 0.4F;
   }

   protected int getDropItemId() {
      return -1;
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
   }

   public void onUpdate() {
      super.onUpdate();
   }

   public float getEyeHeight() {
      return super.height * 0.8F;
   }

   public int getVerticalFaceSpeed() {
      return this.isSitting()?20:super.getVerticalFaceSpeed();
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, float par2) {
      if(this.isEntityInvulnerable()) {
         return false;
      } else {
         Entity entity = par1DamageSource.getEntity();
         super.aiSit.setSitting(false);
         if(entity != null && !(entity instanceof EntityPlayer) && !(entity instanceof EntityArrow)) {
            par2 = (par2 + 1.0F) / 2.0F;
         }

         return super.attackEntityFrom(par1DamageSource, par2);
      }
   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      int i = this.isTamed()?4:2;
      return par1Entity.attackEntityFrom(DamageSource.causeMobDamage(this), (float)i);
   }

   public void setTamed(boolean par1) {
      super.setTamed(par1);
      if(par1) {
         this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue((double)maxTamedHealth);
      } else {
         this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue((double)maxUntamedHealth);
      }

   }

   public boolean interact(EntityPlayer par1EntityPlayer) {
      ItemStack itemstack = par1EntityPlayer.inventory.getCurrentItem();
      if(this.isTamed()) {
         if(itemstack != null && itemstack.getItem() instanceof ItemFood) {
            ItemFood itemfood = (ItemFood)itemstack.getItem();
            if(itemfood.isWolfsFavoriteMeat() && super.dataWatcher.getWatchableObjectFloat(18) < maxTamedHealth) {
               if(!par1EntityPlayer.capabilities.isCreativeMode) {
                  --itemstack.stackSize;
               }

               this.heal((float)itemfood.func_150905_g(itemstack));
               if(itemstack.stackSize <= 0) {
                  par1EntityPlayer.inventory.setInventorySlotContents(par1EntityPlayer.inventory.currentItem, (ItemStack)null);
               }

               return true;
            }
         }

         if(this.getOwner() instanceof EntityPlayer && SpellHelper.getUsername(par1EntityPlayer).equalsIgnoreCase(SpellHelper.getUsername((EntityPlayer)this.getOwner())) && !this.isBreedingItem(itemstack)) {
            if(!super.worldObj.isRemote) {
               super.aiSit.setSitting(!this.isSitting());
               super.isJumping = false;
               this.setPathToEntity((PathEntity)null);
               this.setTarget((Entity)null);
               this.setAttackTarget((EntityLivingBase)null);
            }

            this.sendSittingMessageToPlayer(par1EntityPlayer, !this.isSitting());
         }
      } else if(itemstack != null && itemstack.getItem().equals(ModItems.weakBloodOrb) && !this.isAngry()) {
         if(!par1EntityPlayer.capabilities.isCreativeMode) {
            --itemstack.stackSize;
         }

         if(itemstack.stackSize <= 0) {
            par1EntityPlayer.inventory.setInventorySlotContents(par1EntityPlayer.inventory.currentItem, (ItemStack)null);
         }

         if(!super.worldObj.isRemote) {
            if(super.rand.nextInt(1) == 0) {
               this.setTamed(true);
               this.setPathToEntity((PathEntity)null);
               this.setAttackTarget((EntityLivingBase)null);
               super.aiSit.setSitting(true);
               this.setHealth(maxTamedHealth);
               this.func_152115_b(par1EntityPlayer.getUniqueID().toString());
               this.playTameEffect(true);
               super.worldObj.setEntityState(this, (byte)7);
            } else {
               this.playTameEffect(false);
               super.worldObj.setEntityState(this, (byte)6);
            }
         }

         return true;
      }

      return super.interact(par1EntityPlayer);
   }

   public boolean isBreedingItem(ItemStack par1ItemStack) {
      return false;
   }

   public boolean isAngry() {
      return (super.dataWatcher.getWatchableObjectByte(16) & 2) != 0;
   }

   public void setAngry(boolean par1) {
      byte b0 = super.dataWatcher.getWatchableObjectByte(16);
      if(par1) {
         super.dataWatcher.updateObject(16, Byte.valueOf((byte)(b0 | 2)));
      } else {
         super.dataWatcher.updateObject(16, Byte.valueOf((byte)(b0 & -3)));
      }

   }

   public int getCollarColor() {
      return super.dataWatcher.getWatchableObjectByte(20) & 15;
   }

   public void setCollarColor(int par1) {
      super.dataWatcher.updateObject(20, Byte.valueOf((byte)(par1 & 15)));
   }

   public EntityWolf spawnBabyAnimal(EntityAgeable par1EntityAgeable) {
      return null;
   }

   public void func_70918_i(boolean par1) {
      if(par1) {
         super.dataWatcher.updateObject(19, Byte.valueOf((byte)1));
      } else {
         super.dataWatcher.updateObject(19, Byte.valueOf((byte)0));
      }

   }

   public boolean canMateWith(EntityAnimal par1EntityAnimal) {
      return false;
   }

   public boolean func_70922_bv() {
      return super.dataWatcher.getWatchableObjectByte(19) == 1;
   }

   protected boolean canDespawn() {
      return false;
   }

   public boolean func_142018_a(EntityLivingBase par1EntityLivingBase, EntityLivingBase par2EntityLivingBase) {
      if(!(par1EntityLivingBase instanceof EntityCreeper) && !(par1EntityLivingBase instanceof EntityGhast)) {
         if(par1EntityLivingBase instanceof EntityWingedFireDemon) {
            EntityWingedFireDemon entitywolf = (EntityWingedFireDemon)par1EntityLivingBase;
            if(entitywolf.isTamed() && entitywolf.getOwner() == par2EntityLivingBase) {
               return false;
            }
         }

         return par1EntityLivingBase instanceof EntityPlayer && par2EntityLivingBase instanceof EntityPlayer && !((EntityPlayer)par2EntityLivingBase).canAttackPlayer((EntityPlayer)par1EntityLivingBase)?false:!(par1EntityLivingBase instanceof EntityHorse) || !((EntityHorse)par1EntityLivingBase).isTame();
      } else {
         return false;
      }
   }

   public EntityAgeable createChild(EntityAgeable par1EntityAgeable) {
      return this.spawnBabyAnimal(par1EntityAgeable);
   }

   public void attackEntityWithRangedAttack(EntityLivingBase par1EntityLivingBase, float par2) {
      super.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1009, (int)super.posX, (int)super.posY, (int)super.posZ, 0);
      FireProjectile hol = new FireProjectile(super.worldObj, this, par1EntityLivingBase, 1.8F, 0.0F, 20, 600);
      super.worldObj.spawnEntityInWorld(hol);
   }

   public void setCombatTask() {
      super.tasks.removeTask(this.aiAttackOnCollide);
      super.tasks.removeTask(this.aiArrowAttack);
      ItemStack itemstack = this.getHeldItem();
      super.tasks.addTask(4, this.aiArrowAttack);
   }

}
