package WayofTime.alchemicalWizardry.common.entity.mob;

import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class BookEntityItem extends EntityItem {

   public BookEntityItem(World par1World, double par2, double par4, double par6) {
      super(par1World, par2, par4, par6);
      super.isImmuneToFire = true;
      super.lifespan = 72000;
   }

   public BookEntityItem(World par1World, double par2, double par4, double par6, ItemStack par8ItemStack) {
      this(par1World, par2, par4, par6);
      this.setEntityItemStack(par8ItemStack);
      super.lifespan = par8ItemStack.getItem() == null?6000:par8ItemStack.getItem().getEntityLifespan(par8ItemStack, par1World);
      super.isImmuneToFire = true;
   }

   public BookEntityItem(World world, Entity original, ItemStack stack) {
      this(world, original.posX, original.posY, original.posZ);
      super.delayBeforeCanPickup = 20;
      super.motionX = original.motionX;
      super.motionY = original.motionY;
      super.motionZ = original.motionZ;
      this.setEntityItemStack(stack);
      super.isImmuneToFire = true;
   }

   public BookEntityItem(World par1world) {
      super(par1world);
   }

   public void onUpdate() {
      super.onUpdate();
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, float par2) {
      return par1DamageSource.getDamageType().equals("outOfWorld");
   }
}
