package WayofTime.alchemicalWizardry.common.entity.mob;

import WayofTime.alchemicalWizardry.ModItems;
import WayofTime.alchemicalWizardry.common.IDemon;
import WayofTime.alchemicalWizardry.common.items.DemonPlacer;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;

public class EntityDemon extends EntityTameable implements IDemon {

   private boolean isAggro;
   private String demonID;
   protected boolean dropCrystal = true;


   public EntityDemon(World par1World, String demonID) {
      super(par1World);
      this.demonID = demonID;
   }

   public boolean getDoesDropCrystal() {
      return this.dropCrystal;
   }

   public void setDropCrystal(boolean crystal) {
      this.dropCrystal = crystal;
   }

   public void setSummonedConditions() {
      this.setAggro(true);
   }

   public boolean isAggro() {
      return this.isAggro;
   }

   public void setAggro(boolean aggro) {
      this.isAggro = aggro;
   }

   public EntityAgeable createChild(EntityAgeable entityageable) {
      return null;
   }

   public void writeToNBT(NBTTagCompound tag) {
      super.writeToNBT(tag);
      tag.setBoolean("dropCrystal", this.getDoesDropCrystal());
   }

   public void readFromNBT(NBTTagCompound tag) {
      super.readFromNBT(tag);
      this.setDropCrystal(tag.getBoolean("dropCrystal"));
   }

   protected void dropFewItems(boolean par1, int par2) {
      if(this.getDoesDropCrystal()) {
         ItemStack drop = new ItemStack(ModItems.demonPlacer);
         DemonPlacer.setDemonString(drop, this.getDemonID());
         if(this.getOwner() instanceof EntityPlayer) {
            DemonPlacer.setOwnerName(drop, SpellHelper.getUsername((EntityPlayer)this.getOwner()));
         }

         if(this.hasCustomNameTag()) {
            drop.setStackDisplayName(this.getCustomNameTag());
         }

         this.entityDropItem(drop, 0.0F);
      }

   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
      if(!this.isAggro() && super.worldObj.getWorldTime() % 100L == 0L) {
         this.heal(1.0F);
      }

   }

   public void sendSittingMessageToPlayer(EntityPlayer owner, boolean isSitting) {
      if(owner != null && owner.worldObj.isRemote) {
         ChatComponentText chatmessagecomponent;
         if(isSitting) {
            chatmessagecomponent = new ChatComponentText(StatCollector.translateToLocal("message.demon.willstay"));
         } else {
            chatmessagecomponent = new ChatComponentText(StatCollector.translateToLocal("message.demon.shallfollow"));
         }

         owner.addChatComponentMessage(chatmessagecomponent);
      }

   }

   public String getDemonID() {
      return this.demonID;
   }

   protected void setDemonID(String id) {
      this.demonID = id;
   }
}
