package WayofTime.alchemicalWizardry.common.entity.mob;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.ModItems;
import WayofTime.alchemicalWizardry.common.entity.mob.EntityBoulderFist;
import WayofTime.alchemicalWizardry.common.entity.mob.EntityDemon;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityElemental extends EntityDemon {

   private EntityAIAttackOnCollide aiAttackOnCollide = new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.2D, false);
   private static float maxTamedHealth = 100.0F;
   private static float maxUntamedHealth = 100.0F;
   public int courseChangeCooldown;
   public double waypointX;
   public double waypointY;
   public double waypointZ;
   private Entity targetedEntity;
   private int aggroCooldown;
   public int prevAttackCounter;
   public int attackCounter;


   public EntityElemental(World par1World, String entityAirElementalID) {
      super(par1World, entityAirElementalID);
      this.setSize(0.5F, 1.0F);
      this.setAggro(false);
      this.setTamed(false);
      if(par1World != null && !par1World.isRemote) {
         this.setCombatTask();
      }

   }

   protected void dropFewItems(boolean par1, int par2) {
      if((double)super.worldObj.rand.nextFloat() < 1.0D - Math.pow(0.6000000238418579D, (double)(par2 + 1))) {
         this.entityDropItem(new ItemStack(ModItems.demonBloodShard, 1, 0), 0.0F);
      }

   }

   protected void fall(float par1) {}

   protected void updateFallState(double par1, boolean par3) {}

   public void moveEntityWithHeading(float par1, float par2) {
      if(this.isInWater()) {
         this.moveFlying(par1, par2, 0.02F);
         this.moveEntity(super.motionX, super.motionY, super.motionZ);
         super.motionX *= 0.800000011920929D;
         super.motionY *= 0.800000011920929D;
         super.motionZ *= 0.800000011920929D;
      } else if(this.handleLavaMovement()) {
         this.moveFlying(par1, par2, 0.02F);
         this.moveEntity(super.motionX, super.motionY, super.motionZ);
         super.motionX *= 0.5D;
         super.motionY *= 0.5D;
         super.motionZ *= 0.5D;
      } else {
         float d0 = 0.91F;
         if(super.onGround) {
            d0 = 0.54600006F;
            Block f3 = super.worldObj.getBlock(MathHelper.floor_double(super.posX), MathHelper.floor_double(super.boundingBox.minY) - 1, MathHelper.floor_double(super.posZ));
            if(f3 != null) {
               d0 = f3.slipperiness * 0.91F;
            }
         }

         float f31 = 0.16277136F / (d0 * d0 * d0);
         this.moveFlying(par1, par2, super.onGround?0.1F * f31:0.02F);
         d0 = 0.91F;
         if(super.onGround) {
            d0 = 0.54600006F;
            Block d1 = super.worldObj.getBlock(MathHelper.floor_double(super.posX), MathHelper.floor_double(super.boundingBox.minY) - 1, MathHelper.floor_double(super.posZ));
            if(d1 != null) {
               d0 = d1.slipperiness * 0.91F;
            }
         }

         this.moveEntity(super.motionX, super.motionY, super.motionZ);
         super.motionX *= (double)d0;
         super.motionY *= (double)d0;
         super.motionZ *= (double)d0;
      }

      double d01 = super.posX - super.prevPosX;
      double d11 = super.posZ - super.prevPosZ;
      float f4 = MathHelper.sqrt_double(d01 * d01 + d11 * d11) * 4.0F;
      if(f4 > 1.0F) {
         f4 = 1.0F;
      }

   }

   public boolean isOnLadder() {
      return false;
   }

   @SideOnly(Side.CLIENT)
   public boolean func_110182_bF() {
      return super.dataWatcher.getWatchableObjectByte(25) != 0;
   }

   protected void updateEntityActionState() {
      if(this.getHealth() <= this.getMaxHealth() / 2.0F && super.worldObj.rand.nextInt(200) == 0) {
         this.addPotionEffect(new PotionEffect(AlchemicalWizardry.customPotionReciprocation.id, 100, 1));
      }

      this.prevAttackCounter = this.attackCounter;
      double d0 = this.waypointX - super.posX;
      double d1 = this.waypointY - super.posY;
      double d2 = this.waypointZ - super.posZ;
      double d3 = d0 * d0 + d1 * d1 + d2 * d2;
      if(d3 < 1.0D || d3 > 3600.0D) {
         this.waypointX = super.posX + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
         this.waypointY = super.posY + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
         this.waypointZ = super.posZ + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
      }

      if(this.courseChangeCooldown-- <= 0) {
         this.courseChangeCooldown += super.rand.nextInt(5) + 2;
         d3 = (double)MathHelper.sqrt_double(d3);
         if(this.isCourseTraversable(this.waypointX, this.waypointY, this.waypointZ, d3)) {
            super.motionX += d0 / d3 * 0.1D;
            super.motionY += d1 / d3 * 0.1D;
            super.motionZ += d2 / d3 * 0.1D;
         } else {
            this.waypointX = super.posX + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
            this.waypointY = super.posY + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
            this.waypointZ = super.posZ + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
         }
      }

      if(this.targetedEntity != null && this.targetedEntity.isDead) {
         this.targetedEntity = null;
      }

      if(this.targetedEntity == null || this.aggroCooldown-- <= 0) {
         this.targetedEntity = getClosestVulnerableMonsterToEntity(this, 100.0D);
         if(this.targetedEntity != null) {
            this.aggroCooldown = 20;
         }
      }

      double d4 = 64.0D;
      if(this.targetedEntity != null && this.targetedEntity.getDistanceSqToEntity(this) < d4 * d4) {
         double b0 = this.targetedEntity.posX - super.posX;
         double d6 = this.targetedEntity.boundingBox.minY + (double)(this.targetedEntity.height / 2.0F) - (super.posY + (double)(super.height / 2.0F));
         double d7 = this.targetedEntity.posZ - super.posZ;
         super.renderYawOffset = super.rotationYaw = -((float)Math.atan2(b0, d7)) * 180.0F / 3.1415927F;
         if(this.courseChangeCooldown <= 0) {
            if(this.isCourseTraversable(this.targetedEntity.posX, this.targetedEntity.posY, this.targetedEntity.posZ, Math.sqrt(b0 * b0 + d6 * d6 + d7 * d7))) {
               this.waypointX = this.targetedEntity.posX;
               this.waypointY = this.targetedEntity.posY;
               this.waypointZ = this.targetedEntity.posZ;
               super.motionX += b0 / d3 * 0.1D;
               super.motionY += d6 / d3 * 0.1D;
               super.motionZ += d7 / d3 * 0.1D;
            } else {
               this.waypointX = super.posX + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
               this.waypointY = super.posY + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
               this.waypointZ = super.posZ + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
               super.motionX += b0 / d3 * 0.1D;
               super.motionY += d6 / d3 * 0.1D;
               super.motionZ += d7 / d3 * 0.1D;
            }
         }

         if(this.canEntityBeSeen(this.targetedEntity)) {
            if(Math.sqrt(b0 * b0 + d6 * d6 + d7 * d7) < 4.0D) {
               ++this.attackCounter;
               if(this.attackCounter >= 10) {
                  super.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1008, (int)super.posX, (int)super.posY, (int)super.posZ, 0);
                  this.inflictEffectOnEntity(this.targetedEntity);
                  this.attackCounter = -40;
               }
            }
         } else if(this.attackCounter > 0) {
            --this.attackCounter;
         }
      } else {
         super.renderYawOffset = super.rotationYaw = -((float)Math.atan2(super.motionX, super.motionZ)) * 180.0F / 3.1415927F;
         if(this.attackCounter > 0) {
            --this.attackCounter;
         }
      }

      if(!super.worldObj.isRemote) {
         byte var17 = super.dataWatcher.getWatchableObjectByte(25);
         byte b1 = (byte)(this.attackCounter > 10?1:0);
         if(var17 != b1) {
            super.dataWatcher.updateObject(25, Byte.valueOf(b1));
         }
      }

   }

   private boolean isCourseTraversable(double par1, double par3, double par5, double par7) {
      double d4 = (this.waypointX - super.posX) / par7;
      double d5 = (this.waypointY - super.posY) / par7;
      double d6 = (this.waypointZ - super.posZ) / par7;
      AxisAlignedBB axisalignedbb = super.boundingBox.copy();

      for(int i = 1; (double)i < par7; ++i) {
         axisalignedbb.offset(d4, d5, d6);
         if(!super.worldObj.getCollidingBoundingBoxes(this, axisalignedbb).isEmpty()) {
            return false;
         }
      }

      return true;
   }

   public int getMaxSpawnedInChunk() {
      return 1;
   }

   public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
      super.writeEntityToNBT(par1NBTTagCompound);
   }

   public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
      super.readEntityFromNBT(par1NBTTagCompound);
      this.setAngry(par1NBTTagCompound.getBoolean("Angry"));
      this.setCombatTask();
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.30000001192092896D);
      if(this.isTamed()) {
         this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue((double)maxTamedHealth);
      } else {
         this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue((double)maxUntamedHealth);
      }

   }

   public boolean isAIEnabled() {
      return false;
   }

   public void setAttackTarget(EntityLivingBase par1EntityLivingBase) {
      super.setAttackTarget(par1EntityLivingBase);
      if(par1EntityLivingBase == null) {
         this.setAngry(false);
      } else if(!this.isTamed()) {
         this.setAngry(true);
      }

   }

   protected void updateAITick() {
      super.dataWatcher.updateObject(18, Float.valueOf(this.getHealth()));
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(18, new Float(this.getHealth()));
      super.dataWatcher.addObject(19, new Byte((byte)0));
      super.dataWatcher.addObject(25, Byte.valueOf((byte)0));
   }

   protected void playStepSound(int par1, int par2, int par3, int par4) {
      this.playSound("mob.zombie.step", 0.15F, 1.0F);
   }

   protected String getLivingSound() {
      return "none";
   }

   protected String getHurtSound() {
      return "none";
   }

   protected String getDeathSound() {
      return "none";
   }

   protected float getSoundVolume() {
      return 0.4F;
   }

   protected int getDropItemId() {
      return -1;
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
   }

   public void onUpdate() {
      super.onUpdate();
   }

   public float getEyeHeight() {
      return super.height * 0.8F;
   }

   public int getVerticalFaceSpeed() {
      return this.isSitting()?20:super.getVerticalFaceSpeed();
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, float par2) {
      if(this.isEntityInvulnerable()) {
         return false;
      } else {
         Entity entity = par1DamageSource.getEntity();
         super.aiSit.setSitting(false);
         if(entity != null && !(entity instanceof EntityPlayer) && !(entity instanceof EntityArrow)) {
            par2 = (par2 + 1.0F) / 2.0F;
         }

         return super.attackEntityFrom(par1DamageSource, par2);
      }
   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      int i = this.isTamed()?6:7;
      return par1Entity.attackEntityFrom(DamageSource.causeMobDamage(this), (float)i);
   }

   public void setTamed(boolean par1) {
      super.setTamed(par1);
      if(par1) {
         this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue((double)maxTamedHealth);
      } else {
         this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue((double)maxUntamedHealth);
      }

   }

   public boolean isBreedingItem(ItemStack par1ItemStack) {
      return false;
   }

   public boolean isAngry() {
      return (super.dataWatcher.getWatchableObjectByte(16) & 2) != 0;
   }

   public void setAngry(boolean par1) {
      byte b0 = super.dataWatcher.getWatchableObjectByte(16);
      if(par1) {
         super.dataWatcher.updateObject(16, Byte.valueOf((byte)(b0 | 2)));
      } else {
         super.dataWatcher.updateObject(16, Byte.valueOf((byte)(b0 & -3)));
      }

   }

   public void func_70918_i(boolean par1) {
      if(par1) {
         super.dataWatcher.updateObject(19, Byte.valueOf((byte)1));
      } else {
         super.dataWatcher.updateObject(19, Byte.valueOf((byte)0));
      }

   }

   public boolean canMateWith(EntityAnimal par1EntityAnimal) {
      return false;
   }

   public boolean func_70922_bv() {
      return super.dataWatcher.getWatchableObjectByte(19) == 1;
   }

   protected boolean canDespawn() {
      return false;
   }

   public boolean func_142018_a(EntityLivingBase par1EntityLivingBase, EntityLivingBase par2EntityLivingBase) {
      if(!(par1EntityLivingBase instanceof EntityCreeper) && !(par1EntityLivingBase instanceof EntityGhast)) {
         if(par1EntityLivingBase instanceof EntityBoulderFist) {
            EntityBoulderFist entitywolf = (EntityBoulderFist)par1EntityLivingBase;
            if(entitywolf.isTamed() && entitywolf.getOwner() == par2EntityLivingBase) {
               return false;
            }
         }

         return par1EntityLivingBase instanceof EntityPlayer && par2EntityLivingBase instanceof EntityPlayer && !((EntityPlayer)par2EntityLivingBase).canAttackPlayer((EntityPlayer)par1EntityLivingBase)?false:!(par1EntityLivingBase instanceof EntityHorse) || !((EntityHorse)par1EntityLivingBase).isTame();
      } else {
         return false;
      }
   }

   public void setCombatTask() {
      super.tasks.removeTask(this.aiAttackOnCollide);
      ItemStack itemstack = this.getHeldItem();
      super.tasks.addTask(4, this.aiAttackOnCollide);
   }

   public void inflictEffectOnEntity(Entity target) {
      if(target instanceof EntityLivingBase) {
         ((EntityLivingBase)target).addPotionEffect(new PotionEffect(AlchemicalWizardry.customPotionDrowning.id, 100, 0));
      }

   }

   public static Entity getClosestVulnerableMonsterToEntity(Entity par1Entity, double par2) {
      double d4 = -1.0D;
      double par1 = par1Entity.posX;
      double par3 = par1Entity.posY;
      double par5 = par1Entity.posZ;
      EntityLivingBase entityLiving = null;
      World world = par1Entity.worldObj;
      double range = Math.sqrt(par2);
      double verticalRange = Math.sqrt(par2);
      List entities = world.getEntitiesWithinAABB(EntityLivingBase.class, AxisAlignedBB.getBoundingBox(par1 - 0.5D, par3 - 0.5D, par5 - 0.5D, par1 + 0.5D, par3 + 0.5D, par5 + 0.5D).expand(range, verticalRange, range));
      if(entities == null) {
         return null;
      } else {
         for(int i = 0; i < entities.size(); ++i) {
            EntityLivingBase entityLiving1 = (EntityLivingBase)entities.get(i);
            if((!(entityLiving1 instanceof EntityPlayer) || !((EntityPlayer)entityLiving1).capabilities.disableDamage) && entityLiving1.isEntityAlive()) {
               double d5 = entityLiving1.getDistanceSq(par1, par3, par5);
               double d6 = par2;
               if(entityLiving1.isSneaking()) {
                  d6 = par2 * 0.800000011920929D;
               }

               if(entityLiving1.isInvisible()) {
                  float f = entityLiving1 instanceof EntityPlayer?((EntityPlayer)entityLiving1).getArmorVisibility():1.0F;
                  if(f < 0.1F) {
                     f = 0.1F;
                  }

                  d6 *= (double)(0.7F * f);
               }

               if((par2 < 0.0D || d5 < d6 * d6) && (d4 == -1.0D || d5 < d4) && par1Entity != entityLiving1) {
                  d4 = d5;
                  entityLiving = entityLiving1;
               }
            }
         }

         return entityLiving;
      }
   }

   public int getTotalArmorValue() {
      return 10;
   }

}
