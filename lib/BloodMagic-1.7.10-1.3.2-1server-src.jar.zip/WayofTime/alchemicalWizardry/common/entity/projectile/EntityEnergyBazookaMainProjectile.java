package WayofTime.alchemicalWizardry.common.entity.projectile;

import WayofTime.alchemicalWizardry.common.entity.projectile.EnergyBlastProjectile;
import WayofTime.alchemicalWizardry.common.entity.projectile.EntityEnergyBazookaSecondaryProjectile;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.World;

public class EntityEnergyBazookaMainProjectile extends EnergyBlastProjectile {

   public EntityEnergyBazookaMainProjectile(World par1World) {
      super(par1World);
   }

   public EntityEnergyBazookaMainProjectile(World par1World, double par2, double par4, double par6) {
      super(par1World, par2, par4, par6);
   }

   public EntityEnergyBazookaMainProjectile(World par1World, EntityLivingBase par2EntityPlayer, int damage) {
      super(par1World, par2EntityPlayer, damage);
   }

   public EntityEnergyBazookaMainProjectile(World par1World, EntityLivingBase par2EntityPlayer, int damage, int maxTicksInAir, double posX, double posY, double posZ, float rotationYaw, float rotationPitch) {
      super(par1World, par2EntityPlayer, damage, maxTicksInAir, posX, posY, posZ, rotationYaw, rotationPitch);
   }

   public EntityEnergyBazookaMainProjectile(World par1World, EntityLivingBase par2EntityLivingBase, EntityLivingBase par3EntityLivingBase, float par4, float par5, int damage, int maxTicksInAir) {
      super(par1World, par2EntityLivingBase, par3EntityLivingBase, par4, par5, damage, maxTicksInAir);
   }

   public DamageSource getDamageSource() {
      return DamageSource.causeMobDamage(super.shootingEntity);
   }

   public void onImpact(MovingObjectPosition mop) {
      if(mop.typeOfHit == MovingObjectType.ENTITY && mop.entityHit != null) {
         if(mop.entityHit == super.shootingEntity) {
            return;
         }

         this.onImpact(mop.entityHit);
      } else if(mop.typeOfHit == MovingObjectType.BLOCK) {
         super.worldObj.createExplosion(super.shootingEntity, super.posX, super.posY, super.posZ, 5.0F, false);
         this.spawnSecondaryProjectiles();
      }

      this.setDead();
   }

   public void onImpact(Entity mop) {
      if(mop == super.shootingEntity && super.ticksInAir > 3) {
         super.shootingEntity.attackEntityFrom(DamageSource.causeMobDamage(super.shootingEntity), 1.0F);
         this.setDead();
      } else {
         if(mop instanceof EntityLivingBase) {
            this.spawnSecondaryProjectiles();
         }

         super.worldObj.createExplosion(super.shootingEntity, super.posX, super.posY, super.posZ, 5.0F, false);
      }

      this.spawnHitParticles("magicCrit", 8);
      this.setDead();
   }

   public void spawnSecondaryProjectiles() {
      for(int i = 0; i < 20; ++i) {
         EntityEnergyBazookaSecondaryProjectile secProj = new EntityEnergyBazookaSecondaryProjectile(super.worldObj, super.posX, super.posY, super.posZ, 15);
         secProj.shootingEntity = super.shootingEntity;
         float xVel = super.rand.nextFloat() - super.rand.nextFloat();
         float yVel = super.rand.nextFloat() - super.rand.nextFloat();
         float zVel = super.rand.nextFloat() - super.rand.nextFloat();
         float wantedVel = 0.5F;
         secProj.motionX = (double)(xVel * wantedVel);
         secProj.motionY = (double)(yVel * wantedVel);
         secProj.motionZ = (double)(zVel * wantedVel);
         super.worldObj.spawnEntityInWorld(secProj);
      }

   }
}
