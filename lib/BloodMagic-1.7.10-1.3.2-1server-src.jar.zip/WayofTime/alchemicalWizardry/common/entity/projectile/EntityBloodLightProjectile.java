package WayofTime.alchemicalWizardry.common.entity.projectile;

import WayofTime.alchemicalWizardry.ModBlocks;
import WayofTime.alchemicalWizardry.common.entity.projectile.EnergyBlastProjectile;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.World;

public class EntityBloodLightProjectile extends EnergyBlastProjectile {

   public EntityBloodLightProjectile(World par1World) {
      super(par1World);
   }

   public EntityBloodLightProjectile(World par1World, double par2, double par4, double par6) {
      super(par1World, par2, par4, par6);
   }

   public EntityBloodLightProjectile(World par1World, EntityLivingBase par2EntityPlayer, int damage) {
      super(par1World, par2EntityPlayer, damage);
   }

   public EntityBloodLightProjectile(World par1World, EntityLivingBase par2EntityPlayer, int damage, int maxTicksInAir, double posX, double posY, double posZ, float rotationYaw, float rotationPitch) {
      super(par1World, par2EntityPlayer, damage, maxTicksInAir, posX, posY, posZ, rotationYaw, rotationPitch);
   }

   public EntityBloodLightProjectile(World par1World, EntityLivingBase par2EntityLivingBase, EntityLivingBase par3EntityLivingBase, float par4, float par5, int damage, int maxTicksInAir) {
      super(par1World, par2EntityLivingBase, par3EntityLivingBase, par4, par5, damage, maxTicksInAir);
   }

   public DamageSource getDamageSource() {
      return DamageSource.causeMobDamage(super.shootingEntity);
   }

   public void onImpact(MovingObjectPosition mop) {
      if(mop.typeOfHit == MovingObjectType.ENTITY && mop.entityHit != null) {
         if(mop.entityHit == super.shootingEntity) {
            return;
         }

         this.onImpact(mop.entityHit);
      } else if(mop.typeOfHit == MovingObjectType.BLOCK) {
         int sideHit = mop.sideHit;
         int blockX = mop.blockX;
         int blockY = mop.blockY;
         int blockZ = mop.blockZ;
         if(sideHit == 0 && super.worldObj.isAirBlock(blockX, blockY - 1, blockZ)) {
            super.worldObj.setBlock(blockX, blockY - 1, blockZ, ModBlocks.blockBloodLight);
         }

         if(sideHit == 1 && super.worldObj.isAirBlock(blockX, blockY + 1, blockZ)) {
            super.worldObj.setBlock(blockX, blockY + 1, blockZ, ModBlocks.blockBloodLight);
         }

         if(sideHit == 2 && super.worldObj.isAirBlock(blockX, blockY, blockZ - 1)) {
            super.worldObj.setBlock(blockX, blockY, blockZ - 1, ModBlocks.blockBloodLight);
         }

         if(sideHit == 3 && super.worldObj.isAirBlock(blockX, blockY, blockZ + 1)) {
            super.worldObj.setBlock(blockX, blockY, blockZ + 1, ModBlocks.blockBloodLight);
         }

         if(sideHit == 4 && super.worldObj.isAirBlock(blockX - 1, blockY, blockZ)) {
            super.worldObj.setBlock(blockX - 1, blockY, blockZ, ModBlocks.blockBloodLight);
         }

         if(sideHit == 5 && super.worldObj.isAirBlock(blockX + 1, blockY, blockZ)) {
            super.worldObj.setBlock(blockX + 1, blockY, blockZ, ModBlocks.blockBloodLight);
         }
      }

      this.setDead();
   }

   public void onImpact(Entity mop) {
      if(mop == super.shootingEntity && super.ticksInAir > 3) {
         super.shootingEntity.attackEntityFrom(DamageSource.causeMobDamage(super.shootingEntity), 1.0F);
         this.setDead();
      } else if(mop instanceof EntityLivingBase) {
         ((EntityLivingBase)mop).setRevengeTarget(super.shootingEntity);
         this.doDamage(1, mop);
      }

      if(super.worldObj.isAirBlock((int)super.posX, (int)super.posY, (int)super.posZ)) {
         super.worldObj.setBlock((int)super.posX, (int)super.posY, (int)super.posZ, Blocks.fire);
      }

      this.spawnHitParticles("magicCrit", 8);
      this.setDead();
   }
}
