package WayofTime.alchemicalWizardry.common.entity.projectile;

import cpw.mods.fml.client.FMLClientHandler;
import cpw.mods.fml.common.registry.IThrowableEntity;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.particle.EntityCloudFX;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IProjectile;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityParticleBeam extends Entity implements IProjectile, IThrowableEntity {

   protected int xTile = -1;
   protected int yTile = -1;
   protected int zTile = -1;
   protected int inTile = 0;
   protected int inData = 0;
   protected float colourRed = 0.0F;
   protected float colourGreen = 0.0F;
   protected float colourBlue = 0.0F;
   protected int xDest = 0;
   protected int yDest = 0;
   protected int zDest = 0;
   protected boolean inGround = false;
   public EntityLivingBase shootingEntity;
   protected int ticksInAir = 0;
   protected int maxTicksInAir = 600;
   private int ricochetCounter = 0;
   private boolean scheduledForDeath = false;
   protected int projectileDamage;


   public EntityParticleBeam(World par1World) {
      super(par1World);
      this.setSize(0.5F, 0.5F);
      this.maxTicksInAir = 600;
   }

   public EntityParticleBeam(World par1World, double par2, double par4, double par6) {
      super(par1World);
      this.setSize(0.5F, 0.5F);
      this.setPosition(par2, par4, par6);
      super.yOffset = 0.0F;
      this.maxTicksInAir = 600;
   }

   public EntityParticleBeam(World par1World, EntityLivingBase par2EntityPlayer, int damage) {
      super(par1World);
      this.shootingEntity = par2EntityPlayer;
      float par3 = 0.8F;
      this.setSize(0.5F, 0.5F);
      this.setLocationAndAngles(par2EntityPlayer.posX, par2EntityPlayer.posY + (double)par2EntityPlayer.getEyeHeight(), par2EntityPlayer.posZ, par2EntityPlayer.rotationYaw, par2EntityPlayer.rotationPitch);
      super.posX -= (double)(MathHelper.cos(super.rotationYaw / 180.0F * 3.1415927F) * 0.16F);
      super.posY -= 0.2D;
      super.posZ -= (double)(MathHelper.sin(super.rotationYaw / 180.0F * 3.1415927F) * 0.16F);
      this.setPosition(super.posX, super.posY, super.posZ);
      super.yOffset = 0.0F;
      super.motionX = (double)(-MathHelper.sin(super.rotationYaw / 180.0F * 3.1415927F) * MathHelper.cos(super.rotationPitch / 180.0F * 3.1415927F));
      super.motionZ = (double)(MathHelper.cos(super.rotationYaw / 180.0F * 3.1415927F) * MathHelper.cos(super.rotationPitch / 180.0F * 3.1415927F));
      super.motionY = (double)(-MathHelper.sin(super.rotationPitch / 180.0F * 3.1415927F));
      this.setThrowableHeading(super.motionX, super.motionY, super.motionZ, par3 * 1.5F, 1.0F);
      this.projectileDamage = damage;
      this.maxTicksInAir = 600;
   }

   public EntityParticleBeam(World par1World, EntityLivingBase par2EntityPlayer, int damage, int maxTicksInAir, double posX, double posY, double posZ, float rotationYaw, float rotationPitch) {
      super(par1World);
      this.shootingEntity = par2EntityPlayer;
      float par3 = 0.8F;
      this.setSize(0.5F, 0.5F);
      this.setLocationAndAngles(posX, posY, posZ, rotationYaw, rotationPitch);
      posX -= (double)(MathHelper.cos(rotationYaw / 180.0F * 3.1415927F) * 0.16F);
      posY -= 0.2D;
      posZ -= (double)(MathHelper.sin(rotationYaw / 180.0F * 3.1415927F) * 0.16F);
      this.setPosition(posX, posY, posZ);
      super.yOffset = 0.0F;
      super.motionX = (double)(-MathHelper.sin(rotationYaw / 180.0F * 3.1415927F) * MathHelper.cos(rotationPitch / 180.0F * 3.1415927F));
      super.motionZ = (double)(MathHelper.cos(rotationYaw / 180.0F * 3.1415927F) * MathHelper.cos(rotationPitch / 180.0F * 3.1415927F));
      super.motionY = (double)(-MathHelper.sin(rotationPitch / 180.0F * 3.1415927F));
      this.setThrowableHeading(super.motionX, super.motionY, super.motionZ, par3 * 1.5F, 1.0F);
      this.projectileDamage = damage;
      this.maxTicksInAir = maxTicksInAir;
   }

   public EntityParticleBeam(World par1World, EntityLivingBase par2EntityLivingBase, EntityLivingBase par3EntityLivingBase, float par4, float par5, int damage, int maxTicksInAir) {
      super(par1World);
      super.renderDistanceWeight = 10.0D;
      this.shootingEntity = par2EntityLivingBase;
      super.posY = par2EntityLivingBase.posY + (double)par2EntityLivingBase.getEyeHeight() - 0.10000000149011612D;
      double d0 = par3EntityLivingBase.posX - par2EntityLivingBase.posX;
      double d1 = par3EntityLivingBase.boundingBox.minY + (double)(par3EntityLivingBase.height / 1.5F) - super.posY;
      double d2 = par3EntityLivingBase.posZ - par2EntityLivingBase.posZ;
      double d3 = (double)MathHelper.sqrt_double(d0 * d0 + d2 * d2);
      if(d3 >= 1.0E-7D) {
         float f2 = (float)(Math.atan2(d2, d0) * 180.0D / 3.141592653589793D) - 90.0F;
         float f3 = (float)(-(Math.atan2(d1, d3) * 180.0D / 3.141592653589793D));
         double d4 = d0 / d3;
         double d5 = d2 / d3;
         this.setLocationAndAngles(par2EntityLivingBase.posX + d4, super.posY, par2EntityLivingBase.posZ + d5, f2, f3);
         super.yOffset = 0.0F;
         float f4 = (float)d3 * 0.2F;
         this.setThrowableHeading(d0, d1, d2, par4, par5);
      }

      this.projectileDamage = damage;
      this.maxTicksInAir = maxTicksInAir;
   }

   protected void entityInit() {
      super.dataWatcher.addObject(16, Byte.valueOf((byte)0));
   }

   public void setThrowableHeading(double var1, double var3, double var5, float var7, float var8) {
      float var9 = MathHelper.sqrt_double(var1 * var1 + var3 * var3 + var5 * var5);
      var1 /= (double)var9;
      var3 /= (double)var9;
      var5 /= (double)var9;
      var1 += super.rand.nextGaussian() * 0.007499999832361937D * (double)var8;
      var3 += super.rand.nextGaussian() * 0.007499999832361937D * (double)var8;
      var5 += super.rand.nextGaussian() * 0.007499999832361937D * (double)var8;
      var1 *= (double)var7;
      var3 *= (double)var7;
      var5 *= (double)var7;
      super.motionX = var1;
      super.motionY = var3;
      super.motionZ = var5;
      float var10 = MathHelper.sqrt_double(var1 * var1 + var5 * var5);
      super.prevRotationYaw = super.rotationYaw = (float)(Math.atan2(var1, var5) * 180.0D / 3.141592653589793D);
      super.prevRotationPitch = super.rotationPitch = (float)(Math.atan2(var3, (double)var10) * 180.0D / 3.141592653589793D);
   }

   @SideOnly(Side.CLIENT)
   public void setPositionAndRotation2(double par1, double par3, double par5, float par7, float par8, int par9) {
      this.setPosition(par1, par3, par5);
      this.setRotation(par7, par8);
   }

   @SideOnly(Side.CLIENT)
   public void setVelocity(double par1, double par3, double par5) {
      super.motionX = par1;
      super.motionY = par3;
      super.motionZ = par5;
      if(super.prevRotationPitch == 0.0F && super.prevRotationYaw == 0.0F) {
         float var7 = MathHelper.sqrt_double(par1 * par1 + par5 * par5);
         super.prevRotationYaw = super.rotationYaw = (float)(Math.atan2(par1, par5) * 180.0D / 3.141592653589793D);
         super.prevRotationPitch = super.rotationPitch = (float)(Math.atan2(par3, (double)var7) * 180.0D / 3.141592653589793D);
         super.prevRotationPitch = super.rotationPitch;
         super.prevRotationYaw = super.rotationYaw;
         this.setLocationAndAngles(super.posX, super.posY, super.posZ, super.rotationYaw, super.rotationPitch);
      }

   }

   public void onUpdate() {
      super.onUpdate();
      if(this.ticksInAir > this.maxTicksInAir) {
         this.setDead();
      }

      super.posX += super.motionX;
      super.posY += super.motionY;
      super.posZ += super.motionZ;
      MathHelper.sqrt_double(super.motionX * super.motionX + super.motionZ * super.motionZ);
      this.setPosition(super.posX, super.posY, super.posZ);
      this.doFiringParticles();
      if(Math.pow(super.posX - (double)this.xDest, 2.0D) + Math.pow(super.posY - (double)this.yDest, 2.0D) + Math.pow(super.posZ - (double)this.zDest, 2.0D) <= 1.0D) {
         this.scheduledForDeath = true;
      }

      if(this.scheduledForDeath) {
         this.setDead();
      }

   }

   public void doFiringParticles() {
      if(super.worldObj.isRemote) {
         EntityCloudFX particle = new EntityCloudFX(super.worldObj, super.posX, super.posY, super.posZ, 0.0D, 0.0D, 0.0D);
         particle.setRBGColorF(this.colourRed + 0.15F * (super.worldObj.rand.nextFloat() - super.worldObj.rand.nextFloat()), this.colourGreen + 0.15F * (super.worldObj.rand.nextFloat() - super.worldObj.rand.nextFloat()), this.colourBlue + 0.15F * (super.worldObj.rand.nextFloat() - super.worldObj.rand.nextFloat()));
         FMLClientHandler.instance().getClient().effectRenderer.addEffect(particle);
      }
   }

   public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
      par1NBTTagCompound.setShort("xTile", (short)this.xTile);
      par1NBTTagCompound.setShort("yTile", (short)this.yTile);
      par1NBTTagCompound.setShort("zTile", (short)this.zTile);
      par1NBTTagCompound.setByte("inTile", (byte)this.inTile);
      par1NBTTagCompound.setByte("inData", (byte)this.inData);
      par1NBTTagCompound.setByte("inGround", (byte)(this.inGround?1:0));
      par1NBTTagCompound.setInteger("ticksInAir", this.ticksInAir);
      par1NBTTagCompound.setInteger("maxTicksInAir", this.maxTicksInAir);
      par1NBTTagCompound.setInteger("projectileDamage", this.projectileDamage);
      par1NBTTagCompound.setFloat("colourRed", this.colourRed);
      par1NBTTagCompound.setFloat("colourGreen", this.colourGreen);
      par1NBTTagCompound.setFloat("colourBlue", this.colourBlue);
      par1NBTTagCompound.setInteger("xDest", this.xDest);
      par1NBTTagCompound.setInteger("yDest", this.yDest);
      par1NBTTagCompound.setInteger("zDest", this.zDest);
   }

   public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
      this.xTile = par1NBTTagCompound.getShort("xTile");
      this.yTile = par1NBTTagCompound.getShort("yTile");
      this.zTile = par1NBTTagCompound.getShort("zTile");
      this.inTile = par1NBTTagCompound.getByte("inTile") & 255;
      this.inData = par1NBTTagCompound.getByte("inData") & 255;
      this.inGround = par1NBTTagCompound.getByte("inGround") == 1;
      this.ticksInAir = par1NBTTagCompound.getInteger("ticksInAir");
      this.maxTicksInAir = par1NBTTagCompound.getInteger("maxTicksInAir");
      this.projectileDamage = par1NBTTagCompound.getInteger("projectileDamage");
      this.colourRed = par1NBTTagCompound.getFloat("colourRed");
      this.colourGreen = par1NBTTagCompound.getFloat("colourGreen");
      this.colourBlue = par1NBTTagCompound.getFloat("colourBlue");
      this.xDest = par1NBTTagCompound.getInteger("xDest");
      this.yDest = par1NBTTagCompound.getInteger("yDest");
      this.zDest = par1NBTTagCompound.getInteger("zDest");
   }

   protected boolean canTriggerWalking() {
      return false;
   }

   @SideOnly(Side.CLIENT)
   public float getShadowSize() {
      return 0.0F;
   }

   protected void spawnHitParticles(String string, int i) {
      for(int particles = 0; particles < i; ++particles) {
         super.worldObj.spawnParticle(string, super.posX, super.posY - (double)(string == "portal"?1:0), super.posZ, this.gaussian(super.motionX), this.gaussian(super.motionY), this.gaussian(super.motionZ));
      }

   }

   public DamageSource getDamageSource() {
      return DamageSource.causeMobDamage(this.shootingEntity);
   }

   public double smallGauss(double d) {
      return ((double)super.worldObj.rand.nextFloat() - 0.5D) * d;
   }

   public double gaussian(double d) {
      return d + d * (((double)super.rand.nextFloat() - 0.5D) / 4.0D);
   }

   private int getRicochetMax() {
      return 0;
   }

   public Entity getThrower() {
      return this.shootingEntity;
   }

   public void setThrower(Entity entity) {
      if(entity instanceof EntityLivingBase) {
         this.shootingEntity = (EntityLivingBase)entity;
      }

   }

   public void setColour(float red, float green, float blue) {
      this.colourRed = red;
      this.colourGreen = green;
      this.colourBlue = blue;
   }

   public void setDestination(int xDest, int yDest, int zDest) {
      this.xDest = xDest;
      this.yDest = yDest;
      this.zDest = zDest;
   }
}
