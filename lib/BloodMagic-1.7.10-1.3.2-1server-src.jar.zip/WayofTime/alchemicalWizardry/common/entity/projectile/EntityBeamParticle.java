package WayofTime.alchemicalWizardry.common.entity.projectile;

import net.minecraft.client.particle.EntityFX;
import net.minecraft.world.World;

public class EntityBeamParticle extends EntityFX {

   protected EntityBeamParticle(World p_i1218_1_, double p_i1218_2_, double p_i1218_4_, double p_i1218_6_) {
      super(p_i1218_1_, p_i1218_2_, p_i1218_4_, p_i1218_6_);
   }
}
