package WayofTime.alchemicalWizardry.common.entity.projectile;

import WayofTime.alchemicalWizardry.common.entity.projectile.EnergyBlastProjectile;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IProjectile;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.World;

public class EntityEnergyBazookaSecondaryProjectile extends EnergyBlastProjectile implements IProjectile {

   private int xTile = -1;
   private int yTile = -1;
   private int zTile = -1;
   private int inTile = 0;
   private int inData = 0;
   private boolean inGround = false;
   public EntityLivingBase shootingEntity;
   private int ticksInAir = 0;
   private int ricochetCounter = 0;
   private boolean scheduledForDeath = false;
   public int damage;


   public EntityEnergyBazookaSecondaryProjectile(World par1World) {
      super(par1World);
      this.setSize(0.5F, 0.5F);
      this.damage = 5;
   }

   public EntityEnergyBazookaSecondaryProjectile(World par1World, double par2, double par4, double par6, int damage) {
      super(par1World);
      this.setSize(0.5F, 0.5F);
      this.setPosition(par2, par4, par6);
      super.yOffset = 0.0F;
      this.damage = damage;
   }

   public EntityEnergyBazookaSecondaryProjectile(World par1World, EntityPlayer par2EntityPlayer, int damage) {
      super(par1World);
      this.shootingEntity = par2EntityPlayer;
      float par3 = 0.8F;
      this.setSize(0.1F, 0.1F);
      this.setLocationAndAngles(par2EntityPlayer.posX, par2EntityPlayer.posY + (double)par2EntityPlayer.getEyeHeight(), par2EntityPlayer.posZ, par2EntityPlayer.rotationYaw, par2EntityPlayer.rotationPitch);
      super.posX -= (double)(MathHelper.cos(super.rotationYaw / 180.0F * 3.1415927F) * 0.16F);
      super.posY -= 0.2D;
      super.posZ -= (double)(MathHelper.sin(super.rotationYaw / 180.0F * 3.1415927F) * 0.16F);
      this.setPosition(super.posX, super.posY, super.posZ);
      super.yOffset = 0.0F;
      super.motionX = (double)(-MathHelper.sin(super.rotationYaw / 180.0F * 3.1415927F) * MathHelper.cos(super.rotationPitch / 180.0F * 3.1415927F));
      super.motionZ = (double)(MathHelper.cos(super.rotationYaw / 180.0F * 3.1415927F) * MathHelper.cos(super.rotationPitch / 180.0F * 3.1415927F));
      super.motionY = (double)(-MathHelper.sin(super.rotationPitch / 180.0F * 3.1415927F));
      this.setThrowableHeading(super.motionX, super.motionY, super.motionZ, par3 * 1.5F, 1.0F);
      this.damage = damage;
   }

   protected void entityInit() {
      super.dataWatcher.addObject(16, Byte.valueOf((byte)0));
   }

   public void setThrowableHeading(double var1, double var3, double var5, float var7, float var8) {
      float var9 = MathHelper.sqrt_double(var1 * var1 + var3 * var3 + var5 * var5);
      var1 /= (double)var9;
      var3 /= (double)var9;
      var5 /= (double)var9;
      var1 += super.rand.nextGaussian() * 0.007499999832361937D * (double)var8;
      var3 += super.rand.nextGaussian() * 0.007499999832361937D * (double)var8;
      var5 += super.rand.nextGaussian() * 0.007499999832361937D * (double)var8;
      var1 *= (double)var7;
      var3 *= (double)var7;
      var5 *= (double)var7;
      super.motionX = var1;
      super.motionY = var3;
      super.motionZ = var5;
      float var10 = MathHelper.sqrt_double(var1 * var1 + var5 * var5);
      super.prevRotationYaw = super.rotationYaw = (float)(Math.atan2(var1, var5) * 180.0D / 3.141592653589793D);
      super.prevRotationPitch = super.rotationPitch = (float)(Math.atan2(var3, (double)var10) * 180.0D / 3.141592653589793D);
   }

   @SideOnly(Side.CLIENT)
   public void setPositionAndRotation2(double par1, double par3, double par5, float par7, float par8, int par9) {
      this.setPosition(par1, par3, par5);
      this.setRotation(par7, par8);
   }

   @SideOnly(Side.CLIENT)
   public void setVelocity(double par1, double par3, double par5) {
      super.motionX = par1;
      super.motionY = par3;
      super.motionZ = par5;
      if(super.prevRotationPitch == 0.0F && super.prevRotationYaw == 0.0F) {
         float var7 = MathHelper.sqrt_double(par1 * par1 + par5 * par5);
         super.prevRotationYaw = super.rotationYaw = (float)(Math.atan2(par1, par5) * 180.0D / 3.141592653589793D);
         super.prevRotationPitch = super.rotationPitch = (float)(Math.atan2(par3, (double)var7) * 180.0D / 3.141592653589793D);
         super.prevRotationPitch = super.rotationPitch;
         super.prevRotationYaw = super.rotationYaw;
         this.setLocationAndAngles(super.posX, super.posY, super.posZ, super.rotationYaw, super.rotationPitch);
      }

   }

   public void onUpdate() {
      super.onUpdate();
      if(this.ticksInAir > super.maxTicksInAir) {
         this.setDead();
      }

      double var7;
      if(this.shootingEntity == null) {
         List var16 = super.worldObj.getEntitiesWithinAABB(EntityPlayer.class, AxisAlignedBB.getBoundingBox(super.posX - 1.0D, super.posY - 1.0D, super.posZ - 1.0D, super.posX + 1.0D, super.posY + 1.0D, super.posZ + 1.0D));
         Iterator var17 = var16.iterator();
         double var3 = Double.MAX_VALUE;
         EntityPlayer var5 = null;

         while(var17.hasNext()) {
            EntityPlayer var6 = (EntityPlayer)var17.next();
            var7 = (double)var6.getDistanceToEntity(this);
            if(var7 < var3) {
               var5 = var6;
            }
         }

         if(var5 != null) {
            this.shootingEntity = var5;
         }
      }

      if(super.prevRotationPitch == 0.0F && super.prevRotationYaw == 0.0F) {
         float var161 = MathHelper.sqrt_double(super.motionX * super.motionX + super.motionZ * super.motionZ);
         super.prevRotationYaw = super.rotationYaw = (float)(Math.atan2(super.motionX, super.motionZ) * 180.0D / 3.141592653589793D);
         super.prevRotationPitch = super.rotationPitch = (float)(Math.atan2(super.motionY, (double)var161) * 180.0D / 3.141592653589793D);
      }

      Block var171 = super.worldObj.getBlock(this.xTile, this.yTile, this.zTile);
      if(var171 != null) {
         var171.setBlockBoundsBasedOnState(super.worldObj, this.xTile, this.yTile, this.zTile);
         AxisAlignedBB var18 = var171.getCollisionBoundingBoxFromPool(super.worldObj, this.xTile, this.yTile, this.zTile);
         if(var18 != null && var18.isVecInside(SpellHelper.createVec3(super.posX, super.posY, super.posZ))) {
            this.inGround = true;
         }
      }

      if(this.inGround) {
         Block var19 = super.worldObj.getBlock(this.xTile, this.yTile, this.zTile);
         int var21 = super.worldObj.getBlockMetadata(this.xTile, this.yTile, this.zTile);
         if(var19.equals(Block.getBlockById(this.inTile)) && var21 == this.inData) {
            ;
         }
      } else {
         ++this.ticksInAir;
         if(this.ticksInAir > 1 && this.ticksInAir < 3) {
            for(int var20 = 0; var20 < 3; ++var20) {
               this.doFiringParticles();
            }
         }

         Vec3 var22 = SpellHelper.createVec3(super.posX, super.posY, super.posZ);
         Vec3 var23 = SpellHelper.createVec3(super.posX + super.motionX, super.posY + super.motionY, super.posZ + super.motionZ);
         MovingObjectPosition var4 = super.worldObj.func_147447_a(var22, var23, true, false, false);
         var22 = SpellHelper.createVec3(super.posX, super.posY, super.posZ);
         var23 = SpellHelper.createVec3(super.posX + super.motionX, super.posY + super.motionY, super.posZ + super.motionZ);
         if(var4 != null) {
            var23 = SpellHelper.createVec3(var4.hitVec.xCoord, var4.hitVec.yCoord, var4.hitVec.zCoord);
         }

         Entity var24 = null;
         List var25 = super.worldObj.getEntitiesWithinAABBExcludingEntity(this, super.boundingBox.addCoord(super.motionX, super.motionY, super.motionZ).expand(1.0D, 1.0D, 1.0D));
         var7 = 0.0D;
         Iterator var9 = var25.iterator();

         while(var9.hasNext()) {
            Entity var10 = (Entity)var9.next();
            if(var10.canBeCollidedWith() && (var10 != this.shootingEntity || this.ticksInAir >= 5)) {
               float var11 = 0.3F;
               AxisAlignedBB var12 = var10.boundingBox.expand((double)var11, (double)var11, (double)var11);
               MovingObjectPosition var13 = var12.calculateIntercept(var22, var23);
               if(var13 != null) {
                  double var14 = var22.distanceTo(var13.hitVec);
                  if(var14 < var7 || var7 == 0.0D) {
                     var24 = var10;
                     var7 = var14;
                  }
               }
            }
         }

         if(var24 != null) {
            var4 = new MovingObjectPosition(var24);
         }

         if(var4 != null) {
            this.onImpact(var4);
            if(this.scheduledForDeath) {
               this.setDead();
            }
         }

         super.posX += super.motionX;
         super.posY += super.motionY;
         super.posZ += super.motionZ;
         MathHelper.sqrt_double(super.motionX * super.motionX + super.motionZ * super.motionZ);
         this.setPosition(super.posX, super.posY, super.posZ);
      }

   }

   public void doFiringParticles() {
      super.worldObj.spawnParticle("mobSpellAmbient", super.posX + this.smallGauss(0.1D), super.posY + this.smallGauss(0.1D), super.posZ + this.smallGauss(0.1D), 0.5D, 0.5D, 0.5D);
      super.worldObj.spawnParticle("flame", super.posX, super.posY, super.posZ, this.gaussian(super.motionX), this.gaussian(super.motionY), this.gaussian(super.motionZ));
   }

   public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
      par1NBTTagCompound.setShort("xTile", (short)this.xTile);
      par1NBTTagCompound.setShort("yTile", (short)this.yTile);
      par1NBTTagCompound.setShort("zTile", (short)this.zTile);
      par1NBTTagCompound.setByte("inTile", (byte)this.inTile);
      par1NBTTagCompound.setByte("inData", (byte)this.inData);
      par1NBTTagCompound.setByte("inGround", (byte)(this.inGround?1:0));
   }

   public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
      this.xTile = par1NBTTagCompound.getShort("xTile");
      this.yTile = par1NBTTagCompound.getShort("yTile");
      this.zTile = par1NBTTagCompound.getShort("zTile");
      this.inTile = par1NBTTagCompound.getByte("inTile") & 255;
      this.inData = par1NBTTagCompound.getByte("inData") & 255;
      this.inGround = par1NBTTagCompound.getByte("inGround") == 1;
   }

   protected boolean canTriggerWalking() {
      return false;
   }

   @SideOnly(Side.CLIENT)
   public float getShadowSize() {
      return 0.0F;
   }

   public void setKnockbackStrength(int par1) {}

   public boolean canAttackWithItem() {
      return false;
   }

   public void setIsCritical(boolean par1) {
      byte var2 = super.dataWatcher.getWatchableObjectByte(16);
      if(par1) {
         super.dataWatcher.updateObject(16, Byte.valueOf((byte)(var2 | 1)));
      } else {
         super.dataWatcher.updateObject(16, Byte.valueOf((byte)(var2 & -2)));
      }

   }

   public boolean getIsCritical() {
      byte var1 = super.dataWatcher.getWatchableObjectByte(16);
      return (var1 & 1) != 0;
   }

   public void onImpact(MovingObjectPosition mop) {
      if(mop.typeOfHit == MovingObjectType.ENTITY && mop.entityHit != null) {
         if(mop.entityHit == this.shootingEntity) {
            return;
         }

         this.onImpact(mop.entityHit);
      } else if(mop.typeOfHit == MovingObjectType.BLOCK) {
         this.groundImpact(mop.sideHit);
         super.worldObj.createExplosion(this.shootingEntity, super.posX, super.posY, super.posZ, 2.0F, false);
      }

   }

   public void onImpact(Entity mop) {
      if(mop == this.shootingEntity && this.ticksInAir > 3) {
         this.shootingEntity.attackEntityFrom(DamageSource.causeMobDamage(this.shootingEntity), 1.0F);
         this.setDead();
      } else {
         this.doDamage(this.damage + this.d6(), mop);
         super.worldObj.createExplosion(this.shootingEntity, super.posX, super.posY, super.posZ, 2.0F, false);
      }

      this.spawnHitParticles("magicCrit", 8);
      this.setDead();
   }

   private int d6() {
      return super.rand.nextInt(6) + 1;
   }

   public void spawnHitParticles(String string, int i) {
      for(int particles = 0; particles < i; ++particles) {
         super.worldObj.spawnParticle(string, super.posX, super.posY - (double)(string == "portal"?1:0), super.posZ, this.gaussian(super.motionX), this.gaussian(super.motionY), this.gaussian(super.motionZ));
      }

   }

   public void doDamage(int i, Entity mop) {
      mop.attackEntityFrom(this.getDamageSource(), (float)i);
   }

   public DamageSource getDamageSource() {
      return DamageSource.causeMobDamage(this.shootingEntity);
   }

   public void groundImpact(int sideHit) {
      this.ricochet(sideHit);
   }

   public double smallGauss(double d) {
      return ((double)super.worldObj.rand.nextFloat() - 0.5D) * d;
   }

   public double gaussian(double d) {
      return d + d * (((double)super.rand.nextFloat() - 0.5D) / 4.0D);
   }

   private void ricochet(int sideHit) {
      switch(sideHit) {
      case 0:
      case 1:
         super.motionY *= -1.0D;
         break;
      case 2:
      case 3:
         super.motionZ *= -1.0D;
         break;
      case 4:
      case 5:
         super.motionX *= -1.0D;
      }

      ++this.ricochetCounter;
      if(this.ricochetCounter > this.getRicochetMax()) {
         this.scheduledForDeath = true;

         for(int particles = 0; particles < 4; ++particles) {
            switch(sideHit) {
            case 0:
               super.worldObj.spawnParticle("smoke", super.posX, super.posY, super.posZ, this.gaussian(0.1D), -this.gaussian(0.1D), this.gaussian(0.1D));
               break;
            case 1:
               super.worldObj.spawnParticle("smoke", super.posX, super.posY, super.posZ, this.gaussian(0.1D), this.gaussian(0.1D), this.gaussian(0.1D));
               break;
            case 2:
               super.worldObj.spawnParticle("smoke", super.posX, super.posY, super.posZ, this.gaussian(0.1D), this.gaussian(0.1D), -this.gaussian(0.1D));
               break;
            case 3:
               super.worldObj.spawnParticle("smoke", super.posX, super.posY, super.posZ, this.gaussian(0.1D), this.gaussian(0.1D), this.gaussian(0.1D));
               break;
            case 4:
               super.worldObj.spawnParticle("smoke", super.posX, super.posY, super.posZ, -this.gaussian(0.1D), this.gaussian(0.1D), this.gaussian(0.1D));
               break;
            case 5:
               super.worldObj.spawnParticle("smoke", super.posX, super.posY, super.posZ, this.gaussian(0.1D), this.gaussian(0.1D), this.gaussian(0.1D));
            }
         }
      }

   }

   private int getRicochetMax() {
      return 3;
   }
}
