package WayofTime.alchemicalWizardry.common.entity.projectile;

import WayofTime.alchemicalWizardry.common.entity.projectile.EnergyBlastProjectile;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import WayofTime.alchemicalWizardry.common.spell.simple.SpellTeleport;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.EnderTeleportEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public class TeleportProjectile extends EnergyBlastProjectile {

   private boolean isEntityTeleport;


   public TeleportProjectile(World par1World) {
      super(par1World);
      super.motionX *= 3.0D;
      super.motionY *= 3.0D;
      super.motionZ *= 3.0D;
   }

   public TeleportProjectile(World par1World, double par2, double par4, double par6) {
      super(par1World, par2, par4, par6);
      super.motionX *= 3.0D;
      super.motionY *= 3.0D;
      super.motionZ *= 3.0D;
   }

   public TeleportProjectile(World par1World, EntityLivingBase par2EntityPlayer, int damage, boolean flag) {
      super(par1World, par2EntityPlayer, damage);
      this.isEntityTeleport = flag;
      super.motionX *= 3.0D;
      super.motionY *= 3.0D;
      super.motionZ *= 3.0D;
   }

   public TeleportProjectile(World par1World, EntityLivingBase par2EntityPlayer, int damage, int maxTicksInAir, double posX, double posY, double posZ, float rotationYaw, float rotationPitch, boolean flag) {
      super(par1World, par2EntityPlayer, damage, maxTicksInAir, posX, posY, posZ, rotationYaw, rotationPitch);
      this.isEntityTeleport = flag;
      super.motionX *= 3.0D;
      super.motionY *= 3.0D;
      super.motionZ *= 3.0D;
   }

   public DamageSource getDamageSource() {
      return DamageSource.causeMobDamage(super.shootingEntity);
   }

   public void onImpact(MovingObjectPosition mop) {
      if(mop.typeOfHit == MovingObjectType.ENTITY && mop.entityHit != null) {
         if(mop.entityHit == super.shootingEntity) {
            return;
         }

         this.onImpact(mop.entityHit);
      } else if(mop.typeOfHit == MovingObjectType.BLOCK && this.isEntityTeleport && super.shootingEntity != null && super.shootingEntity instanceof EntityPlayerMP) {
         EntityPlayerMP entityplayermp = (EntityPlayerMP)super.shootingEntity;
         if(entityplayermp.worldObj == super.worldObj) {
            EnderTeleportEvent event = new EnderTeleportEvent(entityplayermp, super.posX, super.posY, super.posZ, 5.0F);
            if(!MinecraftForge.EVENT_BUS.post(event)) {
               if(super.shootingEntity.isRiding()) {
                  super.shootingEntity.mountEntity((Entity)null);
               }

               super.shootingEntity.setPositionAndUpdate(event.targetX, event.targetY, event.targetZ);
            }
         }
      }

      this.setDead();
   }

   public void onImpact(Entity mop) {
      if(mop == super.shootingEntity && super.ticksInAir > 3) {
         this.setDead();
      } else if(mop instanceof EntityLivingBase) {
         if(this.isEntityTeleport) {
            if(super.shootingEntity != null && super.shootingEntity instanceof EntityPlayerMP) {
               EntityPlayerMP entityplayermp = (EntityPlayerMP)super.shootingEntity;
               if(entityplayermp.worldObj == super.worldObj) {
                  EnderTeleportEvent event = new EnderTeleportEvent(entityplayermp, super.posX, super.posY, super.posZ, 5.0F);
                  if(!MinecraftForge.EVENT_BUS.post(event)) {
                     if(super.shootingEntity.isRiding()) {
                        super.shootingEntity.mountEntity((Entity)null);
                     }

                     super.shootingEntity.setPositionAndUpdate(event.targetX, event.targetY, event.targetZ);
                  }
               }
            }
         } else {
            if(this.getThrower() != null && FakePlayerUtils.callEntityDamageByEntityEvent(this.getThrower(), mop, DamageCause.ENTITY_ATTACK, 1.0D).isCancelled()) {
               this.setDead();
               return;
            }

            SpellTeleport.teleportRandomly((EntityLivingBase)mop, 64.0D);
         }
      }

      this.spawnHitParticles("magicCrit", 8);
      this.setDead();
   }

   public void doFiringParticles() {
      SpellHelper.sendParticleToAllAround(super.worldObj, super.posX, super.posY, super.posZ, 30, super.worldObj.provider.dimensionId, "mobSpellAmbient", super.posX + this.smallGauss(0.1D), super.posY + this.smallGauss(0.1D), super.posZ + this.smallGauss(0.1D), 0.5D, 0.5D, 0.5D);
      SpellHelper.sendParticleToAllAround(super.worldObj, super.posX, super.posY, super.posZ, 30, super.worldObj.provider.dimensionId, "portal", super.posX, super.posY, super.posZ, -super.motionX, -super.motionY, -super.motionZ);
   }

   public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
      super.writeEntityToNBT(par1NBTTagCompound);
      par1NBTTagCompound.setBoolean("isEntityTeleport", this.isEntityTeleport);
   }

   public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
      super.readEntityFromNBT(par1NBTTagCompound);
      this.isEntityTeleport = par1NBTTagCompound.getBoolean("isEntityTeleport");
   }
}
