package WayofTime.alchemicalWizardry.common.entity.projectile;

import WayofTime.alchemicalWizardry.common.entity.projectile.EnergyBlastProjectile;
import com.gamerforea.bloodmagic.ExplosionByPlayer;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.World;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public class ExplosionProjectile extends EnergyBlastProjectile {

   protected boolean causesEnvDamage;


   public ExplosionProjectile(World par1World) {
      super(par1World);
   }

   public ExplosionProjectile(World par1World, double par2, double par4, double par6) {
      super(par1World, par2, par4, par6);
   }

   public ExplosionProjectile(World par1World, EntityLivingBase par2EntityPlayer, int damage, boolean flag) {
      super(par1World, par2EntityPlayer, damage);
      this.causesEnvDamage = flag;
   }

   public ExplosionProjectile(World par1World, EntityLivingBase par2EntityPlayer, int damage, int maxTicksInAir, double posX, double posY, double posZ, float rotationYaw, float rotationPitch, boolean flag) {
      super(par1World, par2EntityPlayer, damage, maxTicksInAir, posX, posY, posZ, rotationYaw, rotationPitch);
      this.causesEnvDamage = flag;
   }

   public ExplosionProjectile(World par1World, EntityLivingBase par2EntityLivingBase, EntityLivingBase par3EntityLivingBase, float par4, float par5, int damage, int maxTicksInAir, boolean flag) {
      super(par1World, par2EntityLivingBase, par3EntityLivingBase, par4, par5, damage, maxTicksInAir);
      this.causesEnvDamage = flag;
   }

   public DamageSource getDamageSource() {
      return DamageSource.causeMobDamage(super.shootingEntity);
   }

   public void onImpact(MovingObjectPosition mop) {
      if(this.getThrower() != null && this.getThrower() instanceof EntityPlayer) {
         if(mop.typeOfHit == MovingObjectType.ENTITY && mop.entityHit != null) {
            if(mop.entityHit == super.shootingEntity) {
               return;
            }

            this.onImpact(mop.entityHit);
            ExplosionByPlayer.createExplosion((EntityPlayer)this.getThrower(), super.worldObj, this, super.posX, super.posY, super.posZ, 2.0F, this.causesEnvDamage);
         } else if(mop.typeOfHit == MovingObjectType.BLOCK) {
            ExplosionByPlayer.createExplosion((EntityPlayer)this.getThrower(), super.worldObj, this, super.posX, super.posY, super.posZ, 2.0F, this.causesEnvDamage);
         }

         this.setDead();
      } else {
         this.setDead();
      }
   }

   public void onImpact(Entity mop) {
      if(mop == super.shootingEntity && super.ticksInAir > 3) {
         super.shootingEntity.attackEntityFrom(DamageSource.causeMobDamage(super.shootingEntity), 1.0F);
         this.setDead();
      } else if(mop instanceof EntityLivingBase) {
         if(this.getThrower() != null && FakePlayerUtils.callEntityDamageByEntityEvent(this.getThrower(), mop, DamageCause.ENTITY_ATTACK, 1.0D).isCancelled()) {
            this.setDead();
            return;
         }

         this.doDamage(super.projectileDamage, mop);
      }

      this.spawnHitParticles("magicCrit", 8);
      this.setDead();
   }

   public void doFiringParticles() {
      super.worldObj.spawnParticle("mobSpellAmbient", super.posX + this.smallGauss(0.1D), super.posY + this.smallGauss(0.1D), super.posZ + this.smallGauss(0.1D), 0.5D, 0.5D, 0.5D);
      super.worldObj.spawnParticle("explode", super.posX, super.posY, super.posZ, this.gaussian(super.motionX), this.gaussian(super.motionY), this.gaussian(super.motionZ));
   }

   public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
      super.writeEntityToNBT(par1NBTTagCompound);
      par1NBTTagCompound.setBoolean("causesEnvDamage", this.causesEnvDamage);
   }

   public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
      super.readEntityFromNBT(par1NBTTagCompound);
      this.causesEnvDamage = par1NBTTagCompound.getBoolean("causesEnvDamage");
   }
}
