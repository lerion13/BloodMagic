package WayofTime.alchemicalWizardry.common.entity.projectile;

import WayofTime.alchemicalWizardry.common.entity.projectile.EnergyBlastProjectile;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.potion.Potion;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.World;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public class FireProjectile extends EnergyBlastProjectile {

   public FireProjectile(World par1World) {
      super(par1World);
   }

   public FireProjectile(World par1World, double par2, double par4, double par6) {
      super(par1World, par2, par4, par6);
   }

   public FireProjectile(World par1World, EntityLivingBase par2EntityPlayer, int damage) {
      super(par1World, par2EntityPlayer, damage);
   }

   public FireProjectile(World par1World, EntityLivingBase par2EntityPlayer, int damage, int maxTicksInAir, double posX, double posY, double posZ, float rotationYaw, float rotationPitch) {
      super(par1World, par2EntityPlayer, damage, maxTicksInAir, posX, posY, posZ, rotationYaw, rotationPitch);
   }

   public FireProjectile(World par1World, EntityLivingBase par2EntityLivingBase, EntityLivingBase par3EntityLivingBase, float par4, float par5, int damage, int maxTicksInAir) {
      super(par1World, par2EntityLivingBase, par3EntityLivingBase, par4, par5, damage, maxTicksInAir);
   }

   public DamageSource getDamageSource() {
      return DamageSource.causeMobDamage(super.shootingEntity);
   }

   public void onImpact(MovingObjectPosition mop) {
      if(mop.typeOfHit == MovingObjectType.ENTITY && mop.entityHit != null) {
         if(mop.entityHit == super.shootingEntity) {
            return;
         }

         this.onImpact(mop.entityHit);
      } else if(mop.typeOfHit == MovingObjectType.BLOCK) {
         for(int i = -1; i <= 1; ++i) {
            for(int j = -1; j <= 1; ++j) {
               for(int k = -1; k <= 1; ++k) {
                  if(super.worldObj.isAirBlock((int)super.posX + i, (int)super.posY + j, (int)super.posZ + k) && this.getThrower() != null && this.getThrower() instanceof EntityPlayer && !FakePlayerUtils.callBlockBreakEvent((int)super.posX + i, (int)super.posY + j, (int)super.posZ + k, (EntityPlayer)this.getThrower()).isCancelled()) {
                     super.worldObj.setBlock((int)super.posX + i, (int)super.posY + j, (int)super.posZ + k, Blocks.fire);
                  }
               }
            }
         }
      }

      this.setDead();
   }

   public void onImpact(Entity mop) {
      if(mop == super.shootingEntity && super.ticksInAir > 3) {
         super.shootingEntity.attackEntityFrom(DamageSource.causeMobDamage(super.shootingEntity), 1.0F);
         this.setDead();
      } else if(mop instanceof EntityLivingBase) {
         if(this.getThrower() != null && FakePlayerUtils.callEntityDamageByEntityEvent(this.getThrower(), mop, DamageCause.ENTITY_ATTACK, 1.0D).isCancelled()) {
            this.setDead();
            return;
         }

         ((EntityLivingBase)mop).setFire(10 * super.projectileDamage);
         ((EntityLivingBase)mop).setRevengeTarget(super.shootingEntity);
         if(!((EntityLivingBase)mop).isPotionActive(Potion.fireResistance) && !((EntityLivingBase)mop).isImmuneToFire()) {
            this.doDamage(super.projectileDamage, mop);
            ((EntityLivingBase)mop).hurtResistantTime = 0;
         } else {
            ((EntityLivingBase)mop).attackEntityFrom(DamageSource.causeMobDamage(super.shootingEntity), 1.0F);
         }
      }

      if(super.worldObj.isAirBlock((int)super.posX, (int)super.posY, (int)super.posZ) && this.getThrower() != null && this.getThrower() instanceof EntityPlayer && !FakePlayerUtils.callBlockBreakEvent((int)super.posX, (int)super.posY, (int)super.posZ, (EntityPlayer)this.getThrower()).isCancelled()) {
         super.worldObj.setBlock((int)super.posX, (int)super.posY, (int)super.posZ, Blocks.fire);
      }

      this.spawnHitParticles("magicCrit", 8);
      this.setDead();
   }
}
