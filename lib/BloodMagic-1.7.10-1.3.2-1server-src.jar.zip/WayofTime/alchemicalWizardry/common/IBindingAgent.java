package WayofTime.alchemicalWizardry.common;


public interface IBindingAgent {

   float getSuccessRateForPotionNumber(int var1);
}
