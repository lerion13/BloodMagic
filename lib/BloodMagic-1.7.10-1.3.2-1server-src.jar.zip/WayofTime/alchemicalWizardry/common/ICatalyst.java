package WayofTime.alchemicalWizardry.common;


public interface ICatalyst {

   int getCatalystLevel();

   boolean isConcentration();
}
