package WayofTime.alchemicalWizardry.common;


public interface IFillingAgent {

   int getFilledAmountForPotionNumber(int var1);
}
