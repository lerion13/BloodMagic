package WayofTime.alchemicalWizardry.common.demonVillage.demonHoard;


public enum DemonType {

   NORMAL("NORMAL", 0),
   FIRE("FIRE", 1),
   EARTH("EARTH", 2),
   ICE("ICE", 3),
   WIND("WIND", 4);
   // $FF: synthetic field
   private static final DemonType[] $VALUES = new DemonType[]{NORMAL, FIRE, EARTH, ICE, WIND};


   private DemonType(String var1, int var2) {}

}
