package WayofTime.alchemicalWizardry.common.demonVillage.demonHoard;

import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.DemonType;
import WayofTime.alchemicalWizardry.common.demonVillage.tileEntity.TEDemonPortal;
import net.minecraft.world.World;

public abstract class DemonHoardPacket {

   public abstract int summonDemons(TEDemonPortal var1, World var2, int var3, int var4, int var5, DemonType var6, int var7, boolean var8);

   public abstract boolean canFitType(DemonType var1);

   public abstract float getRelativeChance(DemonType var1, int var2, boolean var3);
}
