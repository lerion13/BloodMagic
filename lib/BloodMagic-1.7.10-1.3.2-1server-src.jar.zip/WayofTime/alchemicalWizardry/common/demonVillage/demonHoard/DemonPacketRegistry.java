package WayofTime.alchemicalWizardry.common.demonVillage.demonHoard;

import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.DemonHoardPacket;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.DemonType;
import WayofTime.alchemicalWizardry.common.demonVillage.tileEntity.TEDemonPortal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.world.World;

public class DemonPacketRegistry {

   public static Map packetMap = new HashMap();


   public static boolean registerDemonPacket(String string, DemonHoardPacket packet) {
      if(!packetMap.containsValue(string) && packet != null) {
         packetMap.put(string, packet);
         return true;
      } else {
         return false;
      }
   }

   public static String getDemonPacketName(DemonType type, int tier, boolean spawnGuardian) {
      float totalChance = 0.0F;
      Iterator i$ = packetMap.entrySet().iterator();

      Entry entry;
      DemonHoardPacket packet;
      while(i$.hasNext()) {
         entry = (Entry)i$.next();
         packet = (DemonHoardPacket)entry.getValue();
         if(packet != null) {
            totalChance += packet.getRelativeChance(type, tier, spawnGuardian);
         }
      }

      i$ = packetMap.entrySet().iterator();

      while(i$.hasNext()) {
         entry = (Entry)i$.next();
         packet = (DemonHoardPacket)entry.getValue();
         if(packet != null) {
            float relativeChance = packet.getRelativeChance(type, tier, spawnGuardian);
            if(relativeChance >= totalChance) {
               return (String)entry.getKey();
            }

            totalChance -= relativeChance;
         }
      }

      return "";
   }

   public static int spawnDemons(TEDemonPortal teDemonPortal, World world, int x, int y, int z, DemonType type, int tier, boolean spawnGuardian) {
      return spawnDemons(teDemonPortal, world, x, y, z, getDemonPacketName(type, tier, spawnGuardian), type, tier, spawnGuardian);
   }

   public static int spawnDemons(TEDemonPortal teDemonPortal, World world, int x, int y, int z, String name, DemonType type, int tier, boolean spawnGuardian) {
      DemonHoardPacket packet = (DemonHoardPacket)packetMap.get(name);
      return packet != null?packet.summonDemons(teDemonPortal, world, x, y, z, type, tier, spawnGuardian):0;
   }

}
