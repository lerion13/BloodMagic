package WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.EntityMinorDemonGrunt;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.IHoardDemon;
import WayofTime.alchemicalWizardry.common.entity.projectile.ExplosionProjectile;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class EntityMinorDemonGruntEarth extends EntityMinorDemonGrunt {

   public EntityMinorDemonGruntEarth(World par1World) {
      super(par1World);
      this.setDemonID(AlchemicalWizardry.entityMinorDemonGruntEarthID);
   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      int i = this.isTamed()?20:20;
      if(par1Entity instanceof IHoardDemon && ((IHoardDemon)par1Entity).isSamePortal(this)) {
         return false;
      } else {
         if(par1Entity instanceof EntityLivingBase) {
            ((EntityLivingBase)par1Entity).addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 200, 2));
         }

         return par1Entity.attackEntityFrom(DamageSource.causeMobDamage(this), (float)i);
      }
   }

   public void attackEntityWithRangedAttack(EntityLivingBase par1EntityLivingBase, float par2) {
      if(!(par1EntityLivingBase instanceof IHoardDemon) || !((IHoardDemon)par1EntityLivingBase).isSamePortal(this)) {
         ExplosionProjectile hol = new ExplosionProjectile(super.worldObj, this, par1EntityLivingBase, 1.8F, 0.0F, 15, 600, false);
         super.worldObj.spawnEntityInWorld(hol);
      }
   }
}
