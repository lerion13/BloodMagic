package WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.EntityMinorDemonGrunt;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.IHoardDemon;
import WayofTime.alchemicalWizardry.common.entity.projectile.IceProjectile;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class EntityMinorDemonGruntIce extends EntityMinorDemonGrunt {

   public EntityMinorDemonGruntIce(World par1World) {
      super(par1World);
      this.setDemonID(AlchemicalWizardry.entityMinorDemonGruntIceID);
   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      int i = this.isTamed()?20:20;
      return par1Entity instanceof IHoardDemon && ((IHoardDemon)par1Entity).isSamePortal(this)?false:par1Entity.attackEntityFrom(DamageSource.causeMobDamage(this), (float)i);
   }

   public void attackEntityWithRangedAttack(EntityLivingBase par1EntityLivingBase, float par2) {
      if(!(par1EntityLivingBase instanceof IHoardDemon) || !((IHoardDemon)par1EntityLivingBase).isSamePortal(this)) {
         IceProjectile hol = new IceProjectile(super.worldObj, this, par1EntityLivingBase, 1.8F, 0.0F, 15, 600);
         super.worldObj.spawnEntityInWorld(hol);
      }
   }
}
