package WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon;

import WayofTime.alchemicalWizardry.api.Int3;

public interface IHoardDemon {

   void setPortalLocation(Int3 var1);

   Int3 getPortalLocation();

   boolean thrallDemon(Int3 var1);

   boolean isSamePortal(IHoardDemon var1);
}
