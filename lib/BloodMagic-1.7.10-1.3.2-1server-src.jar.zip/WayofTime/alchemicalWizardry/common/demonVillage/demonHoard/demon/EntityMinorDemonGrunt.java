package WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.ModItems;
import WayofTime.alchemicalWizardry.api.Int3;
import WayofTime.alchemicalWizardry.api.rituals.IMasterRitualStone;
import WayofTime.alchemicalWizardry.api.rituals.LocalRitualStorage;
import WayofTime.alchemicalWizardry.common.EntityAITargetAggroCloaking;
import WayofTime.alchemicalWizardry.common.demonVillage.ai.EntityAIOccasionalRangedAttack;
import WayofTime.alchemicalWizardry.common.demonVillage.ai.EntityDemonAIHurtByTarget;
import WayofTime.alchemicalWizardry.common.demonVillage.ai.IOccasionalRangedAttackMob;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.IHoardDemon;
import WayofTime.alchemicalWizardry.common.demonVillage.tileEntity.TEDemonPortal;
import WayofTime.alchemicalWizardry.common.entity.mob.EntityDemon;
import WayofTime.alchemicalWizardry.common.entity.projectile.HolyProjectile;
import WayofTime.alchemicalWizardry.common.rituals.LocalStorageAlphaPact;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIFollowOwner;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIOwnerHurtByTarget;
import net.minecraft.entity.ai.EntityAIOwnerHurtTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.pathfinding.PathEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class EntityMinorDemonGrunt extends EntityDemon implements IOccasionalRangedAttackMob, IHoardDemon {

   private EntityAIOccasionalRangedAttack aiArrowAttack = new EntityAIOccasionalRangedAttack(this, 1.0D, 40, 40, 15.0F, 5.0D);
   private EntityAIAttackOnCollide aiAttackOnCollide = new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.2D, false);
   private boolean isAngry = true;
   private Int3 demonPortal;
   private static float maxTamedHealth = 200.0F;
   private static float maxUntamedHealth = 200.0F;
   private boolean enthralled = false;


   public EntityMinorDemonGrunt(World par1World) {
      super(par1World, AlchemicalWizardry.entityMinorDemonGruntID);
      this.setSize(0.7F, 1.8F);
      this.getNavigator().setAvoidsWater(true);
      super.tasks.addTask(1, new EntityAISwimming(this));
      super.tasks.addTask(2, super.aiSit);
      super.tasks.addTask(3, new EntityAIFollowOwner(this, 1.0D, 10.0F, 2.0F));
      super.tasks.addTask(4, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(5, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(6, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIOwnerHurtByTarget(this));
      super.targetTasks.addTask(2, new EntityAIOwnerHurtTarget(this));
      super.targetTasks.addTask(3, new EntityDemonAIHurtByTarget(this, true));
      super.targetTasks.addTask(4, new EntityAITargetAggroCloaking(this, EntityPlayer.class, 0, false, 0));
      this.setAggro(false);
      this.setTamed(false);
      this.demonPortal = new Int3(0, 0, 0);
      if(par1World != null && !par1World.isRemote) {
         this.setCombatTask();
      }

   }

   public boolean isTameable() {
      return false;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.30000001192092896D);
      if(this.isTamed()) {
         this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue((double)maxTamedHealth);
      } else {
         this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue((double)maxUntamedHealth);
      }

   }

   protected void dropFewItems(boolean par1, int par2) {
      if(!this.getDoesDropCrystal()) {
         ItemStack lifeShardStack = new ItemStack(ModItems.baseItems, 1, 28);
         ItemStack soulShardStack = new ItemStack(ModItems.baseItems, 1, 29);
         int dropAmount = 0;

         for(int drop = 0; drop <= par2; ++drop) {
            dropAmount += super.worldObj.rand.nextFloat() < 0.6F?1:0;
         }

         ItemStack var7 = super.worldObj.rand.nextBoolean()?lifeShardStack:soulShardStack;
         var7.stackSize = dropAmount;
         if(dropAmount > 0) {
            this.entityDropItem(var7, 0.0F);
         }
      } else {
         super.dropFewItems(par1, par2);
      }

   }

   public void setPortalLocation(Int3 position) {
      this.demonPortal = position;
   }

   public Int3 getPortalLocation() {
      return this.demonPortal;
   }

   public boolean isAIEnabled() {
      return true;
   }

   public void setAttackTarget(EntityLivingBase par1EntityLivingBase) {
      super.setAttackTarget(par1EntityLivingBase);
      if(par1EntityLivingBase == null) {
         this.setAngry(false);
      } else if(!this.isTamed()) {
         this.setAngry(true);
      }

   }

   public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
      super.writeEntityToNBT(par1NBTTagCompound);
      par1NBTTagCompound.setBoolean("Angry", this.isAngry());
      this.demonPortal.writeToNBT(par1NBTTagCompound);
   }

   public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
      super.readEntityFromNBT(par1NBTTagCompound);
      this.setAngry(par1NBTTagCompound.getBoolean("Angry"));
      this.demonPortal = Int3.readFromNBT(par1NBTTagCompound);
      this.setCombatTask();
   }

   protected String getLivingSound() {
      return "none";
   }

   protected String getHurtSound() {
      return "none";
   }

   protected String getDeathSound() {
      return "mob.wolf.death";
   }

   protected float getSoundVolume() {
      return 0.4F;
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
   }

   public void onUpdate() {
      if(!this.enthralled) {
         TileEntity tile = super.worldObj.getTileEntity(this.demonPortal.xCoord, this.demonPortal.yCoord, this.demonPortal.zCoord);
         if(tile instanceof TEDemonPortal) {
            ((TEDemonPortal)tile).enthrallDemon(this);
            this.enthralled = true;
         } else if(tile instanceof IMasterRitualStone) {
            IMasterRitualStone stone = (IMasterRitualStone)tile;
            LocalRitualStorage stor = stone.getLocalStorage();
            if(stor instanceof LocalStorageAlphaPact) {
               LocalStorageAlphaPact storage = (LocalStorageAlphaPact)stor;
               storage.thrallDemon(this);
            }
         }
      }

      super.onUpdate();
   }

   public float getEyeHeight() {
      return super.height * 0.8F;
   }

   public int getVerticalFaceSpeed() {
      return this.isSitting()?20:super.getVerticalFaceSpeed();
   }

   public void setTamed(boolean par1) {
      super.setTamed(par1);
      if(par1) {
         this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue((double)maxTamedHealth);
      } else {
         this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue((double)maxUntamedHealth);
      }

   }

   public boolean interact(EntityPlayer par1EntityPlayer) {
      ItemStack itemstack = par1EntityPlayer.inventory.getCurrentItem();
      if(this.isTamed()) {
         if(itemstack != null && itemstack.getItem() instanceof ItemFood) {
            ItemFood itemfood = (ItemFood)itemstack.getItem();
            if(itemfood.isWolfsFavoriteMeat() && super.dataWatcher.getWatchableObjectFloat(18) < maxTamedHealth) {
               if(!par1EntityPlayer.capabilities.isCreativeMode) {
                  --itemstack.stackSize;
               }

               this.heal((float)itemfood.func_150905_g(itemstack));
               if(itemstack.stackSize <= 0) {
                  par1EntityPlayer.inventory.setInventorySlotContents(par1EntityPlayer.inventory.currentItem, (ItemStack)null);
               }

               return true;
            }
         }

         if(this.getOwner() instanceof EntityPlayer && SpellHelper.getUsername(par1EntityPlayer).equalsIgnoreCase(SpellHelper.getUsername((EntityPlayer)this.getOwner())) && !this.isBreedingItem(itemstack)) {
            if(!super.worldObj.isRemote) {
               super.aiSit.setSitting(!this.isSitting());
               super.isJumping = false;
               this.setPathToEntity((PathEntity)null);
               this.setTarget((Entity)null);
               this.setAttackTarget((EntityLivingBase)null);
            }

            this.sendSittingMessageToPlayer(par1EntityPlayer, !this.isSitting());
         }
      } else if(this.isTameable() && itemstack != null && itemstack.getItem().equals(ModItems.weakBloodOrb) && !this.isAngry()) {
         if(!par1EntityPlayer.capabilities.isCreativeMode) {
            --itemstack.stackSize;
         }

         if(itemstack.stackSize <= 0) {
            par1EntityPlayer.inventory.setInventorySlotContents(par1EntityPlayer.inventory.currentItem, (ItemStack)null);
         }

         if(!super.worldObj.isRemote) {
            if(super.rand.nextInt(1) == 0) {
               this.setTamed(true);
               this.setPathToEntity((PathEntity)null);
               this.setAttackTarget((EntityLivingBase)null);
               super.aiSit.setSitting(true);
               this.setHealth(maxTamedHealth);
               this.func_152115_b(par1EntityPlayer.getUniqueID().toString());
               this.playTameEffect(true);
               super.worldObj.setEntityState(this, (byte)7);
            } else {
               this.playTameEffect(false);
               super.worldObj.setEntityState(this, (byte)6);
            }
         }

         return true;
      }

      return super.interact(par1EntityPlayer);
   }

   public boolean isBreedingItem(ItemStack par1ItemStack) {
      return false;
   }

   public boolean isAngry() {
      return this.isAngry;
   }

   public void setAngry(boolean angry) {
      this.isAngry = angry;
   }

   public boolean canMateWith(EntityAnimal par1EntityAnimal) {
      return false;
   }

   protected boolean canDespawn() {
      return false;
   }

   public boolean func_142018_a(EntityLivingBase par1EntityLivingBase, EntityLivingBase par2EntityLivingBase) {
      if(!(par1EntityLivingBase instanceof EntityCreeper) && !(par1EntityLivingBase instanceof EntityGhast)) {
         if(par1EntityLivingBase instanceof EntityDemon) {
            EntityDemon entitywolf = (EntityDemon)par1EntityLivingBase;
            if(entitywolf.isTamed() && entitywolf.getOwner() == par2EntityLivingBase) {
               return false;
            }
         }

         return par1EntityLivingBase instanceof EntityPlayer && par2EntityLivingBase instanceof EntityPlayer && !((EntityPlayer)par2EntityLivingBase).canAttackPlayer((EntityPlayer)par1EntityLivingBase)?false:!(par1EntityLivingBase instanceof EntityHorse) || !((EntityHorse)par1EntityLivingBase).isTame();
      } else {
         return false;
      }
   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      int i = this.isTamed()?20:20;
      return par1Entity instanceof IHoardDemon && ((IHoardDemon)par1Entity).isSamePortal(this)?false:par1Entity.attackEntityFrom(DamageSource.causeMobDamage(this), (float)i);
   }

   public void attackEntityWithRangedAttack(EntityLivingBase par1EntityLivingBase, float par2) {
      if(!(par1EntityLivingBase instanceof IHoardDemon) || !((IHoardDemon)par1EntityLivingBase).isSamePortal(this)) {
         HolyProjectile hol = new HolyProjectile(super.worldObj, this, par1EntityLivingBase, 1.8F, 0.0F, 15, 600);
         super.worldObj.spawnEntityInWorld(hol);
      }
   }

   public void setCombatTask() {
      super.tasks.removeTask(this.aiAttackOnCollide);
      super.tasks.removeTask(this.aiArrowAttack);
      super.tasks.addTask(4, this.aiArrowAttack);
      super.tasks.addTask(5, this.aiAttackOnCollide);
   }

   public boolean shouldUseRangedAttack() {
      return true;
   }

   public boolean thrallDemon(Int3 location) {
      this.setPortalLocation(location);
      return true;
   }

   public boolean isSamePortal(IHoardDemon demon) {
      Int3 position = demon.getPortalLocation();
      TileEntity portal = super.worldObj.getTileEntity(this.demonPortal.xCoord, this.demonPortal.yCoord, this.demonPortal.zCoord);
      return portal instanceof TEDemonPortal?portal == super.worldObj.getTileEntity(position.xCoord, position.yCoord, position.zCoord):false;
   }

}
