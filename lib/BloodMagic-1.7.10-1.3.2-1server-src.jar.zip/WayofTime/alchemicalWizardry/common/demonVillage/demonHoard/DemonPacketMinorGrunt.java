package WayofTime.alchemicalWizardry.common.demonVillage.demonHoard;

import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.DemonHoardPacket;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.DemonType;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.EntityMinorDemonGrunt;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.EntityMinorDemonGruntEarth;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.EntityMinorDemonGruntFire;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.EntityMinorDemonGruntGuardian;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.EntityMinorDemonGruntGuardianEarth;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.EntityMinorDemonGruntGuardianFire;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.EntityMinorDemonGruntGuardianIce;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.EntityMinorDemonGruntGuardianWind;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.EntityMinorDemonGruntIce;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.EntityMinorDemonGruntWind;
import WayofTime.alchemicalWizardry.common.demonVillage.tileEntity.TEDemonPortal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.World;

public class DemonPacketMinorGrunt extends DemonHoardPacket {

   public boolean canFitType(DemonType type) {
      return true;
   }

   public float getRelativeChance(DemonType type, int tier, boolean spawnGuardian) {
      return 1.0F;
   }

   public int summonDemons(TEDemonPortal teDemonPortal, World world, int x, int y, int z, DemonType type, int tier, boolean spawnGuardian) {
      Object entity;
      switch(DemonPacketMinorGrunt.NamelessClass1562703736.$SwitchMap$WayofTime$alchemicalWizardry$common$demonVillage$demonHoard$DemonType[type.ordinal()]) {
      case 1:
         if(spawnGuardian) {
            entity = new EntityMinorDemonGruntGuardianFire(world);
         } else {
            entity = new EntityMinorDemonGruntFire(world);
         }
         break;
      case 2:
         if(spawnGuardian) {
            entity = new EntityMinorDemonGruntGuardianIce(world);
         } else {
            entity = new EntityMinorDemonGruntIce(world);
         }
         break;
      case 3:
         if(spawnGuardian) {
            entity = new EntityMinorDemonGruntGuardianEarth(world);
         } else {
            entity = new EntityMinorDemonGruntEarth(world);
         }
         break;
      case 4:
         if(spawnGuardian) {
            entity = new EntityMinorDemonGruntGuardianWind(world);
         } else {
            entity = new EntityMinorDemonGruntWind(world);
         }
         break;
      case 5:
      default:
         if(spawnGuardian) {
            entity = new EntityMinorDemonGruntGuardian(world);
         } else {
            entity = new EntityMinorDemonGrunt(world);
         }
      }

      ((EntityMinorDemonGrunt)entity).setPosition((double)x, (double)y, (double)z);
      world.spawnEntityInWorld((Entity)entity);
      teDemonPortal.enthrallDemon((EntityLivingBase)entity);
      ((EntityMinorDemonGrunt)entity).setAggro(true);
      ((EntityMinorDemonGrunt)entity).setDropCrystal(false);
      return spawnGuardian?3:1;
   }

   // $FF: synthetic class
   static class NamelessClass1562703736 {

      // $FF: synthetic field
      static final int[] $SwitchMap$WayofTime$alchemicalWizardry$common$demonVillage$demonHoard$DemonType = new int[DemonType.values().length];


      static {
         try {
            $SwitchMap$WayofTime$alchemicalWizardry$common$demonVillage$demonHoard$DemonType[DemonType.FIRE.ordinal()] = 1;
         } catch (NoSuchFieldError var5) {
            ;
         }

         try {
            $SwitchMap$WayofTime$alchemicalWizardry$common$demonVillage$demonHoard$DemonType[DemonType.ICE.ordinal()] = 2;
         } catch (NoSuchFieldError var4) {
            ;
         }

         try {
            $SwitchMap$WayofTime$alchemicalWizardry$common$demonVillage$demonHoard$DemonType[DemonType.EARTH.ordinal()] = 3;
         } catch (NoSuchFieldError var3) {
            ;
         }

         try {
            $SwitchMap$WayofTime$alchemicalWizardry$common$demonVillage$demonHoard$DemonType[DemonType.WIND.ordinal()] = 4;
         } catch (NoSuchFieldError var2) {
            ;
         }

         try {
            $SwitchMap$WayofTime$alchemicalWizardry$common$demonVillage$demonHoard$DemonType[DemonType.NORMAL.ordinal()] = 5;
         } catch (NoSuchFieldError var1) {
            ;
         }

      }
   }
}
