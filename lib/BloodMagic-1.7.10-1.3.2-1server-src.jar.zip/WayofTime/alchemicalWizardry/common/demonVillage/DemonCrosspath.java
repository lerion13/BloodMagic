package WayofTime.alchemicalWizardry.common.demonVillage;

import net.minecraft.world.World;

public class DemonCrosspath {

   private int xCoord;
   private int yLevel;
   private int zCoord;


   public DemonCrosspath(int xCoord, int yLevel, int zCoord) {
      this.xCoord = xCoord;
      this.yLevel = yLevel;
      this.zCoord = zCoord;
   }

   public void createCrosspath(World world) {}
}
