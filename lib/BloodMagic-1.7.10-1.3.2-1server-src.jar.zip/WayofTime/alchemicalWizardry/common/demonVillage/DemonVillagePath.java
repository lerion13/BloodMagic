package WayofTime.alchemicalWizardry.common.demonVillage;

import WayofTime.alchemicalWizardry.ModBlocks;
import WayofTime.alchemicalWizardry.api.Int3;
import WayofTime.alchemicalWizardry.common.demonVillage.tileEntity.IRoadWard;
import WayofTime.alchemicalWizardry.common.demonVillage.tileEntity.TEDemonPortal;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFlower;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public class DemonVillagePath {

   public int xi;
   public int yi;
   public int zi;
   public ForgeDirection dir;
   public int length;
   public static boolean canGoDown = true;
   public static boolean tunnelIfObstructed = false;
   public static boolean createBridgeInAirIfObstructed = false;


   public DemonVillagePath(int xi, int yi, int zi, ForgeDirection dir, int length) {
      this.xi = xi;
      this.yi = yi;
      this.zi = zi;
      this.dir = dir;
      this.length = length;
   }

   public DemonVillagePath.Int3AndBool constructFullPath(TEDemonPortal portal, World world, int clearance) {
      int xPos = this.xi;
      int yPos = this.yi;
      int zPos = this.zi;
      int rad = this.getRoadRadius();
      int value = 0;
      int finalYPos = this.constructPartialPath(portal, world, clearance, xPos - rad * this.dir.offsetX, yPos, zPos - rad * this.dir.offsetZ, this.dir, this.length + rad, false);

      for(int position = -rad; position <= rad; ++position) {
         value = Math.max(this.constructPartialPath(portal, world, clearance, xPos - rad * this.dir.offsetX + position * this.dir.offsetZ, yPos, zPos - rad * this.dir.offsetZ + position * this.dir.offsetX, this.dir, this.length + 2 * rad, true), value);
         if(TEDemonPortal.printDebug) {
            System.out.println("" + (this.length + 2 * rad) + ", " + value + "");
         }
      }

      Int3 var12 = new Int3(xPos, finalYPos, zPos);
      boolean bool = value >= this.length + 2 * rad;
      return new DemonVillagePath.Int3AndBool(var12, bool);
   }

   public int constructPartialPath(TEDemonPortal portal, World world, int clearance, int xi, int yi, int zi, ForgeDirection dir, int length, boolean doConstruct) {
      int xPos = xi;
      int yPos = yi;
      int zPos = zi;
      int i = 0;

      while(i < length) {
         int xOffset = i * dir.offsetX;
         int zOffset = i * dir.offsetZ;
         boolean completed = false;
         int returnAmount = 0;

         while(true) {
            if(returnAmount <= clearance) {
               byte block1 = 1;
               Block block11 = world.getBlock(xPos + xOffset, yPos + block1 * returnAmount, zPos + zOffset);
               Block highBlock1 = world.getBlock(xPos + xOffset, yPos + block1 * returnAmount + 1, zPos + zOffset);
               if(!this.forceReplaceBlock(block11) && (block11.isReplaceable(world, xPos + xOffset, yPos + block1 * returnAmount, zPos + zOffset) || !this.isBlockReplaceable(block11) || !this.forceCanTunnelUnder(highBlock1) && !highBlock1.isReplaceable(world, xPos + xOffset, yPos + block1 * returnAmount + 1, zPos + zOffset))) {
                  label119: {
                     if(canGoDown) {
                        byte var25 = -1;
                        Block block2 = world.getBlock(xPos + xOffset, yPos + var25 * returnAmount, zPos + zOffset);
                        Block highBlock2 = world.getBlock(xPos + xOffset, yPos + var25 * returnAmount + 1, zPos + zOffset);
                        if(this.forceReplaceBlock(block2) || !block2.isReplaceable(world, xPos + xOffset, yPos + var25 * returnAmount, zPos + zOffset) && this.isBlockReplaceable(block2) && (this.forceCanTunnelUnder(highBlock2) || highBlock2.isReplaceable(world, xPos + xOffset, yPos + var25 * returnAmount + 1, zPos + zOffset))) {
                           if(doConstruct) {
                              world.setBlock(xPos + xOffset, yPos + var25 * returnAmount, zPos + zOffset, portal.getRoadBlock(), portal.getRoadMeta(), 3);
                           }

                           yPos += var25 * returnAmount;
                           completed = true;
                           break label119;
                        }
                     }

                     ++returnAmount;
                     continue;
                  }
               } else {
                  if(doConstruct) {
                     world.setBlock(xPos + xOffset, yPos + block1 * returnAmount, zPos + zOffset, portal.getRoadBlock(), portal.getRoadMeta(), 3);
                  }

                  yPos += block1 * returnAmount;
                  completed = true;
               }
            }

            if(!completed) {
               boolean var23 = true;
               Block var24;
               if(createBridgeInAirIfObstructed) {
                  var24 = world.getBlock(xPos + xOffset, yPos, zPos + zOffset);
                  if(!var24.isReplaceable(world, xPos + xOffset, yPos, zPos + zOffset) && this.isBlockReplaceable(var24) && this.forceReplaceBlock(var24)) {
                     var23 = true;
                  } else {
                     var23 = false;
                     if(doConstruct) {
                        world.setBlock(xPos + xOffset, yPos, zPos + zOffset, portal.getRoadBlock(), portal.getRoadMeta(), 3);
                     }
                  }
               } else if(tunnelIfObstructed) {
                  var24 = world.getBlock(xPos + xOffset, yPos, zPos + zOffset);
                  if(var24.isReplaceable(world, xPos + xOffset, yPos, zPos + zOffset) && !this.isBlockReplaceable(var24) && this.forceReplaceBlock(var24)) {
                     var23 = true;
                  } else {
                     var23 = false;
                     if(doConstruct) {
                        world.setBlock(xPos + xOffset, yPos, zPos + zOffset, portal.getRoadBlock(), portal.getRoadMeta(), 3);
                        world.setBlockToAir(xPos + xOffset, yPos + 1, zPos + zOffset);
                        world.setBlockToAir(xPos + xOffset, yPos + 2, zPos + zOffset);
                        world.setBlockToAir(xPos + xOffset, yPos + 3, zPos + zOffset);
                     }
                  }
               }

               if(var23) {
                  return doConstruct?i:yPos;
               }
            }

            ++i;
            break;
         }
      }

      return doConstruct?length:yPos;
   }

   public Int3 getFinalLocation(World world, int clearance) {
      int xPos = this.xi;
      int yPos = this.yi;
      int zPos = this.zi;
      int i = 0;

      while(i < this.length) {
         int xOffset = i * this.dir.offsetX;
         int zOffset = i * this.dir.offsetZ;
         int yOffset = 0;

         while(true) {
            if(yOffset <= clearance) {
               byte sign = 1;
               Block block1 = world.getBlock(xPos + xOffset, yPos + sign * yOffset, zPos + zOffset);
               Block highBlock1 = world.getBlock(xPos + xOffset, yPos + sign * yOffset + 1, zPos + zOffset);
               if(!this.forceReplaceBlock(block1) && (block1.isReplaceable(world, xPos + xOffset, yPos + sign * yOffset, zPos + zOffset) || !this.isBlockReplaceable(block1) || !this.forceCanTunnelUnder(highBlock1) && !highBlock1.isReplaceable(world, xPos + xOffset, yPos + sign * yOffset + 1, zPos + zOffset))) {
                  byte var15 = -1;
                  Block block2 = world.getBlock(xPos + xOffset, yPos + var15 * yOffset, zPos + zOffset);
                  Block highBlock2 = world.getBlock(xPos + xOffset, yPos + var15 * yOffset + 1, zPos + zOffset);
                  if(!this.forceReplaceBlock(block2) && (block2.isReplaceable(world, xPos + xOffset, yPos + var15 * yOffset, zPos + zOffset) || !this.isBlockReplaceable(block2) || !this.forceCanTunnelUnder(highBlock2) && !highBlock2.isReplaceable(world, xPos + xOffset, yPos + var15 * yOffset + 1, zPos + zOffset))) {
                     ++yOffset;
                     continue;
                  }

                  yPos += var15 * yOffset;
               } else {
                  yPos += sign * yOffset;
               }
            }

            ++i;
            break;
         }
      }

      return new Int3(xPos, yPos, zPos);
   }

   public int getRoadRadius() {
      return 1;
   }

   public boolean isBlockReplaceable(Block block) {
      return block.getMaterial() != Material.leaves && block.getMaterial() != Material.vine && !(block instanceof IRoadWard)?!block.equals(ModBlocks.blockDemonPortal):false;
   }

   public boolean forceReplaceBlock(Block block) {
      return block.getMaterial().isLiquid();
   }

   public boolean forceCanTunnelUnder(Block block) {
      return block instanceof BlockFlower || block == Blocks.double_plant;
   }


   public class Int3AndBool {

      public Int3 coords;
      public boolean bool;


      public Int3AndBool(Int3 int3, boolean bool) {
         this.coords = int3;
         this.bool = bool;
      }
   }
}
