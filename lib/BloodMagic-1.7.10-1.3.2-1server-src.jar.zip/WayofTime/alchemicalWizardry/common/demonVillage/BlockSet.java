package WayofTime.alchemicalWizardry.common.demonVillage;

import WayofTime.alchemicalWizardry.api.Int3;
import WayofTime.alchemicalWizardry.common.demonVillage.loot.DemonVillageLootRegistry;
import WayofTime.alchemicalWizardry.common.demonVillage.tileEntity.IBlockPortalNode;
import WayofTime.alchemicalWizardry.common.demonVillage.tileEntity.ITilePortalNode;
import WayofTime.alchemicalWizardry.common.demonVillage.tileEntity.TEDemonPortal;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.common.registry.GameRegistry.UniqueIdentifier;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.BlockLadder;
import net.minecraft.block.BlockRedstoneComparator;
import net.minecraft.block.BlockRedstoneRepeater;
import net.minecraft.block.BlockStairs;
import net.minecraft.block.BlockTorch;
import net.minecraft.block.BlockTrapDoor;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.IInventory;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public class BlockSet {

   protected String blockid;
   protected int[] metadata;
   protected List positions;


   public BlockSet() {
      this(Blocks.stone);
   }

   public BlockSet(String blockid) {
      this.blockid = blockid;
      this.metadata = new int[4];
      this.positions = new ArrayList();
   }

   public BlockSet(Block block) {
      this(getPairedIdForBlock(block));
   }

   public BlockSet(Block block, int meta) {
      this(block);

      int div;
      for(div = 0; div < this.metadata.length; ++div) {
         this.metadata[div] = meta;
      }

      int[] mod;
      int[] northSet;
      int[] eastSet;
      int[] southSet;
      int[] westSet;
      int[] var11;
      if(block instanceof BlockStairs) {
         var11 = new int[]{2, 3, 0, 1};
         mod = new int[]{1, 0, 2, 3};
         northSet = new int[]{3, 2, 1, 0};
         eastSet = new int[]{0, 1, 3, 2};
         southSet = new int[]{6, 7, 4, 5};
         westSet = new int[]{5, 4, 6, 7};
         int[] southUpSet = new int[]{7, 6, 5, 4};
         int[] westUpSet = new int[]{4, 5, 7, 6};
         switch(meta) {
         case 0:
            this.metadata = eastSet;
            break;
         case 1:
            this.metadata = mod;
            break;
         case 2:
            this.metadata = var11;
            break;
         case 3:
            this.metadata = northSet;
            break;
         case 4:
            this.metadata = westUpSet;
            break;
         case 5:
            this.metadata = westSet;
            break;
         case 6:
            this.metadata = southSet;
            break;
         case 7:
            this.metadata = southUpSet;
         }
      } else if(block instanceof BlockLadder) {
         var11 = new int[]{3, 2, 5, 4};
         mod = new int[]{4, 5, 3, 2};
         northSet = new int[]{2, 3, 4, 5};
         eastSet = new int[]{5, 4, 2, 3};
         switch(meta) {
         case 2:
            this.metadata = northSet;
            break;
         case 3:
            this.metadata = var11;
            break;
         case 4:
            this.metadata = mod;
            break;
         case 5:
            this.metadata = eastSet;
         }
      } else {
         int var12;
         if(block instanceof BlockTrapDoor) {
            div = meta / 4;
            var12 = meta % 4;
            northSet = new int[]{1 + div * 4, 0 + div * 4, 3 + div * 4, 2 + div * 4};
            eastSet = new int[]{2 + div * 4, 3 + div * 4, 1 + div * 4, 0 + div * 4};
            southSet = new int[]{0 + div * 4, 1 + div * 4, 2 + div * 4, 3 + div * 4};
            westSet = new int[]{3 + div * 4, 2 + div * 4, 0 + div * 4, 1 + div * 4};
            switch(var12) {
            case 0:
               this.metadata = southSet;
               break;
            case 1:
               this.metadata = northSet;
               break;
            case 2:
               this.metadata = eastSet;
               break;
            case 3:
               this.metadata = westSet;
            }
         } else if(block instanceof BlockTorch) {
            var11 = new int[]{3, 4, 1, 2};
            mod = new int[]{2, 1, 3, 4};
            northSet = new int[]{4, 3, 2, 1};
            eastSet = new int[]{1, 2, 4, 3};
            switch(meta) {
            case 1:
               this.metadata = eastSet;
               break;
            case 2:
               this.metadata = mod;
               break;
            case 3:
               this.metadata = var11;
               break;
            case 4:
               this.metadata = northSet;
            }
         } else if(block instanceof BlockDoor) {
            var11 = new int[]{3, 1, 2, 0};
            mod = new int[]{0, 2, 3, 1};
            northSet = new int[]{1, 3, 0, 2};
            eastSet = new int[]{2, 0, 1, 3};
            switch(meta) {
            case 0:
               this.metadata = mod;
               break;
            case 1:
               this.metadata = northSet;
               break;
            case 2:
               this.metadata = eastSet;
               break;
            case 3:
               this.metadata = var11;
            }
         } else if(block instanceof BlockRedstoneComparator) {
            div = meta / 4;
            var12 = meta % 4;
            northSet = new int[]{0 + div * 4, 2 + div * 4, 3 + div * 4, 1 + div * 4};
            eastSet = new int[]{1 + div * 4, 3 + div * 4, 0 + div * 4, 2 + div * 4};
            southSet = new int[]{2 + div * 4, 0 + div * 4, 1 + div * 4, 3 + div * 4};
            westSet = new int[]{3 + div * 4, 1 + div * 4, 2 + div * 4, 0 + div * 4};
            switch(var12) {
            case 0:
               this.metadata = northSet;
               break;
            case 1:
               this.metadata = eastSet;
               break;
            case 2:
               this.metadata = southSet;
               break;
            case 3:
               this.metadata = westSet;
            }
         } else if(block instanceof BlockRedstoneRepeater) {
            div = meta / 4;
            var12 = meta % 4;
            northSet = new int[]{0 + div * 4, 2 + div * 4, 3 + div * 4, 1 + div * 4};
            eastSet = new int[]{1 + div * 4, 3 + div * 4, 0 + div * 4, 2 + div * 4};
            southSet = new int[]{2 + div * 4, 0 + div * 4, 1 + div * 4, 3 + div * 4};
            westSet = new int[]{3 + div * 4, 1 + div * 4, 2 + div * 4, 0 + div * 4};
            switch(var12) {
            case 0:
               this.metadata = northSet;
               break;
            case 1:
               this.metadata = eastSet;
               break;
            case 2:
               this.metadata = southSet;
               break;
            case 3:
               this.metadata = westSet;
            }
         }
      }

   }

   public List getPositions() {
      return this.positions;
   }

   public void addPositionToBlock(int xOffset, int yOffset, int zOffset) {
      this.positions.add(new Int3(xOffset, yOffset, zOffset));
   }

   public Block getBlock() {
      return getBlockForString(this.blockid);
   }

   public static String getPairedIdForBlock(Block block) {
      UniqueIdentifier un = GameRegistry.findUniqueIdentifierFor(block);
      String name = "";
      if(un != null) {
         name = un.modId + ":" + un.name;
      }

      return name;
   }

   public static Block getBlockForString(String str) {
      String[] parts = str.split(":");
      String modId = parts[0];
      String name = parts[1];
      return GameRegistry.findBlock(modId, name);
   }

   public int getMetaForDirection(ForgeDirection dir) {
      if(this.metadata.length < 4) {
         return 0;
      } else {
         switch(BlockSet.NamelessClass604650437.$SwitchMap$net$minecraftforge$common$util$ForgeDirection[dir.ordinal()]) {
         case 1:
            return this.metadata[0];
         case 2:
            return this.metadata[1];
         case 3:
            return this.metadata[2];
         case 4:
            return this.metadata[3];
         default:
            return 0;
         }
      }
   }

   public void buildAtIndex(TEDemonPortal teDemonPortal, World world, int xCoord, int yCoord, int zCoord, ForgeDirection dir, int index, boolean populateInventories, int tier) {
      Block block = this.getBlock();
      if(index < this.positions.size() && block != null) {
         Int3 position = (Int3)this.positions.get(index);
         int xOff = position.xCoord;
         int yOff = position.yCoord;
         int zOff = position.zCoord;
         int meta = this.getMetaForDirection(dir);
         switch(BlockSet.NamelessClass604650437.$SwitchMap$net$minecraftforge$common$util$ForgeDirection[dir.ordinal()]) {
         case 1:
         default:
            break;
         case 2:
            xOff *= -1;
            zOff *= -1;
            break;
         case 3:
            int tile = zOff;
            zOff = xOff * -1;
            xOff = tile;
            break;
         case 4:
            int temp2 = zOff * -1;
            zOff = xOff;
            xOff = temp2;
         }

         world.setBlock(xCoord + xOff, yCoord + yOff, zCoord + zOff, block, meta, 3);
         if(populateInventories) {
            this.populateIfIInventory(world, xCoord + xOff, yCoord + yOff, zCoord + zOff, tier);
         }

         if(block instanceof IBlockPortalNode) {
            TileEntity tile1 = world.getTileEntity(xCoord + xOff, yCoord + yOff, zCoord + zOff);
            if(tile1 instanceof ITilePortalNode) {
               ((ITilePortalNode)tile1).setPortalLocation(teDemonPortal);
            }
         }

      }
   }

   public void populateIfIInventory(World world, int x, int y, int z, int tier) {
      TileEntity tile = world.getTileEntity(x, y, z);
      if(tile instanceof IInventory) {
         DemonVillageLootRegistry.populateChest((IInventory)tile, tier);
      }

   }

   public void buildAll(TEDemonPortal teDemonPortal, World world, int xCoord, int yCoord, int zCoord, ForgeDirection dir, boolean populateInventories, int tier) {
      for(int i = 0; i < this.positions.size(); ++i) {
         this.buildAtIndex(teDemonPortal, world, xCoord, yCoord, zCoord, dir, i, populateInventories, tier);
      }

   }

   public boolean isContained(Block block, int defaultMeta) {
      Block thisBlock = this.getBlock();
      return thisBlock == null?false:thisBlock.equals(block) && this.metadata[0] == defaultMeta;
   }

   // $FF: synthetic class
   static class NamelessClass604650437 {

      // $FF: synthetic field
      static final int[] $SwitchMap$net$minecraftforge$common$util$ForgeDirection = new int[ForgeDirection.values().length];


      static {
         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.NORTH.ordinal()] = 1;
         } catch (NoSuchFieldError var4) {
            ;
         }

         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.SOUTH.ordinal()] = 2;
         } catch (NoSuchFieldError var3) {
            ;
         }

         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.WEST.ordinal()] = 3;
         } catch (NoSuchFieldError var2) {
            ;
         }

         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.EAST.ordinal()] = 4;
         } catch (NoSuchFieldError var1) {
            ;
         }

      }
   }
}
