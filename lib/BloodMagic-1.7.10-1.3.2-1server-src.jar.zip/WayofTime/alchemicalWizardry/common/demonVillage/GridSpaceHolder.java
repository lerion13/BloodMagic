package WayofTime.alchemicalWizardry.common.demonVillage;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.ModBlocks;
import WayofTime.alchemicalWizardry.common.demonVillage.GridSpace;
import WayofTime.alchemicalWizardry.common.demonVillage.tileEntity.TEDemonPortal;
import net.minecraft.block.Block;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public class GridSpaceHolder {

   public GridSpace[][] area = new GridSpace[1][1];
   public int negXRadius;
   public int posXRadius;
   public int negZRadius;
   public int posZRadius;


   public GridSpaceHolder() {
      this.area[0][0] = new GridSpace();
   }

   public void expandAreaInNegX() {
      GridSpace[][] newGrid = new GridSpace[this.negXRadius + this.posXRadius + 2][this.negZRadius + this.posZRadius + 1];

      int i;
      for(i = 0; i <= this.negZRadius + this.posZRadius; ++i) {
         newGrid[0][i] = new GridSpace();
      }

      for(i = 0; i <= this.negXRadius + this.posXRadius; ++i) {
         for(int j = 0; j <= this.negZRadius + this.posZRadius; ++j) {
            newGrid[i + 1][j] = this.area[i][j];
         }
      }

      this.area = newGrid;
      ++this.negXRadius;
   }

   public void expandAreaInPosX() {
      GridSpace[][] newGrid = new GridSpace[this.negXRadius + this.posXRadius + 2][this.negZRadius + this.posZRadius + 1];

      int i;
      for(i = 0; i <= this.negZRadius + this.posZRadius; ++i) {
         newGrid[this.negXRadius + this.posXRadius + 1][i] = new GridSpace();
      }

      for(i = 0; i <= this.negXRadius + this.posXRadius; ++i) {
         for(int j = 0; j <= this.negZRadius + this.posZRadius; ++j) {
            newGrid[i][j] = this.area[i][j];
         }
      }

      this.area = newGrid;
      ++this.posXRadius;
   }

   public void expandAreaInNegZ() {
      GridSpace[][] newGrid = new GridSpace[this.negXRadius + this.posXRadius + 1][this.negZRadius + this.posZRadius + 2];

      int i;
      for(i = 0; i <= this.negXRadius + this.posXRadius; ++i) {
         newGrid[i][0] = new GridSpace();
      }

      for(i = 0; i <= this.negXRadius + this.posXRadius; ++i) {
         for(int j = 0; j <= this.negZRadius + this.posZRadius; ++j) {
            newGrid[i][j + 1] = this.area[i][j];
         }
      }

      this.area = newGrid;
      ++this.negZRadius;
   }

   public void expandAreaInPosZ() {
      GridSpace[][] newGrid = new GridSpace[this.negXRadius + this.posXRadius + 1][this.negZRadius + this.posZRadius + 2];

      int i;
      for(i = 0; i <= this.negXRadius + this.posXRadius; ++i) {
         newGrid[i][this.negZRadius + this.posZRadius + 1] = new GridSpace();
      }

      for(i = 0; i <= this.negXRadius + this.posXRadius; ++i) {
         for(int j = 0; j <= this.negZRadius + this.posZRadius; ++j) {
            newGrid[i][j] = this.area[i][j];
         }
      }

      this.area = newGrid;
      ++this.posZRadius;
   }

   public GridSpace getGridSpace(int x, int z) {
      return x <= this.posXRadius && x >= -this.negXRadius && z <= this.posZRadius && z >= -this.negZRadius?this.area[x + this.negXRadius][z + this.negZRadius]:new GridSpace();
   }

   public void setGridSpace(int x, int z, GridSpace space) {
      if(x > this.posXRadius) {
         this.expandAreaInPosX();
         this.setGridSpace(x, z, space);
      } else if(x < -this.negXRadius) {
         this.expandAreaInNegX();
         this.setGridSpace(x, z, space);
      } else if(z > this.posZRadius) {
         this.expandAreaInPosZ();
         this.setGridSpace(x, z, space);
      } else if(z < -this.negZRadius) {
         this.expandAreaInNegZ();
         this.setGridSpace(x, z, space);
      } else {
         this.area[x + this.negXRadius][z + this.negZRadius] = space;
      }
   }

   public boolean doesContainAll(GridSpaceHolder master, int xInit, int zInit, ForgeDirection dir) {
      if(master == null) {
         return false;
      } else {
         if(TEDemonPortal.printDebug) {
            AlchemicalWizardry.logger.info("negXRadius: " + this.negXRadius + " posXRadius: " + this.posXRadius + " negZRadius: " + this.negZRadius + " posZRadius: " + this.posZRadius);
         }

         for(int i = -this.negXRadius; i <= this.posXRadius; ++i) {
            for(int j = -this.negZRadius; j <= this.posZRadius; ++j) {
               GridSpace thisSpace = this.getGridSpace(i, j);
               if(!thisSpace.isEmpty()) {
                  if(TEDemonPortal.printDebug) {
                     AlchemicalWizardry.logger.info("x: " + i + " z: " + j);
                  }

                  boolean xOff = false;
                  boolean zOff = false;
                  int var10;
                  int var11;
                  switch(GridSpaceHolder.NamelessClass676422500.$SwitchMap$net$minecraftforge$common$util$ForgeDirection[dir.ordinal()]) {
                  case 1:
                     var10 = -i;
                     var11 = -j;
                     break;
                  case 2:
                     var10 = j;
                     var11 = -i;
                     break;
                  case 3:
                     var10 = -j;
                     var11 = i;
                     break;
                  default:
                     var10 = i;
                     var11 = j;
                  }

                  if(!master.getGridSpace(xInit + var10, zInit + var11).isEmpty()) {
                     return false;
                  }
               }
            }
         }

         return true;
      }
   }

   public void setAllGridSpaces(int xInit, int zInit, int yLevel, ForgeDirection dir, int type, GridSpaceHolder master) {
      if(TEDemonPortal.printDebug) {
         AlchemicalWizardry.logger.info("Grid space selected: (" + xInit + "," + zInit + ")");
      }

      if(master != null) {
         for(int i = -this.negXRadius; i <= this.posXRadius; ++i) {
            for(int j = -this.negZRadius; j <= this.posZRadius; ++j) {
               GridSpace thisSpace = this.getGridSpace(i, j);
               if(!thisSpace.isEmpty()) {
                  boolean xOff = false;
                  boolean zOff = false;
                  int var12;
                  int var13;
                  switch(GridSpaceHolder.NamelessClass676422500.$SwitchMap$net$minecraftforge$common$util$ForgeDirection[dir.ordinal()]) {
                  case 1:
                     var13 = -i;
                     var12 = -j;
                     break;
                  case 2:
                     var13 = j;
                     var12 = -i;
                     break;
                  case 3:
                     var13 = -j;
                     var12 = i;
                     break;
                  default:
                     var13 = i;
                     var12 = j;
                  }

                  if(TEDemonPortal.printDebug) {
                     AlchemicalWizardry.logger.info("Grid space (" + (xInit + var13) + "," + (zInit + var12) + ")");
                  }

                  master.setGridSpace(xInit + var13, zInit + var12, new GridSpace(type, yLevel));
               }
            }
         }
      }

   }

   public void destroyAllInGridSpaces(World world, int xCoord, int yCoord, int zCoord, ForgeDirection dir) {
      for(int i = -this.negXRadius; i <= this.posXRadius; ++i) {
         for(int j = -this.negZRadius; j <= this.posZRadius; ++j) {
            GridSpace thisSpace = this.getGridSpace(i, j);
            if(!thisSpace.isEmpty()) {
               boolean xOff = false;
               boolean zOff = false;
               int var14;
               int var15;
               switch(GridSpaceHolder.NamelessClass676422500.$SwitchMap$net$minecraftforge$common$util$ForgeDirection[dir.ordinal()]) {
               case 1:
                  var14 = -i;
                  var15 = -j;
                  break;
               case 2:
                  var14 = j;
                  var15 = -i;
                  break;
               case 3:
                  var14 = -j;
                  var15 = i;
                  break;
               default:
                  var14 = i;
                  var15 = j;
               }

               for(int l = -2; l <= 2; ++l) {
                  for(int m = -2; m <= 2; ++m) {
                     Block block = world.getBlock(xCoord + var14 * 5 + l, yCoord, zCoord + var15 * 5 + m);
                     if(block != ModBlocks.blockDemonPortal) {
                        world.setBlockToAir(xCoord + var14 * 5 + l, yCoord, zCoord + var15 * 5 + m);
                     }
                  }
               }
            }
         }
      }

   }

   public int getNumberOfGridSpaces() {
      int num = 0;

      for(int i = -this.negXRadius; i <= this.posXRadius; ++i) {
         for(int j = -this.negZRadius; j <= this.posZRadius; ++j) {
            if(!this.getGridSpace(i, j).isEmpty()) {
               ++num;
            }
         }
      }

      return num;
   }

   // $FF: synthetic class
   static class NamelessClass676422500 {

      // $FF: synthetic field
      static final int[] $SwitchMap$net$minecraftforge$common$util$ForgeDirection = new int[ForgeDirection.values().length];


      static {
         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.SOUTH.ordinal()] = 1;
         } catch (NoSuchFieldError var3) {
            ;
         }

         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.WEST.ordinal()] = 2;
         } catch (NoSuchFieldError var2) {
            ;
         }

         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.EAST.ordinal()] = 3;
         } catch (NoSuchFieldError var1) {
            ;
         }

      }
   }
}
