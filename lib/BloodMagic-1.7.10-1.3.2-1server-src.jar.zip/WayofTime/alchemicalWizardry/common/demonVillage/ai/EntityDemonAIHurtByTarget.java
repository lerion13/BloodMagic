package WayofTime.alchemicalWizardry.common.demonVillage.ai;

import WayofTime.alchemicalWizardry.api.Int3;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.IHoardDemon;
import WayofTime.alchemicalWizardry.common.demonVillage.tileEntity.TEDemonPortal;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.tileentity.TileEntity;

public class EntityDemonAIHurtByTarget extends EntityAIHurtByTarget {

   boolean field_75312_a;
   private int revengeTimer;


   public EntityDemonAIHurtByTarget(EntityCreature demon, boolean callsForHelp) {
      super(demon, callsForHelp);
      this.field_75312_a = callsForHelp;
   }

   public void startExecuting() {
      Int3 portalPosition = ((IHoardDemon)super.taskOwner).getPortalLocation();
      if(portalPosition == null) {
         super.startExecuting();
      } else {
         TileEntity portal = super.taskOwner.worldObj.getTileEntity(portalPosition.xCoord, portalPosition.yCoord, portalPosition.zCoord);
         if(!(super.taskOwner.getAITarget() instanceof IHoardDemon) || !portalPosition.equals(((IHoardDemon)super.taskOwner.getAITarget()).getPortalLocation())) {
            super.taskOwner.setAttackTarget(super.taskOwner.getAITarget());
            this.revengeTimer = super.taskOwner.func_142015_aE();
            if(this.field_75312_a && super.taskOwner instanceof IHoardDemon && portal instanceof TEDemonPortal) {
               ((TEDemonPortal)portal).notifyDemons(super.taskOwner, super.taskOwner.getAITarget(), 25.0D);
            }

            super.startExecuting();
         }
      }
   }
}
