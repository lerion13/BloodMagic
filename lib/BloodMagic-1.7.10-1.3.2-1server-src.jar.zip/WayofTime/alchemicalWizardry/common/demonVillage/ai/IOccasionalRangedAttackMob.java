package WayofTime.alchemicalWizardry.common.demonVillage.ai;

import net.minecraft.entity.IRangedAttackMob;

public interface IOccasionalRangedAttackMob extends IRangedAttackMob {

   boolean shouldUseRangedAttack();
}
