package WayofTime.alchemicalWizardry.common.demonVillage.tileEntity;

import WayofTime.alchemicalWizardry.common.demonVillage.tileEntity.TEDemonPortal;

public interface ITilePortalNode {

   void setPortalLocation(TEDemonPortal var1);
}
