package WayofTime.alchemicalWizardry.common.demonVillage.tileEntity;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.Int3;
import WayofTime.alchemicalWizardry.common.block.BlockTeleposer;
import WayofTime.alchemicalWizardry.common.demonVillage.BuildingSchematic;
import WayofTime.alchemicalWizardry.common.demonVillage.DemonBuilding;
import WayofTime.alchemicalWizardry.common.demonVillage.DemonCrosspath;
import WayofTime.alchemicalWizardry.common.demonVillage.DemonVillagePath;
import WayofTime.alchemicalWizardry.common.demonVillage.GridSpace;
import WayofTime.alchemicalWizardry.common.demonVillage.GridSpaceHolder;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.DemonPacketRegistry;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.DemonType;
import WayofTime.alchemicalWizardry.common.demonVillage.demonHoard.demon.IHoardDemon;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.tileentity.TileEntity;
import net.minecraftforge.common.util.ForgeDirection;

public class TEDemonPortal extends TileEntity {

   public DemonType type;
   public static boolean printDebug = false;
   public static int limit = 100;
   public static int demonLimit = 100;
   public static int buildingGridDelay = 25;
   public static int roadGridDelay = 10;
   public static int demonHoardDelay = 40;
   public static float demonRoadChance = 0.3F;
   public static float demonHouseChance = 0.6F;
   public static float demonPortalChance = 0.5F;
   public static float demonHoardChance = 0.8F;
   public static float portalTickRate = 1.0F;
   public static int[] tierCostList = new int[]{1500};
   public static Set hoardList = new HashSet();
   public static List buildingList = new ArrayList();
   public Random rand;
   private GridSpace[][] area;
   private int negXRadius;
   private int posXRadius;
   private int negZRadius;
   private int posZRadius;
   private boolean isInitialized;
   public int houseCooldown;
   public int roadCooldown;
   public int tier;
   public int demonHouseCooldown;
   public int demonHoardCooldown;
   public float pointPool;
   public String nextDemonPortalName;
   public ForgeDirection nextDemonPortalDirection;
   public int buildingStage;
   public int delayBeforeParty;
   public int lockdownTimer;


   public TEDemonPortal() {
      this.type = DemonType.FIRE;
      this.rand = new Random();
      this.nextDemonPortalName = "";
      this.nextDemonPortalDirection = ForgeDirection.DOWN;
      this.buildingStage = -1;
      this.delayBeforeParty = 0;
      this.negXRadius = this.posXRadius = this.negZRadius = this.posZRadius = 1;
      this.area = new GridSpace[this.negXRadius + this.posXRadius + 1][this.negZRadius + this.posZRadius + 1];

      for(int xIndex = -this.negXRadius; xIndex <= this.posXRadius; ++xIndex) {
         for(int zIndex = -this.negZRadius; zIndex <= this.posZRadius; ++zIndex) {
            if(Math.abs(xIndex) != 1 && Math.abs(zIndex) != 1) {
               this.setGridSpace(xIndex, zIndex, new GridSpace());
            } else {
               this.setGridSpace(xIndex, zIndex, new GridSpace(3, 4));
            }
         }
      }

      this.isInitialized = false;
      this.setGridSpace(0, 0, new GridSpace(1, super.yCoord));
      this.houseCooldown = 0;
      this.roadCooldown = 0;
      this.tier = 0;
      this.lockdownTimer = 0;
   }

   public boolean isLockedDown() {
      return this.lockdownTimer > 0;
   }

   public float getRoadChance() {
      return this.isLockedDown()?0.0F:demonRoadChance;
   }

   public float getHouseChance() {
      return this.isLockedDown()?0.0F:demonHouseChance;
   }

   public float getDemonPortalChance() {
      return this.isLockedDown()?0.0F:demonPortalChance;
   }

   public float getDemonHoardChance() {
      return demonHoardChance;
   }

   public boolean decreaseRandomCooldown(int amount) {
      float totalChance = 0.0F;
      HashMap map = new HashMap();
      map.put("roadChance", Float.valueOf(this.getRoadChance()));
      map.put("houseChance", Float.valueOf(this.getHouseChance()));
      map.put("demonPortalChance", Float.valueOf(this.getDemonPortalChance()));
      map.put("demonHoardChance", Float.valueOf(this.getDemonHoardChance()));
      String action = "";

      Entry i$;
      for(Iterator pointer = map.entrySet().iterator(); pointer.hasNext(); totalChance += ((Float)i$.getValue()).floatValue()) {
         i$ = (Entry)pointer.next();
      }

      float pointer1 = this.rand.nextFloat() * totalChance;

      float value;
      for(Iterator i$1 = map.entrySet().iterator(); i$1.hasNext(); pointer1 -= value) {
         Entry entry = (Entry)i$1.next();
         value = ((Float)entry.getValue()).floatValue();
         if(pointer1 <= value) {
            action = (String)entry.getKey();
            break;
         }
      }

      if(action.equals("roadChance")) {
         if(this.roadCooldown <= 0) {
            return false;
         }

         this.roadCooldown -= amount;
      } else if(action.equals("houseChance")) {
         if(this.houseCooldown <= 0) {
            return false;
         }

         this.houseCooldown -= amount;
      } else if(action.equals("demonPortalChance")) {
         this.demonHouseCooldown += amount;
      } else if(action.equals("demonHoardChance")) {
         if(this.demonHoardCooldown <= 0) {
            return false;
         }

         this.demonHoardCooldown -= amount;
      }

      return true;
   }

   public void notifyDemons(EntityLivingBase demon, EntityLivingBase target, double radius) {
      this.lockdownTimer = 1000;
      Iterator i$ = hoardList.iterator();

      while(i$.hasNext()) {
         IHoardDemon thrallDemon = (IHoardDemon)i$.next();
         if(thrallDemon instanceof EntityCreature && thrallDemon != demon && ((EntityCreature)thrallDemon).getAttackTarget() == null && !((EntityCreature)thrallDemon).isOnSameTeam(target)) {
            double xf = demon.posX;
            double yf = demon.posY;
            double zf = demon.posZ;
            double xi = ((EntityCreature)thrallDemon).posX;
            double yi = ((EntityCreature)thrallDemon).posY;
            double zi = ((EntityCreature)thrallDemon).posZ;
            if((xi - xf) * (xi - xf) + (yi - yf) * (yi - yf) + (zi - zf) * (zi - zf) <= radius * radius) {
               ((EntityCreature)thrallDemon).setAttackTarget(target);
            } else {
               ((EntityCreature)thrallDemon).getNavigator().tryMoveToEntityLiving(target, 2.0D);
            }
         }
      }

   }

   public void notifyDemons(int xf, int yf, int zf, double radius) {
      Iterator i$ = hoardList.iterator();

      while(i$.hasNext()) {
         IHoardDemon thrallDemon = (IHoardDemon)i$.next();
         if(thrallDemon instanceof EntityCreature && ((EntityCreature)thrallDemon).getAttackTarget() == null) {
            double xi = ((EntityCreature)thrallDemon).posX;
            double yi = ((EntityCreature)thrallDemon).posY;
            double zi = ((EntityCreature)thrallDemon).posZ;
            if((xi - (double)xf) * (xi - (double)xf) + (yi - (double)yf) * (yi - (double)yf) + (zi - (double)zf) * (zi - (double)zf) <= radius * radius) {
               ((EntityCreature)thrallDemon).getNavigator().tryMoveToXYZ((double)xf, (double)yf, (double)zf, 1.0D);
            }
         }
      }

   }

   public void enthrallDemon(EntityLivingBase demon) {
      if(demon instanceof IHoardDemon) {
         boolean enthrall = ((IHoardDemon)demon).thrallDemon(new Int3(super.xCoord, super.yCoord, super.zCoord));
         if(enthrall) {
            hoardList.add((IHoardDemon)demon);
         }
      }

   }

   public void initialize() {
      if(!this.isInitialized) {
         DemonType[] types = DemonType.values();
         this.type = types[this.rand.nextInt(types.length)];

         for(int xIndex = -this.negXRadius; xIndex <= this.posXRadius; ++xIndex) {
            for(int zIndex = -this.negZRadius; zIndex <= this.posZRadius; ++zIndex) {
               if(Math.abs(xIndex) != 1 && Math.abs(zIndex) != 1) {
                  if(xIndex == 0 && zIndex == 0) {
                     this.setGridSpace(0, 0, new GridSpace(1, super.yCoord));
                  } else {
                     this.setGridSpace(xIndex, zIndex, new GridSpace());
                  }
               } else {
                  this.setGridSpace(xIndex, zIndex, new GridSpace(3, super.yCoord));
               }
            }
         }

         this.houseCooldown = buildingGridDelay;
         this.roadCooldown = roadGridDelay;
         this.demonHoardCooldown = demonHoardDelay;
         this.createRandomRoad();
         if(this.createRandomBuilding(1, this.tier) >= 1) {
            System.out.println("Portal building successfully found!");
            this.buildingStage = 0;
         }

         this.isInitialized = true;
      }
   }

   public void createParty() {
      super.worldObj.createExplosion((Entity)null, (double)(super.xCoord + this.rand.nextInt(10) - this.rand.nextInt(10)), (double)super.yCoord, (double)(super.zCoord + this.rand.nextInt(10) - this.rand.nextInt(10)), 5.0F * this.rand.nextFloat(), false);
   }

   public void start() {
      this.delayBeforeParty = 200;
   }

   public void updateEntity() {
      if(!super.worldObj.isRemote) {
         if(this.delayBeforeParty > 0) {
            --this.delayBeforeParty;
            if(this.rand.nextInt(20) == 0) {
               this.createParty();
            }

            if(this.delayBeforeParty <= 0) {
               super.worldObj.createExplosion((Entity)null, (double)super.xCoord, (double)super.yCoord, (double)super.zCoord, 15.0F, false);
               this.initialize();
            }

         } else if(this.isInitialized) {
            this.lockdownTimer = Math.max(0, this.lockdownTimer - 1);
            this.incrementPoints();
            this.assignPoints();
            if(printDebug) {
               AlchemicalWizardry.logger.info("Roads: " + this.roadCooldown + " Buildings: " + this.houseCooldown + " Lockdown: " + this.lockdownTimer);
            }

            if(this.buildingStage >= 0 && this.buildingStage <= 2) {
               if(printDebug) {
                  AlchemicalWizardry.logger.info("BuildingStage = " + this.buildingStage);
               }

               if(printDebug) {
                  AlchemicalWizardry.logger.info("Tier = " + this.tier);
               }

               this.createPortalBuilding(this.buildingStage, this.nextDemonPortalName, this.tier);
               ++this.buildingStage;
            } else {
               int complexityCost;
               if(this.roadCooldown <= 0) {
                  complexityCost = this.createRandomRoad();
                  if(complexityCost > 0) {
                     this.roadCooldown = roadGridDelay * complexityCost;
                  }
               }

               if(this.houseCooldown <= 0) {
                  complexityCost = this.createRandomBuilding(0, this.tier);
                  if(complexityCost > 0) {
                     this.houseCooldown = buildingGridDelay * complexityCost;
                  }
               }

               if(this.demonHoardCooldown <= 0 && hoardList.size() <= demonLimit) {
                  complexityCost = this.createRandomDemonHoard(this, this.tier, this.type, this.isLockedDown());
                  if(complexityCost > 0) {
                     this.demonHoardCooldown += demonHoardDelay * complexityCost;
                  }
               }

               if(this.tier < tierCostList.length && this.demonHouseCooldown > tierCostList[this.tier]) {
                  ++this.tier;
                  if(this.createRandomBuilding(1, this.tier) >= 1) {
                     this.buildingStage = 0;
                  }
               }

            }
         }
      }
   }

   public void assignPoints() {
      if((int)this.pointPool > 0 && this.decreaseRandomCooldown((int)this.pointPool)) {
         this.pointPool -= (float)((int)this.pointPool);
      }

   }

   public void incrementPoints() {
      this.pointPool += portalTickRate;
   }

   public void readFromNBT(NBTTagCompound par1NBTTagCompound) {
      super.readFromNBT(par1NBTTagCompound);
      this.negXRadius = par1NBTTagCompound.getInteger("negXRadius");
      this.negZRadius = par1NBTTagCompound.getInteger("negZRadius");
      this.posXRadius = par1NBTTagCompound.getInteger("posXRadius");
      this.posZRadius = par1NBTTagCompound.getInteger("posZRadius");
      this.houseCooldown = par1NBTTagCompound.getInteger("houseCooldown");
      this.roadCooldown = par1NBTTagCompound.getInteger("roadCooldown");
      this.demonHoardCooldown = par1NBTTagCompound.getInteger("demonHoardCooldown");
      this.area = new GridSpace[this.negXRadius + this.posXRadius + 1][this.negZRadius + this.posZRadius + 1];
      NBTTagList tagList = par1NBTTagCompound.getTagList("Grid", 10);

      for(int i = 0; i < tagList.tagCount(); ++i) {
         int length = this.negZRadius + this.posZRadius + 1;
         int x = i / length;
         int z = i % length;
         NBTTagCompound tag = tagList.getCompoundTagAt(i);
         GridSpace space = GridSpace.getGridFromTag(tag);
         this.area[x][z] = space;
      }

      this.isInitialized = par1NBTTagCompound.getBoolean("init");
      this.tier = par1NBTTagCompound.getInteger("tier");
      this.demonHouseCooldown = par1NBTTagCompound.getInteger("demonHouseCooldown");
      this.nextDemonPortalName = par1NBTTagCompound.getString("nextDemonPortalName");
      this.buildingStage = par1NBTTagCompound.getInteger("buildingStage");
      this.nextDemonPortalDirection = ForgeDirection.getOrientation(par1NBTTagCompound.getInteger("nextDemonPortalDirection"));
      this.pointPool = par1NBTTagCompound.getFloat("pointPool");
      this.lockdownTimer = par1NBTTagCompound.getInteger("lockdownTimer");
      this.delayBeforeParty = par1NBTTagCompound.getInteger("delayBeforeParty");
      this.type = DemonType.valueOf(par1NBTTagCompound.getString("demonType"));
   }

   public void writeToNBT(NBTTagCompound par1NBTTagCompound) {
      super.writeToNBT(par1NBTTagCompound);
      par1NBTTagCompound.setInteger("negXRadius", this.negXRadius);
      par1NBTTagCompound.setInteger("negZRadius", this.negZRadius);
      par1NBTTagCompound.setInteger("posXRadius", this.posXRadius);
      par1NBTTagCompound.setInteger("posZRadius", this.posZRadius);
      par1NBTTagCompound.setInteger("houseCooldown", this.houseCooldown);
      par1NBTTagCompound.setInteger("roadCooldown", this.roadCooldown);
      par1NBTTagCompound.setInteger("demonHoardCooldown", this.demonHoardCooldown);
      NBTTagList gridList = new NBTTagList();

      for(int i = 0; i <= this.negXRadius + this.posXRadius; ++i) {
         for(int j = 0; j <= this.negZRadius + this.posZRadius; ++j) {
            int var10000 = i + (this.negZRadius + this.posZRadius + 1) * j;
            GridSpace space = this.area[i][j];
            NBTTagCompound nextTag;
            if(space == null) {
               nextTag = (new GridSpace()).getTag();
            } else {
               nextTag = space.getTag();
            }

            gridList.appendTag(nextTag);
         }
      }

      par1NBTTagCompound.setTag("Grid", gridList);
      par1NBTTagCompound.setBoolean("init", this.isInitialized);
      par1NBTTagCompound.setInteger("tier", this.tier);
      par1NBTTagCompound.setInteger("demonHouseCooldown", this.demonHouseCooldown);
      par1NBTTagCompound.setString("nextDemonPortalName", this.nextDemonPortalName);
      par1NBTTagCompound.setInteger("buildingStage", this.buildingStage);
      par1NBTTagCompound.setInteger("nextDemonPortalDirection", this.nextDemonPortalDirection.ordinal());
      par1NBTTagCompound.setFloat("pointPool", this.pointPool);
      par1NBTTagCompound.setInteger("lockdownTimer", this.lockdownTimer);
      par1NBTTagCompound.setInteger("delayBeforeParty", this.delayBeforeParty);
      par1NBTTagCompound.setString("demonType", this.type.toString());
   }

   public int createRandomDemonHoard(TEDemonPortal teDemonPortal, int tier, DemonType type, boolean spawnGuardian) {
      int next = this.rand.nextInt(4);
      ForgeDirection dir;
      switch(next) {
      case 0:
         dir = ForgeDirection.NORTH;
         break;
      case 1:
         dir = ForgeDirection.SOUTH;
         break;
      case 2:
         dir = ForgeDirection.EAST;
         break;
      case 3:
         dir = ForgeDirection.WEST;
         break;
      default:
         dir = ForgeDirection.NORTH;
      }

      Int3 road = this.findRoadSpaceFromDirection(dir, this.rand.nextInt(this.negXRadius + this.negZRadius + this.posXRadius + this.posZRadius) + 1);
      if(road == null) {
         return 0;
      } else {
         if(printDebug) {
            System.out.println("Spawning Demons");
         }

         return DemonPacketRegistry.spawnDemons(teDemonPortal, super.worldObj, super.xCoord + road.xCoord * 5, road.yCoord + 1, super.zCoord + road.zCoord * 5, type, tier, spawnGuardian);
      }
   }

   public int createRandomRoad() {
      int next = this.rand.nextInt(4);
      ForgeDirection dir;
      switch(next) {
      case 0:
         dir = ForgeDirection.NORTH;
         break;
      case 1:
         dir = ForgeDirection.SOUTH;
         break;
      case 2:
         dir = ForgeDirection.EAST;
         break;
      case 3:
         dir = ForgeDirection.WEST;
         break;
      default:
         dir = ForgeDirection.NORTH;
      }

      boolean length = true;
      Int3 road = this.findRoadSpaceFromDirection(dir, this.rand.nextInt(this.negXRadius + this.negZRadius + this.posXRadius + this.posZRadius) + 1);
      int x = road.xCoord;
      int yLevel = road.yCoord;
      int z = road.zCoord;
      if(printDebug) {
         AlchemicalWizardry.logger.info("X: " + x + " Z: " + z + " Direction: " + dir.toString());
      }

      List directions = this.findValidExtentionDirection(x, z);
      if(directions.size() <= 0) {
         return 0;
      } else {
         byte maxDistance = 5;
         int distance = 0;
         ForgeDirection dominantDirection = null;
         Iterator i$ = directions.iterator();

         while(i$.hasNext()) {
            ForgeDirection direction = (ForgeDirection)i$.next();
            int amt = this.getLength(direction, maxDistance, x, z);
            if(amt > distance) {
               distance = amt;
               dominantDirection = direction;
            } else if(amt == distance && this.rand.nextBoolean()) {
               dominantDirection = direction;
            }
         }

         if(dominantDirection == null) {
            return 0;
         } else {
            if(printDebug) {
               AlchemicalWizardry.logger.info("I got here!");
            }

            if(printDebug) {
               AlchemicalWizardry.logger.info("Distance: " + distance + " Direction: " + dominantDirection.toString() + " yLevel: " + yLevel);
            }

            this.createGriddedRoad(x, yLevel, z, dominantDirection, distance + 1, true);
            return distance;
         }
      }
   }

   public List findValidExtentionDirection(int x, int z) {
      LinkedList directions = new LinkedList();
      if(this.getGridSpace(x, z) != null && this.getGridSpace(x, z).isRoadSegment()) {
         GridSpace nextGrid = this.getGridSpace(x + 1, z);
         if(nextGrid.isEmpty()) {
            directions.add(ForgeDirection.EAST);
         }

         nextGrid = this.getGridSpace(x - 1, z);
         if(nextGrid.isEmpty()) {
            directions.add(ForgeDirection.WEST);
         }

         nextGrid = this.getGridSpace(x, z + 1);
         if(nextGrid.isEmpty()) {
            directions.add(ForgeDirection.SOUTH);
         }

         nextGrid = this.getGridSpace(x, z - 1);
         if(nextGrid.isEmpty()) {
            directions.add(ForgeDirection.NORTH);
         }

         return directions;
      } else {
         return directions;
      }
   }

   public int getLength(ForgeDirection dir, int maxLength, int x, int z) {
      for(int i = 1; i <= maxLength; ++i) {
         GridSpace space = this.getGridSpace(x + i * dir.offsetX, z + i * dir.offsetZ);
         if(!space.isEmpty()) {
            if(space.isRoadSegment()) {
               return i;
            }

            return i - 1;
         }

         for(int k = 1; k <= this.getRoadSpacer(); ++k) {
            GridSpace space1 = this.getGridSpace(x + i * dir.offsetX + dir.offsetZ * k, z + i * dir.offsetZ + dir.offsetX * k);
            GridSpace space2 = this.getGridSpace(x + i * dir.offsetX - dir.offsetZ * k, z + i * dir.offsetZ - dir.offsetX * k);
            if(space1.isRoadSegment() || space2.isRoadSegment()) {
               return i - 1;
            }
         }
      }

      return maxLength;
   }

   public Int3 findRoadSpaceFromDirection(ForgeDirection dir, int amount) {
      int index = 0;
      int i;
      int j;
      GridSpace space;
      if(dir == ForgeDirection.NORTH) {
         if(printDebug) {
            System.out.print("NORTH!");
         }

         for(i = Math.max(0, -limit + this.negZRadius); i <= this.negZRadius + Math.min(this.posZRadius, limit); ++i) {
            for(j = Math.max(0, -limit + this.negXRadius); j <= this.negXRadius + Math.min(this.posXRadius, limit); ++j) {
               space = this.area[j][i];
               if(space.isRoadSegment()) {
                  ++index;
                  if(index >= amount) {
                     return new Int3(j - this.negXRadius, space.getYLevel(), i - this.negZRadius);
                  }
               }
            }
         }
      } else if(dir == ForgeDirection.SOUTH) {
         for(i = this.negZRadius + Math.min(this.posZRadius, limit); i >= Math.max(0, -limit + this.negZRadius); --i) {
            for(j = Math.max(0, -limit + this.negXRadius); j <= this.negXRadius + Math.min(this.posXRadius, limit); ++j) {
               space = this.area[j][i];
               if(space.isRoadSegment()) {
                  ++index;
                  if(index >= amount) {
                     return new Int3(j - this.negXRadius, space.getYLevel(), i - this.negZRadius);
                  }
               }
            }
         }
      } else if(dir == ForgeDirection.EAST) {
         for(i = this.negXRadius + Math.min(this.posXRadius, limit); i >= Math.max(0, -limit + this.negXRadius); --i) {
            for(j = Math.max(0, -limit + this.negZRadius); j <= this.negZRadius + Math.min(this.posZRadius, limit); ++j) {
               space = this.area[i][j];
               if(space.isRoadSegment()) {
                  ++index;
                  if(index >= amount) {
                     return new Int3(i - this.negXRadius, space.getYLevel(), j - this.negZRadius);
                  }
               }
            }
         }
      } else if(dir == ForgeDirection.WEST) {
         for(i = Math.max(0, -limit + this.negXRadius); i <= this.negXRadius + Math.min(this.posXRadius, limit); ++i) {
            for(j = Math.max(0, -limit + this.negZRadius); j <= this.negZRadius + Math.min(this.posZRadius, limit); ++j) {
               space = this.area[i][j];
               if(space.isRoadSegment()) {
                  ++index;
                  if(index >= amount) {
                     return new Int3(i - this.negXRadius, space.getYLevel(), j - this.negZRadius);
                  }
               }
            }
         }
      }

      return new Int3(0, 0, 0);
   }

   public Int3 findEmptySpaceNearRoad(ForgeDirection dir, int amount, int closeness) {
      int index = 0;
      int i;
      int j;
      GridSpace space;
      int yLevel;
      if(dir == ForgeDirection.NORTH) {
         if(printDebug) {
            System.out.print("NORTH!");
         }

         for(i = 0; i <= this.negZRadius + this.posZRadius; ++i) {
            for(j = 0; j <= this.negXRadius + this.posXRadius; ++j) {
               space = this.area[j][i];
               if(space.isEmpty()) {
                  yLevel = this.findNearestRoadYLevel(j - this.negXRadius, i - this.negZRadius, closeness);
                  if(yLevel != -1) {
                     ++index;
                     if(index >= amount) {
                        return new Int3(j - this.negXRadius, yLevel, i - this.negZRadius);
                     }
                  }
               }
            }
         }
      } else if(dir == ForgeDirection.SOUTH) {
         for(i = this.negZRadius + this.posZRadius; i >= 0; --i) {
            for(j = 0; j <= this.negXRadius + this.posXRadius; ++j) {
               space = this.area[j][i];
               yLevel = this.findNearestRoadYLevel(j - this.negXRadius, i - this.negZRadius, closeness);
               if(yLevel != -1 && space.isEmpty()) {
                  ++index;
                  if(index >= amount) {
                     return new Int3(j - this.negXRadius, yLevel, i - this.negZRadius);
                  }
               }
            }
         }
      } else if(dir == ForgeDirection.EAST) {
         for(i = this.negXRadius + this.posXRadius; i >= 0; --i) {
            for(j = 0; j <= this.negZRadius + this.posZRadius; ++j) {
               space = this.area[i][j];
               yLevel = this.findNearestRoadYLevel(i - this.negXRadius, j - this.negZRadius, closeness);
               if(yLevel != -1 && space.isEmpty()) {
                  ++index;
                  if(index >= amount) {
                     return new Int3(i - this.negXRadius, yLevel, j - this.negZRadius);
                  }
               }
            }
         }
      } else if(dir == ForgeDirection.WEST) {
         for(i = 0; i <= this.negXRadius + this.posXRadius; ++i) {
            for(j = 0; j <= this.negZRadius + this.posZRadius; ++j) {
               space = this.area[i][j];
               yLevel = this.findNearestRoadYLevel(i - this.negXRadius, j - this.negZRadius, closeness);
               if(yLevel != -1 && space.isEmpty()) {
                  ++index;
                  if(index >= amount) {
                     return new Int3(i - this.negXRadius, yLevel, j - this.negZRadius);
                  }
               }
            }
         }
      }

      return new Int3(0, 0, 0);
   }

   public Int3 findEmptySpaceFromDirection(ForgeDirection dir, int amount) {
      int index = 0;
      int i;
      int j;
      GridSpace space;
      if(dir == ForgeDirection.NORTH) {
         if(printDebug) {
            System.out.print("NORTH!");
         }

         for(i = 0; i <= this.negZRadius + this.posZRadius; ++i) {
            for(j = 0; j <= this.negXRadius + this.posXRadius; ++j) {
               space = this.area[j][i];
               if(space.isEmpty()) {
                  ++index;
                  if(index >= amount) {
                     return new Int3(j - this.negXRadius, space.getYLevel(), i - this.negZRadius);
                  }
               }
            }
         }
      } else if(dir == ForgeDirection.SOUTH) {
         for(i = this.negZRadius + this.posZRadius; i >= 0; --i) {
            for(j = 0; j <= this.negXRadius + this.posXRadius; ++j) {
               space = this.area[j][i];
               if(space.isEmpty()) {
                  ++index;
                  if(index >= amount) {
                     return new Int3(j - this.negXRadius, space.getYLevel(), i - this.negZRadius);
                  }
               }
            }
         }
      } else if(dir == ForgeDirection.EAST) {
         for(i = this.negXRadius + this.posXRadius; i >= 0; --i) {
            for(j = 0; j <= this.negZRadius + this.posZRadius; ++j) {
               space = this.area[i][j];
               if(space.isEmpty()) {
                  ++index;
                  if(index >= amount) {
                     return new Int3(i - this.negXRadius, space.getYLevel(), j - this.negZRadius);
                  }
               }
            }
         }
      } else if(dir == ForgeDirection.WEST) {
         for(i = 0; i <= this.negXRadius + this.posXRadius; ++i) {
            for(j = 0; j <= this.negZRadius + this.posZRadius; ++j) {
               space = this.area[i][j];
               if(space.isEmpty()) {
                  ++index;
                  if(index >= amount) {
                     return new Int3(i - this.negXRadius, space.getYLevel(), j - this.negZRadius);
                  }
               }
            }
         }
      }

      return new Int3(0, 0, 0);
   }

   public int createGriddedRoad(int gridXi, int yi, int gridZi, ForgeDirection dir, int gridLength, boolean convertStarter) {
      if(gridLength != 0 && gridLength != 1) {
         if(convertStarter) {
            ;
         }

         int initGridX = gridXi;
         int initGridZ = gridZi;
         int initY = yi;
         if(convertStarter) {
            this.setGridSpace(gridXi, gridZi, new GridSpace(4, yi));
            DemonCrosspath index = new DemonCrosspath(super.xCoord + gridXi * 5, yi, super.zCoord + gridZi * 5);
            index.createCrosspath(super.worldObj);
         }

         for(int var14 = 0; var14 < gridLength - 1; ++var14) {
            DemonVillagePath path = new DemonVillagePath(super.xCoord + initGridX * 5, initY, super.zCoord + initGridZ * 5, dir, 6);
            DemonVillagePath.Int3AndBool temp = path.constructFullPath(this, super.worldObj, this.getRoadStepClearance());
            Int3 next = temp.coords;
            if(next != null) {
               initY = next.yCoord;
               if(printDebug) {
                  AlchemicalWizardry.logger.info("" + initY);
               }
            }

            if(!temp.bool) {
               return var14;
            }

            initGridX += dir.offsetX;
            initGridZ += dir.offsetZ;
            if(!this.getGridSpace(initGridX, initGridZ).isRoadSegment()) {
               this.setGridSpace(initGridX, initGridZ, new GridSpace(3, initY));
            }
         }

         return gridLength - 1;
      } else {
         return 0;
      }
   }

   public void expandAreaInNegX() {
      GridSpace[][] newGrid = new GridSpace[this.negXRadius + this.posXRadius + 2][this.negZRadius + this.posZRadius + 1];

      int i;
      for(i = 0; i <= this.negZRadius + this.posZRadius; ++i) {
         newGrid[0][i] = new GridSpace();
      }

      for(i = 0; i <= this.negXRadius + this.posXRadius; ++i) {
         for(int j = 0; j <= this.negZRadius + this.posZRadius; ++j) {
            newGrid[i + 1][j] = this.area[i][j];
         }
      }

      this.area = newGrid;
      ++this.negXRadius;
   }

   public void expandAreaInPosX() {
      GridSpace[][] newGrid = new GridSpace[this.negXRadius + this.posXRadius + 2][this.negZRadius + this.posZRadius + 1];

      int i;
      for(i = 0; i <= this.negZRadius + this.posZRadius; ++i) {
         newGrid[this.negXRadius + this.posXRadius + 1][i] = new GridSpace();
      }

      for(i = 0; i <= this.negXRadius + this.posXRadius; ++i) {
         for(int j = 0; j <= this.negZRadius + this.posZRadius; ++j) {
            newGrid[i][j] = this.area[i][j];
         }
      }

      this.area = newGrid;
      ++this.posXRadius;
   }

   public void expandAreaInNegZ() {
      GridSpace[][] newGrid = new GridSpace[this.negXRadius + this.posXRadius + 1][this.negZRadius + this.posZRadius + 2];
      if(printDebug) {
         AlchemicalWizardry.logger.info("x " + newGrid.length + "z " + newGrid[0].length);
      }

      int i;
      for(i = 0; i <= this.negXRadius + this.posXRadius; ++i) {
         newGrid[i][0] = new GridSpace();
      }

      for(i = 0; i <= this.negXRadius + this.posXRadius; ++i) {
         for(int j = 0; j <= this.negZRadius + this.posZRadius; ++j) {
            newGrid[i][j + 1] = this.area[i][j];
         }
      }

      this.area = newGrid;
      ++this.negZRadius;
   }

   public void expandAreaInPosZ() {
      GridSpace[][] newGrid = new GridSpace[this.negXRadius + this.posXRadius + 1][this.negZRadius + this.posZRadius + 2];

      int i;
      for(i = 0; i <= this.negXRadius + this.posXRadius; ++i) {
         newGrid[i][this.negZRadius + this.posZRadius + 1] = new GridSpace();
      }

      for(i = 0; i <= this.negXRadius + this.posXRadius; ++i) {
         for(int j = 0; j <= this.negZRadius + this.posZRadius; ++j) {
            newGrid[i][j] = this.area[i][j];
         }
      }

      this.area = newGrid;
      ++this.posZRadius;
   }

   public GridSpace getGridSpace(int x, int z) {
      return x <= this.posXRadius && x >= -this.negXRadius && z <= this.posZRadius && z >= -this.negZRadius?this.area[x + this.negXRadius][z + this.negZRadius]:new GridSpace();
   }

   public void setGridSpace(int x, int z, GridSpace space) {
      if(x > this.posXRadius) {
         this.expandAreaInPosX();
         this.setGridSpace(x, z, space);
      } else if(x < -this.negXRadius) {
         this.expandAreaInNegX();
         this.setGridSpace(x, z, space);
      } else if(z > this.posZRadius) {
         this.expandAreaInPosZ();
         this.setGridSpace(x, z, space);
      } else if(z < -this.negZRadius) {
         this.expandAreaInNegZ();
         this.setGridSpace(x, z, space);
      } else {
         this.area[x + this.negXRadius][z + this.negZRadius] = space;
      }
   }

   public void rightClickBlock(EntityPlayer player, int side) {}

   public int createRandomBuilding(int type, int tier) {
      switch(type) {
      case 0:
         return this.createRandomHouse(tier);
      case 1:
         return this.createPortalBuilding(tier);
      default:
         return 0;
      }
   }

   public int createPortalBuilding(int buildingTier) {
      if(printDebug) {
         AlchemicalWizardry.logger.info("Hello, I am here!");
      }

      byte x = 0;
      byte z = 0;
      GridSpace home = this.getGridSpace(x, z);
      int yLevel = home.getYLevel();
      GridSpaceHolder grid = this.createGSH();
      ArrayList directions = new ArrayList();

      ForgeDirection chosenDirection;
      for(int schemMap = 2; schemMap < 6; ++schemMap) {
         chosenDirection = ForgeDirection.getOrientation(schemMap);
         directions.add(chosenDirection);
      }

      if(directions.isEmpty()) {
         return 0;
      } else {
         HashMap var13 = new HashMap();
         Iterator var14 = directions.iterator();

         while(var14.hasNext()) {
            ForgeDirection build = (ForgeDirection)var14.next();
            Iterator portalSpace = buildingList.iterator();

            while(portalSpace.hasNext()) {
               DemonBuilding build1 = (DemonBuilding)portalSpace.next();
               if(build1.buildingType == 1 && build1.buildingTier == buildingTier) {
                  System.out.println("This one matches!");
                  if(var13.containsKey(build)) {
                     ((List)var13.get(build)).add(build1);
                  } else {
                     var13.put(build, new ArrayList());
                     ((List)var13.get(build)).add(build1);
                  }
               }
            }
         }

         if(var13.keySet().isEmpty()) {
            return 0;
         } else {
            chosenDirection = (ForgeDirection)var13.keySet().toArray()[(new Random()).nextInt(var13.keySet().size())];
            DemonBuilding var15 = (DemonBuilding)((List)var13.get(chosenDirection)).get((new Random()).nextInt(((List)var13.get(chosenDirection)).size()));
            var15.getDoorSpace(chosenDirection);
            this.nextDemonPortalDirection = chosenDirection;
            this.nextDemonPortalName = var15.getName();
            return var15.getNumberOfGridSpaces();
         }
      }
   }

   public void createPortalBuilding(int stage, String name, int tier) {
      Iterator i$ = buildingList.iterator();

      DemonBuilding build;
      do {
         if(!i$.hasNext()) {
            return;
         }

         build = (DemonBuilding)i$.next();
      } while(build.buildingType != 1 || build.buildingTier != tier || !build.getName().equals(this.nextDemonPortalName));

      byte x = 0;
      byte z = 0;
      GridSpace home = this.getGridSpace(x, z);
      int yLevel = home.getYLevel();
      GridSpaceHolder grid = this.createGSH();
      ForgeDirection chosenDirection = this.nextDemonPortalDirection;
      Int3 portalSpace = build.getDoorSpace(chosenDirection);
      int yOffset = portalSpace.yCoord;
      switch(stage) {
      case 0:
      default:
         break;
      case 1:
         int yDestination = yLevel + yOffset;
         if(super.yCoord != yDestination) {
            BlockTeleposer.swapBlocks(this, super.worldObj, super.worldObj, super.xCoord, super.yCoord, super.zCoord, super.xCoord, yDestination, super.zCoord);
         }
         break;
      case 2:
         build.destroyAllInField(super.worldObj, super.xCoord + x * 5, yLevel, super.zCoord + z * 5, chosenDirection.getOpposite());
         build.buildAll(this, super.worldObj, super.xCoord + x * 5, yLevel, super.zCoord + z * 5, chosenDirection.getOpposite(), true);
         build.setAllGridSpaces(x, z, yLevel, chosenDirection.getOpposite(), 1, grid);
         this.loadGSH(grid);
      }

   }

   public int createRandomHouse(int buildingTier) {
      int next = this.rand.nextInt(4);
      ForgeDirection dir;
      switch(next) {
      case 0:
         dir = ForgeDirection.NORTH;
         break;
      case 1:
         dir = ForgeDirection.SOUTH;
         break;
      case 2:
         dir = ForgeDirection.EAST;
         break;
      case 3:
         dir = ForgeDirection.WEST;
         break;
      default:
         dir = ForgeDirection.NORTH;
      }

      Int3 space = this.findRoadSpaceFromDirection(dir, 1 * this.rand.nextInt(this.negXRadius + this.negZRadius + this.posXRadius + this.posZRadius) + 1);
      int x = space.xCoord;
      int z = space.zCoord;
      int yLevel = space.yCoord;
      if(printDebug) {
         AlchemicalWizardry.logger.info("Road space - x: " + x + " z: " + z);
      }

      GridSpaceHolder grid = this.createGSH();
      if(!this.getGridSpace(x, z).isRoadSegment()) {
         return 0;
      } else {
         ArrayList directions = new ArrayList();

         ForgeDirection chosenDirection;
         for(int schemMap = 2; schemMap < 6; ++schemMap) {
            chosenDirection = ForgeDirection.getOrientation(schemMap);
            if(this.getGridSpace(x + chosenDirection.offsetX, z + chosenDirection.offsetZ).isEmpty()) {
               directions.add(chosenDirection);
            }
         }

         if(directions.isEmpty()) {
            return 0;
         } else {
            HashMap var19 = new HashMap();
            Iterator var18 = directions.iterator();

            while(var18.hasNext()) {
               ForgeDirection build = (ForgeDirection)var18.next();
               Iterator offsetSpace = buildingList.iterator();

               while(offsetSpace.hasNext()) {
                  DemonBuilding xOff = (DemonBuilding)offsetSpace.next();
                  if(xOff.buildingTier == buildingTier && xOff.buildingType == 0) {
                     Int3 zOff = xOff.getGridOffsetFromRoad(build, yLevel);
                     int path = zOff.xCoord;
                     int temp = zOff.zCoord;
                     if(xOff.isValid(grid, x + path, z + temp, build.getOpposite())) {
                        if(var19.containsKey(build)) {
                           ((List)var19.get(build)).add(xOff);
                        } else {
                           var19.put(build, new ArrayList());
                           ((List)var19.get(build)).add(xOff);
                        }
                     } else if(printDebug) {
                        AlchemicalWizardry.logger.info("This ISN\'T valid!");
                     }
                  }
               }
            }

            if(var19.keySet().isEmpty()) {
               return 0;
            } else {
               chosenDirection = (ForgeDirection)var19.keySet().toArray()[(new Random()).nextInt(var19.keySet().size())];
               DemonBuilding var20 = (DemonBuilding)((List)var19.get(chosenDirection)).get((new Random()).nextInt(((List)var19.get(chosenDirection)).size()));
               Int3 var21 = var20.getGridOffsetFromRoad(chosenDirection, yLevel);
               int var23 = var21.xCoord;
               int var22 = var21.zCoord;
               var20.destroyAllInField(super.worldObj, super.xCoord + (x + var23) * 5, yLevel, super.zCoord + (z + var22) * 5, chosenDirection.getOpposite());
               var20.buildAll(this, super.worldObj, super.xCoord + (x + var23) * 5, yLevel, super.zCoord + (z + var22) * 5, chosenDirection.getOpposite(), true);
               var20.setAllGridSpaces(x + var23, z + var22, yLevel, chosenDirection.getOpposite(), 5, grid);
               this.loadGSH(grid);
               DemonVillagePath var24 = new DemonVillagePath(super.xCoord + x * 5, yLevel, super.zCoord + z * 5, chosenDirection, 2);
               var24.constructFullPath(this, super.worldObj, this.getRoadStepClearance());
               return var20.getNumberOfGridSpaces();
            }
         }
      }
   }

   public int findNearestRoadYLevel(int xCoord, int zCoord, int maxDistance) {
      for(int l = 1; l <= maxDistance; ++l) {
         for(int i = -l; i <= l; ++i) {
            for(int j = -l; j <= l; ++j) {
               if((Math.abs(i) == l || Math.abs(j) == l) && this.getGridSpace(xCoord + i, zCoord + j).isRoadSegment()) {
                  return this.getGridSpace(xCoord + i, zCoord + j).getYLevel();
               }
            }
         }
      }

      return -1;
   }

   public void createRoad(int xi, int yi, int zi, ForgeDirection dir, int length, boolean doesNotDrop) {
      int roadRadius = this.getRoadRadius();
      if(dir.offsetY == 0) {
         DemonVillagePath path = new DemonVillagePath(xi, yi, zi, dir, length);
         path.constructFullPath(this, super.worldObj, this.getRoadStepClearance());
      }
   }

   public int placeMaterialOnNextAvailable() {
      return 0;
   }

   public int getRoadRadius() {
      return 1;
   }

   public Block getRoadBlock() {
      switch(this.tier) {
      case 0:
         return (double)this.rand.nextFloat() < 0.6D?Blocks.cobblestone:Blocks.mossy_cobblestone;
      case 1:
         return Blocks.stonebrick;
      default:
         return Blocks.nether_brick;
      }
   }

   public int getRoadMeta() {
      switch(this.tier) {
      case 1:
         return (double)this.rand.nextFloat() < 0.6D?1:0;
      default:
         return 0;
      }
   }

   public int getRoadStepClearance() {
      return 10;
   }

   public int getRoadSpacer() {
      return 1;
   }

   public GridSpaceHolder createGSH() {
      GridSpaceHolder grid = new GridSpaceHolder();
      grid.area = this.area;
      grid.negXRadius = this.negXRadius;
      grid.negZRadius = this.negZRadius;
      grid.posXRadius = this.posXRadius;
      grid.posZRadius = this.posZRadius;
      return grid;
   }

   public void loadGSH(GridSpaceHolder grid) {
      this.area = grid.area;
      this.negXRadius = grid.negXRadius;
      this.negZRadius = grid.negZRadius;
      this.posXRadius = grid.posXRadius;
      this.posZRadius = grid.posZRadius;
   }

   public static void loadBuildingList() {
      String folder = "config/BloodMagic/schematics";
      Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
      File file = new File(folder);
      File[] files = file.listFiles();

      try {
         File[] e = files;
         int len$ = files.length;

         for(int i$ = 0; i$ < len$; ++i$) {
            File f = e[i$];
            BufferedReader br = new BufferedReader(new FileReader(f));
            BuildingSchematic schema = (BuildingSchematic)gson.fromJson(br, BuildingSchematic.class);
            buildingList.add(new DemonBuilding(schema));
         }
      } catch (FileNotFoundException var10) {
         var10.printStackTrace();
      }

   }

   public void addToPoints(int addition) {
      this.demonHouseCooldown += addition;
   }

   public void notifyPortalOfBreak() {
      Iterator i$ = hoardList.iterator();

      while(i$.hasNext()) {
         IHoardDemon demon = (IHoardDemon)i$.next();
         if(demon instanceof Entity) {
            ((Entity)demon).setDead();
         }
      }

   }

}
