package WayofTime.alchemicalWizardry.common.demonVillage;

import WayofTime.alchemicalWizardry.api.Int3;
import WayofTime.alchemicalWizardry.common.demonVillage.BuildingSchematic;
import WayofTime.alchemicalWizardry.common.demonVillage.GridSpaceHolder;
import WayofTime.alchemicalWizardry.common.demonVillage.tileEntity.TEDemonPortal;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public class DemonBuilding {

   public static final int BUILDING_HOUSE = 0;
   public static final int BUILDING_PORTAL = 1;
   public BuildingSchematic schematic;
   public GridSpaceHolder area;
   public int buildingTier;
   public int buildingType;
   public Int3 doorGridSpace;


   public DemonBuilding(BuildingSchematic schematic) {
      this.schematic = schematic;
      this.buildingType = schematic.buildingType;
      this.buildingTier = schematic.buildingTier;
      this.area = this.createGSHForSchematic(schematic);
      this.doorGridSpace = schematic.getGridSpotOfDoor();
   }

   public String getName() {
      return this.schematic.getName();
   }

   public boolean isValid(GridSpaceHolder master, int gridX, int gridZ, ForgeDirection dir) {
      return this.area.doesContainAll(master, gridX, gridZ, dir);
   }

   public void buildAll(TEDemonPortal teDemonPortal, World world, int xCoord, int yCoord, int zCoord, ForgeDirection dir, boolean populateInventories) {
      this.schematic.buildAll(teDemonPortal, world, xCoord, yCoord, zCoord, dir, populateInventories);
   }

   public void setAllGridSpaces(int xInit, int zInit, int yLevel, ForgeDirection dir, int type, GridSpaceHolder master) {
      this.area.setAllGridSpaces(xInit, zInit, yLevel, dir, type, master);
   }

   public GridSpaceHolder createGSHForSchematic(BuildingSchematic scheme) {
      switch(this.buildingType) {
      case 0:
         return scheme.createGSH();
      case 1:
      default:
         return scheme.createGSH();
      }
   }

   public Int3 getDoorSpace(ForgeDirection dir) {
      boolean x = false;
      boolean z = false;
      int x1;
      int z1;
      switch(DemonBuilding.NamelessClass600994468.$SwitchMap$net$minecraftforge$common$util$ForgeDirection[dir.ordinal()]) {
      case 1:
         x1 = -this.doorGridSpace.xCoord;
         z1 = -this.doorGridSpace.zCoord;
         break;
      case 2:
         x1 = this.doorGridSpace.zCoord;
         z1 = -this.doorGridSpace.xCoord;
         break;
      case 3:
         x1 = -this.doorGridSpace.zCoord;
         z1 = this.doorGridSpace.xCoord;
         break;
      default:
         x1 = this.doorGridSpace.xCoord;
         z1 = this.doorGridSpace.zCoord;
      }

      return new Int3(x1, this.doorGridSpace.yCoord, z1);
   }

   public Int3 getGridOffsetFromRoad(ForgeDirection sideOfRoad, int yLevel) {
      Int3 doorSpace = this.getDoorSpace(sideOfRoad);
      int x = doorSpace.xCoord;
      int z = doorSpace.zCoord;
      switch(DemonBuilding.NamelessClass600994468.$SwitchMap$net$minecraftforge$common$util$ForgeDirection[sideOfRoad.ordinal()]) {
      case 1:
         ++z;
         break;
      case 2:
         --x;
         break;
      case 3:
         ++x;
         break;
      default:
         --z;
      }

      return new Int3(x, yLevel, z);
   }

   public void destroyAllInField(World world, int xCoord, int yCoord, int zCoord, ForgeDirection dir) {
      this.schematic.destroyAllInField(world, xCoord, yCoord, zCoord, dir);
   }

   public int getNumberOfGridSpaces() {
      return this.area.getNumberOfGridSpaces();
   }

   // $FF: synthetic class
   static class NamelessClass600994468 {

      // $FF: synthetic field
      static final int[] $SwitchMap$net$minecraftforge$common$util$ForgeDirection = new int[ForgeDirection.values().length];


      static {
         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.SOUTH.ordinal()] = 1;
         } catch (NoSuchFieldError var3) {
            ;
         }

         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.WEST.ordinal()] = 2;
         } catch (NoSuchFieldError var2) {
            ;
         }

         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.EAST.ordinal()] = 3;
         } catch (NoSuchFieldError var1) {
            ;
         }

      }
   }
}
