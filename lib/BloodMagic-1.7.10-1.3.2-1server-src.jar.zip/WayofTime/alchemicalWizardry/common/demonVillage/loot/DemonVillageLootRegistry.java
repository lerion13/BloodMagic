package WayofTime.alchemicalWizardry.common.demonVillage.loot;

import WayofTime.alchemicalWizardry.ModItems;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.WeightedRandomChestContent;
import net.minecraftforge.common.ChestGenHooks;

public class DemonVillageLootRegistry {

   public static ArrayList list1 = new ArrayList();


   public static void init() {
      new ItemStack(ModItems.baseItems, 1, 28);
      new ItemStack(ModItems.baseItems, 1, 29);
      String[] tier1Strings = new String[]{"dungeonChest", "pyramidDesertyChest"};
      String[] arr$ = tier1Strings;
      int len$ = tier1Strings.length;

      for(int i$ = 0; i$ < len$; ++i$) {
         String str = arr$[i$];
         WeightedRandomChestContent[] contents = ChestGenHooks.getItems(str, new Random());
         if(contents != null) {
            WeightedRandomChestContent[] arr$1 = contents;
            int len$1 = contents.length;

            for(int i$1 = 0; i$1 < len$1; ++i$1) {
               WeightedRandomChestContent content = arr$1[i$1];
               list1.add(content);
            }
         }
      }

      list1.add(new WeightedRandomChestContent(ModItems.baseItems, 28, 1, 2, 5));
      list1.add(new WeightedRandomChestContent(ModItems.baseItems, 29, 1, 2, 5));
   }

   public static void populateChest(IInventory tile, int tier) {
      WeightedRandomChestContent.generateChestContents(new Random(), toArray(list1), tile, tile.getSizeInventory() / 3);
   }

   public static WeightedRandomChestContent[] toArray(List aList) {
      int size = aList.size();
      WeightedRandomChestContent[] contents = new WeightedRandomChestContent[size];
      contents = (WeightedRandomChestContent[])aList.toArray(contents);
      return contents;
   }

}
