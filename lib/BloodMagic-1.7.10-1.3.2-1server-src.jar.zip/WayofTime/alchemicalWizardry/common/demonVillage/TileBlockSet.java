package WayofTime.alchemicalWizardry.common.demonVillage;

import WayofTime.alchemicalWizardry.common.demonVillage.BlockSet;
import net.minecraft.nbt.NBTTagCompound;

public class TileBlockSet extends BlockSet {

   public NBTTagCompound tag;


}
