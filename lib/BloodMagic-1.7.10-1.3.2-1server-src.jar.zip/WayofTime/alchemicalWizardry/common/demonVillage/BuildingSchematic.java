package WayofTime.alchemicalWizardry.common.demonVillage;

import WayofTime.alchemicalWizardry.ModBlocks;
import WayofTime.alchemicalWizardry.api.Int3;
import WayofTime.alchemicalWizardry.common.demonVillage.BlockSet;
import WayofTime.alchemicalWizardry.common.demonVillage.GridSpace;
import WayofTime.alchemicalWizardry.common.demonVillage.GridSpaceHolder;
import WayofTime.alchemicalWizardry.common.demonVillage.tileEntity.TEDemonPortal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public class BuildingSchematic {

   public String name;
   public int doorX;
   public int doorZ;
   public int doorY;
   public int buildingTier;
   public int buildingType;
   public List blockList;


   public BuildingSchematic() {
      this("");
   }

   public BuildingSchematic(String name) {
      this.name = name;
      this.blockList = new ArrayList();
      this.doorX = 0;
      this.doorZ = 0;
      this.doorY = 0;
      this.buildingTier = 0;
      this.buildingType = 0;
   }

   public void addBlockWithMeta(Block block, int meta, int xOffset, int yOffset, int zOffset) {
      Iterator set = this.blockList.iterator();

      BlockSet set1;
      do {
         if(!set.hasNext()) {
            BlockSet set2 = new BlockSet(block, meta);
            set2.addPositionToBlock(xOffset, yOffset, zOffset);
            this.blockList.add(set2);
            return;
         }

         set1 = (BlockSet)set.next();
      } while(!set1.isContained(block, meta));

      set1.addPositionToBlock(xOffset, yOffset, zOffset);
   }

   public void buildAll(TEDemonPortal teDemonPortal, World world, int xCoord, int yCoord, int zCoord, ForgeDirection dir, boolean populateInventories) {
      Iterator i$ = this.blockList.iterator();

      while(i$.hasNext()) {
         BlockSet set = (BlockSet)i$.next();
         set.buildAll(teDemonPortal, world, xCoord, yCoord, zCoord, dir, populateInventories, this.buildingTier);
      }

   }

   public GridSpaceHolder createGSH() {
      GridSpaceHolder holder = new GridSpaceHolder();
      Iterator i$ = this.blockList.iterator();

      while(i$.hasNext()) {
         BlockSet set = (BlockSet)i$.next();
         Iterator i$1 = set.getPositions().iterator();

         while(i$1.hasNext()) {
            Int3 coords = (Int3)i$1.next();
            int gridX = (int)(((float)coords.xCoord + 2.0F * Math.signum((float)coords.xCoord)) / 5.0F);
            int gridZ = (int)(((float)coords.zCoord + 2.0F * Math.signum((float)coords.zCoord)) / 5.0F);
            holder.setGridSpace(gridX, gridZ, new GridSpace(5, 0));
         }
      }

      return holder;
   }

   public Int3 getGridSpotOfDoor() {
      int gridX = (int)(((float)this.doorX + 2.0F * Math.signum((float)this.doorX)) / 5.0F);
      int gridZ = (int)(((float)this.doorZ + 2.0F * Math.signum((float)this.doorZ)) / 5.0F);
      return new Int3(gridX, this.doorY, gridZ);
   }

   public List getGriddedPositions(ForgeDirection dir) {
      ArrayList positionList = new ArrayList();
      Iterator i$ = this.blockList.iterator();

      while(i$.hasNext()) {
         BlockSet blockSet = (BlockSet)i$.next();
         Iterator i$1 = blockSet.getPositions().iterator();

         while(i$1.hasNext()) {
            Int3 pos = (Int3)i$1.next();
            int xOff = pos.xCoord;
            int zOff = pos.zCoord;
            switch(BuildingSchematic.NamelessClass1403079904.$SwitchMap$net$minecraftforge$common$util$ForgeDirection[dir.ordinal()]) {
            case 1:
               xOff *= -1;
               zOff *= -1;
               break;
            case 2:
               int nextPos = zOff;
               zOff = xOff * -1;
               xOff = nextPos;
               break;
            case 3:
               int temp2 = zOff * -1;
               zOff = xOff;
               xOff = temp2;
            }

            Int3 nextPos1 = new Int3(xOff, 0, zOff);
            if(!positionList.contains(nextPos1)) {
               positionList.add(nextPos1);
            }
         }
      }

      return positionList;
   }

   public void destroyAllInField(World world, int xCoord, int yCoord, int zCoord, ForgeDirection dir) {
      GridSpaceHolder grid = this.createGSH();
      List positionList = this.getGriddedPositions(dir);

      for(int i = this.getMinY(); i <= this.getMaxY(); ++i) {
         Iterator i$ = positionList.iterator();

         while(i$.hasNext()) {
            Int3 pos = (Int3)i$.next();
            Block block = world.getBlock(xCoord + pos.xCoord, yCoord + i, zCoord + pos.zCoord);
            if(block != ModBlocks.blockDemonPortal) {
               world.setBlockToAir(xCoord + pos.xCoord, yCoord + i, zCoord + pos.zCoord);
            }
         }
      }

   }

   public int getMinY() {
      int min = 0;
      Iterator i$ = this.blockList.iterator();

      while(i$.hasNext()) {
         BlockSet set = (BlockSet)i$.next();
         Iterator i$1 = set.getPositions().iterator();

         while(i$1.hasNext()) {
            Int3 pos = (Int3)i$1.next();
            if(pos.yCoord < min) {
               min = pos.yCoord;
            }
         }
      }

      return min;
   }

   public int getMaxY() {
      int max = 0;
      Iterator i$ = this.blockList.iterator();

      while(i$.hasNext()) {
         BlockSet set = (BlockSet)i$.next();
         Iterator i$1 = set.getPositions().iterator();

         while(i$1.hasNext()) {
            Int3 pos = (Int3)i$1.next();
            if(pos.yCoord > max) {
               max = pos.yCoord;
            }
         }
      }

      return max;
   }

   public String getName() {
      return this.name;
   }

   // $FF: synthetic class
   static class NamelessClass1403079904 {

      // $FF: synthetic field
      static final int[] $SwitchMap$net$minecraftforge$common$util$ForgeDirection = new int[ForgeDirection.values().length];


      static {
         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.SOUTH.ordinal()] = 1;
         } catch (NoSuchFieldError var3) {
            ;
         }

         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.WEST.ordinal()] = 2;
         } catch (NoSuchFieldError var2) {
            ;
         }

         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.EAST.ordinal()] = 3;
         } catch (NoSuchFieldError var1) {
            ;
         }

      }
   }
}
