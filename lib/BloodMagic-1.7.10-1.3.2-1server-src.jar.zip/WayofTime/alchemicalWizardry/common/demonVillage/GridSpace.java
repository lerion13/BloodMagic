package WayofTime.alchemicalWizardry.common.demonVillage;

import net.minecraft.nbt.NBTTagCompound;

public class GridSpace {

   public static final int EMPTY = 0;
   public static final int MAIN_PORTAL = 1;
   public static final int MINI_PORTAL = 2;
   public static final int ROAD = 3;
   public static final int CROSSROAD = 4;
   public static final int HOUSE = 5;
   private int yLevel;
   private int type;


   public GridSpace() {
      this(0, -1);
   }

   public GridSpace(int type, int yLevel) {
      this.type = type;
      this.yLevel = yLevel;
   }

   public int getGridType() {
      return this.type;
   }

   public void setGridType(int type) {
      this.type = type;
   }

   public int getYLevel() {
      return this.yLevel;
   }

   public void setYLevel(int yLevel) {
      this.yLevel = yLevel;
   }

   public boolean isEmpty() {
      return this.type == 0;
   }

   public static GridSpace getGridFromTag(NBTTagCompound tag) {
      return new GridSpace(tag.getInteger("type"), tag.getInteger("yLevel"));
   }

   public NBTTagCompound getTag() {
      NBTTagCompound tag = new NBTTagCompound();
      tag.setInteger("type", this.type);
      tag.setInteger("yLevel", this.yLevel);
      return tag;
   }

   public boolean isRoadSegment() {
      return this.type == 3 || this.type == 4;
   }

   public boolean isBuilding() {
      return this.type == 5;
   }
}
