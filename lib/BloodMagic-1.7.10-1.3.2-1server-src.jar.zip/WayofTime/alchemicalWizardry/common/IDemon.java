package WayofTime.alchemicalWizardry.common;


public interface IDemon {

   void setSummonedConditions();

   boolean isAggro();

   void setAggro(boolean var1);

   boolean getDoesDropCrystal();

   void setDropCrystal(boolean var1);
}
