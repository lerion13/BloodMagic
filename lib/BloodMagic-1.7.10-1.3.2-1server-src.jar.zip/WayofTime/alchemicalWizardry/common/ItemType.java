package WayofTime.alchemicalWizardry.common;

import java.util.Objects;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

public class ItemType {

   public final Item item;
   public final int meta;
   public final NBTTagCompound nbtTag;


   public ItemType(Item item, int meta, NBTTagCompound nbtTag) {
      this.item = (Item)Objects.requireNonNull(item);
      this.meta = meta;
      this.nbtTag = nbtTag;
   }

   public ItemType(Item item, int meta) {
      this(item, meta, (NBTTagCompound)null);
   }

   public ItemType(Item item) {
      this(item, 0, (NBTTagCompound)null);
   }

   public ItemType(Block block, int meta, NBTTagCompound nbtTag) {
      this(Item.getItemFromBlock(block), meta, nbtTag);
   }

   public ItemType(Block block, int meta) {
      this(block, meta, (NBTTagCompound)null);
   }

   public ItemType(Block block) {
      this(block, 0, (NBTTagCompound)null);
   }

   public ItemStack createStack(int count) {
      ItemStack result = new ItemStack(this.item, count, this.meta);
      result.stackTagCompound = this.nbtTag;
      return result;
   }

   public boolean equals(Object obj) {
      if(this == obj) {
         return true;
      } else if(obj != null && this.getClass() == obj.getClass()) {
         ItemType other = (ItemType)obj;
         return this.item == other.item && this.meta == other.meta && Objects.equals(this.nbtTag, other.nbtTag);
      } else {
         return false;
      }
   }

   public int hashCode() {
      boolean prime = true;
      byte result = 1;
      int result1 = 31 * result + this.item.hashCode();
      result1 = 31 * result1 + this.meta;
      result1 = 31 * result1 + (this.nbtTag == null?0:this.nbtTag.hashCode());
      return result1;
   }

   public static ItemType fromStack(ItemStack stack) {
      return new ItemType(stack.getItem(), stack.getItemDamage(), stack.stackTagCompound);
   }
}
