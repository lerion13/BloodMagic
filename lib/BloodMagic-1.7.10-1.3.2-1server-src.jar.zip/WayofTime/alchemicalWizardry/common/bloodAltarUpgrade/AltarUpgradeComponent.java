package WayofTime.alchemicalWizardry.common.bloodAltarUpgrade;


public class AltarUpgradeComponent {

   private int speedUpgrades = 0;
   private int efficiencyUpgrades = 0;
   private int sacrificeUpgrades = 0;
   private int selfSacrificeUpgrades = 0;
   private int displacementUpgrades = 0;
   private int altarCapacitiveUpgrades = 0;
   private int orbCapacitiveUpgrades = 0;
   private int betterCapacitiveUpgrades = 0;
   private int accelerationUpgrades = 0;


   public void addSpeedUpgrade() {
      ++this.speedUpgrades;
   }

   public void addEfficiencyUpgrade() {
      ++this.efficiencyUpgrades;
   }

   public void addSacrificeUpgrade() {
      ++this.sacrificeUpgrades;
   }

   public void addSelfSacrificeUpgrade() {
      ++this.selfSacrificeUpgrades;
   }

   public void addDisplacementUpgrade() {
      ++this.displacementUpgrades;
   }

   public void addaltarCapacitiveUpgrade() {
      ++this.altarCapacitiveUpgrades;
   }

   public void addorbCapacitiveUpgrade() {
      ++this.orbCapacitiveUpgrades;
   }

   public void addBetterCapacitiveUpgrade() {
      ++this.betterCapacitiveUpgrades;
   }

   public void addAccelerationUpgrade() {
      ++this.accelerationUpgrades;
   }

   public int getSpeedUpgrades() {
      return this.speedUpgrades;
   }

   public int getEfficiencyUpgrades() {
      return this.efficiencyUpgrades;
   }

   public int getSacrificeUpgrades() {
      return this.sacrificeUpgrades;
   }

   public int getSelfSacrificeUpgrades() {
      return this.selfSacrificeUpgrades;
   }

   public int getDisplacementUpgrades() {
      return this.displacementUpgrades;
   }

   public int getAltarCapacitiveUpgrades() {
      return this.altarCapacitiveUpgrades;
   }

   public int getOrbCapacitiveUpgrades() {
      return this.orbCapacitiveUpgrades;
   }

   public int getBetterCapacitiveUpgrades() {
      return this.betterCapacitiveUpgrades;
   }

   public int getAccelerationUpgrades() {
      return this.accelerationUpgrades;
   }
}
