package WayofTime.alchemicalWizardry.common.bloodAltarUpgrade;

import WayofTime.alchemicalWizardry.ModBlocks;
import WayofTime.alchemicalWizardry.api.altarRecipeRegistry.IFadedRune;
import WayofTime.alchemicalWizardry.common.block.BloodRune;
import WayofTime.alchemicalWizardry.common.bloodAltarUpgrade.AltarComponent;
import WayofTime.alchemicalWizardry.common.bloodAltarUpgrade.AltarUpgradeComponent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;

public class UpgradedAltars {

   public static List secondTierAltar = new ArrayList();
   public static List thirdTierAltar = new ArrayList();
   public static List fourthTierAltar = new ArrayList();
   public static List fifthTierAltar = new ArrayList();
   public static List sixthTierAltar = new ArrayList();
   public static int highestAltar = 6;


   public static int isAltarValid(World world, int x, int y, int z) {
      for(int i = highestAltar; i >= 2; --i) {
         if(checkAltarIsValid(world, x, y, z, i)) {
            return i;
         }
      }

      return 1;
   }

   public static boolean checkAltarIsValid(World world, int x, int y, int z, int altarTier) {
      Iterator i$;
      AltarComponent ac;
      Block block;
      int metadata;
      switch(altarTier) {
      case 1:
         return true;
      case 2:
         i$ = secondTierAltar.iterator();

         do {
            label169:
            do {
               do {
                  if(!i$.hasNext()) {
                     return true;
                  }

                  ac = (AltarComponent)i$.next();
                  if(!ac.isBloodRune()) {
                     block = world.getBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ());
                     metadata = world.getBlockMetadata(x + ac.getX(), y + ac.getY(), z + ac.getZ());
                     continue label169;
                  }

                  block = world.getBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ());
               } while(block instanceof BloodRune);

               return false;
            } while(ac.getBlock() == block && ac.getMetadata() == metadata);
         } while(ac.getBlock() == Blocks.stonebrick && !world.isAirBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ()));

         return false;
      case 3:
         i$ = thirdTierAltar.iterator();

         do {
            label149:
            do {
               do {
                  if(!i$.hasNext()) {
                     return true;
                  }

                  ac = (AltarComponent)i$.next();
                  if(!ac.isBloodRune()) {
                     block = world.getBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ());
                     metadata = world.getBlockMetadata(x + ac.getX(), y + ac.getY(), z + ac.getZ());
                     continue label149;
                  }

                  block = world.getBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ());
               } while(block instanceof BloodRune);

               return false;
            } while(ac.getBlock() == block && ac.getMetadata() == metadata);
         } while(ac.getBlock() == Blocks.stonebrick && !world.isAirBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ()));

         return false;
      case 4:
         i$ = fourthTierAltar.iterator();

         do {
            label130:
            do {
               do {
                  if(!i$.hasNext()) {
                     return true;
                  }

                  ac = (AltarComponent)i$.next();
                  if(!ac.isBloodRune()) {
                     block = world.getBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ());
                     metadata = world.getBlockMetadata(x + ac.getX(), y + ac.getY(), z + ac.getZ());
                     continue label130;
                  }

                  block = world.getBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ());
               } while(block instanceof BloodRune);

               return false;
            } while(ac.getBlock() == block && ac.getMetadata() == metadata);
         } while(ac.getBlock() == Blocks.stonebrick && !world.isAirBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ()));

         return false;
      case 5:
         i$ = fifthTierAltar.iterator();

         do {
            label111:
            do {
               do {
                  if(!i$.hasNext()) {
                     return true;
                  }

                  ac = (AltarComponent)i$.next();
                  if(!ac.isBloodRune()) {
                     block = world.getBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ());
                     metadata = world.getBlockMetadata(x + ac.getX(), y + ac.getY(), z + ac.getZ());
                     continue label111;
                  }

                  block = world.getBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ());
               } while(block instanceof BloodRune);

               return false;
            } while(ac.getBlock() == block && ac.getMetadata() == metadata);
         } while(ac.getBlock() == Blocks.stonebrick && !world.isAirBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ()));

         return false;
      case 6:
         i$ = sixthTierAltar.iterator();

         do {
            label92:
            do {
               do {
                  if(!i$.hasNext()) {
                     return true;
                  }

                  ac = (AltarComponent)i$.next();
                  if(!ac.isBloodRune()) {
                     block = world.getBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ());
                     metadata = world.getBlockMetadata(x + ac.getX(), y + ac.getY(), z + ac.getZ());
                     continue label92;
                  }

                  block = world.getBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ());
               } while(block instanceof BloodRune);

               return false;
            } while(ac.getBlock() == block && ac.getMetadata() == metadata);
         } while(ac.getBlock() == Blocks.stonebrick && !world.isAirBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ()));

         return false;
      default:
         return false;
      }
   }

   public static AltarUpgradeComponent getUpgrades(World world, int x, int y, int z, int altarTier) {
      if(world.isRemote) {
         return null;
      } else {
         AltarUpgradeComponent upgrades = new AltarUpgradeComponent();
         List list = getAltarUpgradeListForTier(altarTier);
         Iterator i$ = list.iterator();

         while(i$.hasNext()) {
            AltarComponent ac = (AltarComponent)i$.next();
            if(ac.isUpgradeSlot()) {
               Block testBlock = world.getBlock(x + ac.getX(), y + ac.getY(), z + ac.getZ());
               int meta = world.getBlockMetadata(x + ac.getX(), y + ac.getY(), z + ac.getZ());
               if(testBlock instanceof BloodRune) {
                  if(testBlock instanceof IFadedRune && altarTier > ((IFadedRune)testBlock).getAltarTierLimit(meta)) {
                     return getUpgrades(world, x, y, z, ((IFadedRune)testBlock).getAltarTierLimit(meta));
                  }

                  switch(((BloodRune)testBlock).getRuneEffect(meta)) {
                  case 1:
                     upgrades.addSpeedUpgrade();
                     break;
                  case 2:
                     upgrades.addEfficiencyUpgrade();
                     break;
                  case 3:
                     upgrades.addSacrificeUpgrade();
                     break;
                  case 4:
                     upgrades.addSelfSacrificeUpgrade();
                     break;
                  case 5:
                     upgrades.addaltarCapacitiveUpgrade();
                     break;
                  case 6:
                     upgrades.addDisplacementUpgrade();
                     break;
                  case 7:
                     upgrades.addorbCapacitiveUpgrade();
                     break;
                  case 8:
                     upgrades.addBetterCapacitiveUpgrade();
                     break;
                  case 9:
                     upgrades.addAccelerationUpgrade();
                  }
               }
            }
         }

         return upgrades;
      }
   }

   public static void loadAltars() {
      secondTierAltar.add(new AltarComponent(-1, -1, -1, ModBlocks.bloodRune, 0, true, false));
      secondTierAltar.add(new AltarComponent(0, -1, -1, ModBlocks.bloodRune, 0, true, true));
      secondTierAltar.add(new AltarComponent(1, -1, -1, ModBlocks.bloodRune, 0, true, false));
      secondTierAltar.add(new AltarComponent(-1, -1, 0, ModBlocks.bloodRune, 0, true, true));
      secondTierAltar.add(new AltarComponent(1, -1, 0, ModBlocks.bloodRune, 0, true, true));
      secondTierAltar.add(new AltarComponent(-1, -1, 1, ModBlocks.bloodRune, 0, true, false));
      secondTierAltar.add(new AltarComponent(0, -1, 1, ModBlocks.bloodRune, 0, true, true));
      secondTierAltar.add(new AltarComponent(1, -1, 1, ModBlocks.bloodRune, 0, true, false));
      thirdTierAltar.add(new AltarComponent(-1, -1, -1, ModBlocks.bloodRune, 0, true, true));
      thirdTierAltar.add(new AltarComponent(0, -1, -1, ModBlocks.bloodRune, 0, true, true));
      thirdTierAltar.add(new AltarComponent(1, -1, -1, ModBlocks.bloodRune, 0, true, true));
      thirdTierAltar.add(new AltarComponent(-1, -1, 0, ModBlocks.bloodRune, 0, true, true));
      thirdTierAltar.add(new AltarComponent(1, -1, 0, ModBlocks.bloodRune, 0, true, true));
      thirdTierAltar.add(new AltarComponent(-1, -1, 1, ModBlocks.bloodRune, 0, true, true));
      thirdTierAltar.add(new AltarComponent(0, -1, 1, ModBlocks.bloodRune, 0, true, true));
      thirdTierAltar.add(new AltarComponent(1, -1, 1, ModBlocks.bloodRune, 0, true, true));
      thirdTierAltar.add(new AltarComponent(-3, -1, -3, Blocks.stonebrick, 0, false, false));
      thirdTierAltar.add(new AltarComponent(-3, 0, -3, Blocks.stonebrick, 0, false, false));
      thirdTierAltar.add(new AltarComponent(3, -1, -3, Blocks.stonebrick, 0, false, false));
      thirdTierAltar.add(new AltarComponent(3, 0, -3, Blocks.stonebrick, 0, false, false));
      thirdTierAltar.add(new AltarComponent(-3, -1, 3, Blocks.stonebrick, 0, false, false));
      thirdTierAltar.add(new AltarComponent(-3, 0, 3, Blocks.stonebrick, 0, false, false));
      thirdTierAltar.add(new AltarComponent(3, -1, 3, Blocks.stonebrick, 0, false, false));
      thirdTierAltar.add(new AltarComponent(3, 0, 3, Blocks.stonebrick, 0, false, false));
      thirdTierAltar.add(new AltarComponent(-3, 1, -3, Blocks.glowstone, 0, false, false));
      thirdTierAltar.add(new AltarComponent(3, 1, -3, Blocks.glowstone, 0, false, false));
      thirdTierAltar.add(new AltarComponent(-3, 1, 3, Blocks.glowstone, 0, false, false));
      thirdTierAltar.add(new AltarComponent(3, 1, 3, Blocks.glowstone, 0, false, false));

      int i;
      for(i = -2; i <= 2; ++i) {
         thirdTierAltar.add(new AltarComponent(3, -2, i, ModBlocks.bloodRune, 0, true, true));
         thirdTierAltar.add(new AltarComponent(-3, -2, i, ModBlocks.bloodRune, 0, true, true));
         thirdTierAltar.add(new AltarComponent(i, -2, 3, ModBlocks.bloodRune, 0, true, true));
         thirdTierAltar.add(new AltarComponent(i, -2, -3, ModBlocks.bloodRune, 0, true, true));
      }

      fourthTierAltar.addAll(thirdTierAltar);

      for(i = -3; i <= 3; ++i) {
         fourthTierAltar.add(new AltarComponent(5, -3, i, ModBlocks.bloodRune, 0, true, true));
         fourthTierAltar.add(new AltarComponent(-5, -3, i, ModBlocks.bloodRune, 0, true, true));
         fourthTierAltar.add(new AltarComponent(i, -3, 5, ModBlocks.bloodRune, 0, true, true));
         fourthTierAltar.add(new AltarComponent(i, -3, -5, ModBlocks.bloodRune, 0, true, true));
      }

      for(i = -2; i <= 1; ++i) {
         fourthTierAltar.add(new AltarComponent(5, i, 5, Blocks.stonebrick, 0, false, false));
         fourthTierAltar.add(new AltarComponent(5, i, -5, Blocks.stonebrick, 0, false, false));
         fourthTierAltar.add(new AltarComponent(-5, i, -5, Blocks.stonebrick, 0, false, false));
         fourthTierAltar.add(new AltarComponent(-5, i, 5, Blocks.stonebrick, 0, false, false));
      }

      fourthTierAltar.add(new AltarComponent(5, 2, 5, ModBlocks.largeBloodStoneBrick, 0, false, false));
      fourthTierAltar.add(new AltarComponent(5, 2, -5, ModBlocks.largeBloodStoneBrick, 0, false, false));
      fourthTierAltar.add(new AltarComponent(-5, 2, -5, ModBlocks.largeBloodStoneBrick, 0, false, false));
      fourthTierAltar.add(new AltarComponent(-5, 2, 5, ModBlocks.largeBloodStoneBrick, 0, false, false));
      fifthTierAltar.addAll(fourthTierAltar);
      fifthTierAltar.add(new AltarComponent(-8, -3, 8, Blocks.beacon, 0, false, false));
      fifthTierAltar.add(new AltarComponent(-8, -3, -8, Blocks.beacon, 0, false, false));
      fifthTierAltar.add(new AltarComponent(8, -3, -8, Blocks.beacon, 0, false, false));
      fifthTierAltar.add(new AltarComponent(8, -3, 8, Blocks.beacon, 0, false, false));

      for(i = -6; i <= 6; ++i) {
         fifthTierAltar.add(new AltarComponent(8, -4, i, ModBlocks.bloodRune, 0, true, true));
         fifthTierAltar.add(new AltarComponent(-8, -4, i, ModBlocks.bloodRune, 0, true, true));
         fifthTierAltar.add(new AltarComponent(i, -4, 8, ModBlocks.bloodRune, 0, true, true));
         fifthTierAltar.add(new AltarComponent(i, -4, -8, ModBlocks.bloodRune, 0, true, true));
      }

      sixthTierAltar.addAll(fifthTierAltar);

      for(i = -4; i <= 2; ++i) {
         sixthTierAltar.add(new AltarComponent(11, i, 11, Blocks.stonebrick, 0, false, false));
         sixthTierAltar.add(new AltarComponent(-11, i, -11, Blocks.stonebrick, 0, false, false));
         sixthTierAltar.add(new AltarComponent(11, i, -11, Blocks.stonebrick, 0, false, false));
         sixthTierAltar.add(new AltarComponent(-11, i, 11, Blocks.stonebrick, 0, false, false));
      }

      sixthTierAltar.add(new AltarComponent(11, 3, 11, ModBlocks.blockCrystal, 0, false, false));
      sixthTierAltar.add(new AltarComponent(-11, 3, -11, ModBlocks.blockCrystal, 0, false, false));
      sixthTierAltar.add(new AltarComponent(11, 3, -11, ModBlocks.blockCrystal, 0, false, false));
      sixthTierAltar.add(new AltarComponent(-11, 3, 11, ModBlocks.blockCrystal, 0, false, false));

      for(i = -9; i <= 9; ++i) {
         sixthTierAltar.add(new AltarComponent(11, -5, i, ModBlocks.bloodRune, 0, true, true));
         sixthTierAltar.add(new AltarComponent(-11, -5, i, ModBlocks.bloodRune, 0, true, true));
         sixthTierAltar.add(new AltarComponent(i, -5, 11, ModBlocks.bloodRune, 0, true, true));
         sixthTierAltar.add(new AltarComponent(i, -5, -11, ModBlocks.bloodRune, 0, true, true));
      }

   }

   public static List getAltarUpgradeListForTier(int tier) {
      switch(tier) {
      case 2:
         return secondTierAltar;
      case 3:
         return thirdTierAltar;
      case 4:
         return fourthTierAltar;
      case 5:
         return fifthTierAltar;
      case 6:
         return sixthTierAltar;
      default:
         return null;
      }
   }

}
