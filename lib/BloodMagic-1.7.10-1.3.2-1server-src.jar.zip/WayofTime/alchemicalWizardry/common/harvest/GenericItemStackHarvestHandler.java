package WayofTime.alchemicalWizardry.common.harvest;

import WayofTime.alchemicalWizardry.api.harvest.IHarvestHandler;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.block.Block;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.common.IPlantable;

public class GenericItemStackHarvestHandler implements IHarvestHandler {

   public Block harvestBlock;
   public int harvestMeta;
   public ItemStack harvestItem;
   public IPlantable harvestSeed;


   public GenericItemStackHarvestHandler(Block block, int meta, ItemStack seed) {
      this.harvestBlock = block;
      this.harvestMeta = meta;
      this.harvestItem = seed;
      if(seed.getItem() instanceof IPlantable) {
         this.harvestSeed = (IPlantable)seed.getItem();
      }

   }

   public boolean canHandleBlock(Block block) {
      return block == this.harvestBlock;
   }

   public int getHarvestMeta(Block block) {
      return this.harvestMeta;
   }

   public boolean harvestAndPlant(World world, int xCoord, int yCoord, int zCoord, Block block, int meta) {
      if(this.canHandleBlock(block) && meta == this.getHarvestMeta(block)) {
         IPlantable seed = this.getSeedItem(block);
         if(seed == null) {
            world.func_147480_a(xCoord, yCoord, zCoord, true);
            return true;
         } else {
            byte fortune = 0;
            ArrayList list = block.getDrops(world, xCoord, yCoord, zCoord, meta, fortune);
            boolean foundAndRemovedSeed = false;
            Iterator plantMeta = list.iterator();

            while(plantMeta.hasNext()) {
               ItemStack plantBlock = (ItemStack)plantMeta.next();
               if(plantBlock != null && this.harvestItem.isItemEqual(plantBlock)) {
                  int i$ = plantBlock.stackSize;
                  if(i$ >= 1) {
                     if(i$ == 1) {
                        list.remove(plantBlock);
                     } else {
                        --plantBlock.stackSize;
                     }

                     foundAndRemovedSeed = true;
                     break;
                  }
               }
            }

            if(foundAndRemovedSeed) {
               int var16 = seed.getPlantMetadata(world, xCoord, yCoord, zCoord);
               Block var17 = seed.getPlant(world, xCoord, yCoord, zCoord);
               world.func_147480_a(xCoord, yCoord, zCoord, false);
               world.setBlock(xCoord, yCoord, zCoord, var17, var16, 3);
               Iterator var18 = list.iterator();

               while(var18.hasNext()) {
                  ItemStack stack = (ItemStack)var18.next();
                  EntityItem itemEnt = new EntityItem(world, (double)xCoord, (double)yCoord, (double)zCoord, stack);
                  world.spawnEntityInWorld(itemEnt);
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }

   public IPlantable getSeedItem(Block block) {
      return this.harvestSeed;
   }
}
