package WayofTime.alchemicalWizardry.common.alchemy;

import WayofTime.alchemicalWizardry.api.alchemy.AlchemyPotionHelper;
import WayofTime.alchemicalWizardry.common.alchemy.CombinedPotionComponent;
import WayofTime.alchemicalWizardry.common.items.potion.AlchemyFlask;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class CombinedPotionRegistry {

   public static List potionList = new ArrayList();


   public static void registerCombinedPotionRecipe(Potion result, Potion pot1, Potion pot2) {
      potionList.add(new CombinedPotionComponent(result, pot1, pot2));
   }

   public static boolean isRecipeValid(Potion pot1, Potion pot2) {
      Iterator i$ = potionList.iterator();

      CombinedPotionComponent recipe;
      do {
         if(!i$.hasNext()) {
            return false;
         }

         recipe = (CombinedPotionComponent)i$.next();
      } while(!recipe.isRecipeValid(pot1, pot2));

      return true;
   }

   public static boolean isRecipeValid(int pot1, int pot2) {
      Iterator i$ = potionList.iterator();

      CombinedPotionComponent recipe;
      do {
         if(!i$.hasNext()) {
            return false;
         }

         recipe = (CombinedPotionComponent)i$.next();
      } while(!recipe.isRecipeValid(pot1, pot2));

      return true;
   }

   public static Potion getPotion(Potion pot1, Potion pot2) {
      Iterator i$ = potionList.iterator();

      CombinedPotionComponent recipe;
      do {
         if(!i$.hasNext()) {
            return null;
         }

         recipe = (CombinedPotionComponent)i$.next();
      } while(!recipe.isRecipeValid(pot1, pot2));

      return recipe.result;
   }

   public static Potion getPotion(int pot1, int pot2) {
      Iterator i$ = potionList.iterator();

      CombinedPotionComponent recipe;
      do {
         if(!i$.hasNext()) {
            return null;
         }

         recipe = (CombinedPotionComponent)i$.next();
      } while(!recipe.isRecipeValid(pot1, pot2));

      return recipe.result;
   }

   public static ItemStack applyPotionEffect(ItemStack stack) {
      if(stack != null && stack.getItem() instanceof AlchemyFlask) {
         ArrayList list = AlchemyFlask.getEffects(stack);
         if(list == null) {
            return stack;
         } else {
            boolean isDone = false;
            Iterator i$ = list.iterator();

            while(i$.hasNext()) {
               AlchemyPotionHelper helper1 = (AlchemyPotionHelper)i$.next();
               if(!isDone) {
                  for(int i = 0; i < list.size(); ++i) {
                     if(!isDone) {
                        AlchemyPotionHelper helper2 = (AlchemyPotionHelper)list.get(i);
                        PotionEffect potEffect = getResultantPotion(helper1, helper2);
                        if(potEffect != null) {
                           AlchemyPotionHelper potHelper = new AlchemyPotionHelper(potEffect.getPotionID(), potEffect.getDuration(), 0, potEffect.getAmplifier());
                           list.remove(helper1);
                           list.remove(helper2);
                           list.add(potHelper);
                           isDone = true;
                        }
                     }
                  }
               }
            }

            if(isDone) {
               AlchemyFlask.setEffects(stack, list);
               return stack;
            } else {
               return null;
            }
         }
      } else {
         return null;
      }
   }

   public static boolean hasCombinablePotionEffect(ItemStack stack) {
      if(stack != null && stack.getItem() instanceof AlchemyFlask) {
         ArrayList list = AlchemyFlask.getEffects(stack);
         if(list == null) {
            return false;
         } else {
            Iterator i$ = list.iterator();

            while(i$.hasNext()) {
               AlchemyPotionHelper helper1 = (AlchemyPotionHelper)i$.next();
               Iterator i$1 = list.iterator();

               while(i$1.hasNext()) {
                  AlchemyPotionHelper helper2 = (AlchemyPotionHelper)i$1.next();
                  int pot1 = helper1.getPotionID();
                  int pot2 = helper2.getPotionID();
                  if(isRecipeValid(pot1, pot2)) {
                     return true;
                  }
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }

   public static PotionEffect getResultantPotion(AlchemyPotionHelper potE1, AlchemyPotionHelper potE2) {
      if(potE1 != null && potE2 != null) {
         int pot1 = potE1.getPotionID();
         int pot2 = potE2.getPotionID();
         if(isRecipeValid(pot1, pot2)) {
            int duration = (int)(((double)potE1.getTickDuration() * Math.pow(2.6666667461395264D, (double)potE1.getdurationFactor()) + (double)potE2.getdurationFactor() * Math.pow(2.6666667461395264D, (double)potE2.getdurationFactor())) / 2.0D);
            int amplifier = (potE1.getConcentration() + potE2.getConcentration()) / 2;
            Potion pot = getPotion(pot1, pot2);
            return new PotionEffect(pot.id, duration, amplifier);
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

}
