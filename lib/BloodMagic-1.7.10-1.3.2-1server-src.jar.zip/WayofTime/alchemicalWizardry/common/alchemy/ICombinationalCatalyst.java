package WayofTime.alchemicalWizardry.common.alchemy;


public interface ICombinationalCatalyst {
}
