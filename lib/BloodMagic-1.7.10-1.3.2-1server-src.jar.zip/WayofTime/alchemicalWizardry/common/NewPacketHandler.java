package WayofTime.alchemicalWizardry.common;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.ColourAndCoords;
import WayofTime.alchemicalWizardry.api.alchemy.energy.Reagent;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentRegistry;
import WayofTime.alchemicalWizardry.api.spell.APISpellHelper;
import WayofTime.alchemicalWizardry.common.tileEntity.TEAltar;
import WayofTime.alchemicalWizardry.common.tileEntity.TEMasterStone;
import WayofTime.alchemicalWizardry.common.tileEntity.TEOrientable;
import WayofTime.alchemicalWizardry.common.tileEntity.TEPedestal;
import WayofTime.alchemicalWizardry.common.tileEntity.TEPlinth;
import WayofTime.alchemicalWizardry.common.tileEntity.TEReagentConduit;
import WayofTime.alchemicalWizardry.common.tileEntity.TESocket;
import WayofTime.alchemicalWizardry.common.tileEntity.TETeleposer;
import WayofTime.alchemicalWizardry.common.tileEntity.TEWritingTable;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.network.FMLEmbeddedChannel;
import cpw.mods.fml.common.network.FMLIndexedMessageToMessageCodec;
import cpw.mods.fml.common.network.FMLOutboundHandler;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.network.FMLOutboundHandler.OutboundTarget;
import cpw.mods.fml.common.network.NetworkRegistry.TargetPoint;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityClientPlayerMP;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.network.Packet;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public enum NewPacketHandler {

   INSTANCE("INSTANCE", 0);
   private EnumMap channels;
   // $FF: synthetic field
   private static final NewPacketHandler[] $VALUES = new NewPacketHandler[]{INSTANCE};


   private NewPacketHandler(String var1, int var2) {
      this.channels = NetworkRegistry.INSTANCE.newChannel("BloodMagic", new ChannelHandler[]{new NewPacketHandler.TEAltarCodec()});
      if(FMLCommonHandler.instance().getSide() == Side.CLIENT) {
         this.addClientHandler();
      }

      if(FMLCommonHandler.instance().getSide() == Side.SERVER) {
         System.out.println("Server sided~");
         this.addServerHandler();
      }

   }

   @SideOnly(Side.CLIENT)
   private void addClientHandler() {
      FMLEmbeddedChannel clientChannel = (FMLEmbeddedChannel)this.channels.get(Side.CLIENT);
      String tileAltarCodec = clientChannel.findChannelHandlerNameForType(NewPacketHandler.TEAltarCodec.class);
      clientChannel.pipeline().addAfter(tileAltarCodec, "TEAltarHandler", new NewPacketHandler.TEAltarMessageHandler((NewPacketHandler.NamelessClass715594307)null));
      clientChannel.pipeline().addAfter(tileAltarCodec, "TEOrientableHandler", new NewPacketHandler.TEOrientableMessageHandler((NewPacketHandler.NamelessClass715594307)null));
      clientChannel.pipeline().addAfter(tileAltarCodec, "TEPedestalHandler", new NewPacketHandler.TEPedestalMessageHandler((NewPacketHandler.NamelessClass715594307)null));
      clientChannel.pipeline().addAfter(tileAltarCodec, "TEPlinthHandler", new NewPacketHandler.TEPlinthMessageHandler((NewPacketHandler.NamelessClass715594307)null));
      clientChannel.pipeline().addAfter(tileAltarCodec, "TESocketHandler", new NewPacketHandler.TESocketMessageHandler((NewPacketHandler.NamelessClass715594307)null));
      clientChannel.pipeline().addAfter(tileAltarCodec, "TETeleposerHandler", new NewPacketHandler.TETeleposerMessageHandler((NewPacketHandler.NamelessClass715594307)null));
      clientChannel.pipeline().addAfter(tileAltarCodec, "TEWritingTableHandler", new NewPacketHandler.TEWritingTableMessageHandler((NewPacketHandler.NamelessClass715594307)null));
      clientChannel.pipeline().addAfter(tileAltarCodec, "ParticleHandler", new NewPacketHandler.ParticleMessageHandler((NewPacketHandler.NamelessClass715594307)null));
      clientChannel.pipeline().addAfter(tileAltarCodec, "VelocityHandler", new NewPacketHandler.VelocityMessageHandler((NewPacketHandler.NamelessClass715594307)null));
      clientChannel.pipeline().addAfter(tileAltarCodec, "TEMasterStoneHandler", new NewPacketHandler.TEMasterStoneMessageHandler((NewPacketHandler.NamelessClass715594307)null));
      clientChannel.pipeline().addAfter(tileAltarCodec, "TEReagentConduitHandler", new NewPacketHandler.TEReagentConduitMessageHandler((NewPacketHandler.NamelessClass715594307)null));
      clientChannel.pipeline().addAfter(tileAltarCodec, "CurrentLPMessageHandler", new NewPacketHandler.CurrentLPMessageHandler((NewPacketHandler.NamelessClass715594307)null));
      clientChannel.pipeline().addAfter(tileAltarCodec, "CurrentReagentBarMessageHandler", new NewPacketHandler.CurrentReagentBarMessageHandler((NewPacketHandler.NamelessClass715594307)null));
      clientChannel.pipeline().addAfter(tileAltarCodec, "CurrentAddedHPMessageHandler", new NewPacketHandler.CurrentAddedHPMessageHandler((NewPacketHandler.NamelessClass715594307)null));
   }

   @SideOnly(Side.SERVER)
   private void addServerHandler() {
      FMLEmbeddedChannel serverChannel = (FMLEmbeddedChannel)this.channels.get(Side.SERVER);
      String messageCodec = serverChannel.findChannelHandlerNameForType(NewPacketHandler.TEAltarCodec.class);
      serverChannel.pipeline().addAfter(messageCodec, "KeyboardMessageHandler", new NewPacketHandler.KeyboardMessageHandler());
   }

   public static Packet getPacket(TEAltar tileAltar) {
      NewPacketHandler.TEAltarMessage msg = new NewPacketHandler.TEAltarMessage();
      msg.index = 0;
      msg.x = tileAltar.xCoord;
      msg.y = tileAltar.yCoord;
      msg.z = tileAltar.zCoord;
      msg.items = tileAltar.buildIntDataList();
      msg.fluids = tileAltar.buildFluidList();
      msg.capacity = tileAltar.getCapacity();
      return ((FMLEmbeddedChannel)INSTANCE.channels.get(Side.SERVER)).generatePacketFrom(msg);
   }

   public static Packet getPacket(TEOrientable tileOrientable) {
      NewPacketHandler.TEOrientableMessage msg = new NewPacketHandler.TEOrientableMessage();
      msg.index = 1;
      msg.x = tileOrientable.xCoord;
      msg.y = tileOrientable.yCoord;
      msg.z = tileOrientable.zCoord;
      msg.input = TEOrientable.getIntForForgeDirection(tileOrientable.getInputDirection());
      msg.output = TEOrientable.getIntForForgeDirection(tileOrientable.getOutputDirection());
      return ((FMLEmbeddedChannel)INSTANCE.channels.get(Side.SERVER)).generatePacketFrom(msg);
   }

   public static Packet getPacket(TEPedestal tilePedestal) {
      NewPacketHandler.TEPedestalMessage msg = new NewPacketHandler.TEPedestalMessage();
      msg.index = 2;
      msg.x = tilePedestal.xCoord;
      msg.y = tilePedestal.yCoord;
      msg.z = tilePedestal.zCoord;
      msg.items = tilePedestal.buildIntDataList();
      return ((FMLEmbeddedChannel)INSTANCE.channels.get(Side.SERVER)).generatePacketFrom(msg);
   }

   public static Packet getPacket(TEPlinth tilePlinth) {
      NewPacketHandler.TEPlinthMessage msg = new NewPacketHandler.TEPlinthMessage();
      msg.index = 3;
      msg.x = tilePlinth.xCoord;
      msg.y = tilePlinth.yCoord;
      msg.z = tilePlinth.zCoord;
      msg.items = tilePlinth.buildIntDataList();
      return ((FMLEmbeddedChannel)INSTANCE.channels.get(Side.SERVER)).generatePacketFrom(msg);
   }

   public static Packet getPacket(TESocket tileSocket) {
      NewPacketHandler.TESocketMessage msg = new NewPacketHandler.TESocketMessage();
      msg.index = 4;
      msg.x = tileSocket.xCoord;
      msg.y = tileSocket.yCoord;
      msg.z = tileSocket.zCoord;
      msg.items = tileSocket.buildIntDataList();
      return ((FMLEmbeddedChannel)INSTANCE.channels.get(Side.SERVER)).generatePacketFrom(msg);
   }

   public static Packet getPacket(TETeleposer tileTeleposer) {
      NewPacketHandler.TETeleposerMessage msg = new NewPacketHandler.TETeleposerMessage();
      msg.index = 5;
      msg.x = tileTeleposer.xCoord;
      msg.y = tileTeleposer.yCoord;
      msg.z = tileTeleposer.zCoord;
      msg.items = tileTeleposer.buildIntDataList();
      return ((FMLEmbeddedChannel)INSTANCE.channels.get(Side.SERVER)).generatePacketFrom(msg);
   }

   public static Packet getPacket(TEWritingTable tileWritingTable) {
      NewPacketHandler.TEWritingTableMessage msg = new NewPacketHandler.TEWritingTableMessage();
      msg.index = 6;
      msg.x = tileWritingTable.xCoord;
      msg.y = tileWritingTable.yCoord;
      msg.z = tileWritingTable.zCoord;
      msg.items = tileWritingTable.buildIntDataList();
      return ((FMLEmbeddedChannel)INSTANCE.channels.get(Side.SERVER)).generatePacketFrom(msg);
   }

   public static Packet getParticlePacket(String str, double xCoord, double yCoord, double zCoord, double xVel, double yVel, double zVel) {
      NewPacketHandler.ParticleMessage msg = new NewPacketHandler.ParticleMessage();
      msg.index = 7;
      msg.particle = str;
      msg.xCoord = xCoord;
      msg.yCoord = yCoord;
      msg.zCoord = zCoord;
      msg.xVel = xVel;
      msg.yVel = yVel;
      msg.zVel = zVel;
      return ((FMLEmbeddedChannel)INSTANCE.channels.get(Side.SERVER)).generatePacketFrom(msg);
   }

   public static Packet getVelSettingPacket(double xVel, double yVel, double zVel) {
      NewPacketHandler.VelocityMessage msg = new NewPacketHandler.VelocityMessage();
      msg.index = 8;
      msg.xVel = xVel;
      msg.yVel = yVel;
      msg.zVel = zVel;
      return ((FMLEmbeddedChannel)INSTANCE.channels.get(Side.SERVER)).generatePacketFrom(msg);
   }

   public static Packet getPacket(TEMasterStone tile) {
      NewPacketHandler.TEMasterStoneMessage msg = new NewPacketHandler.TEMasterStoneMessage();
      msg.index = 9;
      msg.x = tile.xCoord;
      msg.y = tile.yCoord;
      msg.z = tile.zCoord;
      msg.ritual = tile.getCurrentRitual();
      msg.isRunning = tile.isRunning;
      return ((FMLEmbeddedChannel)INSTANCE.channels.get(Side.SERVER)).generatePacketFrom(msg);
   }

   public static Packet getPacket(TEReagentConduit tile) {
      NewPacketHandler.TEReagentConduitMessage msg = new NewPacketHandler.TEReagentConduitMessage();
      msg.index = 10;
      msg.x = tile.xCoord;
      msg.y = tile.yCoord;
      msg.z = tile.zCoord;
      msg.destinationList = tile.destinationList;
      return ((FMLEmbeddedChannel)INSTANCE.channels.get(Side.SERVER)).generatePacketFrom(msg);
   }

   public static Packet getLPPacket(int curLP, int maxLP) {
      NewPacketHandler.CurrentLPMessage msg = new NewPacketHandler.CurrentLPMessage();
      msg.index = 11;
      msg.currentLP = curLP;
      msg.maxLP = maxLP;
      return ((FMLEmbeddedChannel)INSTANCE.channels.get(Side.SERVER)).generatePacketFrom(msg);
   }

   public static Packet getReagentBarPacket(Reagent reagent, float curAR, float maxAR) {
      NewPacketHandler.CurrentReagentBarMessage msg = new NewPacketHandler.CurrentReagentBarMessage();
      msg.index = 12;
      msg.reagent = ReagentRegistry.getKeyForReagent(reagent);
      msg.currentAR = curAR;
      msg.maxAR = maxAR;
      return ((FMLEmbeddedChannel)INSTANCE.channels.get(Side.SERVER)).generatePacketFrom(msg);
   }

   public static Packet getAddedHPPacket(float health, float maxHP) {
      NewPacketHandler.CurrentAddedHPMessage msg = new NewPacketHandler.CurrentAddedHPMessage();
      msg.index = 13;
      msg.currentHP = health;
      msg.maxHP = maxHP;
      return ((FMLEmbeddedChannel)INSTANCE.channels.get(Side.SERVER)).generatePacketFrom(msg);
   }

   public static Packet getKeyboardPressPacket(byte bt) {
      NewPacketHandler.KeyboardMessage msg = new NewPacketHandler.KeyboardMessage();
      msg.index = 14;
      msg.keyPressed = bt;
      System.out.println("Packet is being created");
      return ((FMLEmbeddedChannel)INSTANCE.channels.get(Side.CLIENT)).generatePacketFrom(msg);
   }

   public void sendTo(Packet message, EntityPlayerMP player) {
      ((FMLEmbeddedChannel)this.channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(OutboundTarget.PLAYER);
      ((FMLEmbeddedChannel)this.channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGETARGS).set(player);
      ((FMLEmbeddedChannel)this.channels.get(Side.SERVER)).writeAndFlush(message);
   }

   public void sendToAll(Packet message) {
      ((FMLEmbeddedChannel)this.channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(OutboundTarget.ALL);
      ((FMLEmbeddedChannel)this.channels.get(Side.SERVER)).writeAndFlush(message);
   }

   public void sendToAllAround(Packet message, TargetPoint point) {
      ((FMLEmbeddedChannel)this.channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(OutboundTarget.ALLAROUNDPOINT);
      ((FMLEmbeddedChannel)this.channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGETARGS).set(point);
      ((FMLEmbeddedChannel)this.channels.get(Side.SERVER)).writeAndFlush(message);
   }

   public void sendToServer(Packet message) {
      ((FMLEmbeddedChannel)this.channels.get(Side.CLIENT)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(OutboundTarget.TOSERVER);
      ((FMLEmbeddedChannel)this.channels.get(Side.CLIENT)).writeAndFlush(message).addListener(ChannelFutureListener.FIRE_EXCEPTION_ON_FAILURE);
   }


   private static class KeyboardMessageHandler extends SimpleChannelInboundHandler {

      public KeyboardMessageHandler() {
         System.out.println("I am being created");
      }

      protected void channelRead0(ChannelHandlerContext ctx, NewPacketHandler.KeyboardMessage msg) throws Exception {
         System.out.println("Hmmm");
      }
   }

   public static class CurrentReagentBarMessage extends NewPacketHandler.BMMessage {

      String reagent;
      float currentAR;
      float maxAR;


   }

   public static class TEWritingTableMessage extends NewPacketHandler.BMMessage {

      int x;
      int y;
      int z;
      int[] items;


   }

   private static class TEOrientableMessageHandler extends SimpleChannelInboundHandler {

      private TEOrientableMessageHandler() {}

      protected void channelRead0(ChannelHandlerContext ctx, NewPacketHandler.TEOrientableMessage msg) throws Exception {
         World world = AlchemicalWizardry.proxy.getClientWorld();
         TileEntity te = world.getTileEntity(msg.x, msg.y, msg.z);
         if(te instanceof TEOrientable) {
            TEOrientable tile = (TEOrientable)te;
            ((TEOrientable)te).setInputDirection(ForgeDirection.getOrientation(msg.input));
            ((TEOrientable)te).setOutputDirection(ForgeDirection.getOrientation(msg.output));
         }

      }

      // $FF: synthetic method
      TEOrientableMessageHandler(NewPacketHandler.NamelessClass715594307 x0) {
         this();
      }
   }

   private static class CurrentReagentBarMessageHandler extends SimpleChannelInboundHandler {

      private CurrentReagentBarMessageHandler() {}

      protected void channelRead0(ChannelHandlerContext ctx, NewPacketHandler.CurrentReagentBarMessage msg) throws Exception {
         EntityClientPlayerMP player = Minecraft.getMinecraft().thePlayer;
         APISpellHelper.setPlayerReagentType(player, msg.reagent);
         APISpellHelper.setPlayerCurrentReagentAmount(player, msg.currentAR);
         APISpellHelper.setPlayerMaxReagentAmount(player, msg.maxAR);
      }

      // $FF: synthetic method
      CurrentReagentBarMessageHandler(NewPacketHandler.NamelessClass715594307 x0) {
         this();
      }
   }

   private static class TETeleposerMessageHandler extends SimpleChannelInboundHandler {

      private TETeleposerMessageHandler() {}

      protected void channelRead0(ChannelHandlerContext ctx, NewPacketHandler.TETeleposerMessage msg) throws Exception {
         World world = AlchemicalWizardry.proxy.getClientWorld();
         TileEntity te = world.getTileEntity(msg.x, msg.y, msg.z);
         if(te instanceof TETeleposer) {
            TETeleposer Teleposer = (TETeleposer)te;
            Teleposer.handlePacketData(msg.items);
         }

      }

      // $FF: synthetic method
      TETeleposerMessageHandler(NewPacketHandler.NamelessClass715594307 x0) {
         this();
      }
   }

   public static class TEPedestalMessage extends NewPacketHandler.BMMessage {

      int x;
      int y;
      int z;
      int[] items;


   }

   private class ClientToServerCodec extends FMLIndexedMessageToMessageCodec {

      public void encodeInto(ChannelHandlerContext ctx, NewPacketHandler.BMMessage msg, ByteBuf target) throws Exception {
         target.writeInt(msg.index);
         int var10000 = msg.index;
      }

      public void decodeInto(ChannelHandlerContext ctx, ByteBuf source, NewPacketHandler.BMMessage msg) {
         int index = source.readInt();
         System.out.println("Packet is recieved and being decoded");
      }
   }

   public static class TESocketMessage extends NewPacketHandler.BMMessage {

      int x;
      int y;
      int z;
      int[] items;


   }

   public static class TEOrientableMessage extends NewPacketHandler.BMMessage {

      int x;
      int y;
      int z;
      int input;
      int output;


   }

   public static class TEReagentConduitMessage extends NewPacketHandler.BMMessage {

      int x;
      int y;
      int z;
      List destinationList;


   }

   private static class TEPlinthMessageHandler extends SimpleChannelInboundHandler {

      private TEPlinthMessageHandler() {}

      protected void channelRead0(ChannelHandlerContext ctx, NewPacketHandler.TEPlinthMessage msg) throws Exception {
         World world = AlchemicalWizardry.proxy.getClientWorld();
         TileEntity te = world.getTileEntity(msg.x, msg.y, msg.z);
         if(te instanceof TEPlinth) {
            TEPlinth Plinth = (TEPlinth)te;
            Plinth.handlePacketData(msg.items);
         }

      }

      // $FF: synthetic method
      TEPlinthMessageHandler(NewPacketHandler.NamelessClass715594307 x0) {
         this();
      }
   }

   private static class CurrentAddedHPMessageHandler extends SimpleChannelInboundHandler {

      private CurrentAddedHPMessageHandler() {}

      protected void channelRead0(ChannelHandlerContext ctx, NewPacketHandler.CurrentAddedHPMessage msg) throws Exception {
         EntityClientPlayerMP player = Minecraft.getMinecraft().thePlayer;
         APISpellHelper.setCurrentAdditionalHP(player, msg.currentHP);
         APISpellHelper.setCurrentAdditionalMaxHP(player, msg.maxHP);
      }

      // $FF: synthetic method
      CurrentAddedHPMessageHandler(NewPacketHandler.NamelessClass715594307 x0) {
         this();
      }
   }

   public static class TEAltarMessage extends NewPacketHandler.BMMessage {

      int x;
      int y;
      int z;
      int[] items;
      int[] fluids;
      int capacity;


   }

   public static class TEPlinthMessage extends NewPacketHandler.BMMessage {

      int x;
      int y;
      int z;
      int[] items;


   }

   // $FF: synthetic class
   static class NamelessClass715594307 {
   }

   public static class ParticleMessage extends NewPacketHandler.BMMessage {

      String particle;
      double xCoord;
      double yCoord;
      double zCoord;
      double xVel;
      double yVel;
      double zVel;


   }

   public static class CurrentLPMessage extends NewPacketHandler.BMMessage {

      int currentLP;
      int maxLP;


   }

   public static class BMMessage {

      int index;


   }

   private static class CurrentLPMessageHandler extends SimpleChannelInboundHandler {

      private CurrentLPMessageHandler() {}

      protected void channelRead0(ChannelHandlerContext ctx, NewPacketHandler.CurrentLPMessage msg) throws Exception {
         EntityClientPlayerMP player = Minecraft.getMinecraft().thePlayer;
         APISpellHelper.setPlayerLPTag(player, msg.currentLP);
         APISpellHelper.setPlayerMaxLPTag(player, msg.maxLP);
      }

      // $FF: synthetic method
      CurrentLPMessageHandler(NewPacketHandler.NamelessClass715594307 x0) {
         this();
      }
   }

   public static class TETeleposerMessage extends NewPacketHandler.BMMessage {

      int x;
      int y;
      int z;
      int[] items;


   }

   private static class TEReagentConduitMessageHandler extends SimpleChannelInboundHandler {

      private TEReagentConduitMessageHandler() {}

      protected void channelRead0(ChannelHandlerContext ctx, NewPacketHandler.TEReagentConduitMessage msg) throws Exception {
         World world = AlchemicalWizardry.proxy.getClientWorld();
         TileEntity te = world.getTileEntity(msg.x, msg.y, msg.z);
         if(te instanceof TEReagentConduit) {
            TEReagentConduit reagentConduit = (TEReagentConduit)te;
            reagentConduit.destinationList = msg.destinationList;
         }

      }

      // $FF: synthetic method
      TEReagentConduitMessageHandler(NewPacketHandler.NamelessClass715594307 x0) {
         this();
      }
   }

   public static class TEMasterStoneMessage extends NewPacketHandler.BMMessage {

      int x;
      int y;
      int z;
      String ritual;
      boolean isRunning;


   }

   public static class VelocityMessage extends NewPacketHandler.BMMessage {

      double xVel;
      double yVel;
      double zVel;


   }

   private static class VelocityMessageHandler extends SimpleChannelInboundHandler {

      private VelocityMessageHandler() {}

      protected void channelRead0(ChannelHandlerContext ctx, NewPacketHandler.VelocityMessage msg) throws Exception {
         EntityClientPlayerMP player = Minecraft.getMinecraft().thePlayer;
         if(player != null) {
            player.motionX = msg.xVel;
            player.motionY = msg.yVel;
            player.motionZ = msg.zVel;
         }

      }

      // $FF: synthetic method
      VelocityMessageHandler(NewPacketHandler.NamelessClass715594307 x0) {
         this();
      }
   }

   private class TEAltarCodec extends FMLIndexedMessageToMessageCodec {

      public TEAltarCodec() {
         this.addDiscriminator(0, NewPacketHandler.TEAltarMessage.class);
         this.addDiscriminator(1, NewPacketHandler.TEOrientableMessage.class);
         this.addDiscriminator(2, NewPacketHandler.TEPedestalMessage.class);
         this.addDiscriminator(3, NewPacketHandler.TEPlinthMessage.class);
         this.addDiscriminator(4, NewPacketHandler.TESocketMessage.class);
         this.addDiscriminator(5, NewPacketHandler.TETeleposerMessage.class);
         this.addDiscriminator(6, NewPacketHandler.TEWritingTableMessage.class);
         this.addDiscriminator(7, NewPacketHandler.ParticleMessage.class);
         this.addDiscriminator(8, NewPacketHandler.VelocityMessage.class);
         this.addDiscriminator(9, NewPacketHandler.TEMasterStoneMessage.class);
         this.addDiscriminator(10, NewPacketHandler.TEReagentConduitMessage.class);
         this.addDiscriminator(11, NewPacketHandler.CurrentLPMessage.class);
         this.addDiscriminator(12, NewPacketHandler.CurrentReagentBarMessage.class);
         this.addDiscriminator(13, NewPacketHandler.CurrentAddedHPMessage.class);
         this.addDiscriminator(14, NewPacketHandler.KeyboardMessage.class);
      }

      public void encodeInto(ChannelHandlerContext ctx, NewPacketHandler.BMMessage msg, ByteBuf target) throws Exception {
         target.writeInt(msg.index);
         int[] var12;
         int var13;
         int var14;
         switch(msg.index) {
         case 0:
            target.writeInt(((NewPacketHandler.TEAltarMessage)msg).x);
            target.writeInt(((NewPacketHandler.TEAltarMessage)msg).y);
            target.writeInt(((NewPacketHandler.TEAltarMessage)msg).z);
            target.writeBoolean(((NewPacketHandler.TEAltarMessage)msg).items != null);
            if(((NewPacketHandler.TEAltarMessage)msg).items != null) {
               var12 = ((NewPacketHandler.TEAltarMessage)msg).items;

               for(var13 = 0; var13 < var12.length; ++var13) {
                  var14 = var12[var13];
                  target.writeInt(var14);
               }
            }

            target.writeBoolean(((NewPacketHandler.TEAltarMessage)msg).fluids != null);
            if(((NewPacketHandler.TEAltarMessage)msg).fluids != null) {
               var12 = ((NewPacketHandler.TEAltarMessage)msg).fluids;

               for(var13 = 0; var13 < var12.length; ++var13) {
                  var14 = var12[var13];
                  target.writeInt(var14);
               }
            }

            target.writeInt(((NewPacketHandler.TEAltarMessage)msg).capacity);
            break;
         case 1:
            target.writeInt(((NewPacketHandler.TEOrientableMessage)msg).x);
            target.writeInt(((NewPacketHandler.TEOrientableMessage)msg).y);
            target.writeInt(((NewPacketHandler.TEOrientableMessage)msg).z);
            target.writeInt(((NewPacketHandler.TEOrientableMessage)msg).input);
            target.writeInt(((NewPacketHandler.TEOrientableMessage)msg).output);
            break;
         case 2:
            target.writeInt(((NewPacketHandler.TEPedestalMessage)msg).x);
            target.writeInt(((NewPacketHandler.TEPedestalMessage)msg).y);
            target.writeInt(((NewPacketHandler.TEPedestalMessage)msg).z);
            target.writeBoolean(((NewPacketHandler.TEPedestalMessage)msg).items != null);
            if(((NewPacketHandler.TEPedestalMessage)msg).items != null) {
               var12 = ((NewPacketHandler.TEPedestalMessage)msg).items;

               for(var13 = 0; var13 < var12.length; ++var13) {
                  var14 = var12[var13];
                  target.writeInt(var14);
               }
            }
            break;
         case 3:
            target.writeInt(((NewPacketHandler.TEPlinthMessage)msg).x);
            target.writeInt(((NewPacketHandler.TEPlinthMessage)msg).y);
            target.writeInt(((NewPacketHandler.TEPlinthMessage)msg).z);
            target.writeBoolean(((NewPacketHandler.TEPlinthMessage)msg).items != null);
            if(((NewPacketHandler.TEPlinthMessage)msg).items != null) {
               var12 = ((NewPacketHandler.TEPlinthMessage)msg).items;

               for(var13 = 0; var13 < var12.length; ++var13) {
                  var14 = var12[var13];
                  target.writeInt(var14);
               }
            }
            break;
         case 4:
            target.writeInt(((NewPacketHandler.TESocketMessage)msg).x);
            target.writeInt(((NewPacketHandler.TESocketMessage)msg).y);
            target.writeInt(((NewPacketHandler.TESocketMessage)msg).z);
            target.writeBoolean(((NewPacketHandler.TESocketMessage)msg).items != null);
            if(((NewPacketHandler.TESocketMessage)msg).items != null) {
               var12 = ((NewPacketHandler.TESocketMessage)msg).items;

               for(var13 = 0; var13 < var12.length; ++var13) {
                  var14 = var12[var13];
                  target.writeInt(var14);
               }
            }
            break;
         case 5:
            target.writeInt(((NewPacketHandler.TETeleposerMessage)msg).x);
            target.writeInt(((NewPacketHandler.TETeleposerMessage)msg).y);
            target.writeInt(((NewPacketHandler.TETeleposerMessage)msg).z);
            target.writeBoolean(((NewPacketHandler.TETeleposerMessage)msg).items != null);
            if(((NewPacketHandler.TETeleposerMessage)msg).items != null) {
               var12 = ((NewPacketHandler.TETeleposerMessage)msg).items;

               for(var13 = 0; var13 < var12.length; ++var13) {
                  var14 = var12[var13];
                  target.writeInt(var14);
               }
            }
            break;
         case 6:
            target.writeInt(((NewPacketHandler.TEWritingTableMessage)msg).x);
            target.writeInt(((NewPacketHandler.TEWritingTableMessage)msg).y);
            target.writeInt(((NewPacketHandler.TEWritingTableMessage)msg).z);
            target.writeBoolean(((NewPacketHandler.TEWritingTableMessage)msg).items != null);
            if(((NewPacketHandler.TEWritingTableMessage)msg).items != null) {
               var12 = ((NewPacketHandler.TEWritingTableMessage)msg).items;

               for(var13 = 0; var13 < var12.length; ++var13) {
                  var14 = var12[var13];
                  target.writeInt(var14);
               }
            }
            break;
         case 7:
            String str = ((NewPacketHandler.ParticleMessage)msg).particle;
            target.writeInt(str.length());

            for(var13 = 0; var13 < str.length(); ++var13) {
               target.writeChar(str.charAt(var13));
            }

            target.writeDouble(((NewPacketHandler.ParticleMessage)msg).xCoord);
            target.writeDouble(((NewPacketHandler.ParticleMessage)msg).yCoord);
            target.writeDouble(((NewPacketHandler.ParticleMessage)msg).zCoord);
            target.writeDouble(((NewPacketHandler.ParticleMessage)msg).xVel);
            target.writeDouble(((NewPacketHandler.ParticleMessage)msg).yVel);
            target.writeDouble(((NewPacketHandler.ParticleMessage)msg).zVel);
            break;
         case 8:
            target.writeDouble(((NewPacketHandler.VelocityMessage)msg).xVel);
            target.writeDouble(((NewPacketHandler.VelocityMessage)msg).yVel);
            target.writeDouble(((NewPacketHandler.VelocityMessage)msg).zVel);
            break;
         case 9:
            target.writeInt(((NewPacketHandler.TEMasterStoneMessage)msg).x);
            target.writeInt(((NewPacketHandler.TEMasterStoneMessage)msg).y);
            target.writeInt(((NewPacketHandler.TEMasterStoneMessage)msg).z);
            String ritual = ((NewPacketHandler.TEMasterStoneMessage)msg).ritual;
            target.writeInt(ritual.length());

            for(var14 = 0; var14 < ritual.length(); ++var14) {
               target.writeChar(ritual.charAt(var14));
            }

            target.writeBoolean(((NewPacketHandler.TEMasterStoneMessage)msg).isRunning);
            break;
         case 10:
            target.writeInt(((NewPacketHandler.TEReagentConduitMessage)msg).x);
            target.writeInt(((NewPacketHandler.TEReagentConduitMessage)msg).y);
            target.writeInt(((NewPacketHandler.TEReagentConduitMessage)msg).z);
            List list = ((NewPacketHandler.TEReagentConduitMessage)msg).destinationList;
            target.writeInt(list.size());
            Iterator var15 = list.iterator();

            while(var15.hasNext()) {
               ColourAndCoords var16 = (ColourAndCoords)var15.next();
               target.writeInt(var16.colourRed);
               target.writeInt(var16.colourGreen);
               target.writeInt(var16.colourBlue);
               target.writeInt(var16.colourIntensity);
               target.writeInt(var16.xCoord);
               target.writeInt(var16.yCoord);
               target.writeInt(var16.zCoord);
            }

            return;
         case 11:
            target.writeInt(((NewPacketHandler.CurrentLPMessage)msg).currentLP);
            target.writeInt(((NewPacketHandler.CurrentLPMessage)msg).maxLP);
            break;
         case 12:
            char[] charSet = ((NewPacketHandler.CurrentReagentBarMessage)msg).reagent.toCharArray();
            target.writeInt(charSet.length);
            char[] arr$ = charSet;
            int len$ = charSet.length;

            for(int i$ = 0; i$ < len$; ++i$) {
               char cha = arr$[i$];
               target.writeChar(cha);
            }

            target.writeFloat(((NewPacketHandler.CurrentReagentBarMessage)msg).currentAR);
            target.writeFloat(((NewPacketHandler.CurrentReagentBarMessage)msg).maxAR);
            break;
         case 13:
            target.writeFloat(((NewPacketHandler.CurrentAddedHPMessage)msg).currentHP);
            target.writeFloat(((NewPacketHandler.CurrentAddedHPMessage)msg).maxHP);
            break;
         case 14:
            System.out.println("Packet is being encoded");
            target.writeByte(((NewPacketHandler.KeyboardMessage)msg).keyPressed);
         }

      }

      public void decodeInto(ChannelHandlerContext ctx, ByteBuf dat, NewPacketHandler.BMMessage msg) {
         int index = dat.readInt();
         int size;
         int ritualStrSize;
         int listSize;
         int size1;
         switch(index) {
         case 0:
            ((NewPacketHandler.TEAltarMessage)msg).x = dat.readInt();
            ((NewPacketHandler.TEAltarMessage)msg).y = dat.readInt();
            ((NewPacketHandler.TEAltarMessage)msg).z = dat.readInt();
            boolean hasStacks = dat.readBoolean();
            ((NewPacketHandler.TEAltarMessage)msg).items = new int[3];
            if(hasStacks) {
               ((NewPacketHandler.TEAltarMessage)msg).items = new int[3];

               for(int hasFluids = 0; hasFluids < ((NewPacketHandler.TEAltarMessage)msg).items.length; ++hasFluids) {
                  ((NewPacketHandler.TEAltarMessage)msg).items[hasFluids] = dat.readInt();
               }
            }

            boolean var21 = dat.readBoolean();
            ((NewPacketHandler.TEAltarMessage)msg).fluids = new int[6];
            if(var21) {
               for(int var22 = 0; var22 < ((NewPacketHandler.TEAltarMessage)msg).fluids.length; ++var22) {
                  ((NewPacketHandler.TEAltarMessage)msg).fluids[var22] = dat.readInt();
               }
            }

            ((NewPacketHandler.TEAltarMessage)msg).capacity = dat.readInt();
            break;
         case 1:
            ((NewPacketHandler.TEOrientableMessage)msg).x = dat.readInt();
            ((NewPacketHandler.TEOrientableMessage)msg).y = dat.readInt();
            ((NewPacketHandler.TEOrientableMessage)msg).z = dat.readInt();
            ((NewPacketHandler.TEOrientableMessage)msg).input = dat.readInt();
            ((NewPacketHandler.TEOrientableMessage)msg).output = dat.readInt();
            break;
         case 2:
            ((NewPacketHandler.TEPedestalMessage)msg).x = dat.readInt();
            ((NewPacketHandler.TEPedestalMessage)msg).y = dat.readInt();
            ((NewPacketHandler.TEPedestalMessage)msg).z = dat.readInt();
            boolean hasStacks1 = dat.readBoolean();
            ((NewPacketHandler.TEPedestalMessage)msg).items = new int[3];
            if(hasStacks1) {
               ((NewPacketHandler.TEPedestalMessage)msg).items = new int[3];

               for(int var23 = 0; var23 < ((NewPacketHandler.TEPedestalMessage)msg).items.length; ++var23) {
                  ((NewPacketHandler.TEPedestalMessage)msg).items[var23] = dat.readInt();
               }
            }
            break;
         case 3:
            ((NewPacketHandler.TEPlinthMessage)msg).x = dat.readInt();
            ((NewPacketHandler.TEPlinthMessage)msg).y = dat.readInt();
            ((NewPacketHandler.TEPlinthMessage)msg).z = dat.readInt();
            boolean hasStacks2 = dat.readBoolean();
            ((NewPacketHandler.TEPlinthMessage)msg).items = new int[3];
            if(hasStacks2) {
               ((NewPacketHandler.TEPlinthMessage)msg).items = new int[3];

               for(int var24 = 0; var24 < ((NewPacketHandler.TEPlinthMessage)msg).items.length; ++var24) {
                  ((NewPacketHandler.TEPlinthMessage)msg).items[var24] = dat.readInt();
               }
            }
            break;
         case 4:
            ((NewPacketHandler.TESocketMessage)msg).x = dat.readInt();
            ((NewPacketHandler.TESocketMessage)msg).y = dat.readInt();
            ((NewPacketHandler.TESocketMessage)msg).z = dat.readInt();
            boolean hasStacks3 = dat.readBoolean();
            ((NewPacketHandler.TESocketMessage)msg).items = new int[3];
            if(hasStacks3) {
               ((NewPacketHandler.TESocketMessage)msg).items = new int[3];

               for(int var26 = 0; var26 < ((NewPacketHandler.TESocketMessage)msg).items.length; ++var26) {
                  ((NewPacketHandler.TESocketMessage)msg).items[var26] = dat.readInt();
               }
            }
            break;
         case 5:
            ((NewPacketHandler.TETeleposerMessage)msg).x = dat.readInt();
            ((NewPacketHandler.TETeleposerMessage)msg).y = dat.readInt();
            ((NewPacketHandler.TETeleposerMessage)msg).z = dat.readInt();
            boolean hasStacks4 = dat.readBoolean();
            ((NewPacketHandler.TETeleposerMessage)msg).items = new int[3];
            if(hasStacks4) {
               ((NewPacketHandler.TETeleposerMessage)msg).items = new int[3];

               for(int var25 = 0; var25 < ((NewPacketHandler.TETeleposerMessage)msg).items.length; ++var25) {
                  ((NewPacketHandler.TETeleposerMessage)msg).items[var25] = dat.readInt();
               }
            }
            break;
         case 6:
            ((NewPacketHandler.TEWritingTableMessage)msg).x = dat.readInt();
            ((NewPacketHandler.TEWritingTableMessage)msg).y = dat.readInt();
            ((NewPacketHandler.TEWritingTableMessage)msg).z = dat.readInt();
            boolean hasStacks5 = dat.readBoolean();
            ((NewPacketHandler.TEWritingTableMessage)msg).items = new int[21];
            if(hasStacks5) {
               ((NewPacketHandler.TEWritingTableMessage)msg).items = new int[21];

               for(size = 0; size < ((NewPacketHandler.TEWritingTableMessage)msg).items.length; ++size) {
                  ((NewPacketHandler.TEWritingTableMessage)msg).items[size] = dat.readInt();
               }
            }
            break;
         case 7:
            size = dat.readInt();
            String str = "";

            for(ritualStrSize = 0; ritualStrSize < size; ++ritualStrSize) {
               str = str + dat.readChar();
            }

            ((NewPacketHandler.ParticleMessage)msg).particle = str;
            ((NewPacketHandler.ParticleMessage)msg).xCoord = dat.readDouble();
            ((NewPacketHandler.ParticleMessage)msg).yCoord = dat.readDouble();
            ((NewPacketHandler.ParticleMessage)msg).zCoord = dat.readDouble();
            ((NewPacketHandler.ParticleMessage)msg).xVel = dat.readDouble();
            ((NewPacketHandler.ParticleMessage)msg).yVel = dat.readDouble();
            ((NewPacketHandler.ParticleMessage)msg).zVel = dat.readDouble();
            break;
         case 8:
            ((NewPacketHandler.VelocityMessage)msg).xVel = dat.readDouble();
            ((NewPacketHandler.VelocityMessage)msg).yVel = dat.readDouble();
            ((NewPacketHandler.VelocityMessage)msg).zVel = dat.readDouble();
            break;
         case 9:
            ((NewPacketHandler.TEMasterStoneMessage)msg).x = dat.readInt();
            ((NewPacketHandler.TEMasterStoneMessage)msg).y = dat.readInt();
            ((NewPacketHandler.TEMasterStoneMessage)msg).z = dat.readInt();
            ritualStrSize = dat.readInt();
            String ritual = "";

            for(listSize = 0; listSize < ritualStrSize; ++listSize) {
               ritual = ritual + dat.readChar();
            }

            ((NewPacketHandler.TEMasterStoneMessage)msg).ritual = ritual;
            ((NewPacketHandler.TEMasterStoneMessage)msg).isRunning = dat.readBoolean();
            break;
         case 10:
            ((NewPacketHandler.TEReagentConduitMessage)msg).x = dat.readInt();
            ((NewPacketHandler.TEReagentConduitMessage)msg).y = dat.readInt();
            ((NewPacketHandler.TEReagentConduitMessage)msg).z = dat.readInt();
            listSize = dat.readInt();
            LinkedList list = new LinkedList();

            for(size1 = 0; size1 < listSize; ++size1) {
               list.add(new ColourAndCoords(dat.readInt(), dat.readInt(), dat.readInt(), dat.readInt(), dat.readInt(), dat.readInt(), dat.readInt()));
            }

            ((NewPacketHandler.TEReagentConduitMessage)msg).destinationList = list;
            break;
         case 11:
            ((NewPacketHandler.CurrentLPMessage)msg).currentLP = dat.readInt();
            ((NewPacketHandler.CurrentLPMessage)msg).maxLP = dat.readInt();
            break;
         case 12:
            size1 = dat.readInt();
            String str1 = "";

            for(int i = 0; i < size1; ++i) {
               str1 = str1 + dat.readChar();
            }

            ((NewPacketHandler.CurrentReagentBarMessage)msg).reagent = str1;
            ((NewPacketHandler.CurrentReagentBarMessage)msg).currentAR = dat.readFloat();
            ((NewPacketHandler.CurrentReagentBarMessage)msg).maxAR = dat.readFloat();
            break;
         case 13:
            ((NewPacketHandler.CurrentAddedHPMessage)msg).currentHP = dat.readFloat();
            ((NewPacketHandler.CurrentAddedHPMessage)msg).maxHP = dat.readFloat();
            break;
         case 14:
            System.out.println("Packet recieved: being decoded");
            ((NewPacketHandler.KeyboardMessage)msg).keyPressed = dat.readByte();
         }

      }
   }

   private static class ParticleMessageHandler extends SimpleChannelInboundHandler {

      private ParticleMessageHandler() {}

      protected void channelRead0(ChannelHandlerContext ctx, NewPacketHandler.ParticleMessage msg) throws Exception {
         World world = AlchemicalWizardry.proxy.getClientWorld();
         world.spawnParticle(msg.particle, msg.xCoord, msg.yCoord, msg.zCoord, msg.xVel, msg.yVel, msg.zVel);
      }

      // $FF: synthetic method
      ParticleMessageHandler(NewPacketHandler.NamelessClass715594307 x0) {
         this();
      }
   }

   private static class TEWritingTableMessageHandler extends SimpleChannelInboundHandler {

      private TEWritingTableMessageHandler() {}

      protected void channelRead0(ChannelHandlerContext ctx, NewPacketHandler.TEWritingTableMessage msg) throws Exception {
         World world = AlchemicalWizardry.proxy.getClientWorld();
         TileEntity te = world.getTileEntity(msg.x, msg.y, msg.z);
         if(te instanceof TEWritingTable) {
            TEWritingTable WritingTable = (TEWritingTable)te;
            WritingTable.handlePacketData(msg.items);
         }

      }

      // $FF: synthetic method
      TEWritingTableMessageHandler(NewPacketHandler.NamelessClass715594307 x0) {
         this();
      }
   }

   private static class TEAltarMessageHandler extends SimpleChannelInboundHandler {

      private TEAltarMessageHandler() {}

      protected void channelRead0(ChannelHandlerContext ctx, NewPacketHandler.TEAltarMessage msg) throws Exception {
         World world = AlchemicalWizardry.proxy.getClientWorld();
         TileEntity te = world.getTileEntity(msg.x, msg.y, msg.z);
         if(te instanceof TEAltar) {
            TEAltar altar = (TEAltar)te;
            altar.handlePacketData(msg.items, msg.fluids, msg.capacity);
         }

      }

      // $FF: synthetic method
      TEAltarMessageHandler(NewPacketHandler.NamelessClass715594307 x0) {
         this();
      }
   }

   private static class TEMasterStoneMessageHandler extends SimpleChannelInboundHandler {

      private TEMasterStoneMessageHandler() {}

      protected void channelRead0(ChannelHandlerContext ctx, NewPacketHandler.TEMasterStoneMessage msg) throws Exception {
         World world = AlchemicalWizardry.proxy.getClientWorld();
         TileEntity te = world.getTileEntity(msg.x, msg.y, msg.z);
         if(te instanceof TEMasterStone) {
            TEMasterStone masterStone = (TEMasterStone)te;
            masterStone.setCurrentRitual(msg.ritual);
            masterStone.isRunning = msg.isRunning;
         }

      }

      // $FF: synthetic method
      TEMasterStoneMessageHandler(NewPacketHandler.NamelessClass715594307 x0) {
         this();
      }
   }

   public static class KeyboardMessage extends NewPacketHandler.BMMessage {

      byte keyPressed;


   }

   private static class TESocketMessageHandler extends SimpleChannelInboundHandler {

      private TESocketMessageHandler() {}

      protected void channelRead0(ChannelHandlerContext ctx, NewPacketHandler.TESocketMessage msg) throws Exception {
         World world = AlchemicalWizardry.proxy.getClientWorld();
         TileEntity te = world.getTileEntity(msg.x, msg.y, msg.z);
         if(te instanceof TESocket) {
            TESocket Socket = (TESocket)te;
            Socket.handlePacketData(msg.items);
         }

      }

      // $FF: synthetic method
      TESocketMessageHandler(NewPacketHandler.NamelessClass715594307 x0) {
         this();
      }
   }

   public static class CurrentAddedHPMessage extends NewPacketHandler.BMMessage {

      float currentHP;
      float maxHP;


   }

   private static class TEPedestalMessageHandler extends SimpleChannelInboundHandler {

      private TEPedestalMessageHandler() {}

      protected void channelRead0(ChannelHandlerContext ctx, NewPacketHandler.TEPedestalMessage msg) throws Exception {
         World world = AlchemicalWizardry.proxy.getClientWorld();
         TileEntity te = world.getTileEntity(msg.x, msg.y, msg.z);
         if(te instanceof TEPedestal) {
            TEPedestal pedestal = (TEPedestal)te;
            pedestal.handlePacketData(msg.items);
         }

      }

      // $FF: synthetic method
      TEPedestalMessageHandler(NewPacketHandler.NamelessClass715594307 x0) {
         this();
      }
   }
}
