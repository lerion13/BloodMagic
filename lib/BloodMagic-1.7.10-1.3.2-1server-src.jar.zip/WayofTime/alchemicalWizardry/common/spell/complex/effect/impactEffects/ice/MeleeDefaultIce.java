package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.ice;

import WayofTime.alchemicalWizardry.api.spell.ExtrapolatedMeleeEntityEffect;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

public class MeleeDefaultIce extends ExtrapolatedMeleeEntityEffect {

   public MeleeDefaultIce(int power, int potency, int cost) {
      super(power, potency, cost);
      this.setRange(3.0F + 0.3F * (float)potency);
      this.setRadius(2.0F + 0.3F * (float)potency);
      this.setMaxNumberHit(potency + 1);
   }

   protected boolean entityEffect(World world, Entity entity, EntityPlayer entityPlayer) {
      if(entity.hurtResistantTime > 0) {
         if(FakePlayerUtils.notCanDamage(entityPlayer, entity)) {
            return false;
         }

         entity.hurtResistantTime = Math.max(0, -(super.potencyUpgrades + 1) + entity.hurtResistantTime);
      }

      return true;
   }
}
