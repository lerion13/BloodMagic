package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.fire;

import WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.tool.LeftClickEffect;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;

public class ToolOffensiveFire extends LeftClickEffect {

   public ToolOffensiveFire(int power, int potency, int cost) {
      super(power, potency, cost);
   }

   public int onLeftClickEntity(ItemStack stack, EntityLivingBase attacked, EntityLivingBase weilder) {
      if(!FakePlayerUtils.notCanDamage(weilder, attacked)) {
         attacked.setFire(3 + 4 * super.powerUpgrades);
      }

      return (int)((double)(10 * (1 + super.powerUpgrades)) * Math.pow(0.85D, (double)super.costUpgrades));
   }
}
