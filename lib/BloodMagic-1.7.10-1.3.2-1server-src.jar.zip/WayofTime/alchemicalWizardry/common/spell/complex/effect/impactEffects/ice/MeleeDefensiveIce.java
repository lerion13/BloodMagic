package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.ice;

import WayofTime.alchemicalWizardry.api.spell.MeleeSpellWorldEffect;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public class MeleeDefensiveIce extends MeleeSpellWorldEffect {

   public MeleeDefensiveIce(int power, int potency, int cost) {
      super(power, potency, cost);
   }

   public void onWorldEffect(World world, EntityPlayer entityPlayer) {
      ForgeDirection look = SpellHelper.getCompassDirectionForLookVector(entityPlayer.getLookVec());
      int width = super.powerUpgrades;
      int height = super.powerUpgrades + 2;
      int xOffset = look.offsetX;
      int zOffset = look.offsetZ;
      int range = super.potencyUpgrades + 1;
      Vec3 lookVec = SpellHelper.getEntityBlockVector(entityPlayer);
      int xStart = (int)lookVec.xCoord + range * xOffset;
      int zStart = (int)lookVec.zCoord + range * zOffset;
      int yStart = (int)lookVec.yCoord;

      for(int i = -width; i <= width; ++i) {
         for(int j = 0; j < height; ++j) {
            if(world.isAirBlock(xStart + i * zOffset, yStart + j, zStart + i * xOffset) && !FakePlayerUtils.notCanBreak(entityPlayer, xStart + i * zOffset, yStart + j, zStart + i * xOffset)) {
               world.setBlock(xStart + i * zOffset, yStart + j, zStart + i * xOffset, Blocks.ice);
            }
         }
      }

   }
}
