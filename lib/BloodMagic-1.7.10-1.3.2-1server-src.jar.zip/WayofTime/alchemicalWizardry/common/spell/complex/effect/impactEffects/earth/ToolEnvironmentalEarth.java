package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.earth;

import WayofTime.alchemicalWizardry.api.items.ItemSpellMultiTool;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.tool.DigAreaEffect;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public class ToolEnvironmentalEarth extends DigAreaEffect {

   public ToolEnvironmentalEarth(int power, int potency, int cost) {
      super(power, potency, cost);
   }

   public int digSurroundingArea(ItemStack container, World world, EntityPlayer player, MovingObjectPosition blockPos, String usedToolClass, float blockHardness, int harvestLvl, ItemSpellMultiTool itemTool) {
      if(!blockPos.typeOfHit.equals(MovingObjectType.BLOCK)) {
         return 0;
      } else {
         int x = blockPos.blockX;
         int y = blockPos.blockY;
         int z = blockPos.blockZ;
         ForgeDirection sidehit = ForgeDirection.getOrientation(blockPos.sideHit);
         byte radius = 2;
         byte depth = 5;
         int var24 = depth - 1;
         int posX = radius;
         int negX = radius;
         int posY = radius;
         int negY = radius;
         int posZ = radius;
         int negZ = radius;
         switch(null.$SwitchMap$net$minecraftforge$common$util$ForgeDirection[sidehit.ordinal()]) {
         case 1:
            posY = 0;
            negY = var24;
            break;
         case 2:
            negY = 0;
            posY = var24;
            break;
         case 3:
            posZ = 0;
            negZ = var24;
            break;
         case 4:
            negZ = 0;
            posZ = var24;
            break;
         case 5:
            negX = 0;
            posX = var24;
            break;
         case 6:
            posX = 0;
            negX = var24;
         }

         for(int xPos = x - negX; xPos <= x + posX; ++xPos) {
            for(int yPos = y - negY; yPos <= y + posY; ++yPos) {
               for(int zPos = z - negZ; zPos <= z + posZ; ++zPos) {
                  if(!FakePlayerUtils.notCanBreak(player, xPos, yPos, zPos)) {
                     this.breakBlock(container, world, player, blockHardness, xPos, yPos, zPos, itemTool);
                  }
               }
            }
         }

         return 0;
      }
   }
}
