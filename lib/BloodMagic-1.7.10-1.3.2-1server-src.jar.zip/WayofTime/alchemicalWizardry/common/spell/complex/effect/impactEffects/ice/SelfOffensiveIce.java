package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.ice;

import WayofTime.alchemicalWizardry.api.spell.SelfSpellEffect;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class SelfOffensiveIce extends SelfSpellEffect {

   public SelfOffensiveIce(int power, int potency, int cost) {
      super(power, potency, cost);
   }

   public void onSelfUse(World world, EntityPlayer player) {
      double horizRadius = (double)(super.powerUpgrades + 1);
      double vertRadius = 0.5D * (double)super.powerUpgrades + 1.0D;
      List entities = SpellHelper.getEntitiesInRange(world, player.posX, player.posY, player.posZ, horizRadius, vertRadius);
      if(entities != null) {
         int i = 0;
         int number = (int)horizRadius;
         Iterator var10 = entities.iterator();

         while(var10.hasNext()) {
            Entity entity = (Entity)var10.next();
            if(i < number && entity instanceof EntityLivingBase && !entity.equals(player)) {
               if(!FakePlayerUtils.notCanDamage(player, entity)) {
                  ((EntityLivingBase)entity).addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 60 * (1 + super.powerUpgrades), super.potencyUpgrades));
               }

               ++i;
            }
         }

      }
   }
}
