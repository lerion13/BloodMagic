package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.earth;

import WayofTime.alchemicalWizardry.api.spell.SelfSpellEffect;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class SelfEnvironmentalEarth extends SelfSpellEffect {

   public SelfEnvironmentalEarth(int power, int potency, int cost) {
      super(power, potency, cost);
   }

   public void onSelfUse(World world, EntityPlayer player) {
      float radius = (float)(super.powerUpgrades * 2) + 1.5F;
      int dur = super.powerUpgrades * 5 * 20 + 60;
      List entities = SpellHelper.getEntitiesInRange(world, player.posX, player.posY, player.posZ, (double)radius, (double)radius);
      Iterator var6 = entities.iterator();

      while(var6.hasNext()) {
         Entity entity = (Entity)var6.next();
         if(entity instanceof EntityLiving && !FakePlayerUtils.notCanDamage(player, entity)) {
            ((EntityLiving)entity).addPotionEffect(new PotionEffect(Potion.weakness.id, dur, super.potencyUpgrades));
         }
      }

   }
}
