package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.fire;

import WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.tool.OnBreakBlockEffect;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public class ToolEnvironmentalFire extends OnBreakBlockEffect {

   public ToolEnvironmentalFire(int power, int potency, int cost) {
      super(power, potency, cost);
   }

   public int onBlockBroken(ItemStack container, World world, EntityPlayer player, Block block, int meta, int x, int y, int z, ForgeDirection sideBroken) {
      int amount = 0;
      int cost = (int)((double)(250.0F * (1.0F - 0.1F * (float)super.powerUpgrades)) * Math.pow(0.85D, (double)super.costUpgrades));
      int radius = super.powerUpgrades;
      float chance = 0.35F + 0.15F * (float)super.potencyUpgrades;

      for(int i = -radius; i <= radius; ++i) {
         for(int j = -radius; j <= radius; ++j) {
            for(int k = -radius; k <= radius; ++k) {
               Block blockAffected = world.getBlock(x + i - sideBroken.offsetX, y + j, z + k - sideBroken.offsetZ);
               if((new Random()).nextFloat() <= chance && (blockAffected == Blocks.gravel || blockAffected == Blocks.stone || blockAffected == Blocks.cobblestone) && !FakePlayerUtils.notCanBreak(player, x + i - sideBroken.offsetX, y + j, z + k - sideBroken.offsetZ)) {
                  world.setBlock(x + i - sideBroken.offsetX, y + j, z + k - sideBroken.offsetZ, Blocks.lava);
                  amount += cost;
               }
            }
         }
      }

      return amount;
   }
}
