package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.fire;

import WayofTime.alchemicalWizardry.api.spell.MeleeSpellCenteredWorldEffect;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

public class MeleeEnvironmentalFire extends MeleeSpellCenteredWorldEffect {

   public MeleeEnvironmentalFire(int power, int potency, int cost) {
      super(power, potency, cost);
      this.setRange((float)(3 * power + 2));
   }

   public void onCenteredWorldEffect(EntityPlayer player, World world, int posX, int posY, int posZ) {
      int radius = super.potencyUpgrades;

      for(int i = -radius; i <= radius; ++i) {
         for(int j = -radius; j <= radius; ++j) {
            for(int k = -radius; k <= radius; ++k) {
               if(!FakePlayerUtils.notCanBreak(player, posX + i, posY + j, posZ + k)) {
                  SpellHelper.evaporateWaterBlock(world, posX + i, posY + j, posZ + k);
               }
            }
         }
      }

   }
}
