package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.earth;

import WayofTime.alchemicalWizardry.api.spell.MeleeSpellCenteredWorldEffect;
import WayofTime.alchemicalWizardry.common.block.BlockTeleposer;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public class MeleeDefensiveEarth extends MeleeSpellCenteredWorldEffect {

   public MeleeDefensiveEarth(int power, int potency, int cost) {
      super(power, potency, cost);
      this.setRange((float)(3 * power + 2));
   }

   public void onCenteredWorldEffect(EntityPlayer player, World world, int posX, int posY, int posZ) {
      ForgeDirection dir = SpellHelper.getDirectionForLookVector(player.getLook(1.0F));
      int vertRadius = (int)(2.0D + 0.5D * Math.pow((double)super.potencyUpgrades, 2.0D) + (double)(0.5F * (float)super.potencyUpgrades));
      int horizRadius = super.potencyUpgrades + 1;
      int xOff = dir.offsetX;
      int zOff = dir.offsetZ;

      for(int i = -horizRadius; i <= horizRadius; ++i) {
         for(int j = 0; j < vertRadius; ++j) {
            if(!FakePlayerUtils.notCanBreak(player, posX + i * zOff, posY + j, posZ + i * xOff) && !FakePlayerUtils.notCanBreak(player, posX + i * zOff, posY + j - vertRadius, posZ + i * xOff)) {
               BlockTeleposer.swapBlocks(this, world, world, posX + i * zOff, posY + j, posZ + i * xOff, posX + i * zOff, posY + j - vertRadius, posZ + i * xOff);
            }
         }
      }

   }
}
