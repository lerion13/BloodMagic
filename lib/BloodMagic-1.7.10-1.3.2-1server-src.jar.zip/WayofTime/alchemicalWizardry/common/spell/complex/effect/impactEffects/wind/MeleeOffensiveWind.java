package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.wind;

import WayofTime.alchemicalWizardry.api.spell.ExtrapolatedMeleeEntityEffect;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

public class MeleeOffensiveWind extends ExtrapolatedMeleeEntityEffect {

   public MeleeOffensiveWind(int power, int potency, int cost) {
      super(power, potency, cost);
      this.setRange(3.0F + 0.3F * (float)potency);
      this.setRadius(2.0F + 0.3F * (float)potency);
      this.setMaxNumberHit(potency + 1);
   }

   protected boolean entityEffect(World world, Entity entity, EntityPlayer player) {
      if(entity instanceof EntityLiving) {
         if(FakePlayerUtils.notCanDamage(player, entity)) {
            return false;
         } else {
            double dist = Math.sqrt((double)entity.getDistanceToEntity(player));
            double wantedVel = 1.0D + 1.0D * (double)super.powerUpgrades;
            double xVel = wantedVel * (entity.posX - player.posX) / dist;
            double yVel = wantedVel * (entity.posY - player.posY + 0.5D) / dist;
            double zVel = wantedVel * (entity.posZ - player.posZ) / dist;
            entity.motionX = xVel;
            entity.motionY = yVel;
            entity.motionZ = zVel;
            return true;
         }
      } else {
         return false;
      }
   }
}
