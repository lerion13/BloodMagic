package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.wind;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.tool.LeftClickEffect;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;

public class ToolOffensiveWind extends LeftClickEffect {

   public ToolOffensiveWind(int power, int potency, int cost) {
      super(power, potency, cost);
   }

   public int onLeftClickEntity(ItemStack stack, EntityLivingBase attacked, EntityLivingBase weilder) {
      if(FakePlayerUtils.notCanDamage(weilder, attacked)) {
         return 0;
      } else {
         attacked.addPotionEffect(new PotionEffect(AlchemicalWizardry.customPotionHeavyHeart.id, 100 * (2 * super.powerUpgrades + 1) * (1 / (super.potencyUpgrades + 1)), super.potencyUpgrades));
         return (int)(100.0D * (0.5D * (double)super.potencyUpgrades + 1.0D) * (double)(super.powerUpgrades + 1) * Math.pow(0.85D, (double)super.costUpgrades));
      }
   }
}
