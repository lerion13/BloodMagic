package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.ice;

import WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.tool.LeftClickEffect;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class ToolDefaultIce extends LeftClickEffect {

   public ToolDefaultIce(int power, int potency, int cost) {
      super(power, potency, cost);
   }

   public int onLeftClickEntity(ItemStack stack, EntityLivingBase attacked, EntityLivingBase weilder) {
      if(FakePlayerUtils.notCanDamage(weilder, attacked)) {
         return 0;
      } else {
         boolean duration = true;
         attacked.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 200, super.powerUpgrades));
         return 0;
      }
   }
}
