package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.ice;

import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.tool.SummonToolEffect;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public class ToolDefensiveIce extends SummonToolEffect {

   public ToolDefensiveIce(int power, int potency, int cost) {
      super(power, potency, cost);
   }

   public int onSummonTool(ItemStack toolStack, World world, Entity entity) {
      if(!(entity instanceof EntityPlayer)) {
         return 0;
      } else {
         EntityPlayer player = (EntityPlayer)entity;
         int horizRadius = super.powerUpgrades * 2 + 2;
         int vertRadius = super.powerUpgrades * 3 + 2;
         List entityList = SpellHelper.getEntitiesInRange(world, entity.posX, entity.posY, entity.posZ, (double)horizRadius, (double)vertRadius);
         Iterator blockVec = entityList.iterator();

         while(blockVec.hasNext()) {
            Entity x = (Entity)blockVec.next();
            if(x instanceof EntityLivingBase && !x.equals(entity) && !FakePlayerUtils.notCanDamage(player, x)) {
               ((EntityLivingBase)x).addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 200, super.potencyUpgrades * 2));
            }
         }

         Vec3 var15 = SpellHelper.getEntityBlockVector(entity);
         int var16 = (int)var15.xCoord;
         int y = (int)var15.yCoord;
         int z = (int)var15.zCoord;

         for(int posX = var16 - horizRadius; posX <= var16 + horizRadius; ++posX) {
            for(int posY = y - vertRadius; posY <= y + vertRadius; ++posY) {
               for(int posZ = z - horizRadius; posZ <= z + horizRadius; ++posZ) {
                  SpellHelper.freezeWaterBlock(world, posX, posY, posZ);
                  if(world.isSideSolid(posX, posY, posZ, ForgeDirection.UP) && world.isAirBlock(posX, posY + 1, posZ) && !FakePlayerUtils.notCanBreak(player, posX, posY + 1, posZ)) {
                     world.setBlock(posX, posY + 1, posZ, Blocks.snow_layer);
                  }
               }
            }
         }

         return 0;
      }
   }
}
