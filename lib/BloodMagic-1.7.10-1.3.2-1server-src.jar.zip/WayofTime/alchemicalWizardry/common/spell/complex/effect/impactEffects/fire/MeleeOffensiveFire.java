package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.fire;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.spell.ExtrapolatedMeleeEntityEffect;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class MeleeOffensiveFire extends ExtrapolatedMeleeEntityEffect {

   public MeleeOffensiveFire(int power, int potency, int cost) {
      super(power, potency, cost);
      this.setRange(3.0F + 0.3F * (float)potency);
      this.setRadius(2.0F + 0.3F * (float)potency);
      this.setMaxNumberHit(1);
   }

   protected boolean entityEffect(World world, Entity entity, EntityPlayer entityPlayer) {
      if(entity instanceof EntityLivingBase) {
         if(FakePlayerUtils.notCanDamage(entityPlayer, entity)) {
            return false;
         } else {
            ((EntityLivingBase)entity).addPotionEffect(new PotionEffect(AlchemicalWizardry.customPotionFireFuse.id, 20 * (7 - super.powerUpgrades), super.potencyUpgrades));
            return true;
         }
      } else {
         return false;
      }
   }
}
