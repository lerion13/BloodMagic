package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.wind;

import WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.tool.LeftClickEffect;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Vec3;

public class ToolDefensiveWind extends LeftClickEffect {

   public ToolDefensiveWind(int power, int potency, int cost) {
      super(power, potency, cost);
   }

   public int onLeftClickEntity(ItemStack stack, EntityLivingBase attacked, EntityLivingBase weilder) {
      if(FakePlayerUtils.notCanDamage(weilder, attacked)) {
         return 0;
      } else {
         Vec3 vec = weilder.getLookVec();
         vec.yCoord = 0.0D;
         vec.normalize();
         float velocity = 0.5F * (1.0F + (float)super.powerUpgrades * 0.8F);
         float ratio = 0.1F + 0.3F * (float)super.potencyUpgrades;
         attacked.motionX += vec.xCoord * (double)velocity;
         attacked.motionY += (double)(velocity * ratio);
         attacked.motionZ += vec.zCoord * (double)velocity;
         return 0;
      }
   }
}
