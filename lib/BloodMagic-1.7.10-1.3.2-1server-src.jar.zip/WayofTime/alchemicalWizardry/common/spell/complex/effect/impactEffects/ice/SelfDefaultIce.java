package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.ice;

import WayofTime.alchemicalWizardry.api.spell.SelfSpellEffect;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class SelfDefaultIce extends SelfSpellEffect {

   public SelfDefaultIce(int power, int potency, int cost) {
      super(power, potency, cost);
   }

   public void onSelfUse(World world, EntityPlayer player) {
      Vec3 blockVector = SpellHelper.getEntityBlockVector(player);
      int posX = (int)blockVector.xCoord;
      int posY = (int)blockVector.yCoord;
      int posZ = (int)blockVector.zCoord;
      double yVel = 1.0D * (0.4D * (double)super.powerUpgrades + 0.75D);
      SpellHelper.setPlayerSpeedFromServer(player, player.motionX, yVel, player.motionZ);

      for(int i = 0; i < 2; ++i) {
         if(world.isAirBlock(posX, posY + i, posZ) && !FakePlayerUtils.notCanBreak(player, posX, posY + i, posZ)) {
            world.setBlock(posX, posY + i, posZ, Blocks.ice);
         }
      }

      player.fallDistance = 0.0F;
   }
}
