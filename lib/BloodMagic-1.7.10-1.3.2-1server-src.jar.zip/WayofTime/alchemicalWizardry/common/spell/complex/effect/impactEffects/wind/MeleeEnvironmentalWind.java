package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.wind;

import WayofTime.alchemicalWizardry.api.spell.MeleeSpellCenteredWorldEffect;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

public class MeleeEnvironmentalWind extends MeleeSpellCenteredWorldEffect {

   public MeleeEnvironmentalWind(int power, int potency, int cost) {
      super(power, potency, cost);
      this.setRange((float)(5 * power + 5));
   }

   public void onCenteredWorldEffect(EntityPlayer player, World world, int posX, int posY, int posZ) {
      int radius = 5 * super.potencyUpgrades + 3;
      List entities = SpellHelper.getEntitiesInRange(world, (double)posX, (double)posY, (double)posZ, (double)radius, (double)radius);
      Iterator var8 = entities.iterator();

      while(var8.hasNext()) {
         Entity entity = (Entity)var8.next();
         if(entity instanceof EntityItem && !FakePlayerUtils.notCanDamage(player, entity)) {
            ((EntityItem)entity).delayBeforeCanPickup = 0;
            entity.onCollideWithPlayer(player);
         }
      }

   }
}
