package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.wind;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.spell.SelfSpellEffect;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class SelfDefensiveWind extends SelfSpellEffect {

   public SelfDefensiveWind(int power, int potency, int cost) {
      super(power, potency, cost);
   }

   public void onSelfUse(World world, EntityPlayer player) {
      double radius = 1.5D * (double)super.powerUpgrades + 1.5D;
      double posX = player.posX;
      double posY = player.posY;
      double posZ = player.posZ;
      List entities = SpellHelper.getEntitiesInRange(world, posX, posY, posZ, radius, radius);
      Iterator var12 = entities.iterator();

      while(var12.hasNext()) {
         Entity entity = (Entity)var12.next();
         if(!entity.equals(player) && entity instanceof EntityLiving && !FakePlayerUtils.notCanDamage(player, entity)) {
            ((EntityLiving)entity).addPotionEffect(new PotionEffect(AlchemicalWizardry.customPotionHeavyHeart.id, 200, super.potencyUpgrades));
         }
      }

   }
}
