package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.fire;

import WayofTime.alchemicalWizardry.api.spell.SelfSpellEffect;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;

public class SelfEnvironmentalFire extends SelfSpellEffect {

   public SelfEnvironmentalFire(int power, int potency, int cost) {
      super(power, potency, cost);
   }

   public void onSelfUse(World world, EntityPlayer player) {
      int posX = (int)Math.round(player.posX - 0.5D);
      int posY = (int)player.posY;
      int posZ = (int)Math.round(player.posZ - 0.5D);
      int powRadius = super.powerUpgrades;
      int potRadius = super.potencyUpgrades - 1;

      int i;
      int j;
      int k;
      for(i = -powRadius; i <= powRadius; ++i) {
         for(j = -powRadius; j <= powRadius; ++j) {
            for(k = -powRadius; k <= powRadius; ++k) {
               if(world.isAirBlock(posX + i, posY + j, posZ + k) && !FakePlayerUtils.notCanBreak(player, posX + i, posY + j, posZ + k)) {
                  world.setBlock(posX + i, posY + j, posZ + k, Blocks.fire);
               }
            }
         }
      }

      for(i = -potRadius; i <= potRadius; ++i) {
         for(j = -potRadius; j <= potRadius; ++j) {
            for(k = -potRadius; k <= potRadius; ++k) {
               if(!world.isAirBlock(posX + i, posY + j, posZ + k) && !FakePlayerUtils.notCanBreak(player, posX + i, posY + j, posZ + k)) {
                  SpellHelper.smeltBlockInWorld(world, posX + i, posY + j, posZ + k);
               }
            }
         }
      }

   }
}
