package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.earth;

import WayofTime.alchemicalWizardry.api.spell.MeleeSpellCenteredWorldEffect;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.block.Block;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

public class MeleeDefaultEarth extends MeleeSpellCenteredWorldEffect {

   public MeleeDefaultEarth(int power, int potency, int cost) {
      super(power, potency, cost);
      this.setRange((float)(3 * power + 2));
   }

   public void onCenteredWorldEffect(EntityPlayer player, World world, int posX, int posY, int posZ) {
      int radius = super.potencyUpgrades;

      for(int i = -radius; i <= radius; ++i) {
         for(int j = -radius; j <= radius; ++j) {
            for(int k = -radius; k <= radius; ++k) {
               if(!world.isAirBlock(posX + i, posY + j, posZ + k) && world.getTileEntity(posX + i, posY + j, posZ + k) == null && !FakePlayerUtils.notCanBreak(player, posX + i, posY + j, posZ + k)) {
                  Block block = world.getBlock(posX + i, posY + j, posZ + k);
                  if(block.getBlockHardness(world, posX + i, posY + j, posZ + k) != -1.0F) {
                     int meta = world.getBlockMetadata(posX + i, posY + j, posZ + k);
                     EntityFallingBlock entity = new EntityFallingBlock(world, (double)((float)(posX + i) + 0.5F), (double)((float)(posY + j) + 0.5F), (double)((float)(posZ + k) + 0.5F), block, meta);
                     world.spawnEntityInWorld(entity);
                  }
               }
            }
         }
      }

   }
}
