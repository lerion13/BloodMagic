package WayofTime.alchemicalWizardry.common.spell.complex.effect.impactEffects.earth;

import WayofTime.alchemicalWizardry.api.spell.MeleeSpellCenteredWorldEffect;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class MeleeEnvironmentalEarth extends MeleeSpellCenteredWorldEffect {

   public MeleeEnvironmentalEarth(int power, int potency, int cost) {
      super(power, potency, cost);
      this.setRange((float)(3 * power + 2));
   }

   public void onCenteredWorldEffect(EntityPlayer player, World world, int posX, int posY, int posZ) {
      int radius = super.potencyUpgrades;

      for(int i = -radius; i <= radius; ++i) {
         for(int j = -radius; j <= radius; ++j) {
            for(int k = -radius; k <= radius; ++k) {
               if(!world.isAirBlock(posX + i, posY + j, posZ + k) && world.getTileEntity(posX + i, posY + j, posZ + k) == null && !FakePlayerUtils.notCanBreak(player, posX + i, posY + j, posZ + k)) {
                  ItemStack stack = new ItemStack(world.getBlock(posX + i, posY + j, posZ + k), 1, world.getBlockMetadata(posX + i, posY + j, posZ + k));
                  ItemStack dustStack = SpellHelper.getDustForOre(stack);
                  if(dustStack != null) {
                     dustStack.stackSize *= 3;
                     world.spawnEntityInWorld(new EntityItem(world, (double)posX, (double)posY, (double)posZ, dustStack));
                     world.setBlockToAir(posX + i, posY + j, posZ + k);
                  }
               }
            }
         }
      }

   }
}
