package WayofTime.alchemicalWizardry.common.spell.simple;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.common.entity.projectile.WaterProjectile;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import WayofTime.alchemicalWizardry.common.spell.simple.HomSpell;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public class SpellWateryGrave extends HomSpell {

   Random itemRand = new Random();


   public SpellWateryGrave() {
      this.setEnergies(250, 350, 500, 750);
   }

   public ItemStack onOffensiveRangedRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(!EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getOffensiveRangedEnergy());
         }

         par2World.spawnEntityInWorld(new WaterProjectile(par2World, par3EntityPlayer, 8));
         par2World.playSoundAtEntity(par3EntityPlayer, "random.fizz", 0.5F, 0.4F / (this.itemRand.nextFloat() * 0.4F + 0.8F));
         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onOffensiveMeleeRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(!EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getOffensiveMeleeEnergy());
         }

         if(!par2World.isRemote) {
            for(int i = -1; i <= 1; ++i) {
               for(int j = -1; j <= 1; ++j) {
                  par2World.spawnEntityInWorld(new WaterProjectile(par2World, par3EntityPlayer, 3, 3, par3EntityPlayer.posX, par3EntityPlayer.posY + (double)par3EntityPlayer.getEyeHeight(), par3EntityPlayer.posZ, par3EntityPlayer.rotationYaw + (float)i * 10.0F, par3EntityPlayer.rotationPitch + (float)j * 5.0F));
               }
            }
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onDefensiveRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(!EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getDefensiveEnergy());
         }

         byte d0 = 3;
         AxisAlignedBB axisalignedbb = AxisAlignedBB.getBoundingBox(par3EntityPlayer.posX, par3EntityPlayer.posY, par3EntityPlayer.posZ, par3EntityPlayer.posX + 1.0D, par3EntityPlayer.posY + 2.0D, par3EntityPlayer.posZ + 1.0D).expand((double)d0, (double)d0, (double)d0);
         List list = par3EntityPlayer.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, axisalignedbb);
         Iterator iterator = list.iterator();

         while(iterator.hasNext()) {
            EntityLivingBase xCoord = (EntityLivingBase)iterator.next();
            if((!(xCoord instanceof EntityPlayer) || !xCoord.equals(par3EntityPlayer)) && !FakePlayerUtils.callEntityDamageByEntityEvent(par3EntityPlayer, xCoord, DamageCause.ENTITY_ATTACK, 1.0D).isCancelled()) {
               byte x = 1;
               if(xCoord.isImmuneToFire()) {
                  x = 2;
               }

               xCoord.attackEntityFrom(DamageSource.drown, (float)(2 * x));
               xCoord.addPotionEffect(new PotionEffect(AlchemicalWizardry.customPotionDrowning.id, 100, x - 1));
            }
         }

         double var15 = par3EntityPlayer.posX;
         double yCoord = par3EntityPlayer.posY;
         double zCoord = par3EntityPlayer.posZ;

         for(int i = 0; i < 20; ++i) {
            SpellHelper.sendParticleToAllAround(par2World, var15, yCoord, zCoord, 30, par2World.provider.dimensionId, "mobSpell", var15 + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 3.0F), yCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 3.0F), zCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 3.0F), 0.0D, 0.4099999964237213D, 1.0D);
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onEnvironmentalRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(!EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getEnvironmentalEnergy());
         }

         byte range = 2;
         if(!par2World.isRemote) {
            for(int xCoord = -range; xCoord <= range; ++xCoord) {
               for(int j = -range; j <= range; ++j) {
                  if(par2World.isAirBlock((int)par3EntityPlayer.posX + xCoord, (int)par3EntityPlayer.posY, (int)par3EntityPlayer.posZ + j) && !FakePlayerUtils.callBlockBreakEvent((int)par3EntityPlayer.posX + xCoord, (int)par3EntityPlayer.posY, (int)par3EntityPlayer.posZ + j, par3EntityPlayer).isCancelled()) {
                     par2World.setBlock((int)par3EntityPlayer.posX + xCoord, (int)par3EntityPlayer.posY, (int)par3EntityPlayer.posZ + j, Blocks.water);
                  }
               }
            }
         }

         double var12 = par3EntityPlayer.posX;
         double yCoord = par3EntityPlayer.posY;
         double zCoord = par3EntityPlayer.posZ;

         for(int i = 0; i < 16; ++i) {
            SpellHelper.sendParticleToAllAround(par2World, var12, yCoord, zCoord, 30, par2World.provider.dimensionId, "mobSpell", var12 + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 3.0F), yCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 3.0F), zCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 3.0F), 0.0D, 0.4099999964237213D, 1.0D);
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }
}
