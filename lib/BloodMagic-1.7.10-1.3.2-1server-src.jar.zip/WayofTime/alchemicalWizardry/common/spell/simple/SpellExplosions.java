package WayofTime.alchemicalWizardry.common.spell.simple;

import WayofTime.alchemicalWizardry.common.entity.projectile.ExplosionProjectile;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import WayofTime.alchemicalWizardry.common.spell.simple.HomSpell;
import com.gamerforea.bloodmagic.ExplosionByPlayer;
import java.util.Random;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class SpellExplosions extends HomSpell {

   Random itemRand = new Random();


   public SpellExplosions() {
      this.setEnergies(400, 500, 1900, 1500);
   }

   public ItemStack onOffensiveRangedRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getOffensiveRangedEnergy());
         }

         par2World.playSoundAtEntity(par3EntityPlayer, "random.fizz", 0.5F, 0.4F / (this.itemRand.nextFloat() * 0.4F + 0.8F));
         if(!par2World.isRemote) {
            par2World.spawnEntityInWorld(new ExplosionProjectile(par2World, par3EntityPlayer, 6, true));
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onOffensiveMeleeRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getOffensiveMeleeEnergy());
         }

         boolean distance = true;
         double yaw = (double)par3EntityPlayer.rotationYaw / 565.4866776461628D;
         double pitch = (double)par3EntityPlayer.rotationPitch / 565.4866776461628D;
         ExplosionByPlayer.createExplosion(par3EntityPlayer, par2World, par3EntityPlayer, par3EntityPlayer.posX + Math.sin(yaw) * Math.cos(pitch) * -4.0D, par3EntityPlayer.posY + (double)par3EntityPlayer.getEyeHeight() + Math.sin(-pitch) * 4.0D, par3EntityPlayer.posZ + Math.cos(yaw) * Math.cos(pitch) * 4.0D, 3.0F, true);
         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onDefensiveRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getDefensiveEnergy());
         }

         boolean distance = true;
         ExplosionByPlayer.createExplosion(par3EntityPlayer, par2World, par3EntityPlayer, par3EntityPlayer.posX, par3EntityPlayer.posY + (double)par3EntityPlayer.getEyeHeight(), par3EntityPlayer.posZ, 4.0F, false);
         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onEnvironmentalRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getEnvironmentalEnergy());
         }

         boolean radius = true;

         for(int i = 0; i < 360; i += 36) {
            ExplosionByPlayer.createExplosion(par3EntityPlayer, par2World, par3EntityPlayer, par3EntityPlayer.posX + Math.cos((double)i) * 3.0D, par3EntityPlayer.posY, par3EntityPlayer.posZ + Math.sin((double)i) * 3.0D, 2.0F, true);
         }

         return null;
      } else {
         return par1ItemStack;
      }
   }
}
