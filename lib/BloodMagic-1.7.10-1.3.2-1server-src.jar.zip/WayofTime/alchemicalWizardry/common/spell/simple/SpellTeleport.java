package WayofTime.alchemicalWizardry.common.spell.simple;

import WayofTime.alchemicalWizardry.common.entity.projectile.TeleportProjectile;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import WayofTime.alchemicalWizardry.common.spell.simple.HomSpell;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.EnderTeleportEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public class SpellTeleport extends HomSpell {

   Random itemRand = new Random();


   public SpellTeleport() {
      this.setEnergies(500, 300, 500, 1000);
   }

   public ItemStack onOffensiveRangedRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(!EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getOffensiveRangedEnergy());
         }

         par2World.spawnEntityInWorld(new TeleportProjectile(par2World, par3EntityPlayer, 8, true));
         par2World.playSoundAtEntity(par3EntityPlayer, "random.fizz", 0.5F, 0.4F / (this.itemRand.nextFloat() * 0.4F + 0.8F));
         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onOffensiveMeleeRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(!EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getOffensiveMeleeEnergy());
         }

         par2World.spawnEntityInWorld(new TeleportProjectile(par2World, par3EntityPlayer, 8, false));
         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onDefensiveRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(!EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getDefensiveEnergy());
         }

         double xCoord = par3EntityPlayer.posX;
         double yCoord = par3EntityPlayer.posY;
         double zCoord = par3EntityPlayer.posZ;
         teleportRandomly(par3EntityPlayer, 128.0D);

         for(int i = 0; i < 20; ++i) {
            SpellHelper.sendParticleToAllAround(par2World, xCoord, yCoord, zCoord, 30, par2World.provider.dimensionId, "portal", xCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 2.0F), yCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 2.0F), zCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 2.0F), (double)this.itemRand.nextFloat(), (double)this.itemRand.nextFloat(), (double)this.itemRand.nextFloat());
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onEnvironmentalRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(!EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getEnvironmentalEnergy());
         }

         if(!par2World.isRemote) {
            boolean xCoord = true;
            AxisAlignedBB axisalignedbb = AxisAlignedBB.getBoundingBox(par3EntityPlayer.posX, par3EntityPlayer.posY, par3EntityPlayer.posZ, par3EntityPlayer.posX + 1.0D, par3EntityPlayer.posY + 2.0D, par3EntityPlayer.posZ + 1.0D).expand(3.0D, 3.0D, 3.0D);
            List yCoord = par3EntityPlayer.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, axisalignedbb);
            Iterator iterator = yCoord.iterator();

            while(iterator.hasNext()) {
               EntityLivingBase zCoord = (EntityLivingBase)iterator.next();
               if((!(zCoord instanceof EntityPlayer) || !zCoord.equals(par3EntityPlayer)) && !FakePlayerUtils.callEntityDamageByEntityEvent(par3EntityPlayer, zCoord, DamageCause.ENTITY_ATTACK, 1.0D).isCancelled()) {
                  teleportRandomly(zCoord, 128.0D);
               }
            }
         }

         double var11 = par3EntityPlayer.posX;
         double var12 = par3EntityPlayer.posY;
         double var13 = par3EntityPlayer.posZ;

         for(int i = 0; i < 32; ++i) {
            SpellHelper.sendParticleToAllAround(par2World, var11, var12, var13, 30, par2World.provider.dimensionId, "portal", var11 + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 2.0F), var12 + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 2.0F), var13 + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 2.0F), (double)this.itemRand.nextFloat(), (double)this.itemRand.nextFloat(), (double)this.itemRand.nextFloat());
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public static boolean teleportRandomly(EntityLivingBase entityLiving, double distance) {
      double x = entityLiving.posX;
      double y = entityLiving.posY;
      double z = entityLiving.posZ;
      Random rand = new Random();
      double d0 = x + (rand.nextDouble() - 0.5D) * distance;
      double d1 = y + ((double)rand.nextInt((int)distance) - distance / 2.0D);
      double d2 = z + (rand.nextDouble() - 0.5D) * distance;

      int i;
      for(i = 0; !teleportTo(entityLiving, d0, d1, d2, x, y, z) && i < 100; ++i) {
         d0 = x + (rand.nextDouble() - 0.5D) * distance;
         d1 = y + ((double)rand.nextInt((int)distance) - distance / 2.0D);
         d2 = z + (rand.nextDouble() - 0.5D) * distance;
      }

      return i < 100;
   }

   private static boolean teleportTo(EntityLivingBase entityLiving, double par1, double par3, double par5, double lastX, double lastY, double lastZ) {
      EnderTeleportEvent event = new EnderTeleportEvent(entityLiving, par1, par3, par5, 0.0F);
      if(MinecraftForge.EVENT_BUS.post(event)) {
         return false;
      } else {
         double d3 = lastX;
         double d4 = lastY;
         double d5 = lastZ;
         moveEntityViaTeleport(entityLiving, event.targetX, event.targetY, event.targetZ);
         boolean flag = false;
         int i = MathHelper.floor_double(entityLiving.posX);
         int j = MathHelper.floor_double(entityLiving.posY);
         int k = MathHelper.floor_double(entityLiving.posZ);
         if(entityLiving.worldObj.blockExists(i, j, k)) {
            boolean short1 = false;

            while(!short1 && j > 0) {
               Block l = entityLiving.worldObj.getBlock(i, j - 1, k);
               if(l != null && l.getMaterial().blocksMovement()) {
                  short1 = true;
               } else {
                  --entityLiving.posY;
                  --j;
               }
            }

            if(short1) {
               moveEntityViaTeleport(entityLiving, entityLiving.posX, entityLiving.posY, entityLiving.posZ);
               if(entityLiving.worldObj.getCollidingBoundingBoxes(entityLiving, entityLiving.boundingBox).isEmpty() && !entityLiving.worldObj.isAnyLiquid(entityLiving.boundingBox)) {
                  flag = true;
               }
            }
         }

         if(!flag) {
            moveEntityViaTeleport(entityLiving, lastX, lastY, lastZ);
            return false;
         } else {
            short var37 = 128;

            for(j = 0; j < var37; ++j) {
               double d6 = (double)j / ((double)var37 - 1.0D);
               float f = (entityLiving.worldObj.rand.nextFloat() - 0.5F) * 0.2F;
               float f1 = (entityLiving.worldObj.rand.nextFloat() - 0.5F) * 0.2F;
               float f2 = (entityLiving.worldObj.rand.nextFloat() - 0.5F) * 0.2F;
               double d7 = d3 + (entityLiving.posX - d3) * d6 + (entityLiving.worldObj.rand.nextDouble() - 0.5D) * (double)entityLiving.width * 2.0D;
               double d8 = d4 + (entityLiving.posY - d4) * d6 + entityLiving.worldObj.rand.nextDouble() * (double)entityLiving.height;
               double d9 = d5 + (entityLiving.posZ - d5) * d6 + (entityLiving.worldObj.rand.nextDouble() - 0.5D) * (double)entityLiving.width * 2.0D;
               entityLiving.worldObj.spawnParticle("portal", d7, d8, d9, (double)f, (double)f1, (double)f2);
            }

            return true;
         }
      }
   }

   public static void moveEntityViaTeleport(EntityLivingBase entityLiving, double x, double y, double z) {
      if(entityLiving instanceof EntityPlayer) {
         if(entityLiving != null && entityLiving instanceof EntityPlayerMP) {
            EntityPlayerMP entityplayermp = (EntityPlayerMP)entityLiving;
            if(entityplayermp.worldObj == entityLiving.worldObj) {
               EnderTeleportEvent event = new EnderTeleportEvent(entityplayermp, x, y, z, 5.0F);
               if(!MinecraftForge.EVENT_BUS.post(event)) {
                  if(entityLiving.isRiding()) {
                     entityLiving.mountEntity((Entity)null);
                  }

                  entityLiving.setPositionAndUpdate(event.targetX, event.targetY, event.targetZ);
               }
            }
         }
      } else if(entityLiving != null) {
         entityLiving.setPosition(x, y, z);
      }

   }
}
