package WayofTime.alchemicalWizardry.common.spell.simple;

import WayofTime.alchemicalWizardry.common.entity.projectile.WindGustProjectile;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import WayofTime.alchemicalWizardry.common.spell.simple.HomSpell;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public class SpellWindGust extends HomSpell {

   Random itemRand = new Random();


   public SpellWindGust() {
      this.setEnergies(300, 400, 300, 500);
   }

   public ItemStack onOffensiveRangedRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getOffensiveRangedEnergy());
         }

         par2World.playSoundAtEntity(par3EntityPlayer, "random.fizz", 0.5F, 0.4F / (this.itemRand.nextFloat() * 0.4F + 0.8F));
         if(!par2World.isRemote) {
            par2World.spawnEntityInWorld(new WindGustProjectile(par2World, par3EntityPlayer, 8));
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onOffensiveMeleeRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getOffensiveMeleeEnergy());
         }

         boolean distance = true;
         double yaw = (double)(par3EntityPlayer.rotationYaw / 180.0F) * 3.141592653589793D;
         double pitch = (double)(par3EntityPlayer.rotationPitch / 180.0F) * 3.141592653589793D;
         double xCoord = par3EntityPlayer.posX + Math.sin(yaw) * Math.cos(pitch) * -3.0D;
         double yCoord = par3EntityPlayer.posY + (double)par3EntityPlayer.getEyeHeight() + Math.sin(-pitch) * 3.0D;
         double zCoord = par3EntityPlayer.posZ + Math.cos(yaw) * Math.cos(pitch) * 3.0D;
         float d0 = 0.5F;
         AxisAlignedBB axisalignedbb = AxisAlignedBB.getBoundingBox(par3EntityPlayer.posX - 0.5D + Math.sin(yaw) * Math.cos(pitch) * -3.0D, par3EntityPlayer.posY + (double)par3EntityPlayer.getEyeHeight() + Math.sin(-pitch) * 3.0D, par3EntityPlayer.posZ - 0.5D + Math.cos(yaw) * Math.cos(pitch) * 3.0D, par3EntityPlayer.posX + Math.sin(yaw) * Math.cos(pitch) * -3.0D + 0.5D, par3EntityPlayer.posY + (double)par3EntityPlayer.getEyeHeight() + Math.sin(-pitch) * 3.0D + 1.0D, par3EntityPlayer.posZ + Math.cos(yaw) * Math.cos(pitch) * 3.0D + 0.5D).expand(0.5D, 0.5D, 0.5D);
         List list = par3EntityPlayer.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, axisalignedbb);
         Iterator iterator = list.iterator();

         while(iterator.hasNext()) {
            EntityLivingBase i = (EntityLivingBase)iterator.next();
            if((!(i instanceof EntityPlayer) || !i.equals(par3EntityPlayer)) && !FakePlayerUtils.callEntityDamageByEntityEvent(par3EntityPlayer, i, DamageCause.ENTITY_ATTACK, 1.0D).isCancelled()) {
               i.motionX = Math.sin(-yaw) * 2.0D;
               i.motionY = 2.0D;
               i.motionZ = Math.cos(yaw) * 2.0D;
            }
         }

         for(int var20 = 0; var20 < 5; ++var20) {
            SpellHelper.sendParticleToAllAround(par2World, xCoord, yCoord, zCoord, 30, par2World.provider.dimensionId, "mobSpell", xCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 3.0F), yCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 3.0F), zCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 3.0F), 0.0D, 0.4099999964237213D, 1.0D);
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onDefensiveRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getDefensiveEnergy());
         }

         boolean distance = true;
         double yaw = (double)(par3EntityPlayer.rotationYaw / 180.0F) * 3.141592653589793D;
         double pitch = (double)(par3EntityPlayer.rotationPitch / 180.0F) * 3.141592653589793D;
         double wantedVelocity = 5.0D;
         double pitchCos = Math.cos(pitch);
         double xVel = Math.sin(yaw) * pitchCos * -5.0D;
         double yVel = Math.sin(-pitch) * 5.0D;
         double zVel = Math.cos(yaw) * pitchCos * 5.0D;
         Vec3 vec = par3EntityPlayer.getLookVec();
         par3EntityPlayer.motionX = vec.xCoord * 5.0D;
         par3EntityPlayer.motionY = vec.yCoord * 5.0D;
         par3EntityPlayer.motionZ = vec.zCoord * 5.0D;
         SpellHelper.setPlayerSpeedFromServer(par3EntityPlayer, xVel, yVel, zVel);
         par2World.playSoundEffect((double)((float)par3EntityPlayer.posX + 0.5F), (double)((float)par3EntityPlayer.posY + 0.5F), (double)((float)par3EntityPlayer.posZ + 0.5F), "random.fizz", 0.5F, 2.6F + (par2World.rand.nextFloat() - par2World.rand.nextFloat()) * 0.8F);
         par3EntityPlayer.fallDistance = 0.0F;
         double xCoord = par3EntityPlayer.posX;
         double yCoord = par3EntityPlayer.posY;
         double zCoord = par3EntityPlayer.posZ;

         for(int i = 0; i < 8; ++i) {
            SpellHelper.sendParticleToAllAround(par2World, xCoord, yCoord, zCoord, 30, par2World.provider.dimensionId, "mobSpell", xCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 3.0F), yCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 3.0F), zCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 3.0F), 0.0D, 0.4099999964237213D, 1.0D);
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onEnvironmentalRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getEnvironmentalEnergy());
         }

         boolean d0 = true;
         AxisAlignedBB axisalignedbb = AxisAlignedBB.getBoundingBox(par3EntityPlayer.posX, par3EntityPlayer.posY, par3EntityPlayer.posZ, par3EntityPlayer.posX + 1.0D, par3EntityPlayer.posY + 2.0D, par3EntityPlayer.posZ + 1.0D).expand(3.0D, 3.0D, 3.0D);
         List list = par3EntityPlayer.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, axisalignedbb);
         Iterator iterator = list.iterator();
         double xCoord = par3EntityPlayer.posX;
         double yCoord = par3EntityPlayer.posY;
         double zCoord = par3EntityPlayer.posZ;
         double wantedVel = 2.0D;

         while(iterator.hasNext()) {
            EntityLivingBase i = (EntityLivingBase)iterator.next();
            if((!(i instanceof EntityPlayer) || !i.equals(par3EntityPlayer)) && !FakePlayerUtils.callEntityDamageByEntityEvent(par3EntityPlayer, i, DamageCause.ENTITY_ATTACK, 1.0D).isCancelled()) {
               double posXDif = i.posX - par3EntityPlayer.posX;
               double posYDif = i.posY - par3EntityPlayer.posY + 1.0D;
               double posZDif = i.posZ - par3EntityPlayer.posZ;
               double distance2 = Math.pow(posXDif, 2.0D) + Math.pow(posYDif, 2.0D) + Math.pow(posZDif, 2.0D);
               double distance = Math.sqrt(distance2);
               i.motionX = posXDif * 2.0D / distance;
               i.motionY = posYDif * 2.0D / distance;
               i.motionZ = posZDif * 2.0D / distance;
            }
         }

         for(int var27 = 0; var27 < 20; ++var27) {
            SpellHelper.sendParticleToAllAround(par2World, xCoord, yCoord, zCoord, 30, par2World.provider.dimensionId, "mobSpell", xCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 3.0F), yCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 3.0F), zCoord + (double)((this.itemRand.nextFloat() - this.itemRand.nextFloat()) * 3.0F), 0.0D, 0.4099999964237213D, 1.0D);
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }
}
