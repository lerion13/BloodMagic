package WayofTime.alchemicalWizardry.common.spell.simple;

import WayofTime.alchemicalWizardry.common.entity.projectile.HolyProjectile;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import WayofTime.alchemicalWizardry.common.spell.simple.HomSpell;
import com.gamerforea.bloodmagic.ExplosionByPlayer;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public class SpellHolyBlast extends HomSpell {

   Random itemRand = new Random();


   public SpellHolyBlast() {
      this.setEnergies(100, 300, 500, 400);
   }

   public ItemStack onOffensiveRangedRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getOffensiveRangedEnergy());
         }

         par2World.playSoundAtEntity(par3EntityPlayer, "random.fizz", 0.5F, 0.4F / (this.itemRand.nextFloat() * 0.4F + 0.8F));
         if(!par2World.isRemote) {
            par2World.spawnEntityInWorld(new HolyProjectile(par2World, par3EntityPlayer, 8));
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onOffensiveMeleeRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getOffensiveMeleeEnergy());
         }

         boolean distance = true;
         double yaw = (double)(par3EntityPlayer.rotationYaw / 180.0F) * 3.141592653589793D;
         double pitch = (double)(par3EntityPlayer.rotationPitch / 180.0F) * 3.141592653589793D;
         double xCoord = par3EntityPlayer.posX + Math.sin(yaw) * Math.cos(pitch) * -2.0D;
         double yCoord = par3EntityPlayer.posY + (double)par3EntityPlayer.getEyeHeight() + Math.sin(-pitch) * 2.0D;
         double zCoord = par3EntityPlayer.posZ + Math.cos(yaw) * Math.cos(pitch) * 2.0D;
         float d0 = 0.5F;
         AxisAlignedBB axisalignedbb = AxisAlignedBB.getBoundingBox(par3EntityPlayer.posX - 0.5D + Math.sin(yaw) * Math.cos(pitch) * -2.0D, par3EntityPlayer.posY + (double)par3EntityPlayer.getEyeHeight() + Math.sin(-pitch) * 2.0D, par3EntityPlayer.posZ - 0.5D + Math.cos(yaw) * Math.cos(pitch) * 2.0D, par3EntityPlayer.posX + Math.sin(yaw) * Math.cos(pitch) * -2.0D + 0.5D, par3EntityPlayer.posY + (double)par3EntityPlayer.getEyeHeight() + Math.sin(-pitch) * 2.0D + 1.0D, par3EntityPlayer.posZ + Math.cos(yaw) * Math.cos(pitch) * 2.0D + 0.5D).expand(0.5D, 0.5D, 0.5D);
         List list = par3EntityPlayer.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, axisalignedbb);
         Iterator iterator = list.iterator();

         while(iterator.hasNext()) {
            EntityLivingBase i = (EntityLivingBase)iterator.next();
            if((!(i instanceof EntityPlayer) || !i.equals(par3EntityPlayer)) && !FakePlayerUtils.callEntityDamageByEntityEvent(par3EntityPlayer, i, DamageCause.ENTITY_ATTACK, 1.0D).isCancelled()) {
               byte i1 = 1;
               if(i.isEntityUndead()) {
                  i1 = 3;
               }

               i.attackEntityFrom(DamageSource.causePlayerDamage(par3EntityPlayer), (float)(5 * i1));
            }
         }

         ExplosionByPlayer.createExplosion(par3EntityPlayer, par2World, par3EntityPlayer, xCoord, yCoord, zCoord, 1.0F, false);

         for(int var21 = 0; var21 < 5; ++var21) {
            SpellHelper.sendParticleToAllAround(par2World, xCoord, yCoord, zCoord, 30, par2World.provider.dimensionId, "mobSpell", xCoord + (double)this.itemRand.nextFloat() - (double)this.itemRand.nextFloat(), yCoord + (double)this.itemRand.nextFloat() - (double)this.itemRand.nextFloat(), zCoord + (double)this.itemRand.nextFloat() - (double)this.itemRand.nextFloat(), 1.0D, 1.0D, 1.0D);
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onDefensiveRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getDefensiveEnergy());
         }

         if(!par2World.isRemote) {
            for(int i = 0; i < 360; i += 18) {
               par2World.spawnEntityInWorld(new HolyProjectile(par2World, par3EntityPlayer, 8, 3, par3EntityPlayer.posX, par3EntityPlayer.posY + (double)(par3EntityPlayer.height / 2.0F), par3EntityPlayer.posZ, (float)i, 0.0F));
            }
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onEnvironmentalRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getEnvironmentalEnergy());
         }

         boolean d0 = true;
         AxisAlignedBB axisalignedbb = AxisAlignedBB.getBoundingBox(par3EntityPlayer.posX, par3EntityPlayer.posY, par3EntityPlayer.posZ, par3EntityPlayer.posX + 1.0D, par3EntityPlayer.posY + 2.0D, par3EntityPlayer.posZ + 1.0D).expand(3.0D, 3.0D, 3.0D);
         List list = par3EntityPlayer.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, axisalignedbb);
         Iterator iterator = list.iterator();

         while(iterator.hasNext()) {
            EntityLivingBase xCoord = (EntityLivingBase)iterator.next();
            if((!(xCoord instanceof EntityPlayer) || !xCoord.equals(par3EntityPlayer)) && !FakePlayerUtils.callEntityDamageByEntityEvent(par3EntityPlayer, xCoord, DamageCause.ENTITY_ATTACK, 1.0D).isCancelled()) {
               byte i = 1;
               if(xCoord.isEntityUndead()) {
                  i = 3;
               }

               xCoord.attackEntityFrom(DamageSource.causePlayerDamage(par3EntityPlayer), (float)(5 * i));
            }
         }

         ExplosionByPlayer.createExplosion(par3EntityPlayer, par2World, par3EntityPlayer, par3EntityPlayer.posX, par3EntityPlayer.posY, par3EntityPlayer.posZ, 2.0F, false);
         double var15 = par3EntityPlayer.posX;
         double yCoord = par3EntityPlayer.posY;
         double zCoord = par3EntityPlayer.posZ;

         for(int i1 = 0; i1 < 20; ++i1) {
            SpellHelper.sendParticleToAllAround(par2World, var15, yCoord, zCoord, 30, par2World.provider.dimensionId, "mobSpell", var15 + (double)this.itemRand.nextFloat() - (double)this.itemRand.nextFloat(), yCoord + (double)this.itemRand.nextFloat() - (double)this.itemRand.nextFloat(), zCoord + (double)this.itemRand.nextFloat() - (double)this.itemRand.nextFloat(), 1.0D, 1.0D, 1.0D);
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }
}
