package WayofTime.alchemicalWizardry.common.spell.simple;

import WayofTime.alchemicalWizardry.common.entity.projectile.IceProjectile;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import WayofTime.alchemicalWizardry.common.spell.simple.HomSpell;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class SpellFrozenWater extends HomSpell {

   public Random itemRand = new Random();


   public SpellFrozenWater() {
      this.setEnergies(100, 200, 150, 100);
   }

   public ItemStack onOffensiveRangedRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getOffensiveRangedEnergy());
         }

         par2World.playSoundAtEntity(par3EntityPlayer, "random.fizz", 0.5F, 0.4F / (this.itemRand.nextFloat() * 0.4F + 0.8F));
         if(!par2World.isRemote) {
            par2World.spawnEntityInWorld(new IceProjectile(par2World, par3EntityPlayer, 6));
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onOffensiveMeleeRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par3EntityPlayer.capabilities.isCreativeMode) {
            EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getOffensiveMeleeEnergy());
         }

         for(int i = -2; i <= 2; ++i) {
            par2World.spawnEntityInWorld(new IceProjectile(par2World, par3EntityPlayer, 6, 2, par3EntityPlayer.posX, par3EntityPlayer.posY + (double)par3EntityPlayer.getEyeHeight(), par3EntityPlayer.posZ, par3EntityPlayer.rotationYaw + (float)i * 5.0F, par3EntityPlayer.rotationPitch));
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public ItemStack onDefensiveRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(!par3EntityPlayer.capabilities.isCreativeMode) {
         EnergyItems.syphonAndDamageWhileInContainer(par1ItemStack, par3EntityPlayer, this.getDefensiveEnergy());
      }

      float yaw = par3EntityPlayer.rotationYaw;
      float pitch = par3EntityPlayer.rotationPitch;
      boolean range = true;
      int i;
      int j;
      if(pitch > 40.0F) {
         for(i = -2; i <= 2; ++i) {
            for(j = -2; j <= 2; ++j) {
               if(par2World.isAirBlock((int)par3EntityPlayer.posX + i, (int)par3EntityPlayer.posY - 1, (int)par3EntityPlayer.posZ + j) && !FakePlayerUtils.callBlockBreakEvent((int)par3EntityPlayer.posX + i, (int)par3EntityPlayer.posY - 1, (int)par3EntityPlayer.posZ + j, par3EntityPlayer).isCancelled()) {
                  par2World.setBlock((int)par3EntityPlayer.posX + i, (int)par3EntityPlayer.posY - 1, (int)par3EntityPlayer.posZ + j, Blocks.ice);
               }
            }
         }

         return par1ItemStack;
      } else if(pitch < -40.0F) {
         for(i = -2; i <= 2; ++i) {
            for(j = -2; j <= 2; ++j) {
               if(par2World.isAirBlock((int)par3EntityPlayer.posX + i, (int)par3EntityPlayer.posY + 3, (int)par3EntityPlayer.posZ + j) && !FakePlayerUtils.callBlockBreakEvent((int)par3EntityPlayer.posX + i, (int)par3EntityPlayer.posY + 3, (int)par3EntityPlayer.posZ + j, par3EntityPlayer).isCancelled()) {
                  par2World.setBlock((int)par3EntityPlayer.posX + i, (int)par3EntityPlayer.posY + 3, (int)par3EntityPlayer.posZ + j, Blocks.ice);
               }
            }
         }

         return par1ItemStack;
      } else {
         if((yaw < 315.0F || yaw >= 360.0F) && (yaw < 0.0F || yaw >= 45.0F)) {
            if(yaw >= 45.0F && yaw < 135.0F) {
               for(i = -2; i <= 2; ++i) {
                  for(j = 0; j < 5; ++j) {
                     if(par2World.isAirBlock((int)par3EntityPlayer.posX - 2, (int)par3EntityPlayer.posY + j, (int)par3EntityPlayer.posZ + i) && !FakePlayerUtils.callBlockBreakEvent((int)par3EntityPlayer.posX - 2, (int)par3EntityPlayer.posY + j, (int)par3EntityPlayer.posZ + i, par3EntityPlayer).isCancelled()) {
                        par2World.setBlock((int)par3EntityPlayer.posX - 2, (int)par3EntityPlayer.posY + j, (int)par3EntityPlayer.posZ + i, Blocks.ice);
                     }
                  }
               }
            } else if(yaw >= 135.0F && yaw < 225.0F) {
               for(i = -2; i <= 2; ++i) {
                  for(j = 0; j < 5; ++j) {
                     if(par2World.isAirBlock((int)par3EntityPlayer.posX + i, (int)par3EntityPlayer.posY + j, (int)par3EntityPlayer.posZ - 2) && !FakePlayerUtils.callBlockBreakEvent((int)par3EntityPlayer.posX + i, (int)par3EntityPlayer.posY + j, (int)par3EntityPlayer.posZ - 2, par3EntityPlayer).isCancelled()) {
                        par2World.setBlock((int)par3EntityPlayer.posX + i, (int)par3EntityPlayer.posY + j, (int)par3EntityPlayer.posZ - 2, Blocks.ice);
                     }
                  }
               }
            } else {
               for(i = -2; i <= 2; ++i) {
                  for(j = 0; j < 5; ++j) {
                     if(par2World.isAirBlock((int)par3EntityPlayer.posX + 2, (int)par3EntityPlayer.posY + j, (int)par3EntityPlayer.posZ + i) && !FakePlayerUtils.callBlockBreakEvent((int)par3EntityPlayer.posX + 2, (int)par3EntityPlayer.posY + j, (int)par3EntityPlayer.posZ + i, par3EntityPlayer).isCancelled()) {
                        par2World.setBlock((int)par3EntityPlayer.posX + 2, (int)par3EntityPlayer.posY + j, (int)par3EntityPlayer.posZ + i, Blocks.ice);
                     }
                  }
               }
            }
         } else {
            for(i = -2; i <= 2; ++i) {
               for(j = 0; j < 5; ++j) {
                  if(par2World.isAirBlock((int)par3EntityPlayer.posX + i, (int)par3EntityPlayer.posY + j, (int)par3EntityPlayer.posZ + 2) && !FakePlayerUtils.callBlockBreakEvent((int)par3EntityPlayer.posX + i, (int)par3EntityPlayer.posY + j, (int)par3EntityPlayer.posZ + 2, par3EntityPlayer).isCancelled()) {
                     par2World.setBlock((int)par3EntityPlayer.posX + i, (int)par3EntityPlayer.posY + j, (int)par3EntityPlayer.posZ + 2, Blocks.ice);
                  }
               }
            }
         }

         return par1ItemStack;
      }
   }

   public ItemStack onEnvironmentalRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         boolean radius = true;
         int posX = (int)par3EntityPlayer.posX;
         int posY = (int)par3EntityPlayer.posY;
         int posZ = (int)par3EntityPlayer.posZ;

         for(int i = -3; i <= 3; ++i) {
            for(int j = -3; j <= 3; ++j) {
               for(int k = -3; k <= 3; ++k) {
                  Block block = par2World.getBlock((int)par3EntityPlayer.posX + i - 1, (int)par3EntityPlayer.posY + j, (int)par3EntityPlayer.posZ + k);
                  if((block == Blocks.water || block == Blocks.flowing_water) && !FakePlayerUtils.callBlockBreakEvent((int)par3EntityPlayer.posX + i - 1, (int)par3EntityPlayer.posY + j, (int)par3EntityPlayer.posZ + k, par3EntityPlayer).isCancelled()) {
                     par2World.setBlock((int)par3EntityPlayer.posX + i - 1, (int)par3EntityPlayer.posY + j, (int)par3EntityPlayer.posZ + k, Blocks.ice);
                  }
               }
            }
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }
}
