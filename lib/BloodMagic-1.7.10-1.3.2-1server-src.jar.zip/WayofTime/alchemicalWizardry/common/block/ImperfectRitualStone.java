package WayofTime.alchemicalWizardry.common.block;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class ImperfectRitualStone extends Block {

   public ImperfectRitualStone() {
      super(Material.iron);
      this.setHardness(2.0F);
      this.setResistance(5.0F);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      this.setBlockName("imperfectRitualStone");
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister iconRegister) {
      super.blockIcon = iconRegister.registerIcon("AlchemicalWizardry:ImperfectRitualStone");
   }

   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float xOff, float yOff, float zOff) {
      if(SpellHelper.isFakePlayer(player)) {
         return false;
      } else {
         Block block = world.getBlock(x, y + 1, z);
         if(block == Blocks.bedrock) {
            if(!player.capabilities.isCreativeMode && !world.isRemote) {
               EnergyItems.drainPlayerNetwork(player, 5000);
            }

            if(!world.isRemote) {
               world.addWeatherEffect(new EntityLightningBolt(world, (double)x, (double)(y + 2), (double)z));
            }

            player.addPotionEffect(new PotionEffect(Potion.resistance.id, 1200, 1));
         }

         return false;
      }
   }
}
