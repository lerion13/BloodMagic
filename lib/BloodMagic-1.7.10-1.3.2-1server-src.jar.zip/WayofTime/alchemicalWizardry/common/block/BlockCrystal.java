package WayofTime.alchemicalWizardry.common.block;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.ModBlocks;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;

public class BlockCrystal extends Block {

   private IIcon fullIcon;
   private IIcon brickIcon;


   public BlockCrystal() {
      super(Material.iron);
      this.setBlockName("crystalBlock");
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      this.setHardness(2.0F);
      this.setResistance(5.0F);
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister iconRegister) {
      super.blockIcon = iconRegister.registerIcon("AlchemicalWizardry:BlankRune");
      this.fullIcon = iconRegister.registerIcon("AlchemicalWizardry:ShardCluster");
      this.brickIcon = iconRegister.registerIcon("AlchemicalWizardry:ShardClusterBrick");
   }

   @SideOnly(Side.CLIENT)
   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      if(this.equals(ModBlocks.blockCrystal)) {
         par3List.add(new ItemStack(par1, 1, 0));
         par3List.add(new ItemStack(par1, 1, 1));
      } else {
         super.getSubBlocks(par1, par2CreativeTabs, par3List);
      }

   }

   @SideOnly(Side.CLIENT)
   public IIcon getIcon(int side, int meta) {
      switch(meta) {
      case 0:
         return this.fullIcon;
      case 1:
         return this.brickIcon;
      default:
         return super.blockIcon;
      }
   }

   public int damageDropped(int metadata) {
      return metadata;
   }
}
