package WayofTime.alchemicalWizardry.common.block;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.common.block.BloodRune;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;

public class SpeedRune extends BloodRune {

   public SpeedRune() {
      this.setBlockName("speedRune");
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      this.setHardness(2.0F);
      this.setResistance(5.0F);
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister iconRegister) {
      super.blockIcon = iconRegister.registerIcon("AlchemicalWizardry:SpeedRune");
   }

   public int getRuneEffect(int metaData) {
      return 1;
   }
}
