package WayofTime.alchemicalWizardry.common.block;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.ModItems;
import WayofTime.alchemicalWizardry.api.items.interfaces.ArmourUpgrade;
import WayofTime.alchemicalWizardry.common.ArmourComponent;
import WayofTime.alchemicalWizardry.common.items.armour.BoundArmour;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import WayofTime.alchemicalWizardry.common.tileEntity.TESocket;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public class ArmourForge extends Block {

   public static List helmetList = new ArrayList();
   public static List plateList = new ArrayList();
   public static List leggingsList = new ArrayList();
   public static List bootsList = new ArrayList();


   public ArmourForge() {
      super(Material.iron);
      this.setHardness(2.0F);
      this.setResistance(5.0F);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      this.setBlockName("armourForge");
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister iconRegister) {
      super.blockIcon = iconRegister.registerIcon("AlchemicalWizardry:SoulForge");
   }

   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int idk, float what, float these, float are) {
      if(world.isRemote) {
         return false;
      } else {
         int armourType = this.getArmourType(world, x, y, z);
         if(armourType == -1) {
            return false;
         } else {
            int direction = this.getDirectionForArmourType(world, x, y, z, armourType);
            if(!this.isParadigmValid(armourType, direction, world, x, y, z)) {
               return false;
            } else {
               List list = null;
               ItemStack armourPiece = null;
               switch(armourType) {
               case 0:
                  list = plateList;
                  armourPiece = new ItemStack(ModItems.boundPlate, 1, 0);
                  break;
               case 1:
                  list = leggingsList;
                  armourPiece = new ItemStack(ModItems.boundLeggings, 1, 0);
                  break;
               case 2:
                  list = helmetList;
                  armourPiece = new ItemStack(ModItems.boundHelmet, 1, 0);
                  break;
               case 3:
                  list = bootsList;
                  armourPiece = new ItemStack(ModItems.boundBoots, 1, 0);
               }

               if(list == null) {
                  return false;
               } else if(armourPiece == null) {
                  return false;
               } else {
                  if(armourPiece.getTagCompound() == null) {
                     armourPiece.setTagCompound(new NBTTagCompound());
                  }

                  Iterator xOff = list.iterator();

                  while(xOff.hasNext()) {
                     ArmourComponent zOff = (ArmourComponent)xOff.next();
                     int xOff1 = zOff.getXOff();
                     int zOff1 = zOff.getZOff();
                     TileEntity tileEntity;
                     switch(direction) {
                     case 1:
                        tileEntity = world.getTileEntity(x + xOff1, y, z - zOff1);
                        break;
                     case 2:
                        tileEntity = world.getTileEntity(x + zOff1, y, z + xOff1);
                        break;
                     case 3:
                        tileEntity = world.getTileEntity(x - xOff1, y, z + zOff1);
                        break;
                     case 4:
                        tileEntity = world.getTileEntity(x - zOff1, y, z - xOff1);
                        break;
                     case 5:
                        tileEntity = world.getTileEntity(x + xOff1, y + zOff1, z);
                        break;
                     case 6:
                        tileEntity = world.getTileEntity(x, y + zOff1, z + xOff1);
                        break;
                     default:
                        tileEntity = null;
                     }

                     if(tileEntity instanceof TESocket) {
                        ItemStack itemStack = ((TESocket)tileEntity).getStackInSlot(0);
                        int xCoord = tileEntity.xCoord;
                        int yCoord = tileEntity.yCoord;
                        int zCoord = tileEntity.zCoord;
                        ((TESocket)tileEntity).setInventorySlotContents(0, (ItemStack)null);
                        world.setBlockToAir(tileEntity.xCoord, tileEntity.yCoord, tileEntity.zCoord);

                        for(int item = 0; item < 8; ++item) {
                           SpellHelper.sendIndexedParticleToAllAround(world, (double)xCoord, (double)yCoord, (double)zCoord, 20, world.provider.dimensionId, 1, (double)xCoord, (double)yCoord, (double)zCoord);
                        }

                        if(itemStack != null) {
                           Item var26 = itemStack.getItem();
                           if(var26 instanceof ArmourUpgrade) {
                              ((BoundArmour)armourPiece.getItem()).hasAddedToInventory(armourPiece, itemStack.copy());
                              ((TESocket)tileEntity).setInventorySlotContents(0, (ItemStack)null);
                           }
                        }
                     }
                  }

                  if(armourPiece != null) {
                     int var25 = world.rand.nextInt(11) - 5;
                     int var24 = (int)(Math.sqrt((double)(25 - var25 * var25)) * ((double)world.rand.nextInt(2) - 0.5D) * 2.0D);
                     world.addWeatherEffect(new EntityLightningBolt(world, (double)(x + var25), (double)(y + 5), (double)(z + var24)));
                     world.spawnEntityInWorld(new EntityItem(world, (double)x, (double)(y + 1), (double)z, armourPiece));
                  }

                  return true;
               }
            }
         }
      }
   }

   public int getArmourType(World world, int x, int y, int z) {
      for(int i = 0; i <= 3; ++i) {
         if(this.getDirectionForArmourType(world, x, y, z, i) != -1) {
            return i;
         }
      }

      return -1;
   }

   public int getDirectionForArmourType(World world, int x, int y, int z, int armourType) {
      for(int i = 1; i <= 6; ++i) {
         if(this.isParadigmValid(armourType, i, world, x, y, z)) {
            return i;
         }
      }

      return -1;
   }

   public boolean isParadigmValid(int armourType, int direction, World world, int x, int y, int z) {
      List list = null;
      switch(armourType) {
      case 0:
         list = plateList;
         break;
      case 1:
         list = leggingsList;
         break;
      case 2:
         list = helmetList;
         break;
      case 3:
         list = bootsList;
      }

      if(list == null) {
         return false;
      } else {
         Iterator i$ = list.iterator();

         while(i$.hasNext()) {
            ArmourComponent ac = (ArmourComponent)i$.next();
            int xOff = ac.getXOff();
            int zOff = ac.getZOff();
            switch(direction) {
            case 1:
               if(!(world.getTileEntity(x + xOff, y, z - zOff) instanceof TESocket)) {
                  return false;
               }
               break;
            case 2:
               if(!(world.getTileEntity(x + zOff, y, z + xOff) instanceof TESocket)) {
                  return false;
               }
               break;
            case 3:
               if(!(world.getTileEntity(x - xOff, y, z + zOff) instanceof TESocket)) {
                  return false;
               }
               break;
            case 4:
               if(!(world.getTileEntity(x - zOff, y, z - xOff) instanceof TESocket)) {
                  return false;
               }
               break;
            case 5:
               if(!(world.getTileEntity(x + xOff, y + zOff, z) instanceof TESocket)) {
                  return false;
               }
               break;
            case 6:
               if(!(world.getTileEntity(x, y + zOff, z + xOff) instanceof TESocket)) {
                  return false;
               }
               break;
            default:
               return false;
            }
         }

         return true;
      }
   }

   public static void initializeRecipes() {
      helmetList.add(new ArmourComponent(-1, 1));
      helmetList.add(new ArmourComponent(0, 1));
      helmetList.add(new ArmourComponent(1, 1));
      helmetList.add(new ArmourComponent(-1, 0));
      helmetList.add(new ArmourComponent(1, 0));
      bootsList.add(new ArmourComponent(-1, 1));
      bootsList.add(new ArmourComponent(1, 1));
      bootsList.add(new ArmourComponent(-1, 0));
      bootsList.add(new ArmourComponent(1, 0));
      plateList.add(new ArmourComponent(-1, 0));
      plateList.add(new ArmourComponent(1, 0));
      plateList.add(new ArmourComponent(-1, -1));
      plateList.add(new ArmourComponent(0, -1));
      plateList.add(new ArmourComponent(1, -1));
      plateList.add(new ArmourComponent(-1, -2));
      plateList.add(new ArmourComponent(0, -2));
      plateList.add(new ArmourComponent(1, -2));
      leggingsList.add(new ArmourComponent(-1, 1));
      leggingsList.add(new ArmourComponent(0, 1));
      leggingsList.add(new ArmourComponent(1, 1));
      leggingsList.add(new ArmourComponent(-1, 0));
      leggingsList.add(new ArmourComponent(1, 0));
      leggingsList.add(new ArmourComponent(-1, -1));
      leggingsList.add(new ArmourComponent(1, -1));
   }

}
