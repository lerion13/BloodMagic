package WayofTime.alchemicalWizardry.common.block;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.common.tileEntity.TEWritingTable;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;

public class BlockWritingTable extends BlockContainer {

   @SideOnly(Side.CLIENT)
   private static IIcon topIcon;
   @SideOnly(Side.CLIENT)
   private static IIcon sideIcon1;
   @SideOnly(Side.CLIENT)
   private static IIcon sideIcon2;
   @SideOnly(Side.CLIENT)
   private static IIcon bottomIcon;


   public BlockWritingTable() {
      super(Material.wood);
      this.setHardness(2.0F);
      this.setResistance(5.0F);
      this.setBlockName("blockWritingTable");
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister iconRegister) {
      topIcon = iconRegister.registerIcon("AlchemicalWizardry:AlchemicChemistrySet");
      sideIcon1 = iconRegister.registerIcon("AlchemicalWizardry:BloodAltar_SideType1");
      sideIcon2 = iconRegister.registerIcon("AlchemicalWizardry:BloodAltar_SideType2");
      bottomIcon = iconRegister.registerIcon("AlchemicalWizardry:BloodAltar_Bottom");
   }

   @SideOnly(Side.CLIENT)
   public IIcon getIcon(int side, int meta) {
      switch(side) {
      case 0:
         return bottomIcon;
      case 1:
         return topIcon;
      default:
         return sideIcon2;
      }
   }

   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int metadata, float what, float these, float are) {
      TileEntity tileEntity = world.getTileEntity(x, y, z);
      if(tileEntity != null && !player.isSneaking()) {
         player.openGui(AlchemicalWizardry.instance, 0, world, x, y, z);
         return true;
      } else {
         return false;
      }
   }

   public void breakBlock(World world, int x, int y, int z, Block par5, int par6) {
      this.dropItems(world, x, y, z);
      super.breakBlock(world, x, y, z, par5, par6);
   }

   private void dropItems(World world, int x, int y, int z) {
      Random rand = new Random();
      TileEntity tileEntity = world.getTileEntity(x, y, z);
      if(tileEntity instanceof IInventory) {
         IInventory inventory = (IInventory)tileEntity;

         for(int i = 0; i < inventory.getSizeInventory(); ++i) {
            ItemStack item = inventory.getStackInSlot(i);
            if(item != null && item.stackSize > 0) {
               float rx = rand.nextFloat() * 0.8F + 0.1F;
               float ry = rand.nextFloat() * 0.8F + 0.1F;
               float rz = rand.nextFloat() * 0.8F + 0.1F;
               EntityItem entityItem = new EntityItem(world, (double)((float)x + rx), (double)((float)y + ry), (double)((float)z + rz), new ItemStack(item.getItem(), item.stackSize, item.getItemDamage()));
               if(item.hasTagCompound()) {
                  entityItem.getEntityItem().setTagCompound((NBTTagCompound)item.getTagCompound().copy());
               }

               float factor = 0.05F;
               entityItem.motionX = rand.nextGaussian() * (double)factor;
               entityItem.motionY = rand.nextGaussian() * (double)factor + 0.20000000298023224D;
               entityItem.motionZ = rand.nextGaussian() * (double)factor;
               world.spawnEntityInWorld(entityItem);
               item.stackSize = 0;
            }
         }

      }
   }

   public TileEntity createNewTileEntity(World world, int meta) {
      return new TEWritingTable();
   }

   public boolean renderAsNormalBlock() {
      return false;
   }

   public int getRenderType() {
      return -1;
   }

   public boolean isOpaqueCube() {
      return false;
   }

   public boolean hasTileEntity() {
      return true;
   }

   public void addCollisionBoxesToList(World par1World, int par2, int par3, int par4, AxisAlignedBB par5AxisAlignedBB, List par6List, Entity par7Entity) {
      this.setBlockBounds(0.4375F, 0.0F, 0.4375F, 0.5625F, 0.9375F, 0.5625F);
      super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
      this.setBlockBoundsForItemRender();
      super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
   }

   public void setBlockBoundsForItemRender() {
      this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
   }
}
