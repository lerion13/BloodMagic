package WayofTime.alchemicalWizardry.common.block;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.common.block.BlockOrientable;
import WayofTime.alchemicalWizardry.common.tileEntity.TEConduit;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;

public class BlockConduit extends BlockOrientable {

   @SideOnly(Side.CLIENT)
   private static IIcon topIcon;
   @SideOnly(Side.CLIENT)
   private static IIcon sideIcon1;
   @SideOnly(Side.CLIENT)
   private static IIcon sideIcon2;
   @SideOnly(Side.CLIENT)
   private static IIcon bottomIcon;


   public BlockConduit() {
      this.setHardness(2.0F);
      this.setResistance(5.0F);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      this.setBlockName("blockConduit");
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister iconRegister) {
      topIcon = iconRegister.registerIcon("AlchemicalWizardry:BloodAltar_Top");
      sideIcon1 = iconRegister.registerIcon("AlchemicalWizardry:BloodAltar_SideType1");
      sideIcon2 = iconRegister.registerIcon("AlchemicalWizardry:BloodAltar_SideType2");
      bottomIcon = iconRegister.registerIcon("AlchemicalWizardry:BloodAltar_Bottom");
   }

   @SideOnly(Side.CLIENT)
   public IIcon getIcon(int side, int meta) {
      switch(side) {
      case 0:
         return bottomIcon;
      case 1:
         return topIcon;
      default:
         return sideIcon2;
      }
   }

   public void breakBlock(World world, int x, int y, int z, Block par5, int par6) {
      super.breakBlock(world, x, y, z, par5, par6);
   }

   public TileEntity createNewTileEntity(World world, int noClue) {
      return new TEConduit();
   }

   public boolean renderAsNormalBlock() {
      return false;
   }

   public int getRenderType() {
      return -1;
   }

   public boolean isOpaqueCube() {
      return false;
   }

   public boolean hasTileEntity() {
      return true;
   }
}
