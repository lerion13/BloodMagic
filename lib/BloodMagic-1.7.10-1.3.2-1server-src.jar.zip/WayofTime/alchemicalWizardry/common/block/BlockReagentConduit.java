package WayofTime.alchemicalWizardry.common.block;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.common.tileEntity.TEReagentConduit;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public class BlockReagentConduit extends BlockContainer {

   public BlockReagentConduit() {
      super(Material.cloth);
      this.setHardness(2.0F);
      this.setResistance(5.0F);
      this.setBlockName("blockReagentConduit");
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister iconRegister) {
      super.blockIcon = iconRegister.registerIcon("AlchemicalWizardry:SimpleTransCircle");
   }

   public TileEntity createNewTileEntity(World world, int meta) {
      return new TEReagentConduit();
   }

   public boolean canProvidePower() {
      return true;
   }

   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float what, float these, float are) {
      return super.onBlockActivated(world, x, y, z, player, side, what, these, are);
   }

   public boolean isOpaqueCube() {
      return false;
   }

   public boolean renderAsNormalBlock() {
      return false;
   }

   public int getRenderType() {
      return -1;
   }
}
