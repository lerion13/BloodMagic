package WayofTime.alchemicalWizardry.common.block;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.common.tileEntity.TEOrientable;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public class BlockOrientable extends BlockContainer {

   public BlockOrientable() {
      super(Material.rock);
      this.setHardness(2.0F);
      this.setResistance(5.0F);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   public TileEntity createNewTileEntity(World world, int dunno) {
      return new TEOrientable();
   }

   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float what, float these, float are) {
      if(world.isRemote) {
         return false;
      } else {
         ForgeDirection sideClicked = ForgeDirection.getOrientation(side);
         TileEntity tile = world.getTileEntity(x, y, z);
         if(tile instanceof TEOrientable) {
            TEOrientable newTile = (TEOrientable)tile;
            int nextSide;
            if(player.isSneaking()) {
               nextSide = TEOrientable.getIntForForgeDirection(newTile.getInputDirection()) + 1;
               if(nextSide > 5) {
                  nextSide = 0;
               }

               if(ForgeDirection.getOrientation(nextSide) == newTile.getOutputDirection()) {
                  ++nextSide;
                  if(nextSide > 5) {
                     nextSide = 0;
                  }
               }

               newTile.setInputDirection(ForgeDirection.getOrientation(nextSide));
            } else {
               nextSide = TEOrientable.getIntForForgeDirection(newTile.getOutputDirection()) + 1;
               if(nextSide > 5) {
                  nextSide = 0;
               }

               if(ForgeDirection.getOrientation(nextSide) == newTile.getInputDirection()) {
                  ++nextSide;
                  if(nextSide > 5) {
                     nextSide = 0;
                  }
               }

               newTile.setOutputDirection(ForgeDirection.getOrientation(nextSide));
            }
         }

         world.markBlockForUpdate(x, y, z);
         return true;
      }
   }

   public int damageDropped(int metadata) {
      return metadata;
   }

   // $FF: synthetic class
   static class NamelessClass1001327132 {

      // $FF: synthetic field
      static final int[] $SwitchMap$net$minecraftforge$common$util$ForgeDirection = new int[ForgeDirection.values().length];


      static {
         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.NORTH.ordinal()] = 1;
         } catch (NoSuchFieldError var6) {
            ;
         }

         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.SOUTH.ordinal()] = 2;
         } catch (NoSuchFieldError var5) {
            ;
         }

         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.EAST.ordinal()] = 3;
         } catch (NoSuchFieldError var4) {
            ;
         }

         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.WEST.ordinal()] = 4;
         } catch (NoSuchFieldError var3) {
            ;
         }

         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.DOWN.ordinal()] = 5;
         } catch (NoSuchFieldError var2) {
            ;
         }

         try {
            $SwitchMap$net$minecraftforge$common$util$ForgeDirection[ForgeDirection.UP.ordinal()] = 6;
         } catch (NoSuchFieldError var1) {
            ;
         }

      }
   }
}
