package WayofTime.alchemicalWizardry.common.block;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.ModBlocks;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;

public class BloodRune extends Block {

   private IIcon altarCapacityRuneIcon;
   private IIcon dislocationRuneIcon;
   private IIcon orbCapacityRuneIcon;
   private IIcon betterCapacityRuneIcon;
   private IIcon accelerationRuneIcon;


   public BloodRune() {
      super(Material.iron);
      this.setBlockName("bloodRune");
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      this.setHardness(2.0F);
      this.setResistance(5.0F);
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister iconRegister) {
      super.blockIcon = iconRegister.registerIcon("AlchemicalWizardry:BlankRune");
      this.altarCapacityRuneIcon = iconRegister.registerIcon("AlchemicalWizardry:AltarCapacityRune");
      this.dislocationRuneIcon = iconRegister.registerIcon("AlchemicalWizardry:DislocationRune");
      this.orbCapacityRuneIcon = iconRegister.registerIcon("AlchemicalWizardry:OrbCapacityRune");
      this.betterCapacityRuneIcon = iconRegister.registerIcon("AlchemicalWizardry:BetterCapacityRune");
      this.accelerationRuneIcon = iconRegister.registerIcon("AlchemicalWizardry:AccelerationRune");
   }

   public int getRuneEffect(int metaData) {
      switch(metaData) {
      case 0:
         return 0;
      case 1:
         return 5;
      case 2:
         return 6;
      case 3:
         return 7;
      case 4:
         return 8;
      case 5:
         return 9;
      default:
         return 0;
      }
   }

   @SideOnly(Side.CLIENT)
   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      if(this.equals(ModBlocks.bloodRune)) {
         par3List.add(new ItemStack(par1, 1, 0));
         par3List.add(new ItemStack(par1, 1, 1));
         par3List.add(new ItemStack(par1, 1, 2));
         par3List.add(new ItemStack(par1, 1, 3));
         par3List.add(new ItemStack(par1, 1, 4));
         par3List.add(new ItemStack(par1, 1, 5));
      } else {
         super.getSubBlocks(par1, par2CreativeTabs, par3List);
      }

   }

   @SideOnly(Side.CLIENT)
   public IIcon getIcon(int side, int meta) {
      switch(meta) {
      case 0:
         return super.blockIcon;
      case 1:
         return this.altarCapacityRuneIcon;
      case 2:
         return this.dislocationRuneIcon;
      case 3:
         return this.orbCapacityRuneIcon;
      case 4:
         return this.betterCapacityRuneIcon;
      case 5:
         return this.accelerationRuneIcon;
      default:
         return super.blockIcon;
      }
   }

   public int damageDropped(int metadata) {
      return metadata;
   }
}
