package WayofTime.alchemicalWizardry.common.block;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockBloodLightSource extends Block {

   public BlockBloodLightSource() {
      super(Material.cloth);
      this.setBlockName("blockBloodLightSource");
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister iconRegister) {
      super.blockIcon = iconRegister.registerIcon("AlchemicalWizardry:BlockBloodLight");
   }

   public int getLightValue(IBlockAccess world, int x, int y, int z) {
      return 15;
   }

   public boolean isOpaqueCube() {
      return false;
   }

   public boolean renderAsNormalBlock() {
      return false;
   }

   public void randomDisplayTick(World world, int x, int y, int z, Random rand) {
      if(rand.nextInt(3) != 0) {
         float f = 1.0F;
         float f1 = f * 0.6F + 0.4F;
         float f2 = f * f * 0.7F - 0.5F;
         float f3 = f * f * 0.6F - 0.7F;
         world.spawnParticle("reddust", (double)x + 0.5D + rand.nextGaussian() / 8.0D, (double)y + 0.5D, (double)z + 0.5D + rand.nextGaussian() / 8.0D, (double)f1, (double)f2, (double)f3);
      }

   }

   public void addCollisionBoxesToList(World par1World, int par2, int par3, int par4, AxisAlignedBB par5AxisAlignedBB, List par6List, Entity par7Entity) {
      this.setBlockBounds(0.4F, 0.4F, 0.4F, 0.6F, 0.6F, 0.6F);
   }

   public int quantityDropped(Random par1Random) {
      return 0;
   }
}
