package WayofTime.alchemicalWizardry.common.block;

import net.minecraftforge.common.util.ForgeDirection;

public interface IOrientable {

   ForgeDirection getInputDirection();

   ForgeDirection getOutputDirection();

   void setInputDirection(ForgeDirection var1);

   void setOutputDirection(ForgeDirection var1);
}
