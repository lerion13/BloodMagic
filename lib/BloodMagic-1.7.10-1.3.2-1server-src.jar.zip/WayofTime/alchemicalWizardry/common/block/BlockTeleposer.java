package WayofTime.alchemicalWizardry.common.block;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.event.TeleposeEvent;
import WayofTime.alchemicalWizardry.api.soulNetwork.SoulNetworkHandler;
import WayofTime.alchemicalWizardry.common.demonVillage.tileEntity.TEDemonPortal;
import WayofTime.alchemicalWizardry.common.items.TelepositionFocus;
import WayofTime.alchemicalWizardry.common.tileEntity.TETeleposer;
import codechicken.multipart.MultipartHelper;
import codechicken.multipart.TileMultipart;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import cpw.mods.fml.common.Optional.Method;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.BlockMobSpawner;
import net.minecraft.block.BlockPortal;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;

public class BlockTeleposer extends BlockContainer {

   @SideOnly(Side.CLIENT)
   private static IIcon topIcon;
   @SideOnly(Side.CLIENT)
   private static IIcon sideIcon1;
   @SideOnly(Side.CLIENT)
   private static IIcon sideIcon2;
   @SideOnly(Side.CLIENT)
   private static IIcon bottomIcon;


   public BlockTeleposer() {
      super(Material.rock);
      this.setHardness(2.0F);
      this.setResistance(5.0F);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      this.setBlockName("bloodTeleposer");
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister iconRegister) {
      topIcon = iconRegister.registerIcon("AlchemicalWizardry:Teleposer_Top");
      sideIcon1 = iconRegister.registerIcon("AlchemicalWizardry:Teleposer_Side");
      sideIcon2 = iconRegister.registerIcon("AlchemicalWizardry:Teleposer_Side");
      bottomIcon = iconRegister.registerIcon("AlchemicalWizardry:Teleposer_Side");
   }

   @SideOnly(Side.CLIENT)
   public IIcon getIcon(int side, int meta) {
      switch(side) {
      case 0:
         return bottomIcon;
      case 1:
         return topIcon;
      default:
         return sideIcon2;
      }
   }

   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int idk, float what, float these, float are) {
      TETeleposer tileEntity = (TETeleposer)world.getTileEntity(x, y, z);
      ItemStack playerItem = player.getCurrentEquippedItem();
      if(playerItem != null && playerItem.getItem() instanceof TelepositionFocus) {
         SoulNetworkHandler.checkAndSetItemPlayer(playerItem, player);
         if(playerItem.getTagCompound() == null) {
            playerItem.setTagCompound(new NBTTagCompound());
         }

         NBTTagCompound itemTag = playerItem.getTagCompound();
         itemTag.setInteger("xCoord", x);
         itemTag.setInteger("yCoord", y);
         itemTag.setInteger("zCoord", z);
         itemTag.setInteger("dimensionId", world.provider.dimensionId);
         return true;
      } else {
         player.openGui(AlchemicalWizardry.instance, 1, world, x, y, z);
         return true;
      }
   }

   public void breakBlock(World world, int x, int y, int z, Block par5, int par6) {
      this.dropItems(world, x, y, z);
      super.breakBlock(world, x, y, z, par5, par6);
   }

   private void dropItems(World world, int x, int y, int z) {
      Random rand = new Random();
      TileEntity tileEntity = world.getTileEntity(x, y, z);
      if(tileEntity instanceof IInventory) {
         IInventory inventory = (IInventory)tileEntity;

         for(int i = 0; i < inventory.getSizeInventory(); ++i) {
            ItemStack item = inventory.getStackInSlot(i);
            if(item != null && item.stackSize > 0) {
               float rx = rand.nextFloat() * 0.8F + 0.1F;
               float ry = rand.nextFloat() * 0.8F + 0.1F;
               float rz = rand.nextFloat() * 0.8F + 0.1F;
               EntityItem entityItem = new EntityItem(world, (double)((float)x + rx), (double)((float)y + ry), (double)((float)z + rz), new ItemStack(item.getItem(), item.stackSize, item.getItemDamage()));
               if(item.hasTagCompound()) {
                  entityItem.getEntityItem().setTagCompound((NBTTagCompound)item.getTagCompound().copy());
               }

               float factor = 0.05F;
               entityItem.motionX = rand.nextGaussian() * (double)factor;
               entityItem.motionY = rand.nextGaussian() * (double)factor + 0.20000000298023224D;
               entityItem.motionZ = rand.nextGaussian() * (double)factor;
               world.spawnEntityInWorld(entityItem);
               item.stackSize = 0;
            }
         }

      }
   }

   public TileEntity createNewTileEntity(World world, int meta) {
      return new TETeleposer();
   }

   public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase entity, ItemStack stack) {
      super.onBlockPlacedBy(world, x, y, z, entity, stack);
      TileEntity tile = world.getTileEntity(x, y, z);
      if(tile != null && tile instanceof TETeleposer && entity instanceof EntityPlayer) {
         ((TETeleposer)tile).ownerProfile = ((EntityPlayer)entity).getGameProfile();
      }

   }

   public static boolean swapBlocks(Object caller, World worldI, World worldF, int xi, int yi, int zi, int xf, int yf, int zf) {
      Block blockI = worldI.getBlock(xi, yi, zi);
      Block blockF = worldF.getBlock(xf, yf, zf);
      if(blockI.equals(Blocks.air) && blockF.equals(Blocks.air)) {
         return false;
      } else if(!(blockI instanceof BlockMobSpawner) && !(blockF instanceof BlockMobSpawner) && !(caller instanceof TEDemonPortal) && (blockI instanceof BlockPortal || blockF instanceof BlockPortal)) {
         return false;
      } else {
         if(caller instanceof TETeleposer) {
            TETeleposer tileEntityI = (TETeleposer)caller;
            if(FakePlayerUtils.callBlockBreakEvent(xi, yi, zi, tileEntityI.getOwnerFake()).isCancelled() || FakePlayerUtils.callBlockBreakEvent(xf, yf, zf, tileEntityI.getOwnerFake()).isCancelled()) {
               return false;
            }
         }

         TileEntity tileEntityI1 = worldI.getTileEntity(xi, yi, zi);
         TileEntity tileEntityF = worldF.getTileEntity(xf, yf, zf);
         NBTTagCompound nbttag1 = new NBTTagCompound();
         NBTTagCompound nbttag2 = new NBTTagCompound();
         if(tileEntityI1 != null) {
            tileEntityI1.writeToNBT(nbttag1);
         }

         if(tileEntityF != null) {
            tileEntityF.writeToNBT(nbttag2);
         }

         int metaI = worldI.getBlockMetadata(xi, yi, zi);
         int metaF = worldF.getBlockMetadata(xf, yf, zf);
         TeleposeEvent evt = new TeleposeEvent(worldI, xi, yi, zi, blockI, metaI, worldF, xf, yf, zf, blockF, metaF);
         if(MinecraftForge.EVENT_BUS.post(evt)) {
            return false;
         } else {
            worldI.playSoundEffect((double)xi, (double)yi, (double)zi, "mob.endermen.portal", 1.0F, 1.0F);
            worldF.playSoundEffect((double)xf, (double)yf, (double)zf, "mob.endermen.portal", 1.0F, 1.0F);
            TileEntity newTileEntityF;
            if(blockF != null) {
               newTileEntityF = blockF.createTileEntity(worldF, metaF);
               worldF.setTileEntity(xf, yf, zf, newTileEntityF);
            }

            if(blockI != null) {
               newTileEntityF = blockI.createTileEntity(worldI, metaI);
               worldI.setTileEntity(xi, yi, zi, newTileEntityF);
            }

            worldF.setBlock(xf, yf, zf, blockI, metaI, 3);
            if(tileEntityI1 != null) {
               newTileEntityF = TileEntity.createAndLoadEntity(nbttag1);
               if(AlchemicalWizardry.isFMPLoaded && isMultipart(tileEntityI1)) {
                  newTileEntityF = createMultipartFromNBT(worldF, nbttag1);
               }

               worldF.setTileEntity(xf, yf, zf, newTileEntityF);
               newTileEntityF.xCoord = xf;
               newTileEntityF.yCoord = yf;
               newTileEntityF.zCoord = zf;
               if(AlchemicalWizardry.isFMPLoaded && isMultipart(tileEntityI1)) {
                  sendDescriptorOfTile(worldF, newTileEntityF);
               }
            }

            worldI.setBlock(xi, yi, zi, blockF, metaF, 3);
            if(tileEntityF != null) {
               newTileEntityF = TileEntity.createAndLoadEntity(nbttag2);
               if(AlchemicalWizardry.isFMPLoaded && isMultipart(tileEntityF)) {
                  newTileEntityF = createMultipartFromNBT(worldI, nbttag2);
               }

               worldI.setTileEntity(xi, yi, zi, newTileEntityF);
               newTileEntityF.xCoord = xi;
               newTileEntityF.yCoord = yi;
               newTileEntityF.zCoord = zi;
               if(AlchemicalWizardry.isFMPLoaded && isMultipart(tileEntityF)) {
                  sendDescriptorOfTile(worldI, newTileEntityF);
               }
            }

            return true;
         }
      }
   }

   @Method(
      modid = "ForgeMultipart"
   )
   public static boolean isMultipart(TileEntity tile) {
      return tile instanceof TileMultipart;
   }

   @Method(
      modid = "ForgeMultipart"
   )
   public static TileEntity createMultipartFromNBT(World world, NBTTagCompound tag) {
      return MultipartHelper.createTileFromNBT(world, tag);
   }

   @Method(
      modid = "ForgeMultipart"
   )
   public static void sendDescriptorOfTile(World world, TileEntity tile) {
      MultipartHelper.sendDescPacket(world, (TileMultipart)tile);
   }
}
