package WayofTime.alchemicalWizardry.common.block;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.common.items.BlankSpell;
import WayofTime.alchemicalWizardry.common.tileEntity.TEHomHeart;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;

public class BlockHomHeart extends BlockContainer {

   public IIcon bottomIcon;
   public IIcon topIcon;
   public IIcon sideIcon;


   public BlockHomHeart() {
      super(Material.rock);
      this.setHardness(2.0F);
      this.setResistance(5.0F);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      this.setBlockName("blockHomHeart");
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister iconRegister) {
      this.topIcon = iconRegister.registerIcon("AlchemicalWizardry:HomHeart_top");
      this.bottomIcon = iconRegister.registerIcon("AlchemicalWizardry:HomHeart_bottom");
      this.sideIcon = iconRegister.registerIcon("AlchemicalWizardry:HomHeart_side");
   }

   @SideOnly(Side.CLIENT)
   public IIcon getIcon(int side, int meta) {
      switch(side) {
      case 0:
         return this.bottomIcon;
      case 1:
         return this.topIcon;
      default:
         return this.sideIcon;
      }
   }

   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int idk, float what, float these, float are) {
      TEHomHeart tileEntity = (TEHomHeart)world.getTileEntity(x, y, z);
      if(tileEntity != null && !player.isSneaking()) {
         ItemStack playerItem = player.getCurrentEquippedItem();
         if(playerItem != null && playerItem.getItem() instanceof BlankSpell) {
            if(playerItem.getTagCompound() == null) {
               playerItem.setTagCompound(new NBTTagCompound());
            }

            NBTTagCompound itemTag = playerItem.getTagCompound();
            itemTag.setInteger("xCoord", x);
            itemTag.setInteger("yCoord", y);
            itemTag.setInteger("zCoord", z);
            itemTag.setInteger("dimensionId", world.provider.dimensionId);
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public TileEntity createNewTileEntity(World world, int metaMaybe) {
      return new TEHomHeart();
   }
}
