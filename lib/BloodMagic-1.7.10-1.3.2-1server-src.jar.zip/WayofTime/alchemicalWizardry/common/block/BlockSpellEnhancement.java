package WayofTime.alchemicalWizardry.common.block;

import WayofTime.alchemicalWizardry.ModBlocks;
import WayofTime.alchemicalWizardry.common.block.BlockOrientable;
import WayofTime.alchemicalWizardry.common.tileEntity.TESpellEnhancementBlock;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public class BlockSpellEnhancement extends BlockOrientable {

   public BlockSpellEnhancement() {
      this.setBlockName("blockSpellEnhancement");
   }

   public TileEntity createNewTileEntity(World world, int meta) {
      return new TESpellEnhancementBlock();
   }

   public boolean renderAsNormalBlock() {
      return false;
   }

   public int getRenderType() {
      return -1;
   }

   public boolean isOpaqueCube() {
      return false;
   }

   @SideOnly(Side.CLIENT)
   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      if(this.equals(ModBlocks.blockSpellEnhancement)) {
         for(int i = 0; i < 15; ++i) {
            par3List.add(new ItemStack(par1, 1, i));
         }
      } else {
         super.getSubBlocks(par1, par2CreativeTabs, par3List);
      }

   }
}
