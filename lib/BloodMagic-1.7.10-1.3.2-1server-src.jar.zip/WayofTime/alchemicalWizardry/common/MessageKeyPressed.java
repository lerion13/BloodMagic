package WayofTime.alchemicalWizardry.common;

import WayofTime.alchemicalWizardry.common.items.armour.OmegaArmour;
import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;

public class MessageKeyPressed implements IMessage, IMessageHandler {

   private byte keyPressed;


   public MessageKeyPressed() {}

   public MessageKeyPressed(MessageKeyPressed.Key key) {
      if(key == MessageKeyPressed.Key.OMEGA_ACTIVE) {
         this.keyPressed = (byte)MessageKeyPressed.Key.OMEGA_ACTIVE.ordinal();
      }

   }

   public void fromBytes(ByteBuf buf) {
      this.keyPressed = buf.readByte();
   }

   public void toBytes(ByteBuf buf) {
      buf.writeByte(this.keyPressed);
   }

   public IMessage onMessage(MessageKeyPressed message, MessageContext ctx) {
      EntityPlayerMP entityPlayer = ctx.getServerHandler().playerEntity;
      if(message.keyPressed == MessageKeyPressed.Key.OMEGA_ACTIVE.ordinal() && entityPlayer != null) {
         ItemStack[] armourInventory = entityPlayer.inventory.armorInventory;
         if(armourInventory[2] != null) {
            ItemStack chestStack = armourInventory[2];
            if(chestStack.getItem() instanceof OmegaArmour) {
               ((OmegaArmour)chestStack.getItem()).onOmegaKeyPressed(entityPlayer, chestStack);
            }
         }
      }

      return null;
   }

   public static enum Key {

      OMEGA_ACTIVE("OMEGA_ACTIVE", 0);
      // $FF: synthetic field
      private static final MessageKeyPressed.Key[] $VALUES = new MessageKeyPressed.Key[]{OMEGA_ACTIVE};


      private Key(String var1, int var2) {}

   }
}
