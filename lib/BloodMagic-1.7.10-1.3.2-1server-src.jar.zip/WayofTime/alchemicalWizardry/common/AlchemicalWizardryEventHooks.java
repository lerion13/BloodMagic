package WayofTime.alchemicalWizardry.common;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.BloodMagicConfiguration;
import WayofTime.alchemicalWizardry.api.alchemy.energy.Reagent;
import WayofTime.alchemicalWizardry.api.event.TeleposeEvent;
import WayofTime.alchemicalWizardry.api.soulNetwork.SoulNetworkHandler;
import WayofTime.alchemicalWizardry.api.spell.APISpellHelper;
import WayofTime.alchemicalWizardry.common.CoordAndRange;
import WayofTime.alchemicalWizardry.common.NewPacketHandler;
import WayofTime.alchemicalWizardry.common.entity.projectile.EnergyBlastProjectile;
import WayofTime.alchemicalWizardry.common.items.EnergySword;
import WayofTime.alchemicalWizardry.common.items.armour.BoundArmour;
import WayofTime.alchemicalWizardry.common.items.armour.OmegaArmour;
import WayofTime.alchemicalWizardry.common.omega.OmegaParadigm;
import WayofTime.alchemicalWizardry.common.omega.OmegaRegistry;
import WayofTime.alchemicalWizardry.common.omega.ReagentRegenConfiguration;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import WayofTime.alchemicalWizardry.common.tileEntity.TEMasterStone;
import cpw.mods.fml.client.event.ConfigChangedEvent.OnConfigChangedEvent;
import cpw.mods.fml.common.ObfuscationReflectionHelper;
import cpw.mods.fml.common.Optional.Method;
import cpw.mods.fml.common.eventhandler.EventPriority;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.eventhandler.Event.Result;
import cpw.mods.fml.common.gameevent.PlayerEvent.PlayerRespawnEvent;
import cpw.mods.fml.common.registry.GameRegistry;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IProjectile;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Vec3;
import net.minecraftforge.common.ISpecialArmor.ArmorProperties;
import net.minecraftforge.event.AnvilUpdateEvent;
import net.minecraftforge.event.entity.living.EnderTeleportEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingEvent.LivingJumpEvent;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.event.entity.living.LivingSpawnEvent.CheckSpawn;
import net.minecraftforge.event.entity.player.EntityInteractEvent;
import vazkii.botania.api.internal.IManaBurst;

public class AlchemicalWizardryEventHooks {

   public static Map playerFlightBuff = new HashMap();
   public static Map playerBoostStepHeight = new HashMap();
   public static List playersWith1Step = new ArrayList();
   public static Map respawnMap = new HashMap();
   public static Map forceSpawnMap = new HashMap();
   public static Random rand = new Random();


   @SubscribeEvent
   public void onEntityInteractEvent(EntityInteractEvent event) {
      EntityPlayer player = event.entityPlayer;
      OmegaParadigm parad = OmegaRegistry.getOmegaParadigmOfWeilder(player);
      if(parad != null) {
         ItemStack heldItem = player.getHeldItem();
         if(heldItem == null) {
            parad.onEmptyHandEntityInteract(player, event.target);
         } else if(heldItem.getItem() instanceof EnergySword) {
            parad.onBoundSwordInteractWithEntity(player, event.target);
         }

      }
   }

   @SubscribeEvent
   public void onAnvilUpdateEvent(AnvilUpdateEvent event) {
      if(event.isCancelable() && event.left != null && event.right != null && (event.left.getItem() instanceof BoundArmour || event.right.getItem() instanceof BoundArmour)) {
         event.setCanceled(true);
      }

   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public void onLivingHurtEvent(LivingHurtEvent event) {
      if(!event.isCanceled() && event.entityLiving instanceof EntityPlayer && !event.entityLiving.worldObj.isRemote) {
         EntityPlayer player = (EntityPlayer)event.entityLiving;
         if(APISpellHelper.getCurrentAdditionalMaxHP(player) > 0.0F) {
            APISpellHelper.setPlayerReagentRegenCooldownTag(player, 400);
         }

         float prevHp = APISpellHelper.getCurrentAdditionalHP((EntityPlayer)event.entityLiving);
         if(prevHp > 0.0F) {
            double originalDamage = (double)event.ammount;
            double initialReagentHp = (double)prevHp;
            float recalculatedAmount = ArmorProperties.ApplyArmor(player, player.inventory.armorInventory, event.source, (double)event.ammount);
            if(recalculatedAmount <= 0.0F) {
               return;
            }

            recalculatedAmount = SpellHelper.applyPotionDamageCalculations(player, event.source, recalculatedAmount);
            float ratio = recalculatedAmount / event.ammount;
            float f1 = recalculatedAmount;
            recalculatedAmount = Math.max(recalculatedAmount - player.getAbsorptionAmount(), 0.0F);
            player.setAbsorptionAmount(player.getAbsorptionAmount() - (f1 - recalculatedAmount));
            if(prevHp > recalculatedAmount) {
               float hp = prevHp - recalculatedAmount;
               event.ammount = 0.0F;
               Reagent reagent = APISpellHelper.getPlayerReagentType(player);
               OmegaParadigm paradigm = OmegaRegistry.getParadigmForReagent(reagent);
               if(paradigm != null) {
                  ItemStack chestStack = player.inventory.armorInventory[2];
                  if(chestStack != null && chestStack.getItem() instanceof OmegaArmour && ((OmegaArmour)chestStack.getItem()).paradigm == paradigm) {
                     paradigm.onHPBarDepleted(player, chestStack);
                  }
               }

               APISpellHelper.setCurrentAdditionalHP(player, hp);
               NewPacketHandler.INSTANCE.sendTo(NewPacketHandler.getAddedHPPacket(hp, APISpellHelper.getCurrentAdditionalMaxHP(player)), (EntityPlayerMP)player);
            } else {
               APISpellHelper.setCurrentAdditionalHP(player, 0.0F);
               NewPacketHandler.INSTANCE.sendTo(NewPacketHandler.getAddedHPPacket(0.0F, APISpellHelper.getCurrentAdditionalMaxHP(player)), (EntityPlayerMP)player);
               event.ammount -= prevHp / ratio;
               if(event.ammount < 0.0F) {
                  event.ammount = 0.0F;
               }
            }
         }
      }

   }

   @SubscribeEvent
   public void omegaUpdateReagentAndHpEvent(LivingUpdateEvent event) {
      if(event.entityLiving instanceof EntityPlayer && !event.entityLiving.worldObj.isRemote) {
         EntityPlayer player = (EntityPlayer)event.entityLiving;
         Reagent reagent = APISpellHelper.getPlayerReagentType(player);
         float reagentAmount = APISpellHelper.getPlayerCurrentReagentAmount(player);
         boolean hasReagentChanged = false;
         int len$;
         int i$;
         if(reagentAmount > 0.0F && OmegaRegistry.hasParadigm(reagent)) {
            int hasRevertedArmour = APISpellHelper.getPlayerReagentRegenCooldownTag(player);
            boolean armourInventory = true;
            if(hasRevertedArmour > 0) {
               float arr$ = 0.0F;
               if(player.isPotionActive(AlchemicalWizardry.customPotionSoulHarden)) {
                  arr$ += 0.25F * (float)(1 + player.getActivePotionEffect(AlchemicalWizardry.customPotionSoulHarden).getAmplifier());
               }

               if(player.isPotionActive(AlchemicalWizardry.customPotionSoulFray)) {
                  arr$ -= 0.25F * (float)(1 + player.getActivePotionEffect(AlchemicalWizardry.customPotionSoulFray).getAmplifier());
               }

               len$ = -1 - (arr$ >= 0.0F?(rand.nextFloat() < arr$?1:0):(rand.nextFloat() < -arr$ / 2.0F?-1:0));
               APISpellHelper.setPlayerReagentRegenCooldownTag(player, Math.max(hasRevertedArmour + len$, 0));
               armourInventory = false;
            }

            OmegaParadigm var20 = OmegaRegistry.getParadigmForReagent(reagent);
            ReagentRegenConfiguration var18 = var20.getRegenConfig(player);
            if(var20.isPlayerWearingFullSet(player)) {
               if(armourInventory) {
                  i$ = var18.tickRate;
                  if(player.isPotionActive(Potion.regeneration)) {
                     int stack = player.getActivePotionEffect(Potion.regeneration).getAmplifier();
                     double maxHealth = Math.pow(1.5D, (double)(stack + 1));
                     i$ = Math.max((int)((double)i$ / maxHealth), 1);
                  }

                  if(event.entityLiving.worldObj.getWorldTime() % (long)i$ == 0L) {
                     boolean var22 = false;
                     int var23 = var20.getMaxAdditionalHealth();
                     float health = APISpellHelper.getCurrentAdditionalHP(player);
                     if(health > (float)var23) {
                        health = (float)var23;
                        var22 = true;
                     } else if(health < (float)var23) {
                        float addedAmount = Math.min(Math.min(reagentAmount / var18.costPerPoint, (float)var18.healPerTick), (float)var23 - health);
                        float drain = addedAmount * var18.costPerPoint;
                        reagentAmount -= drain;
                        hasReagentChanged = true;
                        health += addedAmount;
                        var22 = true;
                     }

                     if(player instanceof EntityPlayerMP && var22) {
                        APISpellHelper.setCurrentAdditionalHP(player, health);
                        NewPacketHandler.INSTANCE.sendTo(NewPacketHandler.getAddedHPPacket(health, (float)var23), (EntityPlayerMP)player);
                     }
                  }
               }
            } else {
               reagentAmount = 0.0F;
               APISpellHelper.setPlayerMaxReagentAmount(player, 0.0F);
               NewPacketHandler.INSTANCE.sendTo(NewPacketHandler.getReagentBarPacket((Reagent)null, 0.0F, 0.0F), (EntityPlayerMP)player);
               APISpellHelper.setCurrentAdditionalHP(player, 0.0F);
               NewPacketHandler.INSTANCE.sendTo(NewPacketHandler.getAddedHPPacket(0.0F, 0.0F), (EntityPlayerMP)player);
            }

            float var21 = var20.getCostPerTickOfUse(player);
            if(var20.doDrainReagent(player)) {
               if(reagentAmount > var21) {
                  hasReagentChanged = true;
                  reagentAmount = Math.max(0.0F, reagentAmount - var21);
               } else {
                  hasReagentChanged = true;
                  reagentAmount = 0.0F;
               }
            }

            hasReagentChanged = true;
         }

         if(reagentAmount <= 0.0F) {
            boolean var16 = false;
            ItemStack[] var17 = player.inventory.armorInventory;
            ItemStack[] var19 = var17;
            len$ = var17.length;

            for(i$ = 0; i$ < len$; ++i$) {
               ItemStack var24 = var19[i$];
               if(var24 != null && var24.getItem() instanceof OmegaArmour) {
                  ((OmegaArmour)var24.getItem()).revertArmour(player, var24);
                  var16 = true;
               }
            }

            if(var16) {
               APISpellHelper.setCurrentAdditionalHP(player, 0.0F);
               NewPacketHandler.INSTANCE.sendTo(NewPacketHandler.getAddedHPPacket(0.0F, 0.0F), (EntityPlayerMP)player);
            }
         }

         if(player instanceof EntityPlayerMP && hasReagentChanged) {
            APISpellHelper.setPlayerCurrentReagentAmount(player, reagentAmount);
            NewPacketHandler.INSTANCE.sendTo(NewPacketHandler.getReagentBarPacket(reagent, reagentAmount, APISpellHelper.getPlayerMaxReagentAmount(player)), (EntityPlayerMP)player);
         }
      }

   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerDamageEvent(LivingAttackEvent event) {
      if(event.source.isProjectile() && event.entityLiving.isPotionActive(AlchemicalWizardry.customPotionProjProt) && event.isCancelable()) {
         event.setCanceled(true);
      }

   }

   @SubscribeEvent
   public void onLivingSpawnEvent(CheckSpawn event) {
      if(event.entityLiving instanceof EntityMob) {
         String respawnRitual = "AW028SpawnWard";
         Integer dimension = new Integer(event.world.provider.dimensionId);
         if(respawnMap.containsKey(dimension)) {
            List forceSpawnRitual = (List)respawnMap.get(dimension);
            if(forceSpawnRitual != null) {
               Iterator list = forceSpawnRitual.iterator();

               label101:
               while(list.hasNext()) {
                  CoordAndRange i$ = (CoordAndRange)list.next();
                  TileEntity coords = event.world.getTileEntity(i$.xCoord, i$.yCoord, i$.zCoord);
                  if(coords instanceof TEMasterStone && ((TEMasterStone)coords).isRunning && ((TEMasterStone)coords).getCurrentRitual().equals(respawnRitual)) {
                     if(event.x > (float)(i$.xCoord - i$.horizRadius) && event.x < (float)(i$.xCoord + i$.horizRadius) && event.z > (float)(i$.zCoord - i$.horizRadius) && event.z < (float)(i$.zCoord + i$.horizRadius) && event.y > (float)(i$.yCoord - i$.vertRadius) && event.y < (float)(i$.yCoord + i$.vertRadius)) {
                        switch(AlchemicalWizardryEventHooks.NamelessClass1264855823.$SwitchMap$cpw$mods$fml$common$eventhandler$Event$Result[event.getResult().ordinal()]) {
                        case 1:
                           event.setResult(Result.DEFAULT);
                           break label101;
                        case 2:
                           event.setResult(Result.DENY);
                        case 3:
                        default:
                           break label101;
                        }
                     }
                  } else {
                     forceSpawnRitual.remove(i$);
                  }
               }
            }
         }

         if(!(event.entityLiving instanceof EntityCreeper)) {
            String forceSpawnRitual1 = "AW029VeilOfEvil";
            if(forceSpawnMap.containsKey(dimension)) {
               List list1 = (List)forceSpawnMap.get(dimension);
               if(list1 != null) {
                  Iterator i$1 = list1.iterator();

                  while(i$1.hasNext()) {
                     CoordAndRange coords1 = (CoordAndRange)i$1.next();
                     TileEntity tile = event.world.getTileEntity(coords1.xCoord, coords1.yCoord, coords1.zCoord);
                     if(tile instanceof TEMasterStone && ((TEMasterStone)tile).isRunning && ((TEMasterStone)tile).getCurrentRitual().equals(forceSpawnRitual1)) {
                        if(event.x > (float)(coords1.xCoord - coords1.horizRadius) && event.x < (float)(coords1.xCoord + coords1.horizRadius) && event.z > (float)(coords1.zCoord - coords1.horizRadius) && event.z < (float)(coords1.zCoord + coords1.horizRadius) && event.y > (float)(coords1.yCoord - coords1.vertRadius) && event.y < (float)(coords1.yCoord + coords1.vertRadius)) {
                           switch(AlchemicalWizardryEventHooks.NamelessClass1264855823.$SwitchMap$cpw$mods$fml$common$eventhandler$Event$Result[event.getResult().ordinal()]) {
                           case 1:
                           default:
                              return;
                           case 2:
                              event.setResult(Result.ALLOW);
                              return;
                           case 3:
                              event.setResult(Result.DEFAULT);
                              return;
                           }
                        }
                     } else {
                        list1.remove(coords1);
                     }
                  }
               }
            }

         }
      }
   }

   @SubscribeEvent
   public void onPlayerRespawnEvent(PlayerRespawnEvent event) {
      if(AlchemicalWizardry.respawnWithDebuff && event.player != null) {
         event.player.addPotionEffect(new PotionEffect(AlchemicalWizardry.customPotionSoulFray.id, 6000, 0));
      }

   }

   @SubscribeEvent
   public void onLivingJumpEvent(LivingJumpEvent event) {
      if(event.entityLiving.isPotionActive(AlchemicalWizardry.customPotionBoost)) {
         int i = event.entityLiving.getActivePotionEffect(AlchemicalWizardry.customPotionBoost).getAmplifier();
         event.entityLiving.motionY += (double)(0.1F * (float)(2 + i));
      }

      if(event.entityLiving.isPotionActive(AlchemicalWizardry.customPotionHeavyHeart)) {
         event.entityLiving.motionY = 0.0D;
      }

   }

   @SubscribeEvent
   public void onEndermanTeleportEvent(EnderTeleportEvent event) {
      if(event.entityLiving.isPotionActive(AlchemicalWizardry.customPotionPlanarBinding) && event.isCancelable()) {
         event.setCanceled(true);
      }

   }

   @SubscribeEvent
   public void onEntityDamaged(LivingAttackEvent event) {
      EntityLivingBase entityAttacked = event.entityLiving;
      if(entityAttacked.isPotionActive(AlchemicalWizardry.customPotionReciprocation)) {
         Entity i = event.source.getSourceOfDamage();
         if(i != null && i instanceof EntityLivingBase) {
            int entityAttacking = event.entityLiving.getActivePotionEffect(AlchemicalWizardry.customPotionReciprocation).getAmplifier();
            float damageRecieve = event.ammount / 2.0F * (float)(entityAttacking + 1);
            ((EntityLivingBase)i).attackEntityFrom(DamageSource.generic, damageRecieve);
         }
      }

      if(entityAttacked.isPotionActive(AlchemicalWizardry.customPotionFlameCloak)) {
         int i1 = event.entityLiving.getActivePotionEffect(AlchemicalWizardry.customPotionFlameCloak).getAmplifier();
         Entity entityAttacking1 = event.source.getSourceOfDamage();
         if(entityAttacking1 != null && entityAttacking1 instanceof EntityLivingBase && !entityAttacking1.isImmuneToFire() && !((EntityLivingBase)entityAttacking1).isPotionActive(Potion.fireResistance)) {
            entityAttacking1.attackEntityFrom(DamageSource.inFire, (float)(2 * i1 + 2));
            entityAttacking1.setFire(3);
         }
      }

   }

   @SubscribeEvent
   public void onEntityUpdate(LivingUpdateEvent event) {
      EntityLivingBase entityLiving = event.entityLiving;
      double x = entityLiving.posX;
      double y = entityLiving.posY;
      double z = entityLiving.posZ;
      Vec3 blockVector = SpellHelper.getEntityBlockVector(entityLiving);
      int xPos = (int)blockVector.xCoord;
      int yPos = (int)blockVector.yCoord;
      int zPos = (int)blockVector.zCoord;
      if(entityLiving instanceof EntityPlayer) {
         if(!entityLiving.worldObj.isRemote && entityLiving.worldObj.getTotalWorldTime() % 20L == 0L && entityLiving instanceof EntityPlayerMP) {
            String r = SoulNetworkHandler.getUsername((EntityPlayer)entityLiving);
            NewPacketHandler.INSTANCE.sendTo(NewPacketHandler.getLPPacket(SoulNetworkHandler.getCurrentEssence(r), SoulNetworkHandler.getMaximumForOrbTier(SoulNetworkHandler.getCurrentMaxOrb(r))), (EntityPlayerMP)entityLiving);
         }

         ObfuscationReflectionHelper.setPrivateValue(PlayerCapabilities.class, ((EntityPlayer)event.entityLiving).capabilities, Float.valueOf(0.1F), new String[]{"walkSpeed", "g", "field_75097_g"});
      }

      EntityPlayer var38;
      if(entityLiving instanceof EntityPlayer && entityLiving.worldObj.isRemote) {
         var38 = (EntityPlayer)entityLiving;
         boolean radius = playersWith1Step.contains(var38.getDisplayName());
         boolean vertRange = var38.isPotionActive(AlchemicalWizardry.customPotionBoost);
         if(vertRange && !radius) {
            playersWith1Step.add(SpellHelper.getUsername(var38));
         }

         if(!vertRange && radius) {
            playersWith1Step.remove(SpellHelper.getUsername(var38));
            var38.stepHeight = 0.5F;
         }
      }

      if(event.entityLiving.isPotionActive(AlchemicalWizardry.customPotionFeatherFall)) {
         event.entityLiving.fallDistance = 0.0F;
      }

      int var37;
      if(event.entityLiving.isPotionActive(AlchemicalWizardry.customPotionDrowning) && !event.entityLiving.isPotionActive(Potion.waterBreathing)) {
         var37 = event.entityLiving.getActivePotionEffect(AlchemicalWizardry.customPotionDrowning).getAmplifier();
         if(event.entityLiving.worldObj.getWorldTime() % (long)(20 / (var37 + 1)) == 0L) {
            event.entityLiving.attackEntityFrom(DamageSource.drown, 2.0F);
            event.entityLiving.hurtResistantTime = Math.min(event.entityLiving.hurtResistantTime, 20 / (var37 + 1));
         }
      }

      EntityLivingBase var41;
      if(event.entityLiving.isPotionActive(AlchemicalWizardry.customPotionBoost)) {
         var37 = event.entityLiving.getActivePotionEffect(AlchemicalWizardry.customPotionBoost).getAmplifier();
         var41 = event.entityLiving;
         float var40 = (float)(var37 + 1) * 0.05F;
         if(event.entityLiving instanceof EntityPlayer) {
            EntityPlayer i = (EntityPlayer)event.entityLiving;
            i.stepHeight = 1.0F;
            if((i.onGround || i.capabilities.isFlying) && i.moveForward > 0.0F) {
               i.moveFlying(0.0F, 1.0F, i.capabilities.isFlying?var40 / 2.0F:var40);
            }
         }
      }

      int k;
      int j;
      int var43;
      if(event.entityLiving.isPotionActive(AlchemicalWizardry.customPotionProjProt)) {
         var37 = event.entityLiving.getActivePotionEffect(AlchemicalWizardry.customPotionProjProt).getAmplifier();
         var41 = event.entityLiving;
         int var47 = (int)Math.round(var41.posX - 0.5D);
         var43 = (int)Math.round(var41.posY);
         k = (int)Math.round(var41.posZ - 0.5D);
         j = (int)((double)(var37 + 1) * 2.5D);
         AxisAlignedBB axisalignedbb = AxisAlignedBB.getBoundingBox((double)var47 - 0.5D, (double)var43 - 0.5D, (double)k - 0.5D, (double)var47 + 0.5D, (double)var43 + 0.5D, (double)k + 0.5D).expand((double)j, (double)j, (double)j);
         List list = event.entityLiving.worldObj.getEntitiesWithinAABB(Entity.class, axisalignedbb);
         Iterator iterator = list.iterator();

         while(iterator.hasNext()) {
            Entity projectile = (Entity)iterator.next();
            if(projectile != null && projectile instanceof IProjectile && (!AlchemicalWizardry.isBotaniaLoaded || !this.isManaBurst(projectile))) {
               Object throwingEntity = null;
               if(projectile instanceof EntityArrow) {
                  throwingEntity = ((EntityArrow)projectile).shootingEntity;
               } else if(projectile instanceof EnergyBlastProjectile) {
                  throwingEntity = ((EnergyBlastProjectile)projectile).shootingEntity;
               } else if(projectile instanceof EntityThrowable) {
                  throwingEntity = ((EntityThrowable)projectile).getThrower();
               }

               if(throwingEntity == null || !((Entity)throwingEntity).equals(var41)) {
                  double delX = projectile.posX - var41.posX;
                  double delY = projectile.posY - var41.posY;
                  double delZ = projectile.posZ - var41.posZ;
                  double angle = (delX * projectile.motionX + delY * projectile.motionY + delZ * projectile.motionZ) / (Math.sqrt(delX * delX + delY * delY + delZ * delZ) * Math.sqrt(projectile.motionX * projectile.motionX + projectile.motionY * projectile.motionY + projectile.motionZ * projectile.motionZ));
                  angle = Math.acos(angle);
                  if(angle >= 2.356194490192345D) {
                     if(throwingEntity != null) {
                        delX = -projectile.posX + ((Entity)throwingEntity).posX;
                        delY = -projectile.posY + ((Entity)throwingEntity).posY + (double)((Entity)throwingEntity).getEyeHeight();
                        delZ = -projectile.posZ + ((Entity)throwingEntity).posZ;
                     }

                     double curVel = Math.sqrt(delX * delX + delY * delY + delZ * delZ);
                     delX /= curVel;
                     delY /= curVel;
                     delZ /= curVel;
                     double newVel = Math.sqrt(projectile.motionX * projectile.motionX + projectile.motionY * projectile.motionY + projectile.motionZ * projectile.motionZ);
                     projectile.motionX = newVel * delX;
                     projectile.motionY = newVel * delY;
                     projectile.motionZ = newVel * delZ;
                  }
               }
            }
         }
      }

      String var39;
      if(event.entityLiving.isPotionActive(AlchemicalWizardry.customPotionFlight)) {
         if(event.entityLiving instanceof EntityPlayer) {
            var38 = (EntityPlayer)event.entityLiving;
            var39 = SpellHelper.getUsername(var38);
            playerFlightBuff.put(var39, Boolean.valueOf(true));
            var38.capabilities.allowFlying = true;
         }
      } else if(event.entityLiving instanceof EntityPlayer) {
         var38 = (EntityPlayer)event.entityLiving;
         var39 = SpellHelper.getUsername(var38);
         if(!playerFlightBuff.containsKey(var39)) {
            playerFlightBuff.put(var39, Boolean.valueOf(false));
         }

         if(((Boolean)playerFlightBuff.get(var39)).booleanValue()) {
            playerFlightBuff.put(var39, Boolean.valueOf(false));
            if(!var38.capabilities.isCreativeMode) {
               var38.capabilities.allowFlying = false;
               var38.capabilities.isFlying = false;
               var38.sendPlayerAbilities();
            }
         }
      }

      double var46;
      if(entityLiving.isPotionActive(AlchemicalWizardry.customPotionFlameCloak)) {
         entityLiving.worldObj.spawnParticle("flame", x + SpellHelper.gaussian(1.0D), y - 1.3D + SpellHelper.gaussian(0.3D), z + SpellHelper.gaussian(1.0D), 0.0D, 0.06D, 0.0D);
         var37 = event.entityLiving.getActivePotionEffect(AlchemicalWizardry.customPotionFlameCloak).getAmplifier();
         var46 = (double)var37 * 0.5D;
         List var42 = SpellHelper.getEntitiesInRange(entityLiving.worldObj, x, y, z, var46, var46);
         if(var42 != null) {
            Iterator var48 = var42.iterator();

            while(var48.hasNext()) {
               Entity var49 = (Entity)var48.next();
               if(!var49.equals(entityLiving) && !var49.isImmuneToFire() && (!(var49 instanceof EntityLivingBase) || !((EntityLivingBase)var49).isPotionActive(Potion.fireResistance))) {
                  var49.setFire(3);
               }
            }
         }
      }

      int var44;
      if(entityLiving.isPotionActive(AlchemicalWizardry.customPotionIceCloak)) {
         if(entityLiving.worldObj.getWorldTime() % 2L == 0L) {
            entityLiving.worldObj.spawnParticle("reddust", x + SpellHelper.gaussian(1.0D), y - 1.3D + SpellHelper.gaussian(0.3D), z + SpellHelper.gaussian(1.0D), 116.0D, 187.0D, 251.0D);
         }

         var37 = event.entityLiving.getActivePotionEffect(AlchemicalWizardry.customPotionIceCloak).getAmplifier();
         var44 = var37 + 1;
         byte var45 = 1;
         if(!entityLiving.worldObj.isRemote) {
            for(var43 = -var44; var43 <= var44; ++var43) {
               for(k = -var44; k <= var44; ++k) {
                  for(j = -var45 - 1; j <= var45 - 1; ++j) {
                     SpellHelper.freezeWaterBlock(entityLiving.worldObj, xPos + var43, yPos + j, zPos + k);
                  }
               }
            }
         }
      }

      if(entityLiving.isPotionActive(AlchemicalWizardry.customPotionHeavyHeart)) {
         entityLiving.worldObj.spawnParticle("flame", x + SpellHelper.gaussian(1.0D), y - 1.3D + SpellHelper.gaussian(0.3D), z + SpellHelper.gaussian(1.0D), 0.0D, 0.06D, 0.0D);
         var37 = event.entityLiving.getActivePotionEffect(AlchemicalWizardry.customPotionHeavyHeart).getAmplifier();
         var46 = 0.025D * (double)(var37 + 1);
         if(entityLiving.motionY > -0.9D) {
            entityLiving.motionY -= var46;
         }

         if(entityLiving instanceof EntityPlayer) {
            SpellHelper.setPlayerSpeedFromServer((EntityPlayer)entityLiving, entityLiving.motionX, entityLiving.motionY - var46, entityLiving.motionZ);
         }
      }

      if(entityLiving.isPotionActive(AlchemicalWizardry.customPotionFireFuse)) {
         entityLiving.worldObj.spawnParticle("flame", x + SpellHelper.gaussian(1.0D), y - 1.3D + SpellHelper.gaussian(0.3D), z + SpellHelper.gaussian(1.0D), 0.0D, 0.06D, 0.0D);
         var37 = event.entityLiving.getActivePotionEffect(AlchemicalWizardry.customPotionFireFuse).getAmplifier();
         var44 = var37 + 1;
         if(entityLiving.getActivePotionEffect(AlchemicalWizardry.customPotionFireFuse).getDuration() <= 2) {
            entityLiving.worldObj.createExplosion((Entity)null, x, y, z, (float)var44, false);
         }
      }

   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public void onTelepose(TeleposeEvent event) {
      for(int i = 0; i < BloodMagicConfiguration.teleposerBlacklist.length; ++i) {
         String[] blockData = BloodMagicConfiguration.teleposerBlacklist[i].split(":");
         Block block;
         if(blockData.length == 3) {
            block = GameRegistry.findBlock(blockData[0], blockData[1]);
            int meta;
            if(blockData[2].matches("-?\\d+")) {
               meta = Integer.parseInt(blockData[2]);
            } else if(blockData[2].equals("*")) {
               meta = 32767;
            } else {
               meta = 0;
            }

            if(block != null && (block == event.initialBlock || block == event.finalBlock) && (meta == event.initialMetadata || meta == event.finalMetadata || meta == 32767)) {
               event.setCanceled(true);
            }
         } else if(blockData.length == 2) {
            block = GameRegistry.findBlock(blockData[0], blockData[1]);
            byte var6 = 0;
            if(block != null && (block == event.initialBlock || block == event.finalBlock) && (var6 == event.initialMetadata || var6 == event.finalMetadata || var6 == 32767)) {
               event.setCanceled(true);
            }
         }
      }

   }

   @SubscribeEvent
   public void onConfigChanged(OnConfigChangedEvent event) {
      if(event.modID.equals("AWWayofTime")) {
         BloodMagicConfiguration.syncConfig();
         AlchemicalWizardry.logger.info("Refreshing configuration file.");
      }

   }

   @Method(
      modid = "Botania"
   )
   private boolean isManaBurst(Entity entity) {
      if(entity instanceof IManaBurst) {
         ItemStack lens = ((IManaBurst)entity).getSourceLens();
         return lens.getItemDamage() == 8 || lens.getItemDamage() == 11;
      } else {
         return false;
      }
   }


   // $FF: synthetic class
   static class NamelessClass1264855823 {

      // $FF: synthetic field
      static final int[] $SwitchMap$cpw$mods$fml$common$eventhandler$Event$Result = new int[Result.values().length];


      static {
         try {
            $SwitchMap$cpw$mods$fml$common$eventhandler$Event$Result[Result.ALLOW.ordinal()] = 1;
         } catch (NoSuchFieldError var3) {
            ;
         }

         try {
            $SwitchMap$cpw$mods$fml$common$eventhandler$Event$Result[Result.DEFAULT.ordinal()] = 2;
         } catch (NoSuchFieldError var2) {
            ;
         }

         try {
            $SwitchMap$cpw$mods$fml$common$eventhandler$Event$Result[Result.DENY.ordinal()] = 3;
         } catch (NoSuchFieldError var1) {
            ;
         }

      }
   }
}
