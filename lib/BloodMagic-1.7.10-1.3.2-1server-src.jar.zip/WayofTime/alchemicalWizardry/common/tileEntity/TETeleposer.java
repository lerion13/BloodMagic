package WayofTime.alchemicalWizardry.common.tileEntity;

import WayofTime.alchemicalWizardry.common.NewPacketHandler;
import WayofTime.alchemicalWizardry.common.block.BlockTeleposer;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import WayofTime.alchemicalWizardry.common.items.TelepositionFocus;
import WayofTime.alchemicalWizardry.common.tileEntity.TEInventory;
import com.gamerforea.bloodmagic.FakePlayerUtils;
import com.google.common.base.Strings;
import com.mojang.authlib.GameProfile;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.Packet;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.World;
import net.minecraftforge.common.util.FakePlayer;

public class TETeleposer extends TEInventory {

   public static final int sizeInv = 1;
   private int resultID = 0;
   private int resultDamage = 0;
   private int previousInput = 0;
   private boolean isActive = false;
   public GameProfile ownerProfile;
   private FakePlayer ownerFake;


   public FakePlayer getOwnerFake() {
      return this.ownerFake != null?this.ownerFake:(this.ownerProfile != null?(this.ownerFake = FakePlayerUtils.createFakePlayer(this.ownerProfile, super.worldObj)):FakePlayerUtils.getPlayer(super.worldObj));
   }

   public TETeleposer() {
      super(1);
   }

   public void readFromNBT(NBTTagCompound par1NBTTagCompound) {
      super.readFromNBT(par1NBTTagCompound);
      this.resultID = par1NBTTagCompound.getInteger("resultID");
      this.resultDamage = par1NBTTagCompound.getInteger("resultDamage");
      this.isActive = par1NBTTagCompound.getBoolean("isActive");
      this.previousInput = par1NBTTagCompound.getInteger("previousInput");
      String uuid = par1NBTTagCompound.getString("ownerUUID");
      String name = par1NBTTagCompound.getString("ownerName");
      if(!Strings.isNullOrEmpty(uuid) && !Strings.isNullOrEmpty(name)) {
         this.ownerProfile = new GameProfile(UUID.fromString(uuid), name);
      }

   }

   public void writeToNBT(NBTTagCompound par1NBTTagCompound) {
      super.writeToNBT(par1NBTTagCompound);
      par1NBTTagCompound.setInteger("resultID", this.resultID);
      par1NBTTagCompound.setInteger("resultDamage", this.resultDamage);
      par1NBTTagCompound.setBoolean("isActive", this.isActive);
      par1NBTTagCompound.setInteger("previousInput", this.previousInput);
      if(this.ownerProfile != null) {
         par1NBTTagCompound.setString("ownerUUID", this.ownerProfile.getId().toString());
         par1NBTTagCompound.setString("ownerName", this.ownerProfile.getName());
      }

   }

   public String getInventoryName() {
      return "TETeleposer";
   }

   public int getInventoryStackLimit() {
      return 1;
   }

   public void updateEntity() {
      super.updateEntity();
      if(!super.worldObj.isRemote) {
         int currentInput = super.worldObj.getBlockPowerInput(super.xCoord, super.yCoord, super.zCoord);
         if(this.previousInput == 0 && currentInput != 0) {
            ItemStack focus = this.getStackInSlot(0);
            if(focus != null && focus.getItem() instanceof TelepositionFocus) {
               TelepositionFocus focusItem = (TelepositionFocus)((TelepositionFocus)focus.getItem());
               int xf = focusItem.xCoord(focus);
               int yf = focusItem.yCoord(focus);
               int zf = focusItem.zCoord(focus);
               World worldF = focusItem.getWorld(focus);
               int damage = (int)(0.5D * Math.sqrt((double)((super.xCoord - xf) * (super.xCoord - xf) + (super.yCoord - yf + 1) * (super.yCoord - yf + 1) + (super.zCoord - zf) * (super.zCoord - zf))));
               int focusLevel = focusItem.getFocusLevel();
               int transportCount = 0;
               int entityCount = 0;
               if(worldF != null && worldF.getTileEntity(xf, yf, zf) instanceof TETeleposer && !worldF.getTileEntity(xf, yf, zf).equals(this)) {
                  int d0 = focusLevel - 1;
                  AxisAlignedBB axisalignedbb1 = AxisAlignedBB.getBoundingBox((double)super.xCoord - 0.5D, (double)super.yCoord + (double)d0 + 0.5D, (double)super.zCoord - 0.5D, (double)super.xCoord + 0.5D, (double)super.yCoord + 1.5D + (double)d0, (double)super.zCoord + 0.5D).expand((double)d0, (double)d0, (double)d0);
                  axisalignedbb1.maxY = Math.min((double)super.worldObj.getHeight(), (double)(super.yCoord + 2 + d0 + d0));
                  List list1 = super.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, axisalignedbb1);

                  Iterator iterator1;
                  EntityLivingBase entityplayer1;
                  for(iterator1 = list1.iterator(); iterator1.hasNext(); ++entityCount) {
                     entityplayer1 = (EntityLivingBase)iterator1.next();
                  }

                  AxisAlignedBB axisalignedbb2 = AxisAlignedBB.getBoundingBox((double)xf - 0.5D, (double)(yf + d0) + 0.5D, (double)zf - 0.5D, (double)xf + 0.5D, (double)yf + 1.5D + (double)d0, (double)zf + 0.5D).expand((double)d0, (double)d0, (double)d0);
                  List list2 = worldF.getEntitiesWithinAABB(EntityLivingBase.class, axisalignedbb2);

                  Iterator iterator2;
                  EntityLivingBase entityplayer2;
                  for(iterator2 = list2.iterator(); iterator2.hasNext(); ++entityCount) {
                     entityplayer2 = (EntityLivingBase)iterator2.next();
                  }

                  if(EnergyItems.canSyphonInContainer(focus, damage * (focusLevel * 2 - 1) * (focusLevel * 2 - 1) * (focusLevel * 2 - 1) + damage * entityCount)) {
                     for(int k = 0; k <= focusLevel * 2 - 2; ++k) {
                        for(int i = -(focusLevel - 1); i <= focusLevel - 1; ++i) {
                           for(int j = -(focusLevel - 1); j <= focusLevel - 1; ++j) {
                              if(BlockTeleposer.swapBlocks(this, super.worldObj, worldF, super.xCoord + i, super.yCoord + 1 + k, super.zCoord + j, xf + i, yf + 1 + k, zf + j)) {
                                 ++transportCount;
                              }
                           }
                        }
                     }

                     if(!worldF.equals(super.worldObj)) {
                        entityCount = 0;
                     }

                     EnergyItems.syphonWhileInContainer(focus, damage * transportCount + damage * entityCount);
                     if(worldF.equals(super.worldObj)) {
                        iterator1 = list1.iterator();
                        iterator2 = list2.iterator();

                        while(iterator1.hasNext()) {
                           entityplayer1 = (EntityLivingBase)iterator1.next();
                           entityplayer1.worldObj = worldF;
                           entityplayer1.setPositionAndUpdate(entityplayer1.posX - (double)super.xCoord + (double)xf, entityplayer1.posY - (double)super.yCoord + (double)yf, entityplayer1.posZ - (double)super.zCoord + (double)zf);
                        }

                        while(iterator2.hasNext()) {
                           entityplayer2 = (EntityLivingBase)iterator2.next();
                           entityplayer2.worldObj = worldF;
                           entityplayer2.setPositionAndUpdate(entityplayer2.posX + (double)super.xCoord - (double)xf, entityplayer2.posY + (double)super.yCoord - (double)yf, entityplayer2.posZ + (double)super.zCoord - (double)zf);
                        }
                     }
                  }
               }
            }
         }

         this.previousInput = currentInput;
      }
   }

   public void setActive() {
      this.isActive = false;
   }

   public boolean isActive() {
      return this.isActive;
   }

   public Packet getDescriptionPacket() {
      return NewPacketHandler.getPacket(this);
   }

   public void handlePacketData(int[] intData) {
      if(intData != null) {
         if(intData.length == 3) {
            for(int i = 0; i < 1; ++i) {
               if(intData[i * 3 + 2] != 0) {
                  ItemStack is = new ItemStack(Item.getItemById(intData[i * 3]), intData[i * 3 + 2], intData[i * 3 + 1]);
                  super.inv[i] = is;
               } else {
                  super.inv[i] = null;
               }
            }
         }

      }
   }

   public int[] buildIntDataList() {
      int[] sortList = new int[3];
      int pos = 0;
      ItemStack[] var3 = super.inv;
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         ItemStack is = var3[var5];
         if(is != null) {
            sortList[pos++] = Item.getIdFromItem(is.getItem());
            sortList[pos++] = is.getItemDamage();
            sortList[pos++] = is.stackSize;
         } else {
            sortList[pos++] = 0;
            sortList[pos++] = 0;
            sortList[pos++] = 0;
         }
      }

      return sortList;
   }

   public boolean isItemValidForSlot(int slot, ItemStack itemstack) {
      return itemstack.getItem() instanceof TelepositionFocus;
   }
}
