package WayofTime.alchemicalWizardry.common.omega;

import WayofTime.alchemicalWizardry.ModBlocks;
import WayofTime.alchemicalWizardry.api.Int3;
import WayofTime.alchemicalWizardry.common.omega.IEnchantmentGlyph;
import WayofTime.alchemicalWizardry.common.omega.IStabilityGlyph;
import WayofTime.alchemicalWizardry.common.omega.OmegaStructureParameters;
import net.minecraft.block.Block;
import net.minecraft.world.World;

public class OmegaStructureHandler {

   public static final OmegaStructureParameters emptyParam = new OmegaStructureParameters(0, 0, 0);


   public static boolean isStructureIntact(World world, int x, int y, int z) {
      return true;
   }

   public static OmegaStructureParameters getStructureStabilityFactor(World world, int x, int y, int z, int expLim, Int3 offset) {
      int range = expLim;
      int[][][] boolList = new int[expLim * 2 + 1][expLim * 2 + 1][expLim * 2 + 1];

      int tally;
      int enchantability;
      for(int isReady = 0; isReady < 2 * range + 1; ++isReady) {
         for(tally = 0; tally < 2 * range + 1; ++tally) {
            for(enchantability = 0; enchantability < 2 * range + 1; ++enchantability) {
               boolList[isReady][tally][enchantability] = 0;
            }
         }
      }

      boolList[range + offset.xCoord][range + offset.yCoord][range + offset.zCoord] = 1;
      boolean var18 = false;

      int enchantmentLevel;
      while(!var18) {
         var18 = true;

         for(tally = 0; tally < 2 * range + 1; ++tally) {
            for(enchantability = 0; enchantability < 2 * range + 1; ++enchantability) {
               for(enchantmentLevel = 0; enchantmentLevel < 2 * range + 1; ++enchantmentLevel) {
                  if(boolList[tally][enchantability][enchantmentLevel] == 1) {
                     Block i;
                     if(tally - 1 >= 0 && boolList[tally - 1][enchantability][enchantmentLevel] != 1 && boolList[tally - 1][enchantability][enchantmentLevel] != -1) {
                        i = world.getBlock(x - range + tally - 1, y - range + enchantability, z - range + enchantmentLevel);
                        if(!world.isAirBlock(x - range + tally - 1, y - range + enchantability, z - range + enchantmentLevel) && i != ModBlocks.blockSpectralContainer) {
                           boolList[tally - 1][enchantability][enchantmentLevel] = -1;
                        } else {
                           if(tally - 1 == 0) {
                              return emptyParam;
                           }

                           boolList[tally - 1][enchantability][enchantmentLevel] = 1;
                           var18 = false;
                        }
                     }

                     if(enchantability - 1 >= 0 && boolList[tally][enchantability - 1][enchantmentLevel] != 1 && boolList[tally][enchantability - 1][enchantmentLevel] != -1) {
                        i = world.getBlock(x - range + tally, y - range + enchantability - 1, z - range + enchantmentLevel);
                        if(!world.isAirBlock(x - range + tally, y - range + enchantability - 1, z - range + enchantmentLevel) && i != ModBlocks.blockSpectralContainer) {
                           boolList[tally][enchantability - 1][enchantmentLevel] = -1;
                        } else {
                           if(enchantability - 1 == 0) {
                              return emptyParam;
                           }

                           boolList[tally][enchantability - 1][enchantmentLevel] = 1;
                           var18 = false;
                        }
                     }

                     if(enchantmentLevel - 1 >= 0 && boolList[tally][enchantability][enchantmentLevel - 1] != 1 && boolList[tally][enchantability][enchantmentLevel - 1] != -1) {
                        i = world.getBlock(x - range + tally, y - range + enchantability, z - range + enchantmentLevel - 1);
                        if(!world.isAirBlock(x - range + tally, y - range + enchantability, z - range + enchantmentLevel - 1) && i != ModBlocks.blockSpectralContainer) {
                           boolList[tally][enchantability][enchantmentLevel - 1] = -1;
                        } else {
                           if(enchantmentLevel - 1 == 0) {
                              return emptyParam;
                           }

                           boolList[tally][enchantability][enchantmentLevel - 1] = 1;
                           var18 = false;
                        }
                     }

                     if(tally + 1 <= 2 * range && boolList[tally + 1][enchantability][enchantmentLevel] != 1 && boolList[tally + 1][enchantability][enchantmentLevel] != -1) {
                        i = world.getBlock(x - range + tally + 1, y - range + enchantability, z - range + enchantmentLevel);
                        if(!world.isAirBlock(x - range + tally + 1, y - range + enchantability, z - range + enchantmentLevel) && i != ModBlocks.blockSpectralContainer) {
                           boolList[tally + 1][enchantability][enchantmentLevel] = -1;
                        } else {
                           if(tally + 1 == range * 2) {
                              return emptyParam;
                           }

                           boolList[tally + 1][enchantability][enchantmentLevel] = 1;
                           var18 = false;
                        }
                     }

                     if(enchantability + 1 <= 2 * range && boolList[tally][enchantability + 1][enchantmentLevel] != 1 && boolList[tally][enchantability + 1][enchantmentLevel] != -1) {
                        i = world.getBlock(x - range + tally, y - range + enchantability + 1, z - range + enchantmentLevel);
                        if(!world.isAirBlock(x - range + tally, y - range + enchantability + 1, z - range + enchantmentLevel) && i != ModBlocks.blockSpectralContainer) {
                           boolList[tally][enchantability + 1][enchantmentLevel] = -1;
                        } else {
                           if(enchantability + 1 == range * 2) {
                              return emptyParam;
                           }

                           boolList[tally][enchantability + 1][enchantmentLevel] = 1;
                           var18 = false;
                        }
                     }

                     if(enchantmentLevel + 1 <= 2 * range && boolList[tally][enchantability][enchantmentLevel + 1] != 1 && boolList[tally][enchantability][enchantmentLevel + 1] != -1) {
                        i = world.getBlock(x - range + tally, y - range + enchantability, z - range + enchantmentLevel + 1);
                        if(!world.isAirBlock(x - range + tally, y - range + enchantability, z - range + enchantmentLevel + 1) && i != ModBlocks.blockSpectralContainer) {
                           boolList[tally][enchantability][enchantmentLevel + 1] = -1;
                        } else {
                           if(enchantmentLevel + 1 == range * 2) {
                              return emptyParam;
                           }

                           boolList[tally][enchantability][enchantmentLevel + 1] = 1;
                           var18 = false;
                        }
                     }
                  }
               }
            }
         }
      }

      tally = 0;
      enchantability = 0;
      enchantmentLevel = 0;

      for(int var19 = 0; var19 < 2 * range + 1; ++var19) {
         for(int j = 0; j < 2 * range + 1; ++j) {
            for(int k = 0; k < 2 * range + 1; ++k) {
               if(boolList[var19][j][k] == -1) {
                  int indTally = 0;
                  if(var19 - 1 >= 0 && boolList[var19 - 1][j][k] == 1) {
                     ++indTally;
                  }

                  if(j - 1 >= 0 && boolList[var19][j - 1][k] == 1) {
                     ++indTally;
                  }

                  if(k - 1 >= 0 && boolList[var19][j][k - 1] == 1) {
                     ++indTally;
                  }

                  if(var19 + 1 <= 2 * range && boolList[var19 + 1][j][k] == 1) {
                     ++indTally;
                  }

                  if(j + 1 <= 2 * range && boolList[var19][j + 1][k] == 1) {
                     ++indTally;
                  }

                  if(k + 1 <= 2 * range && boolList[var19][j][k + 1] == 1) {
                     ++indTally;
                  }

                  Block block = world.getBlock(x - range + var19, y - range + j, z - range + k);
                  int meta = world.getBlockMetadata(x - range + var19, y - range + j, z - range + k);
                  if(block instanceof IEnchantmentGlyph) {
                     tally += ((IEnchantmentGlyph)block).getAdditionalStabilityForFaceCount(world, x - range + var19, y - range + j, z - range + k, meta, indTally);
                     enchantability += ((IEnchantmentGlyph)block).getEnchantability(world, x - range + var19, y - range + j, z - range + k, meta);
                     enchantmentLevel += ((IEnchantmentGlyph)block).getEnchantmentLevel(world, x - range + var19, y - range + j, z - range + k, meta);
                  } else if(block instanceof IStabilityGlyph) {
                     tally += ((IStabilityGlyph)block).getAdditionalStabilityForFaceCount(world, x - range + var19, y - range + j, z - range + k, meta, indTally);
                  } else {
                     tally += indTally;
                  }
               }
            }
         }
      }

      return new OmegaStructureParameters(tally, enchantability, enchantmentLevel);
   }

   public static OmegaStructureParameters getStructureStabilityFactor(World world, int x, int y, int z, int expLim) {
      return getStructureStabilityFactor(world, x, y, z, expLim, new Int3(0, 0, 0));
   }

}
