package WayofTime.alchemicalWizardry.common.omega;

import net.minecraft.world.World;

public interface IStabilityGlyph {

   int getAdditionalStabilityForFaceCount(World var1, int var2, int var3, int var4, int var5, int var6);
}
