package WayofTime.alchemicalWizardry.common.omega;

import WayofTime.alchemicalWizardry.common.omega.IStabilityGlyph;
import net.minecraft.world.World;

public interface IEnchantmentGlyph extends IStabilityGlyph {

   int getEnchantability(World var1, int var2, int var3, int var4, int var5);

   int getEnchantmentLevel(World var1, int var2, int var3, int var4, int var5);
}
