package WayofTime.alchemicalWizardry.common.omega;

import WayofTime.alchemicalWizardry.api.alchemy.energy.Reagent;
import WayofTime.alchemicalWizardry.common.items.armour.OmegaArmour;
import WayofTime.alchemicalWizardry.common.omega.OmegaParadigm;
import java.util.HashMap;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public class OmegaRegistry {

   public static HashMap omegaList = new HashMap();


   public static void registerParadigm(Reagent reagent, OmegaParadigm parad) {
      omegaList.put(reagent, parad);
   }

   public static OmegaParadigm getParadigmForReagent(Reagent reagent) {
      return (OmegaParadigm)omegaList.get(reagent);
   }

   public static boolean hasParadigm(Reagent reagent) {
      return omegaList.containsKey(reagent);
   }

   public static OmegaParadigm getOmegaParadigmOfWeilder(EntityPlayer player) {
      ItemStack[] armours = player.inventory.armorInventory;
      ItemStack chestStack = armours[2];
      return chestStack != null && chestStack.getItem() instanceof OmegaArmour?((OmegaArmour)chestStack.getItem()).getOmegaParadigm():null;
   }

}
