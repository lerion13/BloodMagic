package WayofTime.alchemicalWizardry.common.compress;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.ShapedRecipes;
import net.minecraft.item.crafting.ShapelessRecipes;
import net.minecraft.world.World;
import net.minecraftforge.oredict.ShapedOreRecipe;
import net.minecraftforge.oredict.ShapelessOreRecipe;

public class StorageBlockCraftingRecipeAssimilator {

   public List getPackingRecipes() {
      LinkedList packingRecipes = new LinkedList();
      ArrayList unpackingRecipes = new ArrayList();
      Iterator container = this.getCraftingRecipes().iterator();

      while(container.hasNext()) {
         IRecipe inventoryUnpack = (IRecipe)container.next();
         ItemStack inventory2x2 = inventoryUnpack.getRecipeOutput();
         if(inventory2x2 != null && inventory2x2.getItem() != null) {
            if(inventory2x2.stackSize == 1) {
               StorageBlockCraftingRecipeAssimilator.PackingRecipe inventory3x3 = this.getPackingRecipe(inventoryUnpack);
               if(inventory3x3 != null) {
                  packingRecipes.add(inventory3x3);
               }
            } else if((inventory2x2.stackSize == 4 || inventory2x2.stackSize == 9) && inventoryUnpack.getRecipeSize() == 1) {
               unpackingRecipes.add(inventoryUnpack);
            }
         }
      }

      Container var18 = this.makeDummyContainer();
      InventoryCrafting var19 = new InventoryCrafting(var18, 2, 2);
      InventoryCrafting var20 = new InventoryCrafting(var18, 2, 2);
      InventoryCrafting var21 = new InventoryCrafting(var18, 3, 3);
      Object world = null;
      ArrayList ret = new ArrayList();
      Iterator i$ = unpackingRecipes.iterator();

      while(i$.hasNext()) {
         IRecipe recipeUnpack = (IRecipe)i$.next();
         ItemStack unpacked = recipeUnpack.getRecipeOutput();
         InventoryCrafting inventory = null;
         Iterator it = packingRecipes.iterator();

         while(it.hasNext()) {
            StorageBlockCraftingRecipeAssimilator.PackingRecipe recipePack = (StorageBlockCraftingRecipeAssimilator.PackingRecipe)it.next();
            boolean matched = false;
            if(recipePack.possibleInputs != null) {
               if(recipePack.inputCount != unpacked.stackSize) {
                  continue;
               }

               Iterator packOutput = recipePack.possibleInputs.iterator();

               while(packOutput.hasNext()) {
                  ItemStack stack = (ItemStack)packOutput.next();
                  if(this.areInputsIdentical(unpacked, stack)) {
                     matched = true;
                     break;
                  }
               }
            } else {
               if(unpacked.stackSize == 9 && recipePack.recipe.getRecipeSize() < 9) {
                  continue;
               }

               if(inventory == null) {
                  if(unpacked.stackSize == 4) {
                     inventory = var20;
                  } else {
                     inventory = var21;
                  }

                  for(int var22 = 0; var22 < unpacked.stackSize; ++var22) {
                     inventory.setInventorySlotContents(var22, unpacked.copy());
                  }
               }

               matched = recipePack.recipe.matches(inventory, (World)world);
            }

            if(matched) {
               ItemStack var23 = recipePack.recipe.getRecipeOutput();
               var19.setInventorySlotContents(0, var23.copy());
               if(recipeUnpack.matches(var19, (World)world)) {
                  ret.add(recipePack.recipe);
                  AlchemicalWizardry.logger.info("Adding the following recipe to the Compression Handler: " + var23);
                  it.remove();
               }
            }
         }
      }

      return ret;
   }

   private List getCraftingRecipes() {
      return CraftingManager.getInstance().getRecipeList();
   }

   private Container makeDummyContainer() {
      return new Container() {
         public boolean canInteractWith(EntityPlayer p_75145_1_) {
            return true;
         }
      };
   }

   private StorageBlockCraftingRecipeAssimilator.PackingRecipe getPackingRecipe(IRecipe recipe) {
      if(recipe.getRecipeSize() < 4) {
         return null;
      } else {
         Object inputs;
         if(recipe instanceof ShapedRecipes) {
            inputs = Arrays.asList(((ShapedRecipes)recipe).recipeItems);
         } else if(recipe instanceof ShapelessRecipes) {
            inputs = ((ShapelessRecipes)recipe).recipeItems;
         } else if(recipe instanceof ShapedOreRecipe) {
            inputs = Arrays.asList(((ShapedOreRecipe)recipe).getInput());
         } else {
            if(!(recipe instanceof ShapelessOreRecipe)) {
               return new StorageBlockCraftingRecipeAssimilator.PackingRecipe(recipe, (List)null, -1);
            }

            inputs = ((ShapelessOreRecipe)recipe).getInput();
         }

         int count = 0;
         Iterator identicalInputs = ((List)inputs).iterator();

         while(identicalInputs.hasNext()) {
            Object o = identicalInputs.next();
            if(o != null) {
               ++count;
            }
         }

         if(count != 4 && count != 9) {
            return null;
         } else {
            List var6 = this.getIdenticalInputs((List)inputs);
            if(var6 == null) {
               return null;
            } else {
               return new StorageBlockCraftingRecipeAssimilator.PackingRecipe(recipe, var6, count);
            }
         }
      }
   }

   private List getIdenticalInputs(List inputs) {
      ArrayList options = null;
      Iterator i$ = inputs.iterator();

      while(i$.hasNext()) {
         Object input = i$.next();
         if(input != null) {
            List offers;
            if(input instanceof ItemStack) {
               offers = Arrays.asList(new ItemStack[]{(ItemStack)input});
            } else {
               if(!(input instanceof List)) {
                  throw new RuntimeException("invalid input: " + input.getClass());
               }

               offers = (List)input;
               if(offers.isEmpty()) {
                  return null;
               }
            }

            if(options == null) {
               options = new ArrayList(offers);
            } else {
               Iterator it = options.iterator();

               while(it.hasNext()) {
                  ItemStack stackReq = (ItemStack)it.next();
                  boolean found = false;
                  Iterator i$1 = offers.iterator();

                  while(true) {
                     if(i$1.hasNext()) {
                        ItemStack stackCmp = (ItemStack)i$1.next();
                        if(!this.areInputsIdentical(stackReq, stackCmp)) {
                           continue;
                        }

                        found = true;
                     }

                     if(!found) {
                        it.remove();
                        if(options.isEmpty()) {
                           return null;
                        }
                     }
                     break;
                  }
               }
            }
         }
      }

      return options;
   }

   private boolean areInputsIdentical(ItemStack a, ItemStack b) {
      if(a.getItem() != b.getItem()) {
         return false;
      } else {
         int dmgA = a.getItemDamage();
         int dmgB = b.getItemDamage();
         return dmgA == dmgB || dmgA == 32767 || dmgB == 32767;
      }
   }

   private static class PackingRecipe {

      final IRecipe recipe;
      final List possibleInputs;
      final int inputCount;


      PackingRecipe(IRecipe recipe, List possibleInputs, int inputCount) {
         this.recipe = recipe;
         this.possibleInputs = possibleInputs;
         this.inputCount = inputCount;
      }
   }
}
