package WayofTime.alchemicalWizardry.common.book;

import WayofTime.alchemicalWizardry.ModBlocks;
import WayofTime.alchemicalWizardry.ModItems;
import WayofTime.alchemicalWizardry.book.compact.Category;
import WayofTime.alchemicalWizardry.book.compact.Entry;
import WayofTime.alchemicalWizardry.book.entries.EntryImage;
import WayofTime.alchemicalWizardry.book.entries.EntryItemText;
import WayofTime.alchemicalWizardry.book.entries.EntryRitualInfo;
import WayofTime.alchemicalWizardry.book.entries.EntryText;
import WayofTime.alchemicalWizardry.book.entries.IEntry;
import WayofTime.alchemicalWizardry.book.enums.EnumType;
import WayofTime.alchemicalWizardry.book.registries.EntryRegistry;
import WayofTime.alchemicalWizardry.common.book.BookParser;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumChatFormatting;

public class BUEntries {

   public static Category categoryBasics;
   public static Category categoryRituals;
   public static Category catagoryArchitect;
   public static Category categoryTest;
   public static Entry aIntro;
   public static Entry aBloodAltar;
   public static Entry aSoulNetwork;
   public static Entry aBasicsOfSigils;
   public static Entry aTrainingAndWaterSigil;
   public static Entry aLavaCrystal;
   public static Entry aLavaSigil;
   public static Entry aBlankRunes;
   public static Entry aSpeedRune;
   public static Entry aApprenticeOrb;
   public static Entry aVoidSigil;
   public static Entry aAirSigil;
   public static Entry aSightSigil;
   public static Entry aAdvancedAltar;
   public static Entry aFastMinder;
   public static Entry aSoulFray;
   public static Entry aGreenGrove;
   public static Entry aDaggerOfSacrifice;
   public static Entry aRunesOfSacrifice;
   public static Entry aBloodLetterPack;
   public static Entry aNewFriends;
   public static Entry aUpgradedAltar;
   public static Entry aNewRunes;
   public static Entry aPhandomBridge;
   public static Entry aHolding;
   public static Entry aElementalAffinity;
   public static Entry aRitualStones;
   public static Entry aBloodLamp;
   public static Entry aBoundArmour;
   public static Entry aSanguineArmour;
   public static Entry aSoulSuppressing;
   public static Entry aRitualDiviner;
   public static Entry aBloodShards;
   public static Entry aLifeOfMage;
   public static Entry aT4;
   public static Entry aSigilOfWhirlwind;
   public static Entry aSigilOfCompression;
   public static Entry aEnderDivergence;
   public static Entry aTeleposer;
   public static Entry aSuppression;
   public static Entry aSuperiorCapacity;
   public static Entry aRuneOfOrb;
   public static Entry aFieldTrip;
   public static Entry aKeyOfBinding;
   public static Entry aT5;
   public static Entry aPriceOfPower;
   public static Entry aDemonicOrb;
   public static Entry aEnergyBazooka;
   public static Entry aAccelerationRune;
   public static Entry aHarvestSigil;
   public static Entry aDemons;
   public static Entry aT6;
   public static Entry rIntro;
   public static Entry rWeakRituals;
   public static Entry rRituals;
   public static Entry rRitualWater;
   public static Entry theAltar;
   public static Entry runes;
   public static Entry ritualCure;
   public static Entry sigilAdvancedDivination;
   public static Entry blockDivination;
   public static Entry ritualWater;
   public static Entry ritualLava;
   public static Entry ritualGreenGrove;
   public static Entry ritualInterdiction;
   public static Entry ritualContainment;
   public static Entry ritualHighJump;
   public static Entry ritualSpeed;
   public static Entry ritualMagnet;
   public static Entry ritualCrusher;
   public static Entry ritualShepherd;
   public static Entry ritualRegeneration;
   public static Entry ritualFeatheredKnife;
   public static Entry ritualMoon;
   public static Entry ritualSoul;
   public static Entry elementRituals;
   public static Entry reviving;
   public static Entry debug;


   public void postInit() {
      this.initCategories();
      this.initEntries();
   }

   public void initCategories() {
      categoryBasics = new Category("Basics", new ItemStack(ModItems.weakBloodOrb), EnumType.ITEM);
      categoryRituals = new Category("Rituals", new ItemStack(ModItems.itemRitualDiviner), EnumType.ITEM);
      catagoryArchitect = new Category("The Architect", new ItemStack(ModBlocks.blockAltar), EnumType.BLOCK);
      categoryTest = new Category("Test", new ItemStack(ModItems.aether), EnumType.ITEM);
      this.registerCategories();
   }

   public void registerCategories() {
      EntryRegistry.registerCategories(categoryBasics);
      EntryRegistry.registerCategories(categoryRituals);
      EntryRegistry.registerCategories(catagoryArchitect);
      EntryRegistry.registerCategories(categoryTest);
   }

   @SideOnly(Side.CLIENT)
   public void initEntries() {
      HashMap aIntroMap = new HashMap();
      aIntroMap.put(Integer.valueOf(0), new EntryImage("bloodutils:textures/misc/screenshots/t1.png", 854, 480));
      aIntro = this.getMixedTextEntry(6, "Your classic tragic backstory", 1, aIntroMap);
      aBloodAltar = this.getPureTextEntry(3, "The Blood Altar", 1);
      aSoulNetwork = this.getPureTextEntry(3, "The Soul Network", 1);
      aBasicsOfSigils = this.getPureTextEntry(4, "Basics of sigils and a glimpse into the soul", 1);
      aTrainingAndWaterSigil = this.getPureTextEntry(6, "Training, and water sigils", 1);
      aLavaCrystal = this.getPureTextEntry(5, "The Lava crystal", 1);
      aLavaSigil = this.getPureTextEntry(8, "The perversion of the Nether, and a sigil of lava", 1);
      aBlankRunes = this.getPureTextEntry(5, "Blank runes, the building blocks of the future", 1);
      aSpeedRune = this.getPureTextEntry(2, "Speed runes", 1);
      aApprenticeOrb = this.getPureTextEntry(4, "A shining green orb", 1);
      aVoidSigil = this.getPureTextEntry(2, "The void sigil", 1);
      aAirSigil = this.getPureTextEntry(2, "Air sigil", 1);
      aSightSigil = this.getPureTextEntry(2, "Sigil of Sight", 1);
      aAdvancedAltar = this.getPureTextEntry(5, "Advanced altar mechanics", 1);
      aFastMinder = this.getPureTextEntry(2, "Sigil of the fast miner", 2);
      aSoulFray = this.getPureTextEntry(2, "Soul Fray, a few thin threads", 2);
      aGreenGrove = this.getPureTextEntry(2, "Green grove, a farmers friend", 2);
      aDaggerOfSacrifice = this.getPureTextEntry(9, "Dagger of sacrifice, an alternative energy source", 2);
      aRunesOfSacrifice = this.getPureTextEntry(10, "Runes of Sacrifice", 2);
      aBloodLetterPack = this.getPureTextEntry(4, "The blood letters pack", 2);
      aNewFriends = this.getPureTextEntry(18, "And then there was five", 2);
      aUpgradedAltar = this.getPureTextEntry(4, "An altar upgraded, and orb formed", 2);
      aNewRunes = this.getPureTextEntry(5, "New runes", 2);
      aPhandomBridge = this.getPureTextEntry(8, "The Phantom bridge", 2);
      aHolding = this.getPureTextEntry(2, "Sigil of holding", 2);
      aElementalAffinity = this.getPureTextEntry(2, "Elemental affinity, a spell casters best friend", 2);
      aRitualStones = this.getPureTextEntry(2, "Recreating ritual stones", 2);
      aBloodLamp = this.getPureTextEntry(3, "Shining a blood lamp sigil", 2);
      aBoundArmour = this.getPureTextEntry(8, "Bound armor, the walking fortress", 3);
      aSanguineArmour = this.getPureTextEntry(2, "Sanguine armor", 3);
      aSoulSuppressing = this.getPureTextEntry(1, "Suppressing the soul", 3);
      aRitualDiviner = this.getPureTextEntry(5, "The ritual diviner", 3);
      aBloodShards = this.getPureTextEntry(5, "Blood shards", 3);
      aLifeOfMage = this.getPureTextEntry(9, "he life of a Mage", 3);
      aT4 = this.getPureTextEntry(5, "The T4 altar, and a master\'s orb", 3);
      aSigilOfWhirlwind = this.getPureTextEntry(2, "The sigil of whirlwinds", 3);
      aSigilOfCompression = this.getPureTextEntry(2, "The sigil of compression", 3);
      aEnderDivergence = this.getPureTextEntry(3, "The Ender divergence", 3);
      aTeleposer = this.getPureTextEntry(9, "The Teleposer", 3);
      aSuppression = this.getPureTextEntry(2, "The sigil of suppression", 3);
      aSuperiorCapacity = this.getPureTextEntry(2, "The superior capacity rune", 3);
      aRuneOfOrb = this.getPureTextEntry(3, "The rune of the orb", 3);
      aFieldTrip = this.getPureTextEntry(19, "A field trip", 4);
      aKeyOfBinding = this.getPureTextEntry(4, "The key of binding", 4);
      aT5 = this.getPureTextEntry(4, "The trials of a T5 altar", 4);
      aPriceOfPower = this.getPureTextEntry(2, "The price of power", 4);
      aDemonicOrb = this.getPureTextEntry(1, "Demonic orb", 4);
      aEnergyBazooka = this.getPureTextEntry(2, "The unspeakable power of the energy bazooka", 4);
      aAccelerationRune = this.getPureTextEntry(2, "Acceleration runes", 4);
      aHarvestSigil = this.getPureTextEntry(3, "The sigil of the Harvest goddess", 4);
      aDemons = this.getPureTextEntry(6, "Solving a demon problem with more demons", 4);
      aT6 = this.getPureTextEntry(3, "The T6 altar already", 4);
      rIntro = new Entry(new IEntry[]{new EntryText(), new EntryText(), new EntryText()}, "Introduction", 1);
      rWeakRituals = new Entry(new IEntry[]{new EntryText(), new EntryText(), new EntryText(), new EntryText()}, "Weak Rituals", 1);
      rRituals = new Entry(new IEntry[]{new EntryText(), new EntryText(), new EntryText(), new EntryText()}, "Rituals", 1);
      rRitualWater = this.getPureTextEntry(2, "Ritual of the Full Spring", 1);
      theAltar = new Entry(new IEntry[]{new EntryItemText(new ItemStack(ModBlocks.blockAltar), "Blood Altar")}, EnumChatFormatting.BLUE + "Blood Altar", 1);
      runes = new Entry(new IEntry[]{new EntryItemText(new ItemStack(ModBlocks.runeOfSelfSacrifice)), new EntryItemText(new ItemStack(ModBlocks.runeOfSacrifice)), new EntryItemText(new ItemStack(ModBlocks.speedRune))}, "Runes", 1);
      ritualWater = new Entry(new IEntry[]{new EntryText()}, "Full Spring", 1);
      ritualLava = new Entry(new IEntry[]{new EntryText(), new EntryText()}, "Nether", 1);
      ritualGreenGrove = new Entry(new IEntry[]{new EntryText(), new EntryText()}, "Green Grove", 1);
      ritualInterdiction = new Entry(new IEntry[]{new EntryText(), new EntryText()}, "Interdiction", 1);
      ritualContainment = new Entry(new IEntry[]{new EntryText()}, "Containment", 1);
      ritualHighJump = new Entry(new IEntry[]{new EntryText()}, "High Jump", 1);
      ritualSpeed = new Entry(new IEntry[]{new EntryText()}, "Speed", 1);
      ritualMagnet = new Entry(new IEntry[]{new EntryText()}, "Magnetism", 1);
      ritualCrusher = new Entry(new IEntry[]{new EntryText()}, "Crusher", 1);
      ritualShepherd = new Entry(new IEntry[]{new EntryText()}, "Shepherd", 1);
      ritualRegeneration = new Entry(new IEntry[]{new EntryText(), new EntryText(), new EntryText()}, "Regeneration", 1);
      ritualFeatheredKnife = new Entry(new IEntry[]{new EntryText(), new EntryText(), new EntryText(), new EntryText()}, "Feathered Knife", 1);
      ritualMoon = new Entry(new IEntry[]{new EntryText()}, "Harvest Moon", 1);
      ritualSoul = new Entry(new IEntry[]{new EntryText(), new EntryText()}, "Eternal Soul", 2);
      ritualCure = new Entry(new IEntry[]{new EntryText(), new EntryRitualInfo(500)}, "Curing", 1);
      debug = new Entry(new IEntry[]{new EntryText("Debug"), new EntryImage("bloodutils:textures/misc/screenshots/t1.png", 854, 480, "Debug")}, EnumChatFormatting.AQUA + "De" + EnumChatFormatting.RED + "bug", 1);
      this.registerEntries();
   }

   public Entry getPureTextEntry(int numberOfPages, String name, int pageNumber) {
      IEntry[] entries = new IEntry[numberOfPages];

      for(int i = 0; i < numberOfPages; ++i) {
         entries[i] = new EntryText();
      }

      return new Entry(entries, name, pageNumber);
   }

   public Entry getMixedTextEntry(int numberOfPages, String name, int pageNumber, Map map) {
      IEntry[] entries = new IEntry[numberOfPages];

      for(int i$ = 0; i$ < numberOfPages; ++i$) {
         entries[i$] = new EntryText();
      }

      Iterator var8 = map.entrySet().iterator();

      while(var8.hasNext()) {
         java.util.Map.Entry ent = (java.util.Map.Entry)var8.next();
         if(((Integer)ent.getKey()).intValue() < entries.length) {
            entries[((Integer)ent.getKey()).intValue()] = (IEntry)ent.getValue();
         }
      }

      return new Entry(entries, name, pageNumber);
   }

   public void registerEntries() {
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aIntro);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aBloodAltar);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aSoulNetwork);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aBasicsOfSigils);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aTrainingAndWaterSigil);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aLavaCrystal);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aLavaSigil);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aBlankRunes);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aSpeedRune);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aApprenticeOrb);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aVoidSigil);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aAirSigil);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aSightSigil);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aAdvancedAltar);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aFastMinder);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aSoulFray);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aGreenGrove);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aDaggerOfSacrifice);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aRunesOfSacrifice);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aBloodLetterPack);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aNewFriends);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aUpgradedAltar);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aNewRunes);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aPhandomBridge);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aHolding);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aElementalAffinity);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aRitualStones);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aBloodLamp);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aBoundArmour);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aSanguineArmour);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aSoulSuppressing);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aRitualDiviner);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aBloodShards);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aLifeOfMage);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aT4);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aSigilOfWhirlwind);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aSigilOfCompression);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aEnderDivergence);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aTeleposer);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aSuppression);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aSuperiorCapacity);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aRuneOfOrb);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aFieldTrip);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aKeyOfBinding);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aT5);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aPriceOfPower);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aDemonicOrb);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aEnergyBazooka);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aAccelerationRune);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aHarvestSigil);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aDemons);
      EntryRegistry.registerEntry(catagoryArchitect, EntryRegistry.architect, aT6);
      EntryRegistry.registerEntry(categoryBasics, EntryRegistry.basics, theAltar);
      EntryRegistry.registerEntry(categoryBasics, EntryRegistry.basics, runes);
      EntryRegistry.registerEntry(categoryRituals, EntryRegistry.rituals, rIntro);
      EntryRegistry.registerEntry(categoryRituals, EntryRegistry.rituals, rWeakRituals);
      EntryRegistry.registerEntry(categoryRituals, EntryRegistry.rituals, rRituals);
      EntryRegistry.registerEntry(categoryRituals, EntryRegistry.rituals, rRitualWater);
      EntryRegistry.registerEntry(categoryBasics, EntryRegistry.basics, debug);
      this.registerCategory(categoryTest, EntryRegistry.test, BookParser.parseTextFile("/assets/alchemicalwizardryBooks/books/book.txt"));
   }

   public void registerCategory(Category cat, HashMap entryMap, List entries) {
      Iterator i$ = entries.iterator();

      while(i$.hasNext()) {
         Entry entry = (Entry)i$.next();
         EntryRegistry.registerEntry(cat, entryMap, entry);
      }

   }
}
