package WayofTime.alchemicalWizardry.common.book;

import WayofTime.alchemicalWizardry.book.registries.RecipeRegistry;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.item.crafting.IRecipe;

public class SpecialEntryRegistry {

   public static Map recipeStringMap = new HashMap();


   public static void registerIRecipeKey(IRecipe recipe, String key) {
      recipeStringMap.put(key, recipe);
   }

   public static IRecipe getIRecipeForKey(String str) {
      return (IRecipe)recipeStringMap.get(str);
   }

   public static void registerLatestIRecipe(String key) {
      registerIRecipeKey(RecipeRegistry.getLatestCraftingRecipe(), key);
   }

}
