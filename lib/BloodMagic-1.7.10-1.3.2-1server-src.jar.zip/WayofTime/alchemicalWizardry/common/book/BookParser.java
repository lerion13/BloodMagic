package WayofTime.alchemicalWizardry.common.book;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.spell.APISpellHelper;
import WayofTime.alchemicalWizardry.book.compact.Entry;
import WayofTime.alchemicalWizardry.book.entries.EntryCraftingRecipeCustomText;
import WayofTime.alchemicalWizardry.book.entries.EntryImageCustomText;
import WayofTime.alchemicalWizardry.book.entries.EntryItemCustomText;
import WayofTime.alchemicalWizardry.book.entries.EntryTextCustomText;
import WayofTime.alchemicalWizardry.book.entries.IEntryCustomText;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;

public class BookParser {

   @SideOnly(Side.CLIENT)
   public static List parseTextFile(String location) {
      new File("config/BloodMagic/bookDocs");
      ArrayList entryList = new ArrayList();

      try {
         System.out.println("I am in an island of files!");
         InputStream e = AlchemicalWizardry.class.getResourceAsStream(location);
         Minecraft.getMinecraft().fontRenderer.setUnicodeFlag(true);
         if(e != null) {
            DataInputStream in = new DataInputStream(e);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            byte defMaxLines = 16;
            int maxLines = defMaxLines;
            int currentPage = 0;
            int pageIndex = 1;
            String currentTitle = "aw.entry.Magnus";
            String[] strings = new String[]{""};
            ArrayList iEntryList = new ArrayList();
            Object currentIEntry = new EntryTextCustomText();
            boolean lastPageWasSpecial = true;
            byte entriesPerPage = 14;

            String strLine;
            while((strLine = br.readLine()) != null) {
               if(!strLine.trim().isEmpty()) {
                  String[] var29;
                  int var30;
                  if(strLine.startsWith("//TITLE ")) {
                     lastPageWasSpecial = false;
                     var29 = new String[currentPage + 1 + 1];

                     for(var30 = 0; var30 < strings.length; ++var30) {
                        var29[var30] = strings[var30];
                     }

                     if(currentPage != 0) {
                        ((IEntryCustomText)currentIEntry).setText(strings[currentPage]);
                        iEntryList.add(currentIEntry);
                        Entry var33 = new Entry(getArrayForList(iEntryList), currentTitle, entryList.size() / entriesPerPage + 1);
                        entryList.add(var33);
                        iEntryList.clear();
                        currentIEntry = new EntryTextCustomText();
                     }

                     ++currentPage;
                     var29[currentPage - 1] = currentTitle + "." + pageIndex + "=" + var29[currentPage - 1];
                     var29[currentPage] = "";
                     strings = var29;
                     pageIndex = 1;
                     String var32 = strLine.replaceFirst("//TITLE ", " ").trim();
                     currentTitle = var32;
                  } else if(containsSpecialInfo(strLine)) {
                     if(!strings[currentPage].isEmpty() || lastPageWasSpecial) {
                        var29 = new String[currentPage + 1 + 1];

                        for(var30 = 0; var30 < strings.length; ++var30) {
                           var29[var30] = strings[var30];
                        }

                        ((IEntryCustomText)currentIEntry).setText(strings[currentPage]);
                        iEntryList.add(currentIEntry);
                        ++currentPage;
                        var29[currentPage - 1] = currentTitle + "." + pageIndex + "=" + var29[currentPage - 1];
                        var29[currentPage] = "";
                        strings = var29;
                     }

                     currentIEntry = getEntryForStringTitle(strLine);
                     maxLines = getlineLimitForStringTitle(strLine, defMaxLines);
                     lastPageWasSpecial = true;
                  } else {
                     strLine = strLine.replace('\ufffd', '\"').replace('\ufffd', '\"').replace("�", "...").replace('\ufffd', '\'').replace('\ufffd', '-');
                     if(Minecraft.getMinecraft() != null && Minecraft.getMinecraft().fontRenderer != null) {
                        List entry = Minecraft.getMinecraft().fontRenderer.listFormattedStringToWidth(strLine, 110);
                        if(entry != null) {
                           ;
                        }
                     }

                     var29 = strLine.split(" ");
                     String[] currentLines = var29;
                     int len$ = var29.length;

                     for(int i$ = 0; i$ < len$; ++i$) {
                        String word = currentLines[i$];
                        lastPageWasSpecial = true;
                        boolean changePage = false;
                        int length = word.length();
                        word = word.replace('\t', ' ');
                        List list = Minecraft.getMinecraft().fontRenderer.listFormattedStringToWidth(strings[currentPage] + " " + word, 110);
                        if(list.size() > maxLines) {
                           changePage = true;
                        }

                        if(changePage) {
                           String[] newStrings = new String[currentPage + 1 + 1];

                           for(int i = 0; i < strings.length; ++i) {
                              newStrings[i] = strings[i];
                           }

                           ((IEntryCustomText)currentIEntry).setText(strings[currentPage]);
                           iEntryList.add(currentIEntry);
                           currentIEntry = new EntryTextCustomText();
                           ++currentPage;
                           newStrings[currentPage - 1] = currentTitle + "." + pageIndex + "=" + newStrings[currentPage - 1];
                           newStrings[currentPage] = word;
                           strings = newStrings;
                           ++pageIndex;
                           maxLines = defMaxLines;
                           changePage = false;
                        } else {
                           strings[currentPage] = strings[currentPage] + " " + word;
                        }
                     }

                     for(var30 = Minecraft.getMinecraft().fontRenderer.listFormattedStringToWidth(strings[currentPage], 110).size(); Minecraft.getMinecraft().fontRenderer.listFormattedStringToWidth(strings[currentPage] + " ", 110).size() <= var30; strings[currentPage] = strings[currentPage] + " ") {
                        ;
                     }
                  }
               }
            }

            strings[currentPage] = strings[currentPage];
            ((IEntryCustomText)currentIEntry).setText(strings[currentPage]);
            iEntryList.add(currentIEntry);
            Entry var31 = new Entry(getArrayForList(iEntryList), currentTitle, entryList.size() / entriesPerPage + 1);
            entryList.add(var31);
            iEntryList.clear();
         }

         Minecraft.getMinecraft().fontRenderer.setUnicodeFlag(false);
      } catch (FileNotFoundException var27) {
         var27.printStackTrace();
      } catch (IOException var28) {
         var28.printStackTrace();
      }

      return entryList;
   }

   public static IEntryCustomText[] getArrayForList(List list) {
      Object[] tempArray = list.toArray();
      IEntryCustomText[] customTextArray = new IEntryCustomText[tempArray.length];

      for(int i = 0; i < tempArray.length; ++i) {
         if(tempArray[i] instanceof IEntryCustomText) {
            customTextArray[i] = (IEntryCustomText)tempArray[i];
         }
      }

      return customTextArray;
   }

   public static boolean containsSpecialInfo(String unparsedString) {
      return unparsedString.startsWith("//IMAGE") || unparsedString.startsWith("//CRAFTING") || unparsedString.startsWith("//ITEM");
   }

   public static IEntryCustomText getEntryForStringTitle(String unparsedString) {
      String lines;
      if(unparsedString.startsWith("//IMAGE ")) {
         lines = unparsedString.replaceFirst("//IMAGE ", "");
         String[] stack1 = lines.split(" ");
         if(stack1.length < 4) {
            return null;
         } else {
            int recipe1 = Integer.decode(stack1[1]).intValue();
            int ySize = Integer.decode(stack1[2]).intValue();
            return stack1.length >= 5?new EntryImageCustomText(stack1[3], recipe1, ySize, stack1[4]):new EntryImageCustomText(stack1[3], recipe1, ySize);
         }
      } else {
         ItemStack stack;
         if(unparsedString.startsWith("//CRAFTING ")) {
            lines = unparsedString.replaceFirst("//CRAFTING ", "");
            stack = APISpellHelper.getItemStackForString(lines);
            IRecipe recipe = APISpellHelper.getRecipeForItemStack(stack);
            if(recipe != null) {
               return new EntryCraftingRecipeCustomText(recipe);
            }
         } else if(unparsedString.startsWith("//ITEM ")) {
            lines = unparsedString.replaceFirst("//ITEM ", "");
            stack = APISpellHelper.getItemStackForString(lines);
            if(stack != null) {
               return new EntryItemCustomText(stack);
            }
         }

         return new EntryTextCustomText();
      }
   }

   public static int getlineLimitForStringTitle(String unparsedString, int def) {
      if(unparsedString.startsWith("//IMAGE ")) {
         String lines = unparsedString.replaceFirst("//IMAGE ", "");
         String[] arguments = lines.split(" ");
         return arguments.length < 4?def:Integer.decode(arguments[0]).intValue();
      } else {
         return unparsedString.startsWith("//CRAFTING ")?0:(unparsedString.startsWith("//ITEM ")?9:def);
      }
   }
}
