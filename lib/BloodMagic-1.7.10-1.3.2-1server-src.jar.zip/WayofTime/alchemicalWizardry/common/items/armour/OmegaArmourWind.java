package WayofTime.alchemicalWizardry.common.items.armour;

import WayofTime.alchemicalWizardry.ModItems;
import WayofTime.alchemicalWizardry.common.items.armour.OmegaArmour;
import WayofTime.alchemicalWizardry.common.renderer.model.ModelOmegaWind;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.UUID;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;

public class OmegaArmourWind extends OmegaArmour {

   private static IIcon helmetIcon;
   private static IIcon plateIcon;
   private static IIcon leggingsIcon;
   private static IIcon bootsIcon;


   public OmegaArmourWind(int armorType) {
      super(armorType);
      super.storeYLevel = true;
   }

   public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type) {
      return "alchemicalwizardry:models/armor/OmegaWind.png";
   }

   @SideOnly(Side.CLIENT)
   public ModelBiped getChestModel() {
      return new ModelOmegaWind(1.0F, true, true, false, true);
   }

   @SideOnly(Side.CLIENT)
   public ModelBiped getLegsModel() {
      return new ModelOmegaWind(0.5F, false, false, true, false);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:SheathedItem");
      helmetIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaHelmet_wind");
      plateIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaPlate_wind");
      leggingsIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaLeggings_wind");
      bootsIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaBoots_wind");
   }

   @SideOnly(Side.CLIENT)
   public IIcon getIconFromDamage(int par1) {
      return this.equals(ModItems.boundHelmetWind)?helmetIcon:(this.equals(ModItems.boundPlateWind)?plateIcon:(this.equals(ModItems.boundLeggingsWind)?leggingsIcon:(this.equals(ModItems.boundBootsWind)?bootsIcon:super.itemIcon)));
   }

   public Multimap getAttributeModifiers(ItemStack stack) {
      HashMultimap map = HashMultimap.create();
      int yLevel = this.getYLevelStored(stack);
      map.put(SharedMonsterAttributes.maxHealth.getAttributeUnlocalizedName(), new AttributeModifier(new UUID(85212L, (long)super.armorType), "Health modifier" + super.armorType, (double)(this.getDefaultArmourBoost() * this.getHealthBoostModifierForLevel(yLevel)), 1));
      map.put(SharedMonsterAttributes.attackDamage.getAttributeUnlocalizedName(), new AttributeModifier(new UUID(86212L, (long)super.armorType), "Damage modifier" + super.armorType, (double)(this.getDefaultArmourBoost() * this.getDamageModifierForLevel(yLevel)), 2));
      return map;
   }

   public float getDefaultArmourBoost() {
      switch(super.armorType) {
      case 0:
         return 2.5F;
      case 1:
         return 4.0F;
      case 2:
         return 3.5F;
      case 3:
         return 2.0F;
      default:
         return 0.25F;
      }
   }

   public float getHealthBoostModifierForLevel(int yLevel) {
      return 0.05F * ((float)yLevel / 64.0F * 1.5F - 1.0F);
   }

   public float getDamageModifierForLevel(int yLevel) {
      return 0.02F * ((float)yLevel / 64.0F * 1.5F - 1.0F);
   }
}
