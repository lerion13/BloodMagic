package WayofTime.alchemicalWizardry.common.items.armour;

import WayofTime.alchemicalWizardry.ModItems;
import WayofTime.alchemicalWizardry.common.items.armour.OmegaArmour;
import WayofTime.alchemicalWizardry.common.renderer.model.ModelOmegaWater;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.UUID;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.world.biome.BiomeGenBase;

public class OmegaArmourWater extends OmegaArmour {

   private static IIcon helmetIcon;
   private static IIcon plateIcon;
   private static IIcon leggingsIcon;
   private static IIcon bootsIcon;


   public OmegaArmourWater(int armorType) {
      super(armorType);
      super.storeBiomeID = true;
   }

   public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type) {
      return "alchemicalwizardry:models/armor/OmegaWater.png";
   }

   @SideOnly(Side.CLIENT)
   public ModelBiped getChestModel() {
      return new ModelOmegaWater(1.0F, true, true, false, true);
   }

   @SideOnly(Side.CLIENT)
   public ModelBiped getLegsModel() {
      return new ModelOmegaWater(0.5F, false, false, true, false);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:SheathedItem");
      helmetIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaHelmet_water");
      plateIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaPlate_water");
      leggingsIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaLeggings_water");
      bootsIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaBoots_water");
   }

   @SideOnly(Side.CLIENT)
   public IIcon getIconFromDamage(int par1) {
      return this.equals(ModItems.boundHelmetWater)?helmetIcon:(this.equals(ModItems.boundPlateWater)?plateIcon:(this.equals(ModItems.boundLeggingsWater)?leggingsIcon:(this.equals(ModItems.boundBootsWater)?bootsIcon:super.itemIcon)));
   }

   public Multimap getAttributeModifiers(ItemStack stack) {
      HashMultimap map = HashMultimap.create();
      int biomeID = this.getBiomeIDStored(stack);
      BiomeGenBase biome = BiomeGenBase.getBiome(biomeID);
      if(biome != null) {
         map.put(SharedMonsterAttributes.maxHealth.getAttributeUnlocalizedName(), new AttributeModifier(new UUID(85312L, (long)super.armorType), "Health modifier" + super.armorType, (double)(this.getDefaultArmourBoost() * this.getHealthBoostModifierForBiome(biome)), 2));
         map.put(SharedMonsterAttributes.attackDamage.getAttributeUnlocalizedName(), new AttributeModifier(new UUID(85432L, (long)super.armorType), "Damage modifier" + super.armorType, (double)(this.getDefaultArmourBoost() * this.getDamageModifierForBiome(biome)), 2));
      }

      return map;
   }

   public float getDefaultArmourBoost() {
      switch(super.armorType) {
      case 0:
         return 2.5F;
      case 1:
         return 4.0F;
      case 2:
         return 3.5F;
      case 3:
         return 2.0F;
      default:
         return 0.25F;
      }
   }

   public float getHealthBoostModifierForBiome(BiomeGenBase biome) {
      float modifier = 0.05F;
      return biome.isEqualTo(BiomeGenBase.hell)?modifier * -0.5F:(!biome.isEqualTo(BiomeGenBase.ocean) && !biome.isEqualTo(BiomeGenBase.river)?(biome.isHighHumidity()?modifier * 1.5F:modifier * 0.5F):modifier * 2.0F);
   }

   public float getDamageModifierForBiome(BiomeGenBase biome) {
      float modifier = 0.03F;
      return biome.isEqualTo(BiomeGenBase.hell)?modifier * -0.5F:(!biome.isEqualTo(BiomeGenBase.ocean) && !biome.isEqualTo(BiomeGenBase.river)?(biome.isHighHumidity()?modifier * 1.5F:modifier * 0.5F):modifier * 2.0F);
   }
}
