package WayofTime.alchemicalWizardry.common.items.armour;

import WayofTime.alchemicalWizardry.api.alchemy.energy.Reagent;
import WayofTime.alchemicalWizardry.api.soulNetwork.SoulNetworkHandler;
import WayofTime.alchemicalWizardry.api.spell.APISpellHelper;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import WayofTime.alchemicalWizardry.common.items.armour.BoundArmour;
import WayofTime.alchemicalWizardry.common.omega.OmegaParadigm;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentData;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumAction;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;

public abstract class OmegaArmour extends BoundArmour {

   public OmegaParadigm paradigm;
   public Reagent reagent;
   protected boolean storeBiomeID = false;
   protected boolean storeDimensionID = false;
   protected boolean storeYLevel = false;
   protected boolean storeSeesSky = false;
   protected List illegalEnchantmentList = new LinkedList();
   public float reagentDrainPerDamage = 0.1F;
   @SideOnly(Side.CLIENT)
   ModelBiped model1 = null;
   @SideOnly(Side.CLIENT)
   ModelBiped model2 = null;
   @SideOnly(Side.CLIENT)
   ModelBiped model = null;


   public OmegaArmour(int armorType) {
      super(armorType);
   }

   public void setParadigm(OmegaParadigm paradigm) {
      this.paradigm = paradigm;
   }

   public OmegaParadigm getOmegaParadigm() {
      return this.paradigm;
   }

   public void setReagent(Reagent reagent) {
      this.reagent = reagent;
   }

   public boolean isAffectedBySoulHarden() {
      return false;
   }

   public double getBaseArmourReduction() {
      return 0.9D;
   }

   public double getArmourPenetrationReduction() {
      return 0.5D;
   }

   public void onArmorTick(World world, EntityPlayer player, ItemStack itemStack) {
      super.onArmorTick(world, player, itemStack);
      int duration;
      if(world.getWorldTime() % 50L == 0L) {
         if(this.storeBiomeID()) {
            duration = (int)Math.floor(player.posX);
            int zCoord = (int)Math.floor(player.posZ);
            BiomeGenBase biome = world.getBiomeGenForCoords(duration, zCoord);
            if(biome != null) {
               this.setBiomeIDStored(itemStack, biome.biomeID);
            }
         }

         if(this.storeDimensionID()) {
            this.setDimensionIDStored(itemStack, world.provider.dimensionId);
         }

         if(this.storeYLevel()) {
            this.setYLevelStored(itemStack, (int)Math.floor(player.posY));
         }
      }

      if(super.armorType == 1) {
         this.paradigm.onUpdate(world, player, itemStack);
         duration = this.getOmegaStallingDuration(itemStack);
         if(duration > 0) {
            this.setOmegaStallingDuration(itemStack, duration - 1);
         }
      }

   }

   public void repairArmour(World world, EntityPlayer player, ItemStack itemStack) {
      if(itemStack.getItemDamage() > 0 && !player.capabilities.isCreativeMode && EnergyItems.syphonBatteries(itemStack, player, itemStack.getItemDamage() * 75)) {
         Reagent reagent = APISpellHelper.getPlayerReagentType(player);
         float reagentAmount = APISpellHelper.getPlayerCurrentReagentAmount(player);
         reagentAmount -= (float)itemStack.getItemDamage() * this.reagentDrainPerDamage;
         APISpellHelper.setPlayerCurrentReagentAmount(player, Math.max(0.0F, reagentAmount));
         itemStack.setItemDamage(0);
      }

   }

   public void revertArmour(EntityPlayer player, ItemStack itemStack) {
      ItemStack stack = this.getContainedArmourStack(itemStack);
      player.inventory.armorInventory[3 - super.armorType] = stack;
   }

   public ItemStack getSubstituteStack(ItemStack boundStack, int stability, int affinity, int enchantability, int enchantmentLevel, Random rand) {
      ItemStack omegaStack = new ItemStack(this);
      if(boundStack != null && boundStack.hasTagCompound()) {
         NBTTagCompound enchantList = (NBTTagCompound)boundStack.getTagCompound().copy();
         omegaStack.setTagCompound(enchantList);
      }

      this.setContainedArmourStack(omegaStack, boundStack);
      SoulNetworkHandler.checkAndSetItemOwner(omegaStack, SoulNetworkHandler.getOwnerName(boundStack));
      this.setItemEnchantability(omegaStack, Math.min(enchantability, 70));
      EnchantmentHelper.setEnchantments(new HashMap(), omegaStack);
      ArrayList var24 = new ArrayList();
      int adjustedEnchantLevel = Math.min(enchantmentLevel, 30);
      int additionalPasses = enchantmentLevel - adjustedEnchantLevel;

      for(int map = 0; map < 1 + additionalPasses; ++map) {
         List newEnchantList = EnchantmentHelper.buildEnchantmentList(rand, omegaStack, adjustedEnchantLevel);
         if(newEnchantList != null) {
            var24.addAll(newEnchantList);
         }
      }

      HashMap var26 = new HashMap();
      Iterator var25 = var24.iterator();

      EnchantmentData i;
      while(var25.hasNext()) {
         Object iterator = var25.next();
         i = (EnchantmentData)iterator;
         if(!var26.containsKey(i.enchantmentobj)) {
            var26.put(i.enchantmentobj, new HashMap());
         }

         Map ench = (Map)var26.get(i.enchantmentobj);
         if(ench.containsKey(Integer.valueOf(i.enchantmentLevel))) {
            ench.put(Integer.valueOf(i.enchantmentLevel), Integer.valueOf(((Integer)ench.get(Integer.valueOf(i.enchantmentLevel))).intValue() + 1));
         } else {
            ench.put(Integer.valueOf(i.enchantmentLevel), Integer.valueOf(1));
         }
      }

      var25 = this.illegalEnchantmentList.iterator();

      while(var25.hasNext()) {
         Enchantment var29 = (Enchantment)var25.next();
         if(var26.containsKey(var29)) {
            var26.remove(var29);
         }
      }

      ArrayList var28 = new ArrayList();
      Iterator var27 = var26.entrySet().iterator();

      while(var27.hasNext()) {
         Entry var32 = (Entry)var27.next();
         Enchantment var31 = (Enchantment)var32.getKey();
         Map numMap = (Map)var32.getValue();
         if(!numMap.isEmpty()) {
            int[] enchantValues = new int[1];

            int newEnchantValues;
            int number;
            for(Iterator size = numMap.entrySet().iterator(); size.hasNext(); enchantValues[number] += newEnchantValues) {
               Entry i1 = (Entry)size.next();
               number = ((Integer)i1.getKey()).intValue();
               newEnchantValues = ((Integer)i1.getValue()).intValue();
               if(number >= enchantValues.length) {
                  int[] z = new int[number + 1];

                  for(int i2 = 0; i2 < enchantValues.length; ++i2) {
                     z[i2] = enchantValues[i2];
                  }

                  enchantValues = z;
               }
            }

            int var34 = enchantValues.length;

            for(int var33 = 0; var33 < var34; ++var33) {
               number = enchantValues[var33];
               if(number >= 2 && var33 + 1 >= var34) {
                  int[] var36 = new int[var33 + 2];

                  for(int var35 = 0; var35 < enchantValues.length; ++var35) {
                     var36[var35] = enchantValues[var35];
                  }

                  enchantValues = var36;
                  var36[var33 + 1] += number / 2;
                  var34 = var36.length;
               }
            }

            var28.add(new EnchantmentData(var31, enchantValues.length - 1));
         }
      }

      var27 = var28.iterator();

      while(var27.hasNext()) {
         i = (EnchantmentData)var27.next();
         omegaStack.addEnchantment(i.enchantmentobj, i.enchantmentLevel);
      }

      for(int var30 = 0; var30 < 1; ++var30) {
         ;
      }

      return omegaStack;
   }

   public void setContainedArmourStack(ItemStack omegaStack, ItemStack boundStack) {
      if(omegaStack != null && boundStack != null) {
         NBTTagCompound tag = new NBTTagCompound();
         boundStack.writeToNBT(tag);
         NBTTagCompound omegaTag = omegaStack.getTagCompound();
         if(omegaTag == null) {
            omegaTag = new NBTTagCompound();
            omegaStack.setTagCompound(omegaTag);
         }

         omegaTag.setTag("armour", tag);
      }
   }

   public ItemStack getContainedArmourStack(ItemStack omegaStack) {
      NBTTagCompound omegaTag = omegaStack.getTagCompound();
      if(omegaTag == null) {
         return null;
      } else {
         NBTTagCompound tag = omegaTag.getCompoundTag("armour");
         ItemStack armourStack = ItemStack.loadItemStackFromNBT(tag);
         return armourStack;
      }
   }

   public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type) {
      return "alchemicalwizardry:models/armor/OmegaWater.png";
   }

   @SideOnly(Side.CLIENT)
   public abstract ModelBiped getChestModel();

   @SideOnly(Side.CLIENT)
   public abstract ModelBiped getLegsModel();

   @SideOnly(Side.CLIENT)
   public ModelBiped getArmorModel(EntityLivingBase entityLiving, ItemStack itemStack, int armorSlot) {
      if(!BoundArmour.tryComplexRendering) {
         return super.getArmorModel(entityLiving, itemStack, armorSlot);
      } else {
         int type = ((ItemArmor)itemStack.getItem()).armorType;
         if(this.model1 == null) {
            this.model1 = this.getChestModel();
         }

         if(this.model2 == null) {
            this.model2 = this.getLegsModel();
         }

         if(type != 1 && type != 3 && type != 0) {
            this.model = this.model2;
         } else {
            this.model = this.model1;
         }

         if(this.model != null) {
            this.model.bipedHead.showModel = type == 0;
            this.model.bipedHeadwear.showModel = type == 0;
            this.model.bipedBody.showModel = type == 1 || type == 2;
            this.model.bipedLeftArm.showModel = type == 1;
            this.model.bipedRightArm.showModel = type == 1;
            this.model.bipedLeftLeg.showModel = type == 2 || type == 3;
            this.model.bipedRightLeg.showModel = type == 2 || type == 3;
            this.model.isSneak = entityLiving.isSneaking();
            this.model.isRiding = entityLiving.isRiding();
            this.model.isChild = entityLiving.isChild();
            this.model.aimedBow = false;
            this.model.heldItemRight = entityLiving.getHeldItem() != null?1:0;
            if(entityLiving instanceof EntityPlayer && ((EntityPlayer)entityLiving).getItemInUseDuration() > 0) {
               EnumAction enumaction = ((EntityPlayer)entityLiving).getItemInUse().getItemUseAction();
               if(enumaction == EnumAction.block) {
                  this.model.heldItemRight = 3;
               } else if(enumaction == EnumAction.bow) {
                  this.model.aimedBow = true;
               }
            }
         }

         return this.model;
      }
   }

   public void onOmegaKeyPressed(EntityPlayer player, ItemStack stack) {
      if(this.paradigm != null) {
         this.paradigm.onOmegaKeyPressed(player, stack);
      }

   }

   public void setOmegaStallingDuration(ItemStack stack, int duration) {
      NBTTagCompound tag = stack.getTagCompound();
      if(tag == null) {
         tag = new NBTTagCompound();
         stack.setTagCompound(tag);
      }

      tag.setInteger("OmegaStallDuration", duration);
   }

   public int getOmegaStallingDuration(ItemStack stack) {
      NBTTagCompound tag = stack.getTagCompound();
      if(tag == null) {
         tag = new NBTTagCompound();
         stack.setTagCompound(tag);
      }

      return tag.getInteger("OmegaStallDuration");
   }

   public boolean hasOmegaStalling(ItemStack stack) {
      return this.getOmegaStallingDuration(stack) > 0;
   }

   public boolean storeBiomeID() {
      return this.storeBiomeID;
   }

   public boolean storeDimensionID() {
      return this.storeDimensionID;
   }

   public boolean storeYLevel() {
      return this.storeYLevel;
   }

   public boolean storeSeesSky() {
      return this.storeSeesSky;
   }

   public int getBiomeIDStored(ItemStack stack) {
      NBTTagCompound tag = stack.getTagCompound();
      if(tag == null) {
         tag = new NBTTagCompound();
         stack.setTagCompound(tag);
      }

      return tag.getInteger("biomeID");
   }

   public void setBiomeIDStored(ItemStack stack, int id) {
      NBTTagCompound tag = stack.getTagCompound();
      if(tag == null) {
         tag = new NBTTagCompound();
         stack.setTagCompound(tag);
      }

      tag.setInteger("biomeID", id);
   }

   public int getDimensionIDStored(ItemStack stack) {
      NBTTagCompound tag = stack.getTagCompound();
      if(tag == null) {
         tag = new NBTTagCompound();
         stack.setTagCompound(tag);
      }

      return tag.getInteger("dimensionID");
   }

   public void setDimensionIDStored(ItemStack stack, int id) {
      NBTTagCompound tag = stack.getTagCompound();
      if(tag == null) {
         tag = new NBTTagCompound();
         stack.setTagCompound(tag);
      }

      tag.setInteger("dimensionID", id);
   }

   public int getYLevelStored(ItemStack stack) {
      NBTTagCompound tag = stack.getTagCompound();
      if(tag == null) {
         tag = new NBTTagCompound();
         stack.setTagCompound(tag);
      }

      return tag.getInteger("yLevel");
   }

   public void setYLevelStored(ItemStack stack, int level) {
      NBTTagCompound tag = stack.getTagCompound();
      if(tag == null) {
         tag = new NBTTagCompound();
         stack.setTagCompound(tag);
      }

      tag.setInteger("yLevel", level);
   }
}
