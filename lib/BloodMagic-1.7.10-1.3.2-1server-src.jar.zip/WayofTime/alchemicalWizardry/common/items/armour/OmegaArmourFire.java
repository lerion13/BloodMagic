package WayofTime.alchemicalWizardry.common.items.armour;

import WayofTime.alchemicalWizardry.ModItems;
import WayofTime.alchemicalWizardry.common.items.armour.OmegaArmour;
import WayofTime.alchemicalWizardry.common.renderer.model.ModelOmegaFire;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.UUID;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.world.biome.BiomeGenBase;

public class OmegaArmourFire extends OmegaArmour {

   private static IIcon helmetIcon;
   private static IIcon plateIcon;
   private static IIcon leggingsIcon;
   private static IIcon bootsIcon;


   public OmegaArmourFire(int armorType) {
      super(armorType);
      super.storeBiomeID = true;
      super.illegalEnchantmentList.add(Enchantment.fireProtection);
   }

   public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type) {
      return "alchemicalwizardry:models/armor/OmegaFire.png";
   }

   @SideOnly(Side.CLIENT)
   public ModelBiped getChestModel() {
      return new ModelOmegaFire(1.0F, true, true, false, true);
   }

   @SideOnly(Side.CLIENT)
   public ModelBiped getLegsModel() {
      return new ModelOmegaFire(0.5F, false, false, true, false);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:SheathedItem");
      helmetIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaHelmet_fire");
      plateIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaPlate_fire");
      leggingsIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaLeggings_fire");
      bootsIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaBoots_fire");
   }

   @SideOnly(Side.CLIENT)
   public IIcon getIconFromDamage(int par1) {
      return this.equals(ModItems.boundHelmetFire)?helmetIcon:(this.equals(ModItems.boundPlateFire)?plateIcon:(this.equals(ModItems.boundLeggingsFire)?leggingsIcon:(this.equals(ModItems.boundBootsFire)?bootsIcon:super.itemIcon)));
   }

   public Multimap getAttributeModifiers(ItemStack stack) {
      HashMultimap map = HashMultimap.create();
      int biomeID = this.getBiomeIDStored(stack);
      BiomeGenBase biome = BiomeGenBase.getBiome(biomeID);
      if(biome != null) {
         map.put(SharedMonsterAttributes.maxHealth.getAttributeUnlocalizedName(), new AttributeModifier(new UUID(895132L, (long)super.armorType), "Health modifier" + super.armorType, (double)(this.getDefaultArmourBoost() * this.getHealthBoostModifierForBiome(biome)), 1));
         map.put(SharedMonsterAttributes.attackDamage.getAttributeUnlocalizedName(), new AttributeModifier(new UUID(196312L, (long)super.armorType), "Damage modifier" + super.armorType, (double)(this.getDefaultArmourBoost() * this.getDamageModifierForBiome(biome)), 1));
      }

      return map;
   }

   public float getDefaultArmourBoost() {
      switch(super.armorType) {
      case 0:
         return 2.5F;
      case 1:
         return 4.0F;
      case 2:
         return 3.5F;
      case 3:
         return 2.0F;
      default:
         return 0.25F;
      }
   }

   public float getHealthBoostModifierForBiome(BiomeGenBase biome) {
      float modifier = 0.05F;
      return biome.isEqualTo(BiomeGenBase.hell)?modifier * 2.0F:(biome.isEqualTo(BiomeGenBase.ocean)?modifier * -0.5F:(biome.temperature >= 1.0F?modifier * 1.5F:modifier * 0.5F));
   }

   public float getDamageModifierForBiome(BiomeGenBase biome) {
      float modifier = 0.03F;
      return biome.isEqualTo(BiomeGenBase.hell)?modifier * 2.0F:(biome.isEqualTo(BiomeGenBase.ocean)?modifier * -0.5F:(biome.temperature >= 1.0F?modifier * 1.5F:modifier * 0.5F));
   }
}
