package WayofTime.alchemicalWizardry.common.items.armour;

import WayofTime.alchemicalWizardry.ModItems;
import WayofTime.alchemicalWizardry.common.items.armour.OmegaArmour;
import WayofTime.alchemicalWizardry.common.renderer.model.ModelOmegaEarth;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.UUID;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;

public class OmegaArmourEarth extends OmegaArmour {

   private static IIcon helmetIcon;
   private static IIcon plateIcon;
   private static IIcon leggingsIcon;
   private static IIcon bootsIcon;


   public OmegaArmourEarth(int armorType) {
      super(armorType);
      super.storeYLevel = true;
   }

   public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type) {
      return "alchemicalwizardry:models/armor/OmegaEarth.png";
   }

   @SideOnly(Side.CLIENT)
   public ModelBiped getChestModel() {
      return new ModelOmegaEarth(1.0F, true, true, false, true);
   }

   @SideOnly(Side.CLIENT)
   public ModelBiped getLegsModel() {
      return new ModelOmegaEarth(0.5F, false, false, true, false);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:SheathedItem");
      helmetIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaHelmet_earth");
      plateIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaPlate_earth");
      leggingsIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaLeggings_earth");
      bootsIcon = iconRegister.registerIcon("AlchemicalWizardry:OmegaBoots_earth");
   }

   @SideOnly(Side.CLIENT)
   public IIcon getIconFromDamage(int par1) {
      return this.equals(ModItems.boundHelmetEarth)?helmetIcon:(this.equals(ModItems.boundPlateEarth)?plateIcon:(this.equals(ModItems.boundLeggingsEarth)?leggingsIcon:(this.equals(ModItems.boundBootsEarth)?bootsIcon:super.itemIcon)));
   }

   public Multimap getAttributeModifiers(ItemStack stack) {
      HashMultimap map = HashMultimap.create();
      int yLevel = this.getYLevelStored(stack);
      map.put(SharedMonsterAttributes.knockbackResistance.getAttributeUnlocalizedName(), new AttributeModifier(new UUID(179618L, (long)super.armorType), "Knockback modifier" + super.armorType, (double)this.getKnockbackResist(), 0));
      map.put(SharedMonsterAttributes.maxHealth.getAttributeUnlocalizedName(), new AttributeModifier(new UUID(80532L, (long)super.armorType), "Health modifier" + super.armorType, (double)(this.getDefaultArmourBoost() * this.getHealthBoostModifierForLevel(yLevel)), 1));
      map.put(SharedMonsterAttributes.attackDamage.getAttributeUnlocalizedName(), new AttributeModifier(new UUID(85112L, (long)super.armorType), "Damage modifier" + super.armorType, (double)(this.getDefaultArmourBoost() * this.getDamageModifierForLevel(yLevel)), 2));
      return map;
   }

   public float getKnockbackResist() {
      return 0.25F;
   }

   public float getDefaultArmourBoost() {
      switch(super.armorType) {
      case 0:
         return 2.5F;
      case 1:
         return 4.0F;
      case 2:
         return 3.5F;
      case 3:
         return 2.0F;
      default:
         return 0.25F;
      }
   }

   public float getHealthBoostModifierForLevel(int yLevel) {
      return 0.05F * (yLevel <= 50?1.5F:(yLevel >= 100?-0.5F:0.5F));
   }

   public float getDamageModifierForLevel(int yLevel) {
      return 0.03F * (yLevel <= 50?1.5F:(yLevel >= 100?-0.5F:0.5F));
   }
}
