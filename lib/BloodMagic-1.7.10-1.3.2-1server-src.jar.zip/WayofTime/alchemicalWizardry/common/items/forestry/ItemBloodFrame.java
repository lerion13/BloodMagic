package WayofTime.alchemicalWizardry.common.items.forestry;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;

public class ItemBloodFrame extends EnergyItems {

   public ItemBloodFrame() {
      super.maxStackSize = 1;
      this.setMaxDamage(10);
      this.setEnergyUsed(3000);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.bloodframe.desc"));
      if(par1ItemStack.getTagCompound() != null) {
         par3List.add(StatCollector.translateToLocal("tooltip.owner.currentowner") + " " + par1ItemStack.getTagCompound().getString("ownerName"));
      }

   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:BloodFrame");
   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && par1ItemStack.getItemDamage() > 0) {
         EnergyItems.syphonBatteries(par1ItemStack, par3EntityPlayer, this.getEnergyUsed());
         par1ItemStack.setItemDamage(par1ItemStack.getItemDamage() - 1);
      }

      return par1ItemStack;
   }
}
