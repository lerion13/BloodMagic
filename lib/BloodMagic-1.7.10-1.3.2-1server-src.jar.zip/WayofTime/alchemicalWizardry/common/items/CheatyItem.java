package WayofTime.alchemicalWizardry.common.items;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.items.interfaces.IBindable;
import WayofTime.alchemicalWizardry.api.soulNetwork.LifeEssenceNetwork;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.util.FakePlayer;

public class CheatyItem extends Item implements IBindable {

   public CheatyItem() {
      DamageSource damageSource = DamageSource.generic;
      this.setMaxStackSize(1);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:EnergyBattery");
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.mode.creative"));
      par3List.add(StatCollector.translateToLocal("tooltip.cheatyitem.desc1"));
      par3List.add(StatCollector.translateToLocal("tooltip.cheatyitem.desc2"));
      if(par1ItemStack.getTagCompound() != null) {
         par3List.add(StatCollector.translateToLocal("tooltip.owner.currentowner") + " " + par1ItemStack.getTagCompound().getString("ownerName"));
      }

   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      World world = par3EntityPlayer.worldObj;
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !(par3EntityPlayer instanceof FakePlayer)) {
         if(world != null) {
            double itemTag = par3EntityPlayer.posX;
            double posY = par3EntityPlayer.posY;
            double posZ = par3EntityPlayer.posZ;
            world.playSoundEffect((double)((float)itemTag + 0.5F), (double)((float)posY + 0.5F), (double)((float)posZ + 0.5F), "random.fizz", 0.5F, 2.6F + (world.rand.nextFloat() - world.rand.nextFloat()) * 0.8F);
            SpellHelper.sendIndexedParticleToAllAround(world, itemTag, posY, posZ, 20, world.provider.dimensionId, 4, itemTag, posY, posZ);
         }

         if(par3EntityPlayer.worldObj.isRemote) {
            return par1ItemStack;
         } else {
            NBTTagCompound itemTag1 = par1ItemStack.getTagCompound();
            if(itemTag1 != null && !itemTag1.getString("ownerName").equals("")) {
               if(par3EntityPlayer.isSneaking()) {
                  EnergyItems.setCurrentEssence(itemTag1.getString("ownerName"), 0);
               } else {
                  EnergyItems.addEssenceToMaximum(itemTag1.getString("ownerName"), 1000000, Integer.MAX_VALUE);
               }

               return par1ItemStack;
            } else {
               return par1ItemStack;
            }
         }
      } else {
         return par1ItemStack;
      }
   }

   public int damageItem(ItemStack par1ItemStack, int par2int) {
      if(par2int == 0) {
         return 0;
      } else {
         int before = this.getDamage(par1ItemStack);
         this.setDamage(par1ItemStack, this.getDamage(par1ItemStack) + par2int);
         return par2int - (this.getDamage(par1ItemStack) - before);
      }
   }

   protected void damagePlayer(World world, EntityPlayer player, int damage) {
      if(world != null) {
         double i = player.posX;
         double posY = player.posY;
         double posZ = player.posZ;
         world.playSoundEffect((double)((float)i + 0.5F), (double)((float)posY + 0.5F), (double)((float)posZ + 0.5F), "random.fizz", 0.5F, 2.6F + (world.rand.nextFloat() - world.rand.nextFloat()) * 0.8F);
         float f = 1.0F;
         float f1 = f * 0.6F + 0.4F;
         float f2 = f * f * 0.7F - 0.5F;
         float f3 = f * f * 0.6F - 0.7F;

         for(int l = 0; l < 8; ++l) {
            world.spawnParticle("reddust", i + Math.random() - Math.random(), posY + Math.random() - Math.random(), posZ + Math.random() - Math.random(), (double)f1, (double)f2, (double)f3);
         }
      }

      if(!player.capabilities.isCreativeMode) {
         for(int var15 = 0; var15 < damage; ++var15) {
            player.setHealth(player.getHealth() - 1.0F);
         }
      }

      if(player.getHealth() <= 0.0F) {
         player.inventory.dropAllItems();
      }

   }

   public ItemStack getContainerItem(ItemStack itemStack) {
      return itemStack;
   }

   public boolean hasContainerItem() {
      return true;
   }

   public int getCurrentEssence(ItemStack par1ItemStack) {
      if(par1ItemStack == null) {
         return 0;
      } else {
         NBTTagCompound itemTag = par1ItemStack.getTagCompound();
         if(itemTag != null && !itemTag.getString("ownerName").equals("")) {
            String owner = itemTag.getString("ownerName");
            WorldServer worldSave = MinecraftServer.getServer().worldServers[0];
            LifeEssenceNetwork data = (LifeEssenceNetwork)worldSave.loadItemData(LifeEssenceNetwork.class, owner);
            if(data == null) {
               data = new LifeEssenceNetwork(owner);
               worldSave.setItemData(owner, data);
            }

            int currentEssence = data.currentEssence;
            return currentEssence;
         } else {
            return 0;
         }
      }
   }

   public boolean doesContainerItemLeaveCraftingGrid(ItemStack itemStack) {
      return false;
   }
}
