package WayofTime.alchemicalWizardry.common.items;

import WayofTime.alchemicalWizardry.common.items.EnergyBattery;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;

public class MasterBloodOrb extends EnergyBattery {

   public MasterBloodOrb(int damage) {
      super(damage);
      super.orbLevel = 4;
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:MasterBloodOrb");
   }
}
