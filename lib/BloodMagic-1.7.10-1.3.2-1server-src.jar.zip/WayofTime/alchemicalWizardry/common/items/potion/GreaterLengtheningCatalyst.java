package WayofTime.alchemicalWizardry.common.items.potion;

import WayofTime.alchemicalWizardry.common.items.potion.LengtheningCatalyst;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;

public class GreaterLengtheningCatalyst extends LengtheningCatalyst {

   public GreaterLengtheningCatalyst() {
      super(3);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:GreaterLengtheningCatalyst");
   }
}
