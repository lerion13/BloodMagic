package WayofTime.alchemicalWizardry.common.items.potion;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.common.items.potion.WeakFillingAgent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;

public class StandardFillingAgent extends WeakFillingAgent {

   public StandardFillingAgent() {
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   public int getFilledAmountForPotionNumber(int potionEffects) {
      return potionEffects == 0?8:(potionEffects >= 1 && potionEffects <= 3?(int)(4.0D * (Math.pow(0.5D, (double)(potionEffects - 1)) + 0.009999999776482582D)):0);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:StandardFillingAgent");
   }
}
