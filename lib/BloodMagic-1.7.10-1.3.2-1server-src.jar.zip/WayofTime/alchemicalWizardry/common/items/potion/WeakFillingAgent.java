package WayofTime.alchemicalWizardry.common.items.potion;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.alchemy.AlchemyRecipeRegistry;
import WayofTime.alchemicalWizardry.common.IFillingAgent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.StatCollector;
import org.lwjgl.input.Keyboard;

public class WeakFillingAgent extends Item implements IFillingAgent {

   public WeakFillingAgent() {
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   public int getFilledAmountForPotionNumber(int potionEffects) {
      Random rand = new Random();
      return potionEffects == 0?8:(potionEffects != 1 && potionEffects != 2?0:(rand.nextFloat() > 0.5F?4 - potionEffects:3 - potionEffects));
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:WeakFillingAgent");
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.alchemy.usedinalchemy"));
      if(!Keyboard.isKeyDown(54) && !Keyboard.isKeyDown(42)) {
         par3List.add("-" + StatCollector.translateToLocal("tooltip.alchemy.press") + " " + EnumChatFormatting.BLUE + StatCollector.translateToLocal("tooltip.alchemy.shift") + EnumChatFormatting.GRAY + " " + StatCollector.translateToLocal("tooltip.alchemy.forrecipe") + "-");
      } else {
         ItemStack[] recipe = AlchemyRecipeRegistry.getRecipeForItemStack(par1ItemStack);
         if(recipe != null) {
            par3List.add(EnumChatFormatting.BLUE + StatCollector.translateToLocal("tooltip.alchemy.recipe"));
            ItemStack[] arr$ = recipe;
            int len$ = recipe.length;

            for(int i$ = 0; i$ < len$; ++i$) {
               ItemStack item = arr$[i$];
               if(item != null) {
                  par3List.add("" + item.getDisplayName());
               }
            }
         }
      }

   }
}
