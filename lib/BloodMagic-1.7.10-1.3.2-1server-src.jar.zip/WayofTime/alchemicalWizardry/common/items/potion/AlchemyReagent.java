package WayofTime.alchemicalWizardry.common.items.potion;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.ModItems;
import WayofTime.alchemicalWizardry.api.alchemy.AlchemyRecipeRegistry;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.StatCollector;
import org.lwjgl.input.Keyboard;

public class AlchemyReagent extends Item {

   public AlchemyReagent() {
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      this.setMaxStackSize(64);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      if(this == ModItems.incendium) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:Incendium");
      } else if(this == ModItems.magicales) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:Magicales");
      } else if(this == ModItems.sanctus) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:Sanctus");
      } else if(this == ModItems.aether) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:Aether");
      } else if(this == ModItems.simpleCatalyst) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:SimpleCatalyst");
      } else if(this == ModItems.crepitous) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:Crepitous");
      } else if(this == ModItems.crystallos) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:Crystallos");
      } else if(this == ModItems.terrae) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:Terrae");
      } else if(this == ModItems.aquasalus) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:Aquasalus");
      } else if(this == ModItems.tennebrae) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:Tennebrae");
      }
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.alchemy.usedinalchemy"));
      if(!Keyboard.isKeyDown(54) && !Keyboard.isKeyDown(42)) {
         par3List.add("-" + StatCollector.translateToLocal("tooltip.alchemy.press") + " " + EnumChatFormatting.BLUE + StatCollector.translateToLocal("tooltip.alchemy.shift") + EnumChatFormatting.GRAY + " " + StatCollector.translateToLocal("tooltip.alchemy.forrecipe") + "-");
      } else {
         ItemStack[] recipe = AlchemyRecipeRegistry.getRecipeForItemStack(par1ItemStack);
         if(recipe != null) {
            par3List.add(EnumChatFormatting.BLUE + StatCollector.translateToLocal("tooltip.alchemy.recipe"));
            ItemStack[] arr$ = recipe;
            int len$ = recipe.length;

            for(int i$ = 0; i$ < len$; ++i$) {
               ItemStack item = arr$[i$];
               if(item != null) {
                  par3List.add("" + item.getDisplayName());
               }
            }
         }
      }

   }
}
