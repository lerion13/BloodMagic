package WayofTime.alchemicalWizardry.common.items.potion;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.alchemy.AlchemyPotionHelper;
import com.google.common.collect.HashMultimap;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityPotion;
import net.minecraft.init.Items;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;

public class AlchemyFlask extends Item {

   private int maxPotionAmount = 20;


   public AlchemyFlask() {
      this.setMaxDamage(8);
      this.setMaxStackSize(1);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:PotionFlask");
   }

   public static ArrayList getEffects(ItemStack par1ItemStack) {
      if(par1ItemStack.hasTagCompound() && par1ItemStack.getTagCompound().hasKey("CustomFlaskEffects")) {
         ArrayList arraylist = new ArrayList();
         NBTTagList nbttaglist = par1ItemStack.getTagCompound().getTagList("CustomFlaskEffects", 10);

         for(int i = 0; i < nbttaglist.tagCount(); ++i) {
            NBTTagCompound nbttagcompound = nbttaglist.getCompoundTagAt(i);
            arraylist.add(AlchemyPotionHelper.readEffectFromNBT(nbttagcompound));
         }

         return arraylist;
      } else {
         return null;
      }
   }

   public static ArrayList getPotionEffects(ItemStack par1ItemStack) {
      ArrayList list = getEffects(par1ItemStack);
      if(list == null) {
         return null;
      } else {
         ArrayList newList = new ArrayList();
         Iterator i$ = list.iterator();

         while(i$.hasNext()) {
            AlchemyPotionHelper aph = (AlchemyPotionHelper)i$.next();
            newList.add(aph.getPotionEffect());
         }

         return newList;
      }
   }

   public static void setEffects(ItemStack par1ItemStack, List list) {
      NBTTagCompound itemTag = par1ItemStack.getTagCompound();
      if(itemTag == null) {
         par1ItemStack.setTagCompound(new NBTTagCompound());
      }

      NBTTagList nbttaglist = new NBTTagList();
      Iterator i$ = list.iterator();

      while(i$.hasNext()) {
         AlchemyPotionHelper aph = (AlchemyPotionHelper)i$.next();
         nbttaglist.appendTag(AlchemyPotionHelper.setEffectToNBT(aph));
      }

      par1ItemStack.getTagCompound().setTag("CustomFlaskEffects", nbttaglist);
   }

   public ItemStack onEaten(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(!par3EntityPlayer.capabilities.isCreativeMode) {
         par1ItemStack.setItemDamage(par1ItemStack.getItemDamage() + 1);
      }

      if(!par2World.isRemote) {
         ArrayList list = getEffects(par1ItemStack);
         if(list != null) {
            Iterator i$ = list.iterator();

            while(i$.hasNext()) {
               AlchemyPotionHelper aph = (AlchemyPotionHelper)i$.next();
               PotionEffect pe = aph.getPotionEffect();
               if(pe != null) {
                  par3EntityPlayer.addPotionEffect(pe);
               }
            }
         }
      }

      return par1ItemStack;
   }

   public int getMaxItemUseDuration(ItemStack par1ItemStack) {
      return 32;
   }

   public EnumAction getItemUseAction(ItemStack par1ItemStack) {
      return this.isPotionThrowable(par1ItemStack)?EnumAction.none:EnumAction.drink;
   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(par1ItemStack.getItemDamage() < par1ItemStack.getMaxDamage()) {
         if(this.isPotionThrowable(par1ItemStack)) {
            if(!par2World.isRemote) {
               EntityPotion entityPotion = this.getEntityPotion(par1ItemStack, par2World, par3EntityPlayer);
               if(entityPotion != null) {
                  float velocityChange = 2.0F;
                  entityPotion.motionX *= (double)velocityChange;
                  entityPotion.motionY *= (double)velocityChange;
                  entityPotion.motionZ *= (double)velocityChange;
                  par2World.spawnEntityInWorld(entityPotion);
                  par1ItemStack.setItemDamage(par1ItemStack.getItemDamage() + 1);
               }
            }

            return par1ItemStack;
         }

         par3EntityPlayer.setItemInUse(par1ItemStack, this.getMaxItemUseDuration(par1ItemStack));
      }

      return par1ItemStack;
   }

   public void setConcentrationOfPotion(ItemStack par1ItemStack, int potionID, int concentration) {
      ArrayList list = getEffects(par1ItemStack);
      if(list != null) {
         Iterator i$ = list.iterator();

         while(i$.hasNext()) {
            AlchemyPotionHelper aph = (AlchemyPotionHelper)i$.next();
            if(aph.getPotionID() == potionID) {
               aph.setConcentration(concentration);
               break;
            }
         }

         setEffects(par1ItemStack, list);
      }

   }

   public void setDurationFactorOfPotion(ItemStack par1ItemStack, int potionID, int durationFactor) {
      ArrayList list = getEffects(par1ItemStack);
      if(list != null) {
         Iterator i$ = list.iterator();

         while(i$.hasNext()) {
            AlchemyPotionHelper aph = (AlchemyPotionHelper)i$.next();
            if(aph.getPotionID() == potionID) {
               aph.setDurationFactor(durationFactor);
               break;
            }
         }

         setEffects(par1ItemStack, list);
      }

   }

   public boolean hasPotionEffect(ItemStack par1ItemStack, int potionID) {
      return false;
   }

   public int getNumberOfPotionEffects(ItemStack par1ItemStack) {
      return getEffects(par1ItemStack) != null?getEffects(par1ItemStack).size():0;
   }

   public boolean addPotionEffect(ItemStack par1ItemStack, int potionID, int tickDuration) {
      int i = 0;
      ArrayList list = getEffects(par1ItemStack);
      if(list != null) {
         for(Iterator i$ = list.iterator(); i$.hasNext(); ++i) {
            AlchemyPotionHelper aph = (AlchemyPotionHelper)i$.next();
            if(aph.getPotionID() == potionID) {
               return false;
            }
         }

         list.add(new AlchemyPotionHelper(potionID, tickDuration, 0, 0));
         setEffects(par1ItemStack, list);
         return true;
      } else {
         list = new ArrayList();
         list.add(new AlchemyPotionHelper(potionID, tickDuration, 0, 0));
         setEffects(par1ItemStack, list);
         return true;
      }
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(EnumChatFormatting.BLUE + StatCollector.translateToLocal("tooltip.alchemyflask.swigsleft") + " " + (par1ItemStack.getMaxDamage() - par1ItemStack.getItemDamage()) + "/" + par1ItemStack.getMaxDamage());
      if(this.isPotionThrowable(par1ItemStack)) {
         par3List.add(EnumChatFormatting.BLUE + StatCollector.translateToLocal("tooltip.alchemyflask.caution"));
      }

      ArrayList list1 = getPotionEffects(par1ItemStack);
      HashMultimap hashmultimap = HashMultimap.create();
      Iterator iterator;
      if(list1 != null && !list1.isEmpty()) {
         iterator = list1.iterator();

         while(iterator.hasNext()) {
            PotionEffect entry12 = (PotionEffect)iterator.next();
            String attributemodifier2 = StatCollector.translateToLocal(entry12.getEffectName()).trim();
            Potion d0 = Potion.potionTypes[entry12.getPotionID()];
            Map map = d0.func_111186_k();
            if(map != null && map.size() > 0) {
               Iterator d1 = map.entrySet().iterator();

               while(d1.hasNext()) {
                  Entry entry = (Entry)d1.next();
                  AttributeModifier attributemodifier = (AttributeModifier)entry.getValue();
                  AttributeModifier attributemodifier1 = new AttributeModifier(attributemodifier.getName(), d0.func_111183_a(entry12.getAmplifier(), attributemodifier), attributemodifier.getOperation());
                  hashmultimap.put(((IAttribute)entry.getKey()).getAttributeUnlocalizedName(), attributemodifier1);
               }
            }

            if(entry12.getAmplifier() > 0) {
               attributemodifier2 = attributemodifier2 + " " + StatCollector.translateToLocal("potion.potency." + entry12.getAmplifier()).trim();
            }

            if(entry12.getDuration() > 20) {
               attributemodifier2 = attributemodifier2 + " (" + Potion.getDurationString(entry12) + ")";
            }

            if(d0.isBadEffect()) {
               par3List.add(EnumChatFormatting.RED + attributemodifier2);
            } else {
               par3List.add(EnumChatFormatting.GRAY + attributemodifier2);
            }
         }
      } else {
         String entry1 = StatCollector.translateToLocal("potion.empty").trim();
         par3List.add(EnumChatFormatting.GRAY + entry1);
      }

      if(!hashmultimap.isEmpty()) {
         par3List.add("");
         par3List.add(EnumChatFormatting.DARK_PURPLE + StatCollector.translateToLocal("potion.effects.whenDrank"));
         iterator = hashmultimap.entries().iterator();

         while(iterator.hasNext()) {
            Entry entry11 = (Entry)iterator.next();
            AttributeModifier attributemodifier21 = (AttributeModifier)entry11.getValue();
            double d01 = attributemodifier21.getAmount();
            double d11;
            if(attributemodifier21.getOperation() != 1 && attributemodifier21.getOperation() != 2) {
               d11 = attributemodifier21.getAmount();
            } else {
               d11 = attributemodifier21.getAmount() * 100.0D;
            }

            if(d01 > 0.0D) {
               par3List.add(EnumChatFormatting.BLUE + StatCollector.translateToLocalFormatted("attribute.modifier.plus." + attributemodifier21.getOperation(), new Object[]{ItemStack.field_111284_a.format(d11), StatCollector.translateToLocal("attribute.name." + (String)entry11.getKey())}));
            } else if(d01 < 0.0D) {
               d11 *= -1.0D;
               par3List.add(EnumChatFormatting.RED + StatCollector.translateToLocalFormatted("attribute.modifier.take." + attributemodifier21.getOperation(), new Object[]{ItemStack.field_111284_a.format(d11), StatCollector.translateToLocal("attribute.name." + (String)entry11.getKey())}));
            }
         }
      }

   }

   public boolean isPotionThrowable(ItemStack par1ItemStack) {
      return par1ItemStack.hasTagCompound() && par1ItemStack.getTagCompound().getBoolean("throwable");
   }

   public void setIsPotionThrowable(boolean flag, ItemStack par1ItemStack) {
      if(!par1ItemStack.hasTagCompound()) {
         par1ItemStack.setTagCompound(new NBTTagCompound());
      }

      par1ItemStack.getTagCompound().setBoolean("throwable", flag);
   }

   public EntityPotion getEntityPotion(ItemStack par1ItemStack, World worldObj, EntityLivingBase entityLivingBase) {
      ItemStack potionStack = new ItemStack(Items.potionitem, 1, 0);
      potionStack.setTagCompound(new NBTTagCompound());
      ArrayList potionList = getPotionEffects(par1ItemStack);
      if(potionList == null) {
         return null;
      } else {
         NBTTagList nbttaglist = new NBTTagList();
         Iterator entityPotion = potionList.iterator();

         while(entityPotion.hasNext()) {
            PotionEffect pe = (PotionEffect)entityPotion.next();
            NBTTagCompound d = new NBTTagCompound();
            d.setByte("Id", (byte)pe.getPotionID());
            d.setByte("Amplifier", (byte)pe.getAmplifier());
            d.setInteger("Duration", pe.getDuration());
            d.setBoolean("Ambient", pe.getIsAmbient());
            nbttaglist.appendTag(d);
         }

         potionStack.getTagCompound().setTag("CustomPotionEffects", nbttaglist);
         EntityPotion entityPotion1 = new EntityPotion(worldObj, entityLivingBase, potionStack);
         return entityPotion1;
      }
   }
}
