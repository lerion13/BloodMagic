package WayofTime.alchemicalWizardry.common.items.potion;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.alchemy.AlchemyRecipeRegistry;
import WayofTime.alchemicalWizardry.common.ICatalyst;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.StatCollector;
import org.lwjgl.input.Keyboard;

public class LengtheningCatalyst extends Item implements ICatalyst {

   private int catalystStrength;


   public LengtheningCatalyst(int catalystStrength) {
      this.catalystStrength = catalystStrength;
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   public int getCatalystLevel() {
      return this.catalystStrength;
   }

   public boolean isConcentration() {
      return false;
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.alchemy.usedinalchemy"));
      if(!Keyboard.isKeyDown(54) && !Keyboard.isKeyDown(42)) {
         par3List.add("-" + StatCollector.translateToLocal("tooltip.alchemy.press") + " " + EnumChatFormatting.BLUE + StatCollector.translateToLocal("tooltip.alchemy.shift") + EnumChatFormatting.GRAY + " " + StatCollector.translateToLocal("tooltip.alchemy.forrecipe") + "-");
      } else {
         ItemStack[] recipe = AlchemyRecipeRegistry.getRecipeForItemStack(par1ItemStack);
         if(recipe != null) {
            par3List.add(EnumChatFormatting.BLUE + StatCollector.translateToLocal("tooltip.alchemy.recipe"));
            ItemStack[] arr$ = recipe;
            int len$ = recipe.length;

            for(int i$ = 0; i$ < len$; ++i$) {
               ItemStack item = arr$[i$];
               if(item != null) {
                  par3List.add("" + item.getDisplayName());
               }
            }
         }
      }

   }
}
