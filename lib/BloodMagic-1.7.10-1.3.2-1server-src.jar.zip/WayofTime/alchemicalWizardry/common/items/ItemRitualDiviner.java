package WayofTime.alchemicalWizardry.common.items;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.ModBlocks;
import WayofTime.alchemicalWizardry.api.items.interfaces.IRitualDiviner;
import WayofTime.alchemicalWizardry.api.rituals.IRitualStone;
import WayofTime.alchemicalWizardry.api.rituals.RitualComponent;
import WayofTime.alchemicalWizardry.api.rituals.Rituals;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import WayofTime.alchemicalWizardry.common.tileEntity.TEMasterStone;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;
import org.lwjgl.input.Keyboard;

public class ItemRitualDiviner extends EnergyItems implements IRitualDiviner {

   private int maxMetaData;


   public ItemRitualDiviner() {
      super.maxStackSize = 1;
      this.setEnergyUsed(100);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      this.maxMetaData = 4;
      super.hasSubtypes = true;
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:RitualDiviner");
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.ritualdiviner.desc"));
      if(this.getMaxRuneDisplacement(par1ItemStack) == 1) {
         par3List.add(StatCollector.translateToLocal("tooltip.ritualdiviner.canplace"));
      } else if(this.getMaxRuneDisplacement(par1ItemStack) >= 2) {
         par3List.add(StatCollector.translateToLocal("tooltip.ritualdiviner.canplacedawn"));
      } else {
         par3List.add(StatCollector.translateToLocal("tooltip.ritualdiviner.cannotplace"));
      }

      par3List.add(StatCollector.translateToLocal("tooltip.ritualdiviner.ritualtunedto") + " " + this.getNameForDirection(this.getDirection(par1ItemStack)));
      boolean sneaking = Keyboard.isKeyDown(54) || Keyboard.isKeyDown(42);
      if(sneaking) {
         if(par1ItemStack.getTagCompound() != null) {
            String ritualID = this.getCurrentRitual(par1ItemStack);
            par3List.add(StatCollector.translateToLocal("tooltip.owner.currentowner") + " " + par1ItemStack.getTagCompound().getString("ownerName"));
            par3List.add(StatCollector.translateToLocal("tooltip.alchemy.ritualid") + " " + ritualID);
            List ritualList = Rituals.getRitualList(this.getCurrentRitual(par1ItemStack));
            if(ritualList == null) {
               return;
            }

            int blankStones = 0;
            int airStones = 0;
            int waterStones = 0;
            int fireStones = 0;
            int earthStones = 0;
            int duskStones = 0;
            int dawnStones = 0;
            Iterator i$ = ritualList.iterator();

            while(i$.hasNext()) {
               RitualComponent rc = (RitualComponent)i$.next();
               switch(rc.getStoneType()) {
               case 0:
                  ++blankStones;
                  break;
               case 1:
                  ++waterStones;
                  break;
               case 2:
                  ++fireStones;
                  break;
               case 3:
                  ++earthStones;
                  break;
               case 4:
                  ++airStones;
                  break;
               case 5:
                  ++duskStones;
                  break;
               case 6:
                  ++dawnStones;
               }
            }

            par3List.add(StatCollector.translateToLocal("tooltip.ritualdiviner.blankstones") + " " + blankStones);
            par3List.add(EnumChatFormatting.AQUA + StatCollector.translateToLocal("tooltip.ritualdiviner.airstones") + " " + airStones);
            par3List.add(EnumChatFormatting.BLUE + StatCollector.translateToLocal("tooltip.ritualdiviner.waterstones") + " " + waterStones);
            par3List.add(EnumChatFormatting.RED + StatCollector.translateToLocal("tooltip.ritualdiviner.firestones") + " " + fireStones);
            par3List.add(EnumChatFormatting.DARK_GREEN + StatCollector.translateToLocal("tooltip.ritualdiviner.earthstones") + " " + earthStones);
            par3List.add(EnumChatFormatting.BOLD + StatCollector.translateToLocal("tooltip.ritualdiviner.duskstones") + " " + duskStones);
            par3List.add(EnumChatFormatting.GOLD + StatCollector.translateToLocal("tooltip.ritualdiviner.dawnstones") + " " + dawnStones);
         }
      } else {
         par3List.add(EnumChatFormatting.AQUA + "-" + StatCollector.translateToLocal("tooltip.ritualdiviner.moreinfo") + "-");
      }

   }

   public String getItemStackDisplayName(ItemStack par1ItemStack) {
      if(par1ItemStack.getTagCompound() != null) {
         String ritualID = this.getCurrentRitual(par1ItemStack);
         return ritualID.equals("")?super.getItemStackDisplayName(par1ItemStack):"Ritual: " + Rituals.getNameOfRitual(ritualID);
      } else {
         return super.getItemStackDisplayName(par1ItemStack);
      }
   }

   public boolean onItemUse(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, World par3World, int par4, int par5, int par6, int par7, float par8, float par9, float par10) {
      int direction = this.getDirection(par1ItemStack);
      if(!EnergyItems.checkAndSetItemOwner(par1ItemStack, par2EntityPlayer)) {
         return false;
      } else {
         ItemStack[] playerInventory = par2EntityPlayer.inventory.mainInventory;
         TileEntity tileEntity = par3World.getTileEntity(par4, par5, par6);
         if(tileEntity instanceof TEMasterStone) {
            TEMasterStone masterStone = (TEMasterStone)tileEntity;
            List ritualList = Rituals.getRitualList(this.getCurrentRitual(par1ItemStack));
            if(ritualList == null) {
               return false;
            }

            int playerInvRitualStoneLocation = -1;

            for(int i$ = 0; i$ < playerInventory.length; ++i$) {
               if(playerInventory[i$] != null && (new ItemStack(ModBlocks.ritualStone)).isItemEqual(playerInventory[i$])) {
                  playerInvRitualStoneLocation = i$;
                  break;
               }
            }

            Iterator var21 = ritualList.iterator();

            while(var21.hasNext()) {
               RitualComponent rc = (RitualComponent)var21.next();
               if(par3World.isAirBlock(par4 + rc.getX(direction), par5 + rc.getY(), par6 + rc.getZ(direction))) {
                  if(playerInvRitualStoneLocation >= 0 || par2EntityPlayer.capabilities.isCreativeMode) {
                     if(rc.getStoneType() > this.maxMetaData + this.getMaxRuneDisplacement(par1ItemStack)) {
                        par3World.playAuxSFX(200, par4, par5 + 1, par6, 0);
                        return true;
                     }

                     if(!par2EntityPlayer.capabilities.isCreativeMode) {
                        par2EntityPlayer.inventory.decrStackSize(playerInvRitualStoneLocation, 1);
                     }

                     if(EnergyItems.syphonBatteries(par1ItemStack, par2EntityPlayer, this.getEnergyUsed())) {
                        par3World.setBlock(par4 + rc.getX(direction), par5 + rc.getY(), par6 + rc.getZ(direction), ModBlocks.ritualStone, rc.getStoneType(), 3);
                        if(par3World.isRemote) {
                           par3World.playAuxSFX(2005, par4, par5 + 1, par6, 0);
                           return true;
                        }
                     }

                     return true;
                  }
               } else {
                  Block block = par3World.getBlock(par4 + rc.getX(direction), par5 + rc.getY(), par6 + rc.getZ(direction));
                  if(block != ModBlocks.ritualStone) {
                     par3World.playAuxSFX(0, par4, par5 + 1, par6, 0);
                     return true;
                  }

                  int metadata = par3World.getBlockMetadata(par4 + rc.getX(direction), par5 + rc.getY(), par6 + rc.getZ(direction));
                  if(metadata != rc.getStoneType() && EnergyItems.syphonBatteries(par1ItemStack, par2EntityPlayer, this.getEnergyUsed())) {
                     if(rc.getStoneType() > this.maxMetaData + this.getMaxRuneDisplacement(par1ItemStack)) {
                        par3World.playAuxSFX(200, par4, par5 + 1, par6, 0);
                        return true;
                     }

                     par3World.setBlockMetadataWithNotify(par4 + rc.getX(direction), par5 + rc.getY(), par6 + rc.getZ(direction), rc.getStoneType(), 3);
                     return true;
                  }
               }
            }
         } else if(!(par3World.getBlock(par4, par5, par6) instanceof IRitualStone) && !par2EntityPlayer.isSneaking()) {
            if(par3World.isRemote) {
               return false;
            }

            this.cycleDirection(par1ItemStack);
            par2EntityPlayer.addChatComponentMessage(new ChatComponentText(StatCollector.translateToLocal("tooltip.ritualdiviner.ritualtunedto") + " " + this.getNameForDirection(this.getDirection(par1ItemStack))));
            return true;
         }

         return false;
      }
   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && par3EntityPlayer.isSneaking()) {
         this.rotateRituals(par2World, par3EntityPlayer, par1ItemStack, true);
      }

      return par1ItemStack;
   }

   public boolean onEntitySwing(EntityLivingBase entityLiving, ItemStack stack) {
      if(entityLiving instanceof EntityPlayer) {
         EntityPlayer player = (EntityPlayer)entityLiving;
         if(!EnergyItems.checkAndSetItemOwner(stack, player)) {
            return true;
         }

         if(!player.isSwingInProgress && player.isSneaking()) {
            this.rotateRituals(player.worldObj, player, stack, false);
         }
      }

      return false;
   }

   public void rotateRituals(World world, EntityPlayer player, ItemStack stack, boolean next) {
      int maxRitualID = Rituals.getNumberOfRituals();
      String currentRitualID = this.getCurrentRitual(stack);
      this.setCurrentRitual(stack, next?Rituals.getNextRitualKey(currentRitualID):Rituals.getPreviousRitualKey(currentRitualID));
      if(world.isRemote) {
         ChatComponentText chatmessagecomponent = new ChatComponentText(StatCollector.translateToLocal("message.ritual.currentritual") + " " + Rituals.getNameOfRitual(this.getCurrentRitual(stack)));
         player.addChatComponentMessage(chatmessagecomponent);
      }

   }

   public String getCurrentRitual(ItemStack par1ItemStack) {
      if(par1ItemStack.getTagCompound() == null) {
         par1ItemStack.setTagCompound(new NBTTagCompound());
      }

      return par1ItemStack.getTagCompound().getString("ritualID");
   }

   public void setCurrentRitual(ItemStack par1ItemStack, String ritualID) {
      if(par1ItemStack.getTagCompound() == null) {
         par1ItemStack.setTagCompound(new NBTTagCompound());
      }

      par1ItemStack.getTagCompound().setString("ritualID", ritualID);
   }

   public int getMaxRuneDisplacement(ItemStack par1ItemStack) {
      return par1ItemStack.getItemDamage();
   }

   public void setMaxRuneDisplacement(ItemStack par1ItemStack, int displacement) {
      par1ItemStack.setItemDamage(displacement);
   }

   @SideOnly(Side.CLIENT)
   public void getSubItems(Item id, CreativeTabs creativeTab, List list) {
      list.add(new ItemStack(id));
      ItemStack duskRitualDivinerStack = new ItemStack(id);
      this.setMaxRuneDisplacement(duskRitualDivinerStack, 1);
      list.add(duskRitualDivinerStack);
      ItemStack dawnRitualDivinerStack = new ItemStack(id);
      this.setMaxRuneDisplacement(dawnRitualDivinerStack, 2);
      list.add(dawnRitualDivinerStack);
   }

   public int getDirection(ItemStack itemStack) {
      if(itemStack.getTagCompound() == null) {
         itemStack.setTagCompound(new NBTTagCompound());
      }

      return itemStack.getTagCompound().getInteger("direction");
   }

   public void setDirection(ItemStack itemStack, int direction) {
      if(itemStack.getTagCompound() == null) {
         itemStack.setTagCompound(new NBTTagCompound());
      }

      itemStack.getTagCompound().setInteger("direction", direction);
   }

   public int cycleDirection(ItemStack itemStack) {
      int direction = this.getDirection(itemStack);
      if(direction < 4) {
         direction = Math.max(1, direction + 1);
      } else {
         direction = 1;
      }

      this.setDirection(itemStack, direction);
      return direction;
   }

   public String getNameForDirection(int direction) {
      String dir = "";
      switch(direction) {
      case 0:
      case 1:
         dir = StatCollector.translateToLocal("message.ritual.side.north");
         break;
      case 2:
         dir = StatCollector.translateToLocal("message.ritual.side.east");
         break;
      case 3:
         dir = StatCollector.translateToLocal("message.ritual.side.south");
         break;
      case 4:
         dir = StatCollector.translateToLocal("message.ritual.side.west");
      }

      return dir;
   }
}
