package WayofTime.alchemicalWizardry.common.items;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.ModItems;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.StatCollector;

public class AWBaseItems extends Item {

   public AWBaseItems() {
      this.setMaxStackSize(64);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   public void registerIcons(IIconRegister iconRegister) {
      if(this.equals(ModItems.blankSlate)) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:BlankSlate");
      } else if(this.equals(ModItems.reinforcedSlate)) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:ReinforcedSlate");
      } else if(this.equals(ModItems.imbuedSlate)) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:InfusedSlate");
      } else if(this.equals(ModItems.demonicSlate)) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:DemonSlate");
      }

   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.infusedstone.desc1"));
      par3List.add(StatCollector.translateToLocal("tooltip.infusedstone.desc2"));
   }
}
