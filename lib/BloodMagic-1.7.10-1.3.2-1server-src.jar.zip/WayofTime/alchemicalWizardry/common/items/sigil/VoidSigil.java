package WayofTime.alchemicalWizardry.common.items.sigil;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.items.interfaces.ArmourUpgrade;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.MaterialLiquid;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBucket;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.StatCollector;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.ForgeDirection;
import net.minecraftforge.event.entity.player.FillBucketEvent;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.IFluidHandler;

public class VoidSigil extends ItemBucket implements ArmourUpgrade {

   private int isFull;
   private int energyUsed;


   public VoidSigil() {
      super((Block)null);
      super.maxStackSize = 1;
      this.setEnergyUsed(50);
      this.isFull = 0;
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:VoidSigil");
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.voidsigil.desc"));
      if(par1ItemStack.getTagCompound() != null) {
         par3List.add(StatCollector.translateToLocal("tooltip.owner.currentowner") + " " + par1ItemStack.getTagCompound().getString("ownerName"));
      }

   }

   public ItemStack getContainerItem(ItemStack itemStack) {
      ItemStack copiedStack = itemStack.copy();
      copiedStack.setItemDamage(copiedStack.getItemDamage() + this.getEnergyUsed());
      copiedStack.stackSize = 1;
      return copiedStack;
   }

   protected void setEnergyUsed(int par1int) {
      this.energyUsed = par1int;
   }

   protected int getEnergyUsed() {
      return this.energyUsed;
   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         float f = 1.0F;
         double var10000 = par3EntityPlayer.prevPosX + (par3EntityPlayer.posX - par3EntityPlayer.prevPosX) * (double)f;
         double d1 = par3EntityPlayer.prevPosY + (par3EntityPlayer.posY - par3EntityPlayer.prevPosY) * (double)f + 1.62D - (double)par3EntityPlayer.yOffset;
         var10000 = par3EntityPlayer.prevPosZ + (par3EntityPlayer.posZ - par3EntityPlayer.prevPosZ) * (double)f;
         boolean flag = this.isFull == 0;
         MovingObjectPosition movingobjectposition = this.getMovingObjectPositionFromPlayer(par2World, par3EntityPlayer, flag);
         if(movingobjectposition == null) {
            return par1ItemStack;
         } else {
            FillBucketEvent event = new FillBucketEvent(par3EntityPlayer, par1ItemStack, par2World, movingobjectposition);
            if(MinecraftForge.EVENT_BUS.post(event)) {
               return par1ItemStack;
            } else {
               if(movingobjectposition.typeOfHit == MovingObjectType.BLOCK) {
                  int i = movingobjectposition.blockX;
                  int j = movingobjectposition.blockY;
                  int k = movingobjectposition.blockZ;
                  if(!par2World.canMineBlock(par3EntityPlayer, i, j, k)) {
                     return par1ItemStack;
                  }

                  TileEntity tile = par2World.getTileEntity(i, j, k);
                  if(tile instanceof IFluidHandler) {
                     FluidStack amount = ((IFluidHandler)tile).drain(ForgeDirection.getOrientation(movingobjectposition.sideHit), 1000, false);
                     if(amount != null && amount.amount > 0 && EnergyItems.syphonBatteries(par1ItemStack, par3EntityPlayer, this.getEnergyUsed())) {
                        ((IFluidHandler)tile).drain(ForgeDirection.getOrientation(movingobjectposition.sideHit), 1000, true);
                     }

                     return par1ItemStack;
                  }

                  if(this.isFull == 0) {
                     if(!par3EntityPlayer.canPlayerEdit(i, j, k, movingobjectposition.sideHit, par1ItemStack)) {
                        return par1ItemStack;
                     }

                     if(par2World.getBlock(i, j, k).getMaterial() instanceof MaterialLiquid && EnergyItems.syphonBatteries(par1ItemStack, par3EntityPlayer, this.getEnergyUsed())) {
                        par2World.setBlockToAir(i, j, k);
                     }
                  }
               }

               return par1ItemStack;
            }
         }
      } else {
         return par1ItemStack;
      }
   }

   public boolean tryPlaceContainedLiquid(World par1World, double par2, double par4, double par6, int par8, int par9, int par10) {
      return false;
   }

   public void onArmourUpdate(World world, EntityPlayer player, ItemStack thisItemStack) {}

   public boolean isUpgrade() {
      return true;
   }

   public int getEnergyForTenSeconds() {
      return 25;
   }
}
