package WayofTime.alchemicalWizardry.common.items.sigil;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.items.interfaces.ArmourUpgrade;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import WayofTime.alchemicalWizardry.common.tileEntity.TESpectralContainer;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IIcon;
import net.minecraft.util.StatCollector;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class ItemSigilOfSupression extends EnergyItems implements ArmourUpgrade {

   private static IIcon activeIcon;
   private static IIcon passiveIcon;
   private int tickDelay = 200;
   private int radius = 5;
   private int refresh = 100;


   public ItemSigilOfSupression() {
      super.maxStackSize = 1;
      this.setEnergyUsed(400);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.sigilofsupression.desc"));
      if(par1ItemStack.getTagCompound() != null) {
         if(par1ItemStack.getTagCompound().getBoolean("isActive")) {
            par3List.add(StatCollector.translateToLocal("tooltip.sigil.state.activated"));
         } else {
            par3List.add(StatCollector.translateToLocal("tooltip.sigil.state.deactivated"));
         }

         par3List.add(StatCollector.translateToLocal("tooltip.owner.currentowner") + " " + par1ItemStack.getTagCompound().getString("ownerName"));
      }

   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:SigilOfSupression_deactivated");
      activeIcon = iconRegister.registerIcon("AlchemicalWizardry:SigilOfSupression_activated");
      passiveIcon = iconRegister.registerIcon("AlchemicalWizardry:SigilOfSupression_deactivated");
   }

   public IIcon getIcon(ItemStack stack, int renderPass, EntityPlayer player, ItemStack usingItem, int useRemaining) {
      if(stack.getTagCompound() == null) {
         stack.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tag = stack.getTagCompound();
      return tag.getBoolean("isActive")?activeIcon:passiveIcon;
   }

   @SideOnly(Side.CLIENT)
   public IIcon getIconFromDamage(int par1) {
      return par1 == 1?activeIcon:passiveIcon;
   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !SpellHelper.isFakePlayer(par2World, par3EntityPlayer)) {
         if(par3EntityPlayer.isSneaking()) {
            return par1ItemStack;
         } else {
            if(par1ItemStack.getTagCompound() == null) {
               par1ItemStack.setTagCompound(new NBTTagCompound());
            }

            NBTTagCompound tag = par1ItemStack.getTagCompound();
            tag.setBoolean("isActive", !tag.getBoolean("isActive"));
            if(tag.getBoolean("isActive")) {
               par1ItemStack.setItemDamage(1);
               tag.setInteger("worldTimeDelay", (int)(par2World.getWorldTime() - 1L) % this.tickDelay);
               if(!par3EntityPlayer.capabilities.isCreativeMode && !EnergyItems.syphonBatteries(par1ItemStack, par3EntityPlayer, this.getEnergyUsed())) {
                  tag.setBoolean("isActive", false);
               }
            } else {
               par1ItemStack.setItemDamage(par1ItemStack.getMaxDamage());
            }

            return par1ItemStack;
         }
      } else {
         return par1ItemStack;
      }
   }

   public void onUpdate(ItemStack par1ItemStack, World par2World, Entity par3Entity, int par4, boolean par5) {
      if(par3Entity instanceof EntityPlayer) {
         if(!SpellHelper.isFakePlayer(par2World, (EntityPlayer)par3Entity)) {
            EntityPlayer par3EntityPlayer = (EntityPlayer)par3Entity;
            if(par1ItemStack.getTagCompound() == null) {
               par1ItemStack.setTagCompound(new NBTTagCompound());
            }

            if(par1ItemStack.getTagCompound().getBoolean("isActive") && !par2World.isRemote) {
               Vec3 blockVec = SpellHelper.getEntityBlockVector(par3EntityPlayer);
               int x = (int)blockVec.xCoord;
               int y = (int)blockVec.yCoord;
               int z = (int)blockVec.zCoord;

               for(int i = -this.radius; i <= this.radius; ++i) {
                  for(int j = -this.radius; j <= this.radius; ++j) {
                     for(int k = -this.radius; k <= this.radius; ++k) {
                        if((float)(i * i + j * j + k * k) < ((float)this.radius + 0.5F) * ((float)this.radius + 0.5F)) {
                           Block block = par2World.getBlock(x + i, y + j, z + k);
                           if(SpellHelper.isBlockFluid(block)) {
                              if(par2World.getTileEntity(x + i, y + j, z + k) != null) {
                                 par2World.setBlockToAir(x + i, y + j, z + k);
                              }

                              TESpectralContainer.createSpectralBlockAtLocation(par2World, x + i, y + j, z + k, this.refresh);
                           } else {
                              TileEntity tile = par2World.getTileEntity(x + i, y + j, z + k);
                              if(tile instanceof TESpectralContainer) {
                                 ((TESpectralContainer)tile).resetDuration(this.refresh);
                              }
                           }
                        }
                     }
                  }
               }
            }

            if(par2World.getWorldTime() % 200L == (long)par1ItemStack.getTagCompound().getInteger("worldTimeDelay") && par1ItemStack.getTagCompound().getBoolean("isActive") && !par3EntityPlayer.capabilities.isCreativeMode && !EnergyItems.syphonBatteries(par1ItemStack, par3EntityPlayer, this.getEnergyUsed())) {
               par1ItemStack.getTagCompound().setBoolean("isActive", false);
            }

         }
      }
   }

   public void onArmourUpdate(World world, EntityPlayer player, ItemStack thisItemStack) {
      Vec3 blockVec = SpellHelper.getEntityBlockVector(player);
      int x = (int)blockVec.xCoord;
      int y = (int)blockVec.yCoord;
      int z = (int)blockVec.zCoord;

      for(int i = -this.radius; i <= this.radius; ++i) {
         for(int j = -this.radius; j <= this.radius; ++j) {
            for(int k = -this.radius; k <= this.radius; ++k) {
               if((float)(i * i + j * j + k * k) < ((float)this.radius + 0.5F) * ((float)this.radius + 0.5F)) {
                  Block block = world.getBlock(x + i, y + j, z + k);
                  if(SpellHelper.isBlockFluid(block)) {
                     if(world.getTileEntity(x + i, y + j, z + k) != null) {
                        world.setBlockToAir(x + i, y + j, z + k);
                     }

                     TESpectralContainer.createSpectralBlockAtLocation(world, x + i, y + j, z + k, this.refresh);
                  } else {
                     TileEntity tile = world.getTileEntity(x + i, y + j, z + k);
                     if(tile instanceof TESpectralContainer) {
                        ((TESpectralContainer)tile).resetDuration(this.refresh);
                     }
                  }
               }
            }
         }
      }

   }

   public boolean isUpgrade() {
      return true;
   }

   public int getEnergyForTenSeconds() {
      return 200;
   }
}
