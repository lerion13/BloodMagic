package WayofTime.alchemicalWizardry.common.items.sigil;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.items.interfaces.ArmourUpgrade;
import WayofTime.alchemicalWizardry.api.items.interfaces.IHolding;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;

public class ItemSeerSigil extends Item implements IHolding, ArmourUpgrade {

   public ItemSeerSigil() {
      super.maxStackSize = 1;
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:SeerSigil");
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.seersigil.desc"));
      if(par1ItemStack.getTagCompound() != null) {
         par3List.add(StatCollector.translateToLocal("tooltip.owner.currentowner") + " " + par1ItemStack.getTagCompound().getString("ownerName"));
      }

   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.worldObj.isRemote) {
         NBTTagCompound itemTag = par1ItemStack.getTagCompound();
         if(itemTag != null && !itemTag.getString("ownerName").equals("")) {
            String ownerName = itemTag.getString("ownerName");
            return par1ItemStack;
         } else {
            return par1ItemStack;
         }
      } else {
         return par1ItemStack;
      }
   }

   public void onArmourUpdate(World world, EntityPlayer player, ItemStack thisItemStack) {}

   public boolean isUpgrade() {
      return false;
   }

   public int getEnergyForTenSeconds() {
      return 0;
   }
}
