package WayofTime.alchemicalWizardry.common.items.sigil;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.alchemy.energy.IReagentHandler;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentContainerInfo;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentRegistry;
import WayofTime.alchemicalWizardry.api.items.interfaces.ArmourUpgrade;
import WayofTime.alchemicalWizardry.api.items.interfaces.IBindable;
import WayofTime.alchemicalWizardry.api.items.interfaces.IReagentManipulator;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.StatCollector;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public class DivinationSigil extends Item implements ArmourUpgrade, IReagentManipulator, IBindable {

   public DivinationSigil() {
      super.maxStackSize = 1;
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:DivinationSigil");
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.divinationsigil.desc1"));
      par3List.add(StatCollector.translateToLocal("tooltip.divinationsigil.desc2"));
      if(par1ItemStack.getTagCompound() != null) {
         par3List.add(StatCollector.translateToLocal("tooltip.owner.currentowner") + " " + par1ItemStack.getTagCompound().getString("ownerName"));
      }

   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer);
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.worldObj.isRemote) {
         if(!EnergyItems.syphonBatteries(par1ItemStack, par3EntityPlayer, 0)) {
            return par1ItemStack;
         } else {
            NBTTagCompound itemTag = par1ItemStack.getTagCompound();
            if(itemTag != null && !itemTag.getString("ownerName").equals("")) {
               String ownerName = itemTag.getString("ownerName");
               int currentEssence = EnergyItems.getCurrentEssence(ownerName);
               MovingObjectPosition movingobjectposition = this.getMovingObjectPositionFromPlayer(par2World, par3EntityPlayer, false);
               if(movingobjectposition == null) {
                  par3EntityPlayer.addChatMessage(new ChatComponentText(StatCollector.translateToLocal("message.divinationsigil.currentessence") + " " + EnergyItems.getCurrentEssence(ownerName) + "LP"));
                  return par1ItemStack;
               } else {
                  if(movingobjectposition.typeOfHit == MovingObjectType.BLOCK) {
                     int x = movingobjectposition.blockX;
                     int y = movingobjectposition.blockY;
                     int z = movingobjectposition.blockZ;
                     TileEntity tile = par2World.getTileEntity(x, y, z);
                     if(!(tile instanceof IReagentHandler)) {
                        par3EntityPlayer.addChatMessage(new ChatComponentText(StatCollector.translateToLocal("message.divinationsigil.currentessence") + " " + EnergyItems.getCurrentEssence(ownerName) + "LP"));
                        return par1ItemStack;
                     }

                     IReagentHandler relay = (IReagentHandler)tile;
                     ReagentContainerInfo[] infoList = relay.getContainerInfo(ForgeDirection.UNKNOWN);
                     if(infoList != null) {
                        ReagentContainerInfo[] arr$ = infoList;
                        int len$ = infoList.length;

                        for(int i$ = 0; i$ < len$; ++i$) {
                           ReagentContainerInfo info = arr$[i$];
                           if(info != null && info.reagent != null && info.reagent.reagent != null) {
                              par3EntityPlayer.addChatComponentMessage(new ChatComponentText(StatCollector.translateToLocal("message.divinationsigil.reagent") + " " + ReagentRegistry.getKeyForReagent(info.reagent.reagent) + "," + StatCollector.translateToLocal("message.divinationsigil.amount") + " " + info.reagent.amount));
                           }
                        }
                     }
                  }

                  return par1ItemStack;
               }
            } else {
               return par1ItemStack;
            }
         }
      } else {
         return par1ItemStack;
      }
   }

   public void onArmourUpdate(World world, EntityPlayer player, ItemStack thisItemStack) {
      player.addPotionEffect(new PotionEffect(Potion.nightVision.id, 400, 9, true));
   }

   public boolean isUpgrade() {
      return true;
   }

   public int getEnergyForTenSeconds() {
      return 25;
   }
}
