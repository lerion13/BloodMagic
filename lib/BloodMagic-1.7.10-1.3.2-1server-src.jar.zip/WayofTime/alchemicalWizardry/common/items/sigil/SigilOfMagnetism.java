package WayofTime.alchemicalWizardry.common.items.sigil;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.items.interfaces.ArmourUpgrade;
import WayofTime.alchemicalWizardry.api.items.interfaces.IHolding;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.IIcon;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;

public class SigilOfMagnetism extends EnergyItems implements ArmourUpgrade, IHolding {

   private static IIcon activeIcon;
   private static IIcon passiveIcon;
   private int tickDelay = 300;


   public SigilOfMagnetism() {
      super.maxStackSize = 1;
      this.setEnergyUsed(50);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.sigilofmagnetism.desc"));
      if(par1ItemStack.getTagCompound() != null) {
         if(par1ItemStack.getTagCompound().getBoolean("isActive")) {
            par3List.add(StatCollector.translateToLocal("tooltip.sigil.state.activated"));
         } else {
            par3List.add(StatCollector.translateToLocal("tooltip.sigil.state.deactivated"));
         }

         par3List.add(StatCollector.translateToLocal("tooltip.owner.currentowner") + " " + par1ItemStack.getTagCompound().getString("ownerName"));
      }

   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:SigilOfMagnetism_deactivated");
      activeIcon = iconRegister.registerIcon("AlchemicalWizardry:SigilOfMagnetism_activated");
      passiveIcon = iconRegister.registerIcon("AlchemicalWizardry:SigilOfMagnetism_deactivated");
   }

   public IIcon getIcon(ItemStack stack, int renderPass, EntityPlayer player, ItemStack usingItem, int useRemaining) {
      if(stack.getTagCompound() == null) {
         stack.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tag = stack.getTagCompound();
      return tag.getBoolean("isActive")?activeIcon:passiveIcon;
   }

   @SideOnly(Side.CLIENT)
   public IIcon getIconFromDamage(int par1) {
      return par1 == 1?activeIcon:passiveIcon;
   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(par1ItemStack.getTagCompound() == null) {
            par1ItemStack.setTagCompound(new NBTTagCompound());
         }

         NBTTagCompound tag = par1ItemStack.getTagCompound();
         tag.setBoolean("isActive", !tag.getBoolean("isActive"));
         if(tag.getBoolean("isActive") && EnergyItems.syphonBatteries(par1ItemStack, par3EntityPlayer, this.getEnergyUsed())) {
            par1ItemStack.setItemDamage(1);
            tag.setInteger("worldTimeDelay", (int)(par2World.getWorldTime() - 1L) % this.tickDelay);
         } else {
            par1ItemStack.setItemDamage(par1ItemStack.getMaxDamage());
         }

         return par1ItemStack;
      } else {
         return par1ItemStack;
      }
   }

   public void onUpdate(ItemStack par1ItemStack, World par2World, Entity par3Entity, int par4, boolean par5) {
      if(par3Entity instanceof EntityPlayer) {
         EntityPlayer par3EntityPlayer = (EntityPlayer)par3Entity;
         if(par1ItemStack.getTagCompound() == null) {
            par1ItemStack.setTagCompound(new NBTTagCompound());
         }

         if(par1ItemStack.getTagCompound().getBoolean("isActive")) {
            if(par2World.getWorldTime() % (long)this.tickDelay == (long)par1ItemStack.getTagCompound().getInteger("worldTimeDelay") && par3Entity instanceof EntityPlayer && !EnergyItems.syphonBatteries(par1ItemStack, (EntityPlayer)par3Entity, this.getEnergyUsed())) {
               par1ItemStack.getTagCompound().setBoolean("isActive", false);
            }

            byte range = 5;
            byte verticalRange = 5;
            float posX = (float)Math.round(par3Entity.posX);
            float posY = (float)(par3Entity.posY - (double)par3Entity.getEyeHeight());
            float posZ = (float)Math.round(par3Entity.posZ);
            List entities = par3EntityPlayer.worldObj.getEntitiesWithinAABB(EntityItem.class, AxisAlignedBB.getBoundingBox((double)(posX - 0.5F), (double)(posY - 0.5F), (double)(posZ - 0.5F), (double)(posX + 0.5F), (double)(posY + 0.5F), (double)(posZ + 0.5F)).expand((double)range, (double)verticalRange, (double)range));
            Iterator i$ = entities.iterator();

            while(i$.hasNext()) {
               EntityItem entity = (EntityItem)i$.next();
               if(entity != null && !par2World.isRemote) {
                  entity.onCollideWithPlayer(par3EntityPlayer);
               }
            }
         }

      }
   }

   public void onArmourUpdate(World world, EntityPlayer player, ItemStack thisItemStack) {
      byte range = 5;
      byte verticalRange = 5;
      float posX = (float)Math.round(player.posX);
      float posY = (float)(player.posY - (double)player.getEyeHeight());
      float posZ = (float)Math.round(player.posZ);
      List entities = player.worldObj.getEntitiesWithinAABB(EntityItem.class, AxisAlignedBB.getBoundingBox((double)(posX - 0.5F), (double)(posY - 0.5F), (double)(posZ - 0.5F), (double)(posX + 0.5F), (double)(posY + 0.5F), (double)(posZ + 0.5F)).expand((double)range, (double)verticalRange, (double)range));
      Iterator i$ = entities.iterator();

      while(i$.hasNext()) {
         EntityItem entity = (EntityItem)i$.next();
         if(entity != null && !world.isRemote) {
            entity.onCollideWithPlayer(player);
         }
      }

   }

   public boolean isUpgrade() {
      return true;
   }

   public int getEnergyForTenSeconds() {
      return 25;
   }
}
