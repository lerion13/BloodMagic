package WayofTime.alchemicalWizardry.common.items;

import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class OrbOfTesting extends EnergyItems {

   public OrbOfTesting() {
      this.setMaxStackSize(1);
      this.setCreativeTab(CreativeTabs.tabMisc);
      this.setUnlocalizedName("orbOfTesting");
      this.setMaxDamage(100);
      this.setFull3D();
      this.setEnergyUsed(100);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:Untitled");
   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(!par3EntityPlayer.shouldHeal()) {
         return par1ItemStack;
      } else {
         if(syphonBatteries(par1ItemStack, par3EntityPlayer, this.getEnergyUsed())) {
            par3EntityPlayer.heal(1.0F);
         }

         return par1ItemStack;
      }
   }
}
