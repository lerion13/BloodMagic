package WayofTime.alchemicalWizardry.common.items;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.alchemy.AlchemyRecipeRegistry;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.IIcon;
import net.minecraft.util.MathHelper;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;
import org.lwjgl.input.Keyboard;

public class ActivationCrystal extends EnergyItems {

   private static final String[] ACTIVATION_CRYSTAL_NAMES = new String[]{"Weak", "Awakened", "Creative"};
   @SideOnly(Side.CLIENT)
   private IIcon[] icons;


   public ActivationCrystal() {
      super.maxStackSize = 1;
      this.setEnergyUsed(100);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      super.hasSubtypes = true;
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      this.icons = new IIcon[ACTIVATION_CRYSTAL_NAMES.length];

      for(int i = 0; i < ACTIVATION_CRYSTAL_NAMES.length; ++i) {
         this.icons[i] = iconRegister.registerIcon("AlchemicalWizardry:activationCrystal" + ACTIVATION_CRYSTAL_NAMES[i]);
      }

   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      switch(par1ItemStack.getItemDamage()) {
      case 0:
         par3List.add(StatCollector.translateToLocal("tooltip.activationcrystal.lowlevelrituals"));
         break;
      case 1:
         par3List.add(StatCollector.translateToLocal("tooltip.activationcrystal.powerfulrituals"));
         if(!Keyboard.isKeyDown(54) && !Keyboard.isKeyDown(42)) {
            par3List.add("-" + StatCollector.translateToLocal("tooltip.alchemy.press") + " " + EnumChatFormatting.BLUE + StatCollector.translateToLocal("tooltip.alchemy.shift") + EnumChatFormatting.GRAY + " " + StatCollector.translateToLocal("tooltip.alchemy.forrecipe") + "-");
         } else {
            ItemStack[] recipe = AlchemyRecipeRegistry.getRecipeForItemStack(par1ItemStack);
            if(recipe != null) {
               par3List.add(EnumChatFormatting.BLUE + StatCollector.translateToLocal("tooltip.alchemy.recipe"));
               ItemStack[] arr$ = recipe;
               int len$ = recipe.length;

               for(int i$ = 0; i$ < len$; ++i$) {
                  ItemStack item = arr$[i$];
                  if(item != null) {
                     par3List.add("" + item.getDisplayName());
                  }
               }
            }
         }
         break;
      case 2:
         par3List.add(StatCollector.translateToLocal("tooltip.activationcrystal.creativeonly"));
      }

      if(par1ItemStack.getTagCompound() != null) {
         par3List.add(StatCollector.translateToLocal("tooltip.owner.currentowner") + " " + par1ItemStack.getTagCompound().getString("ownerName"));
      }

   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer);
      return par1ItemStack;
   }

   public int getCrystalLevel(ItemStack itemStack) {
      return itemStack.getItemDamage() > 1?Integer.MAX_VALUE:itemStack.getItemDamage() + 1;
   }

   public String getUnlocalizedName(ItemStack itemStack) {
      int meta = MathHelper.clamp_int(itemStack.getItemDamage(), 0, ACTIVATION_CRYSTAL_NAMES.length - 1);
      return "item.activationCrystal" + ACTIVATION_CRYSTAL_NAMES[meta];
   }

   @SideOnly(Side.CLIENT)
   public IIcon getIconFromDamage(int meta) {
      int j = MathHelper.clamp_int(meta, 0, ACTIVATION_CRYSTAL_NAMES.length - 1);
      return this.icons[j];
   }

   @SideOnly(Side.CLIENT)
   public void getSubItems(Item id, CreativeTabs creativeTab, List list) {
      for(int meta = 0; meta < ACTIVATION_CRYSTAL_NAMES.length; ++meta) {
         list.add(new ItemStack(id, 1, meta));
      }

   }

}
