package WayofTime.alchemicalWizardry.common.items.thaumcraft;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.ModItems;
import WayofTime.alchemicalWizardry.api.items.interfaces.ArmourUpgrade;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;
import thaumcraft.api.IGoggles;
import thaumcraft.api.IRepairable;
import thaumcraft.api.IRunicArmor;
import thaumcraft.api.IVisDiscountGear;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.nodes.IRevealer;

public class ItemSanguineArmour extends ItemArmor implements ArmourUpgrade, IGoggles, IVisDiscountGear, IRevealer, IRunicArmor, IRepairable {

   private static IIcon helmetIcon;
   private static IIcon plateIcon;
   private static IIcon leggingsIcon;
   private static IIcon bootsIcon;


   public ItemSanguineArmour(int armorType) {
      super(AlchemicalWizardry.sanguineArmourArmourMaterial, 0, armorType);
      this.setMaxDamage(1000);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:SheathedItem");
      helmetIcon = iconRegister.registerIcon("AlchemicalWizardry:SanguineHelmet");
      plateIcon = iconRegister.registerIcon("AlchemicalWizardry:SanguinePlate");
      leggingsIcon = iconRegister.registerIcon("AlchemicalWizardry:SanguineLeggings");
      bootsIcon = iconRegister.registerIcon("AlchemicalWizardry:SanguineBoots");
   }

   @SideOnly(Side.CLIENT)
   public IIcon getIconFromDamage(int par1) {
      return this.equals(ModItems.sanguineHelmet)?helmetIcon:(this.equals(ModItems.sanguineRobe)?plateIcon:(this.equals(ModItems.sanguinePants)?leggingsIcon:(this.equals(ModItems.sanguineBoots)?bootsIcon:super.itemIcon)));
   }

   public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type) {
      return this == ModItems.sanguineHelmet?"alchemicalwizardry:models/armor/sanguineArmour_layer_1.png":(this != ModItems.sanguineRobe && this != ModItems.sanguineBoots?(this == ModItems.sanguinePants?"alchemicalwizardry:models/armor/sanguineArmour_layer_2.png":null):"alchemicalwizardry:models/armor/sanguineArmour_layer_1.png");
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      byte discount = 0;
      switch(super.armorType) {
      case 0:
         discount = 6;
         break;
      case 1:
         discount = 3;
         break;
      case 2:
         discount = 3;
         break;
      case 3:
         discount = 2;
      }

      switch(super.armorType) {
      case 0:
         par3List.add(StatCollector.translateToLocal("tooltip.sanguinearmor.desc1"));
         break;
      case 1:
      case 2:
      case 3:
         par3List.add(StatCollector.translateToLocal("tooltip.sanguinearmor.desc2"));
      }

      par3List.add(StatCollector.translateToLocal("tooltip.sanguinearmor.visdisc") + " " + discount + "%");
   }

   public void onArmourUpdate(World world, EntityPlayer player, ItemStack thisItemStack) {}

   public boolean isUpgrade() {
      return true;
   }

   public int getEnergyForTenSeconds() {
      return 0;
   }

   public boolean showNodes(ItemStack itemstack, EntityLivingBase player) {
      return true;
   }

   public int getVisDiscount(ItemStack stack, EntityPlayer player, Aspect aspect) {
      switch(super.armorType) {
      case 0:
         return 7;
      case 1:
         return 3;
      case 2:
         return 2;
      case 3:
         return 2;
      default:
         return 0;
      }
   }

   public boolean showIngamePopups(ItemStack itemstack, EntityLivingBase player) {
      return true;
   }

   public int getRunicCharge(ItemStack itemstack) {
      return 0;
   }
}
