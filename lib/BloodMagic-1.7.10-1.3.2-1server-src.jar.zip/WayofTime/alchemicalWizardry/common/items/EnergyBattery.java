package WayofTime.alchemicalWizardry.common.items;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.items.interfaces.ArmourUpgrade;
import WayofTime.alchemicalWizardry.api.items.interfaces.IBindable;
import WayofTime.alchemicalWizardry.api.items.interfaces.IBloodOrb;
import WayofTime.alchemicalWizardry.api.soulNetwork.LifeEssenceNetwork;
import WayofTime.alchemicalWizardry.api.soulNetwork.SoulNetworkHandler;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import WayofTime.alchemicalWizardry.common.spell.complex.effect.SpellHelper;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public class EnergyBattery extends Item implements ArmourUpgrade, IBindable, IBloodOrb {

   private int maxEssence;
   protected int orbLevel;


   public EnergyBattery(int damage) {
      DamageSource damageSource = DamageSource.generic;
      this.setMaxStackSize(1);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      this.maxEssence = damage;
      this.orbLevel = 1;
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:EnergyBattery");
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.energybattery.desc"));
      if(par1ItemStack.getTagCompound() != null) {
         par3List.add(StatCollector.translateToLocal("tooltip.owner.currentowner") + " " + par1ItemStack.getTagCompound().getString("ownerName"));
      }

   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(!EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer)) {
         return par1ItemStack;
      } else {
         World world = par3EntityPlayer.worldObj;
         if(world != null) {
            double itemTag = par3EntityPlayer.posX;
            double posY = par3EntityPlayer.posY;
            double posZ = par3EntityPlayer.posZ;
            world.playSoundEffect((double)((float)itemTag + 0.5F), (double)((float)posY + 0.5F), (double)((float)posZ + 0.5F), "random.fizz", 0.5F, 2.6F + (world.rand.nextFloat() - world.rand.nextFloat()) * 0.8F);
            SpellHelper.sendIndexedParticleToAllAround(world, itemTag, posY, posZ, 20, world.provider.dimensionId, 4, itemTag, posY, posZ);
         }

         NBTTagCompound itemTag1 = par1ItemStack.getTagCompound();
         if(SpellHelper.isFakePlayer(par2World, par3EntityPlayer)) {
            return par1ItemStack;
         } else if(itemTag1 != null && !itemTag1.getString("ownerName").equals("")) {
            if(world.isRemote) {
               return par1ItemStack;
            } else {
               if(itemTag1.getString("ownerName").equals(SpellHelper.getUsername(par3EntityPlayer))) {
                  SoulNetworkHandler.setMaxOrbToMax(itemTag1.getString("ownerName"), this.orbLevel);
               }

               SoulNetworkHandler.addCurrentEssenceToMaximum(itemTag1.getString("ownerName"), 200, this.getMaxEssence());
               EnergyItems.hurtPlayer(par3EntityPlayer, 200);
               return par1ItemStack;
            }
         } else {
            return par1ItemStack;
         }
      }
   }

   public int damageItem(ItemStack par1ItemStack, int par2int) {
      if(par2int == 0) {
         return 0;
      } else {
         int before = this.getDamage(par1ItemStack);
         this.setDamage(par1ItemStack, this.getDamage(par1ItemStack) + par2int);
         return par2int - (this.getDamage(par1ItemStack) - before);
      }
   }

   protected void damagePlayer(World world, EntityPlayer player, int damage) {
      if(world != null) {
         double i = player.posX;
         double posY = player.posY;
         double posZ = player.posZ;
         world.playSoundEffect((double)((float)i + 0.5F), (double)((float)posY + 0.5F), (double)((float)posZ + 0.5F), "random.fizz", 0.5F, 2.6F + (world.rand.nextFloat() - world.rand.nextFloat()) * 0.8F);
         float f = 1.0F;
         float f1 = f * 0.6F + 0.4F;
         float f2 = f * f * 0.7F - 0.5F;
         float f3 = f * f * 0.6F - 0.7F;

         for(int l = 0; l < 8; ++l) {
            world.spawnParticle("reddust", i + Math.random() - Math.random(), posY + Math.random() - Math.random(), posZ + Math.random() - Math.random(), (double)f1, (double)f2, (double)f3);
         }
      }

      if(!player.capabilities.isCreativeMode) {
         for(int var15 = 0; var15 < damage; ++var15) {
            player.setHealth(player.getHealth() - 1.0F);
         }
      }

      if(player.getHealth() <= 0.0F) {
         player.inventory.dropAllItems();
      }

   }

   public int getMaxEssence() {
      return this.maxEssence;
   }

   public int getOrbLevel() {
      return this.orbLevel;
   }

   public void onArmourUpdate(World world, EntityPlayer player, ItemStack thisItemStack) {}

   public boolean isUpgrade() {
      return false;
   }

   public int getEnergyForTenSeconds() {
      return 0;
   }

   public ItemStack getContainerItem(ItemStack itemStack) {
      return itemStack;
   }

   public boolean hasContainerItem() {
      return true;
   }

   public int getCurrentEssence(ItemStack par1ItemStack) {
      if(par1ItemStack == null) {
         return 0;
      } else {
         NBTTagCompound itemTag = par1ItemStack.getTagCompound();
         if(itemTag != null && !itemTag.getString("ownerName").equals("")) {
            String owner = itemTag.getString("ownerName");
            WorldServer worldSave = MinecraftServer.getServer().worldServers[0];
            LifeEssenceNetwork data = (LifeEssenceNetwork)worldSave.loadItemData(LifeEssenceNetwork.class, owner);
            if(data == null) {
               data = new LifeEssenceNetwork(owner);
               worldSave.setItemData(owner, data);
            }

            int currentEssence = data.currentEssence;
            return currentEssence;
         } else {
            return 0;
         }
      }
   }

   public boolean doesContainerItemLeaveCraftingGrid(ItemStack itemStack) {
      return false;
   }
}
