package WayofTime.alchemicalWizardry.common.items;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import WayofTime.alchemicalWizardry.common.tileEntity.TEHomHeart;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.DimensionManager;

public class BlankSpell extends EnergyItems {

   public BlankSpell() {
      this.setMaxStackSize(1);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:BlankSpell");
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.blankspell.desc"));
      if(par1ItemStack.getTagCompound() != null) {
         NBTTagCompound itemTag = par1ItemStack.getTagCompound();
         if(!par1ItemStack.getTagCompound().getString("ownerName").equals("")) {
            par3List.add(StatCollector.translateToLocal("tooltip.owner.currentowner") + " " + par1ItemStack.getTagCompound().getString("ownerName"));
         }

         par3List.add(StatCollector.translateToLocal("tooltip.alchemy.coords") + " " + itemTag.getInteger("xCoord") + ", " + itemTag.getInteger("yCoord") + ", " + itemTag.getInteger("zCoord"));
         par3List.add(StatCollector.translateToLocal("tooltip.alchemy.dimension") + " " + this.getDimensionID(par1ItemStack));
      }

   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!par2World.isRemote) {
            WorldServer world = DimensionManager.getWorld(this.getDimensionID(par1ItemStack));
            if(world != null) {
               NBTTagCompound itemTag = par1ItemStack.getTagCompound();
               TileEntity tileEntity = world.getTileEntity(itemTag.getInteger("xCoord"), itemTag.getInteger("yCoord"), itemTag.getInteger("zCoord"));
               if(tileEntity instanceof TEHomHeart) {
                  TEHomHeart homHeart = (TEHomHeart)tileEntity;
                  if(homHeart.canCastSpell(par1ItemStack, par2World, par3EntityPlayer)) {
                     if(EnergyItems.syphonBatteries(par1ItemStack, par3EntityPlayer, homHeart.getCostForSpell())) {
                        EnergyItems.syphonBatteries(par1ItemStack, par3EntityPlayer, homHeart.castSpell(par1ItemStack, par2World, par3EntityPlayer));
                     }

                     par2World.playSoundAtEntity(par3EntityPlayer, "random.fizz", 0.5F, 0.4F / (Item.itemRand.nextFloat() * 0.4F + 0.8F));
                     return par1ItemStack;
                  } else {
                     return par1ItemStack;
                  }
               } else {
                  return par1ItemStack;
               }
            } else {
               return par1ItemStack;
            }
         } else {
            return par1ItemStack;
         }
      } else {
         return par1ItemStack;
      }
   }

   public int getDimensionID(ItemStack itemStack) {
      if(itemStack.getTagCompound() == null) {
         itemStack.setTagCompound(new NBTTagCompound());
      }

      return itemStack.getTagCompound().getInteger("dimensionId");
   }
}
