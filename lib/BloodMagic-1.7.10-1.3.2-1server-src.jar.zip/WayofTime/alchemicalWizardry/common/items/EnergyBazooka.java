package WayofTime.alchemicalWizardry.common.items;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.common.entity.projectile.EntityEnergyBazookaMainProjectile;
import WayofTime.alchemicalWizardry.common.items.EnergyItems;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.IIcon;
import net.minecraft.util.StatCollector;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class EnergyBazooka extends EnergyItems {

   private static IIcon activeIcon;
   private static IIcon passiveIcon;
   private static int damage;
   private static final int maxDelay = 150;


   public EnergyBazooka() {
      this.setMaxStackSize(1);
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      this.setFull3D();
      this.setMaxDamage(250);
      this.setEnergyUsed(20000);
      damage = 12;
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:EnergyBazooka_activated");
      activeIcon = iconRegister.registerIcon("AlchemicalWizardry:EnergyBazooka_activated");
      passiveIcon = iconRegister.registerIcon("AlchemicalWizardry:SheathedItem");
   }

   public IIcon getIcon(ItemStack stack, int renderPass, EntityPlayer player, ItemStack usingItem, int useRemaining) {
      if(stack.getTagCompound() == null) {
         stack.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tag = stack.getTagCompound();
      return tag.getBoolean("isActive")?activeIcon:passiveIcon;
   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(EnergyItems.checkAndSetItemOwner(par1ItemStack, par3EntityPlayer) && !par3EntityPlayer.isSneaking()) {
         if(!this.getActivated(par1ItemStack)) {
            return par1ItemStack;
         } else if(this.getDelay(par1ItemStack) > 0) {
            return par1ItemStack;
         } else if(!par3EntityPlayer.capabilities.isCreativeMode && !syphonBatteries(par1ItemStack, par3EntityPlayer, this.getEnergyUsed())) {
            return par1ItemStack;
         } else {
            par2World.playSoundAtEntity(par3EntityPlayer, "random.bow", 0.5F, 0.4F / (Item.itemRand.nextFloat() * 0.4F + 0.8F));
            if(!par2World.isRemote) {
               par2World.spawnEntityInWorld(new EntityEnergyBazookaMainProjectile(par2World, par3EntityPlayer, damage));
               this.setDelay(par1ItemStack, 150);
            }

            Vec3 vec = par3EntityPlayer.getLookVec();
            double wantedVelocity = 3.0D;
            par3EntityPlayer.motionX = -vec.xCoord * wantedVelocity;
            par3EntityPlayer.motionY = -vec.yCoord * wantedVelocity;
            par3EntityPlayer.motionZ = -vec.zCoord * wantedVelocity;
            par2World.playSoundEffect((double)((float)par3EntityPlayer.posX + 0.5F), (double)((float)par3EntityPlayer.posY + 0.5F), (double)((float)par3EntityPlayer.posZ + 0.5F), "random.fizz", 0.5F, 2.6F + (par2World.rand.nextFloat() - par2World.rand.nextFloat()) * 0.8F);
            par3EntityPlayer.fallDistance = 0.0F;
            return par1ItemStack;
         }
      } else {
         this.setActivated(par1ItemStack, !this.getActivated(par1ItemStack));
         par1ItemStack.getTagCompound().setInteger("worldTimeDelay", (int)(par2World.getWorldTime() - 1L) % 100);
         return par1ItemStack;
      }
   }

   public void onUpdate(ItemStack par1ItemStack, World par2World, Entity par3Entity, int par4, boolean par5) {
      if(par3Entity instanceof EntityPlayer) {
         EntityPlayer par3EntityPlayer = (EntityPlayer)par3Entity;
         if(par1ItemStack.getTagCompound() == null) {
            par1ItemStack.setTagCompound(new NBTTagCompound());
         }

         int delay = this.getDelay(par1ItemStack);
         if(!par2World.isRemote && delay > 0) {
            this.setDelay(par1ItemStack, delay - 1);
         }

         if(par2World.getWorldTime() % 100L == (long)par1ItemStack.getTagCompound().getInteger("worldTimeDelay") && par1ItemStack.getTagCompound().getBoolean("isActive") && !par3EntityPlayer.capabilities.isCreativeMode && !EnergyItems.syphonBatteries(par1ItemStack, par3EntityPlayer, 50)) {
            this.setActivated(par1ItemStack, false);
         }

         par1ItemStack.setItemDamage(0);
      }
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.energybazooka.desc"));
      if(par1ItemStack.getTagCompound() != null) {
         if(par1ItemStack.getTagCompound().getBoolean("isActive")) {
            par3List.add(StatCollector.translateToLocal("tooltip.sigil.state.activated"));
         } else {
            par3List.add(StatCollector.translateToLocal("tooltip.sigil.state.deactivated"));
         }

         if(!par1ItemStack.getTagCompound().getString("ownerName").equals("")) {
            par3List.add(StatCollector.translateToLocal("tooltip.owner.currentowner") + " " + par1ItemStack.getTagCompound().getString("ownerName"));
         }
      }

   }

   public void setActivated(ItemStack par1ItemStack, boolean newActivated) {
      NBTTagCompound itemTag = par1ItemStack.getTagCompound();
      if(itemTag == null) {
         par1ItemStack.setTagCompound(new NBTTagCompound());
      }

      itemTag.setBoolean("isActive", newActivated);
   }

   public boolean getActivated(ItemStack par1ItemStack) {
      NBTTagCompound itemTag = par1ItemStack.getTagCompound();
      if(itemTag == null) {
         par1ItemStack.setTagCompound(new NBTTagCompound());
      }

      return itemTag.getBoolean("isActive");
   }

   public void setDelay(ItemStack par1ItemStack, int newDelay) {
      NBTTagCompound itemTag = par1ItemStack.getTagCompound();
      if(itemTag == null) {
         par1ItemStack.setTagCompound(new NBTTagCompound());
      }

      itemTag.setInteger("delay", newDelay);
   }

   public int getDelay(ItemStack par1ItemStack) {
      NBTTagCompound itemTag = par1ItemStack.getTagCompound();
      if(itemTag == null) {
         par1ItemStack.setTagCompound(new NBTTagCompound());
      }

      return itemTag.getInteger("delay");
   }
}
