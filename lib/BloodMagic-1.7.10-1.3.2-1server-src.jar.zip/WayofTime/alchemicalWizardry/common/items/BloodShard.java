package WayofTime.alchemicalWizardry.common.items;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.ModItems;
import WayofTime.alchemicalWizardry.api.items.interfaces.ArmourUpgrade;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class BloodShard extends Item implements ArmourUpgrade {

   public BloodShard() {
      super.maxStackSize = 64;
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      if(this.equals(ModItems.weakBloodShard)) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:WeakBloodShard");
      } else if(this.equals(ModItems.demonBloodShard)) {
         super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:DemonBloodShard");
      }
   }

   public int getBloodShardLevel() {
      return this.equals(ModItems.weakBloodShard)?1:(this.equals(ModItems.demonBloodShard)?2:0);
   }

   public void onArmourUpdate(World world, EntityPlayer player, ItemStack thisItemStack) {}

   public boolean isUpgrade() {
      return false;
   }

   public int getEnergyForTenSeconds() {
      return 0;
   }
}
