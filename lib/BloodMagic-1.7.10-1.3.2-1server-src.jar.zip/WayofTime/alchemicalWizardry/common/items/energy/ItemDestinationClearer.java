package WayofTime.alchemicalWizardry.common.items.energy;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.items.interfaces.IReagentManipulator;
import WayofTime.alchemicalWizardry.common.tileEntity.TEReagentConduit;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.StatCollector;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.World;

public class ItemDestinationClearer extends Item implements IReagentManipulator {

   public ItemDestinationClearer() {
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      super.maxStackSize = 1;
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:TankClearer");
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.destclearer.desc1"));
      par3List.add(StatCollector.translateToLocal("tooltip.destclearer.desc2"));
   }

   public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer player) {
      if(world.isRemote) {
         return itemStack;
      } else {
         MovingObjectPosition movingobjectposition = this.getMovingObjectPositionFromPlayer(world, player, false);
         if(movingobjectposition == null) {
            return itemStack;
         } else {
            if(movingobjectposition.typeOfHit == MovingObjectType.BLOCK) {
               int x = movingobjectposition.blockX;
               int y = movingobjectposition.blockY;
               int z = movingobjectposition.blockZ;
               TileEntity tile = world.getTileEntity(x, y, z);
               if(!(tile instanceof TEReagentConduit)) {
                  return itemStack;
               }

               TEReagentConduit relay = (TEReagentConduit)tile;
               relay.reagentTargetList.clear();
               player.addChatComponentMessage(new ChatComponentText(StatCollector.translateToLocal("message.destinationclearer.cleared")));
            }

            return itemStack;
         }
      }
   }
}
