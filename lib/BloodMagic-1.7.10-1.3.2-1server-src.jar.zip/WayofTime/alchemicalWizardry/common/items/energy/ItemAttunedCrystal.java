package WayofTime.alchemicalWizardry.common.items.energy;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.Int3;
import WayofTime.alchemicalWizardry.api.alchemy.energy.IReagentHandler;
import WayofTime.alchemicalWizardry.api.alchemy.energy.Reagent;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentContainerInfo;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentRegistry;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentStack;
import WayofTime.alchemicalWizardry.api.items.interfaces.IReagentManipulator;
import WayofTime.alchemicalWizardry.common.tileEntity.TEReagentConduit;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IIcon;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.StatCollector;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public class ItemAttunedCrystal extends Item implements IReagentManipulator {

   public static final int maxDistance = 6;
   public IIcon crystalBody;
   public IIcon crystalLabel;


   public ItemAttunedCrystal() {
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      super.hasSubtypes = true;
      super.maxStackSize = 1;
   }

   public String getItemStackDisplayName(ItemStack stack) {
      Reagent reagent = this.getReagent(stack);
      String name = super.getItemStackDisplayName(stack);
      if(reagent != null) {
         name = name + " (" + reagent.name + ")";
      }

      return name;
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.attunedcrystal.desc1"));
      par3List.add(StatCollector.translateToLocal("tooltip.attunedcrystal.desc2"));
      if(par1ItemStack.getTagCompound() != null) {
         Reagent reagent = this.getReagent(par1ItemStack);
         if(reagent != null) {
            par3List.add(StatCollector.translateToLocal("tooltip.reagent.selectedreagent") + " " + reagent.name);
         }

         if(this.getHasSavedCoordinates(par1ItemStack)) {
            par3List.add("");
            Int3 coords = this.getCoordinates(par1ItemStack);
            par3List.add(StatCollector.translateToLocal("tooltip.alchemy.coords") + " " + coords.xCoord + ", " + coords.yCoord + ", " + coords.zCoord);
            par3List.add(StatCollector.translateToLocal("tooltip.alchemy.dimension") + " " + this.getDimension(par1ItemStack));
         }
      }

   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      this.crystalBody = iconRegister.registerIcon("AlchemicalWizardry:AttunedCrystal1");
      this.crystalLabel = iconRegister.registerIcon("AlchemicalWizardry:AttunedCrystal2");
   }

   @SideOnly(Side.CLIENT)
   public int getColorFromItemStack(ItemStack stack, int pass) {
      switch(pass) {
      case 0:
         return 16777215;
      case 1:
         Reagent reagent = this.getReagent(stack);
         if(reagent != null) {
            return reagent.getColourRed() * 256 * 256 + reagent.getColourGreen() * 256 + reagent.getColourBlue();
         }
      default:
         return 16777215;
      }
   }

   @SideOnly(Side.CLIENT)
   public boolean requiresMultipleRenderPasses() {
      return true;
   }

   @SideOnly(Side.CLIENT)
   public int getRenderPasses(int meta) {
      return 2;
   }

   @SideOnly(Side.CLIENT)
   public IIcon getIcon(ItemStack stack, int pass) {
      switch(pass) {
      case 0:
         return this.crystalBody;
      case 1:
         return this.crystalLabel;
      default:
         return super.itemIcon;
      }
   }

   public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer player) {
      if(world.isRemote) {
         return itemStack;
      } else {
         MovingObjectPosition movingobjectposition = this.getMovingObjectPositionFromPlayer(world, player, false);
         if(movingobjectposition == null) {
            if(player.isSneaking()) {
               this.setHasSavedCoordinates(itemStack, false);
               player.addChatComponentMessage(new ChatComponentText(StatCollector.translateToLocal("message.attunedcrystal.clearing")));
            }

            return itemStack;
         } else {
            if(movingobjectposition.typeOfHit == MovingObjectType.BLOCK) {
               int x = movingobjectposition.blockX;
               int y = movingobjectposition.blockY;
               int z = movingobjectposition.blockZ;
               TileEntity tile = world.getTileEntity(x, y, z);
               if(!(tile instanceof IReagentHandler)) {
                  return itemStack;
               }

               IReagentHandler relay = (IReagentHandler)tile;
               if(player.isSneaking()) {
                  ReagentContainerInfo[] dimension = relay.getContainerInfo(ForgeDirection.UNKNOWN);
                  if(dimension != null) {
                     LinkedList dimension1 = new LinkedList();
                     ReagentContainerInfo[] pastTile = dimension;
                     int reagent = dimension.length;

                     for(int pastRelay = 0; pastRelay < reagent; ++pastRelay) {
                        ReagentContainerInfo info = pastTile[pastRelay];
                        if(info != null) {
                           ReagentStack reagentStack = info.reagent;
                           if(reagentStack != null) {
                              Reagent reagent1 = reagentStack.reagent;
                              if(reagent1 != null) {
                                 dimension1.add(reagent1);
                              }
                           }
                        }
                     }

                     Reagent var21 = this.getReagent(itemStack);
                     if(dimension1.size() <= 0) {
                        return itemStack;
                     }

                     boolean var24 = true;
                     reagent = dimension1.indexOf(var21);
                     if(reagent != -1 && reagent + 1 < dimension1.size()) {
                        this.setReagentWithNotification(itemStack, (Reagent)dimension1.get(reagent + 1), player);
                     } else {
                        this.setReagentWithNotification(itemStack, (Reagent)dimension1.get(0), player);
                     }
                  }
               } else if(this.getHasSavedCoordinates(itemStack)) {
                  Int3 var19 = this.getCoordinates(itemStack);
                  int var18 = this.getDimension(itemStack);
                  if(var19 == null) {
                     return itemStack;
                  }

                  if(var18 != world.provider.dimensionId || Math.abs(var19.xCoord - x) > 6 || Math.abs(var19.yCoord - y) > 6 || Math.abs(var19.zCoord - z) > 6) {
                     player.addChatComponentMessage(new ChatComponentText(StatCollector.translateToLocal("message.attunedcrystal.error.toofar")));
                     return itemStack;
                  }

                  TileEntity var22 = world.getTileEntity(var19.xCoord, var19.yCoord, var19.zCoord);
                  if(!(var22 instanceof TEReagentConduit)) {
                     player.addChatComponentMessage(new ChatComponentText(StatCollector.translateToLocal("message.attunedcrystal.error.cannotfind")));
                     return itemStack;
                  }

                  Reagent var23 = this.getReagent(itemStack);
                  if(var23 == null) {
                     return itemStack;
                  }

                  TEReagentConduit var25 = (TEReagentConduit)var22;
                  if(player.isSneaking()) {
                     var25.removeReagentDestinationViaActual(var23, x, y, z);
                  } else if(var25.addReagentDestinationViaActual(var23, x, y, z)) {
                     player.addChatComponentMessage(new ChatComponentText(StatCollector.translateToLocal("message.attunedcrystal.linked") + " " + var23.name));
                  } else {
                     player.addChatComponentMessage(new ChatComponentText(StatCollector.translateToLocal("message.attunedcrystal.error.noconnections")));
                  }

                  world.markBlockForUpdate(var19.xCoord, var19.yCoord, var19.zCoord);
               } else {
                  int var20 = world.provider.dimensionId;
                  this.setDimension(itemStack, var20);
                  this.setCoordinates(itemStack, new Int3(x, y, z));
                  player.addChatComponentMessage(new ChatComponentText(StatCollector.translateToLocal("message.attunedcrystal.linking")));
               }
            }

            return itemStack;
         }
      }
   }

   public void setCoordinates(ItemStack stack, Int3 coords) {
      if(!stack.hasTagCompound()) {
         stack.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tag = stack.getTagCompound();
      coords.writeToNBT(tag);
      this.setHasSavedCoordinates(stack, true);
   }

   public void setDimension(ItemStack stack, int dimension) {
      if(!stack.hasTagCompound()) {
         stack.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tag = stack.getTagCompound();
      tag.setInteger("dimension", dimension);
   }

   public Int3 getCoordinates(ItemStack stack) {
      if(!stack.hasTagCompound()) {
         stack.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tag = stack.getTagCompound();
      return Int3.readFromNBT(tag);
   }

   public int getDimension(ItemStack stack) {
      if(!stack.hasTagCompound()) {
         stack.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tag = stack.getTagCompound();
      return tag.getInteger("dimension");
   }

   public void setHasSavedCoordinates(ItemStack stack, boolean flag) {
      if(!stack.hasTagCompound()) {
         stack.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tag = stack.getTagCompound();
      tag.setBoolean("hasSavedCoordinates", flag);
   }

   public boolean getHasSavedCoordinates(ItemStack stack) {
      if(!stack.hasTagCompound()) {
         stack.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tag = stack.getTagCompound();
      return tag.getBoolean("hasSavedCoordinates");
   }

   public Reagent getReagent(ItemStack stack) {
      if(!stack.hasTagCompound()) {
         stack.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tag = stack.getTagCompound();
      return ReagentRegistry.getReagentForKey(tag.getString("reagent"));
   }

   public void setReagent(ItemStack stack, Reagent reagent) {
      if(!stack.hasTagCompound()) {
         stack.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tag = stack.getTagCompound();
      tag.setString("reagent", ReagentRegistry.getKeyForReagent(reagent));
   }

   public void setReagentWithNotification(ItemStack stack, Reagent reagent, EntityPlayer player) {
      this.setReagent(stack, reagent);
      if(reagent != null) {
         player.addChatComponentMessage(new ChatComponentText(StatCollector.translateToLocal("message.attunedcrystal.setto") + " " + reagent.name));
      }

   }
}
