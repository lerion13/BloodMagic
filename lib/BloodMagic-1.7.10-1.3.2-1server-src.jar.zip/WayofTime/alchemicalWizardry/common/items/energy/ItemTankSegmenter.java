package WayofTime.alchemicalWizardry.common.items.energy;

import WayofTime.alchemicalWizardry.AlchemicalWizardry;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ISegmentedReagentHandler;
import WayofTime.alchemicalWizardry.api.alchemy.energy.Reagent;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentContainerInfo;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentRegistry;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentStack;
import WayofTime.alchemicalWizardry.api.items.interfaces.IReagentManipulator;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IIcon;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.StatCollector;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public class ItemTankSegmenter extends Item implements IReagentManipulator {

   public IIcon crystalBody;
   public IIcon crystalLabel;


   public ItemTankSegmenter() {
      this.setCreativeTab(AlchemicalWizardry.tabBloodMagic);
      super.hasSubtypes = true;
      super.maxStackSize = 1;
   }

   public String getItemStackDisplayName(ItemStack stack) {
      Reagent reagent = this.getReagent(stack);
      String name = super.getItemStackDisplayName(stack);
      if(reagent != null) {
         name = name + " (" + reagent.name + ")";
      }

      return name;
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add(StatCollector.translateToLocal("tooltip.tanksegmenter.desc1"));
      par3List.add(StatCollector.translateToLocal("tooltip.tanksegmenter.desc2"));
      if(par1ItemStack.getTagCompound() != null) {
         Reagent reagent = this.getReagent(par1ItemStack);
         if(reagent != null) {
            par3List.add(StatCollector.translateToLocal("tooltip.reagent.selectedreagent") + " " + reagent.name);
         }
      }

   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      this.crystalBody = iconRegister.registerIcon("AlchemicalWizardry:TankSegmenter1");
      this.crystalLabel = iconRegister.registerIcon("AlchemicalWizardry:TankSegmenter2");
   }

   @SideOnly(Side.CLIENT)
   public int getColorFromItemStack(ItemStack stack, int pass) {
      switch(pass) {
      case 0:
         return 16777215;
      case 1:
         Reagent reagent = this.getReagent(stack);
         if(reagent != null) {
            return reagent.getColourRed() * 256 * 256 + reagent.getColourGreen() * 256 + reagent.getColourBlue();
         }
      default:
         return 16777215;
      }
   }

   @SideOnly(Side.CLIENT)
   public boolean requiresMultipleRenderPasses() {
      return true;
   }

   @SideOnly(Side.CLIENT)
   public int getRenderPasses(int meta) {
      return 2;
   }

   @SideOnly(Side.CLIENT)
   public IIcon getIcon(ItemStack stack, int pass) {
      switch(pass) {
      case 0:
         return this.crystalBody;
      case 1:
         return this.crystalLabel;
      default:
         return super.itemIcon;
      }
   }

   public ItemStack onItemRightClick(ItemStack itemStack, World world, EntityPlayer player) {
      if(world.isRemote) {
         return itemStack;
      } else {
         MovingObjectPosition movingobjectposition = this.getMovingObjectPositionFromPlayer(world, player, false);
         if(movingobjectposition == null) {
            return itemStack;
         } else {
            if(movingobjectposition.typeOfHit == MovingObjectType.BLOCK) {
               int x = movingobjectposition.blockX;
               int y = movingobjectposition.blockY;
               int z = movingobjectposition.blockZ;
               TileEntity tile = world.getTileEntity(x, y, z);
               if(!(tile instanceof ISegmentedReagentHandler)) {
                  return itemStack;
               }

               ISegmentedReagentHandler reagentHandler = (ISegmentedReagentHandler)tile;
               if(player.isSneaking()) {
                  ReagentContainerInfo[] reagent = reagentHandler.getContainerInfo(ForgeDirection.UNKNOWN);
                  if(reagent != null) {
                     LinkedList totalTankSize = new LinkedList();
                     ReagentContainerInfo[] numberAssigned = reagent;
                     int goForNext = reagent.length;

                     for(int hasFound = 0; hasFound < goForNext; ++hasFound) {
                        ReagentContainerInfo i$ = numberAssigned[hasFound];
                        if(i$ != null) {
                           ReagentStack reagent1 = i$.reagent;
                           if(reagent1 != null) {
                              Reagent reagent2 = reagent1.reagent;
                              if(reagent2 != null) {
                                 totalTankSize.add(reagent2);
                              }
                           }
                        }
                     }

                     Reagent var20 = this.getReagent(itemStack);
                     boolean var22 = false;
                     boolean var24 = false;
                     Iterator var23 = totalTankSize.iterator();

                     while(var23.hasNext()) {
                        Reagent var25 = (Reagent)var23.next();
                        if(var22) {
                           var22 = false;
                           break;
                        }

                        if(var25 == var20) {
                           var22 = true;
                           var24 = true;
                        }
                     }

                     if(var24) {
                        if(var22) {
                           this.setReagentWithNotification(itemStack, (Reagent)totalTankSize.get(0), player);
                        }
                     } else if(totalTankSize.size() >= 1) {
                        this.setReagentWithNotification(itemStack, (Reagent)totalTankSize.get(0), player);
                     }
                  }
               } else {
                  Reagent var19 = this.getReagent(itemStack);
                  if(var19 == null) {
                     reagentHandler.getAttunedTankMap().clear();
                     return itemStack;
                  }

                  int var18 = reagentHandler.getNumberOfTanks();
                  int var21 = reagentHandler.getTanksTunedToReagent(var19) + 1;
                  if(var21 > var18) {
                     var21 = 0;
                  }

                  player.addChatComponentMessage(new ChatComponentText(StatCollector.translateToLocal("message.tanksegmenter.nowhas") + " " + var21 + " " + StatCollector.translateToLocal("message.tanksegmenter.tankssetto") + " " + var19.name));
                  reagentHandler.setTanksTunedToReagent(var19, var21);
               }
            } else if(movingobjectposition.typeOfHit == MovingObjectType.MISS) {
               this.setReagent(itemStack, (Reagent)null);
            }

            return itemStack;
         }
      }
   }

   public Reagent getReagent(ItemStack stack) {
      if(!stack.hasTagCompound()) {
         stack.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tag = stack.getTagCompound();
      return ReagentRegistry.getReagentForKey(tag.getString("reagent"));
   }

   public void setReagent(ItemStack stack, Reagent reagent) {
      if(!stack.hasTagCompound()) {
         stack.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tag = stack.getTagCompound();
      tag.setString("reagent", ReagentRegistry.getKeyForReagent(reagent));
   }

   public void setReagentWithNotification(ItemStack stack, Reagent reagent, EntityPlayer player) {
      this.setReagent(stack, reagent);
      if(reagent != null) {
         player.addChatComponentMessage(new ChatComponentText(StatCollector.translateToLocal("message.tanksegmenter.setto") + " " + reagent.name));
      }

   }
}
