package WayofTime.alchemicalWizardry.common.items.routing;

import net.minecraft.item.ItemStack;

public interface ILimitedRoutingFocus {

   int getRoutingFocusLimit(ItemStack var1);

   void setRoutingFocusLimit(ItemStack var1, int var2);
}
