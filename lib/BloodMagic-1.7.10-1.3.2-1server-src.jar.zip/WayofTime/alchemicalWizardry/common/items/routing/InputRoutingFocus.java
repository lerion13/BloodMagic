package WayofTime.alchemicalWizardry.common.items.routing;

import WayofTime.alchemicalWizardry.common.items.routing.RoutingFocus;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;

public class InputRoutingFocus extends RoutingFocus {

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:InputRoutingFocus");
   }
}
