package WayofTime.alchemicalWizardry.common.achievements;

import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.Achievement;

public interface IPickupAchievement {

   Achievement getAchievementOnPickup(ItemStack var1, EntityPlayer var2, EntityItem var3);
}
