package WayofTime.alchemicalWizardry.common.achievements;

import WayofTime.alchemicalWizardry.ModItems;
import WayofTime.alchemicalWizardry.common.achievements.AchievementTrigger;
import WayofTime.alchemicalWizardry.common.achievements.AchievementsMod;
import cpw.mods.fml.common.FMLCommonHandler;
import net.minecraft.stats.Achievement;
import net.minecraft.util.StatCollector;
import net.minecraftforge.common.AchievementPage;

public class ModAchievements {

   public static AchievementPage alchemicalWizardryPage;
   public static Achievement firstPrick;


   public static void init() {
      firstPrick = new AchievementsMod(StatCollector.translateToLocal("achievement.firstPrick"), 0, 0, ModItems.sacrificialDagger, firstPrick);
      alchemicalWizardryPage = new AchievementPage("AlchemicalWizardry", (Achievement[])AchievementsMod.achievements.toArray(new Achievement[AchievementsMod.achievements.size()]));
      AchievementPage.registerAchievementPage(alchemicalWizardryPage);
      FMLCommonHandler.instance().bus().register(new AchievementTrigger());
   }
}
