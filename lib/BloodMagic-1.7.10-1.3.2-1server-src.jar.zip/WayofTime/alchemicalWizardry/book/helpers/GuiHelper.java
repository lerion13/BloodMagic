package WayofTime.alchemicalWizardry.book.helpers;

import WayofTime.alchemicalWizardry.book.enums.EnumType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.util.IIcon;
import org.lwjgl.opengl.GL11;

public class GuiHelper {

   public static boolean isMouseBetween(int mouseX, int mouseY, int x, int y, int width, int height) {
      int xSize = x + width;
      int ySize = y + height;
      return mouseX > x && mouseX < xSize && mouseY > y && mouseY < ySize;
   }

   public static void renderIcon(int x, int y, int width, int height, IIcon icon, EnumType type) {
      if(type == EnumType.BLOCK) {
         Minecraft.getMinecraft().getTextureManager().bindTexture(TextureMap.locationBlocksTexture);
      } else if(type == EnumType.ITEM) {
         Minecraft.getMinecraft().getTextureManager().bindTexture(TextureMap.locationItemsTexture);
      }

      byte zLevel = 0;
      GL11.glPushMatrix();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      RenderHelper.enableGUIStandardItemLighting();
      GL11.glEnable('\u803a');
      GL11.glEnable(2929);
      Tessellator t = Tessellator.instance;
      t.startDrawingQuads();
      t.addVertexWithUV((double)(x + 0), (double)(y + height), (double)zLevel, (double)icon.getMinU(), (double)icon.getMaxV());
      t.addVertexWithUV((double)(x + width), (double)(y + height), (double)zLevel, (double)icon.getMaxU(), (double)icon.getMaxV());
      t.addVertexWithUV((double)(x + width), (double)(y + 0), (double)zLevel, (double)icon.getMaxU(), (double)icon.getMinV());
      t.addVertexWithUV((double)(x + 0), (double)(y + 0), (double)zLevel, (double)icon.getMinU(), (double)icon.getMinV());
      t.draw();
      RenderHelper.disableStandardItemLighting();
      GL11.glDisable(2896);
      GL11.glPopMatrix();
   }

   public static void drawScaledIconWithoutColor(int x, int y, int width, int height, float zLevel) {
      GL11.glPushMatrix();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glScaled(0.13D, 0.13D, 0.13D);
      GL11.glTranslated((double)(x + 900), (double)(y + 250), 0.0D);
      RenderHelper.enableGUIStandardItemLighting();
      GL11.glEnable('\u803a');
      GL11.glEnable(2929);
      Tessellator t = Tessellator.instance;
      t.startDrawingQuads();
      t.addVertexWithUV((double)(x + 0), (double)(y + height), (double)zLevel, 0.0D, 1.0D);
      t.addVertexWithUV((double)(x + width), (double)(y + height), (double)zLevel, 1.0D, 1.0D);
      t.addVertexWithUV((double)(x + width), (double)(y + 0), (double)zLevel, 1.0D, 0.0D);
      t.addVertexWithUV((double)(x + 0), (double)(y + 0), (double)zLevel, 0.0D, 0.0D);
      t.draw();
      RenderHelper.disableStandardItemLighting();
      GL11.glDisable(2896);
      GL11.glPopMatrix();
   }

   public static void drawIconWithoutColor(int x, int y, int width, int height, float zLevel) {
      GL11.glPushMatrix();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      RenderHelper.enableGUIStandardItemLighting();
      GL11.glEnable('\u803a');
      GL11.glEnable(2929);
      Tessellator t = Tessellator.instance;
      t.startDrawingQuads();
      t.addVertexWithUV((double)(x + 0), (double)(y + height), (double)zLevel, 0.0D, 1.0D);
      t.addVertexWithUV((double)(x + width), (double)(y + height), (double)zLevel, 1.0D, 1.0D);
      t.addVertexWithUV((double)(x + width), (double)(y + 0), (double)zLevel, 1.0D, 0.0D);
      t.addVertexWithUV((double)(x + 0), (double)(y + 0), (double)zLevel, 0.0D, 0.0D);
      t.draw();
      RenderHelper.disableStandardItemLighting();
      GL11.glDisable(2896);
      GL11.glPopMatrix();
   }
}
