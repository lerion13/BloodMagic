package WayofTime.alchemicalWizardry.book.registries;

import WayofTime.alchemicalWizardry.book.compact.CompactItem;
import WayofTime.alchemicalWizardry.book.interfaces.IReviving;
import java.util.HashMap;

public class RevivingRegistry {

   public static HashMap recipes = new HashMap();


   public static void registerReviving(CompactItem ingredients, IReviving reviving) {
      recipes.put(ingredients, reviving);
   }

}
