package WayofTime.alchemicalWizardry.book.registries;

import WayofTime.alchemicalWizardry.book.compact.Category;
import WayofTime.alchemicalWizardry.book.compact.Entry;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class EntryRegistry {

   public static ArrayList categories = new ArrayList();
   public static HashMap entryOrder = new HashMap();
   public static HashMap categoryMap = new HashMap();
   public static int categoryCount = 0;
   public static HashMap entries = new HashMap();
   public static HashMap maxEntries = new HashMap();
   public static HashMap architect = new HashMap();
   public static HashMap basics = new HashMap();
   public static HashMap rituals = new HashMap();
   public static HashMap bloodUtils = new HashMap();
   public static HashMap test = new HashMap();


   public static void registerCategories(Category category) {
      categories.add(category);
      categoryMap.put(category.name, category);
      entryOrder.put(category, new ArrayList());
      ++categoryCount;
   }

   public static void registerEntry(Category category, HashMap entryMap, Entry entry) {
      entryMap.put(entry.name, entry);
      entries.put(category, entryMap);
      ((List)entryOrder.get(category)).add(entry.name);
      if(maxEntries.containsKey(category) && entry.indexPage > ((Integer)maxEntries.get(category)).intValue()) {
         maxEntries.put(category, Integer.valueOf(entry.indexPage));
      } else if(!maxEntries.containsKey(category)) {
         maxEntries.put(category, Integer.valueOf(0));
      }

   }

   public static Entry[] getEntriesInOrderForCategory(Category category) {
      HashMap entries = (HashMap)entries.get(category);
      List nameList = (List)entryOrder.get(category);
      ArrayList list = new ArrayList();
      Iterator entriesList = nameList.iterator();

      while(entriesList.hasNext()) {
         String entryList = (String)entriesList.next();
         list.add(entries.get(entryList));
      }

      Object[] var7 = list.toArray();
      Entry[] var8 = new Entry[var7.length];

      for(int i = 0; i < var7.length; ++i) {
         var8[i] = (Entry)((Entry)var7[i]);
      }

      return var8;
   }

}
