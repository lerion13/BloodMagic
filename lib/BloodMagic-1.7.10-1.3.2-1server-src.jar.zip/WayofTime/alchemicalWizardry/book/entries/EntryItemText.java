package WayofTime.alchemicalWizardry.book.entries;

import WayofTime.alchemicalWizardry.book.classes.guide.GuiEntry;
import WayofTime.alchemicalWizardry.book.entries.IEntry;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.StatCollector;
import org.lwjgl.opengl.GL11;

public class EntryItemText implements IEntry {

   public ItemStack stack;
   public String entryName;


   public EntryItemText(ItemStack stack) {
      this.stack = stack;
   }

   public EntryItemText(ItemStack stack, String entryName) {
      this.stack = stack;
      this.entryName = entryName;
   }

   public void draw(GuiEntry entry, int width, int height, int left, int top, EntityPlayer player, String key, int page, int mX, int mY) {
      this.drawText(entry, width, height, left, top, player, key, page, mX, mY);
      this.drawBlock(entry, width, height, left, top, player, key, page, mX, mY);
   }

   public void drawText(GuiEntry entry, int width, int height, int left, int top, EntityPlayer player, String key, int page, int mX, int mY) {
      if(this.entryName == null) {
         this.entryName = key;
      }

      String s = StatCollector.translateToLocal("aw.entry." + this.entryName + "." + page);
      int x = left + width / 2 - 58;
      int y = top + 15;
      Minecraft.getMinecraft().fontRenderer.setUnicodeFlag(true);
      Minecraft.getMinecraft().fontRenderer.drawSplitString(s, x, y, 110, 0);
      Minecraft.getMinecraft().fontRenderer.setUnicodeFlag(false);
   }

   public void drawBlock(GuiEntry entry, int width, int height, int left, int top, EntityPlayer player, String key, int page, int mX, int mY) {
      RenderItem ri = new RenderItem();
      GL11.glPushMatrix();
      GL11.glScaled(3.0D, 3.0D, 1.0D);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      RenderHelper.enableGUIStandardItemLighting();
      GL11.glEnable('\u803a');
      GL11.glEnable(2929);
      ri.renderItemAndEffectIntoGUI(Minecraft.getMinecraft().fontRenderer, Minecraft.getMinecraft().getTextureManager(), this.stack, left - left / 2 + 2, top + 20);
      ri.renderItemOverlayIntoGUI(Minecraft.getMinecraft().fontRenderer, Minecraft.getMinecraft().getTextureManager(), this.stack, left - left / 2 + 2, top + 20);
      RenderHelper.disableStandardItemLighting();
      GL11.glPopMatrix();
      GL11.glDisable(2896);
   }

   public void initGui(int width, int height, int left, int top, EntityPlayer player, List buttonList) {}

   public void actionPerformed(GuiButton button) {}
}
