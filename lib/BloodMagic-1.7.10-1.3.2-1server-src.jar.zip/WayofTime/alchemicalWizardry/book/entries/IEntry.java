package WayofTime.alchemicalWizardry.book.entries;

import WayofTime.alchemicalWizardry.book.classes.guide.GuiEntry;
import java.util.List;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.entity.player.EntityPlayer;

public interface IEntry {

   void draw(GuiEntry var1, int var2, int var3, int var4, int var5, EntityPlayer var6, String var7, int var8, int var9, int var10);

   void initGui(int var1, int var2, int var3, int var4, EntityPlayer var5, List var6);

   void actionPerformed(GuiButton var1);
}
