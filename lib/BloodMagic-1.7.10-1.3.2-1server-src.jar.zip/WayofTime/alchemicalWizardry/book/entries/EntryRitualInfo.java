package WayofTime.alchemicalWizardry.book.entries;

import WayofTime.alchemicalWizardry.book.classes.guide.GuiEntry;
import WayofTime.alchemicalWizardry.book.entries.IEntry;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.entity.player.EntityPlayer;

public class EntryRitualInfo implements IEntry {

   public int cost;


   public EntryRitualInfo(int cost) {
      this.cost = cost;
   }

   public void draw(GuiEntry entry, int width, int height, int left, int top, EntityPlayer player, String key, int page, int mX, int mY) {
      int x = left + width / 2 - 58;
      int y = top + 15;
      Minecraft.getMinecraft().fontRenderer.setUnicodeFlag(true);
      Minecraft.getMinecraft().fontRenderer.drawString("Cost: " + this.cost + " LP", x, y, 0);
      Minecraft.getMinecraft().fontRenderer.setUnicodeFlag(false);
   }

   public void initGui(int width, int height, int left, int top, EntityPlayer player, List buttonList) {}

   public void actionPerformed(GuiButton button) {}
}
