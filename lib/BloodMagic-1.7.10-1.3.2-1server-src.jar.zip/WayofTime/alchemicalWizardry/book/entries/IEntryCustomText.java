package WayofTime.alchemicalWizardry.book.entries;

import WayofTime.alchemicalWizardry.book.entries.IEntry;

public interface IEntryCustomText extends IEntry {

   String getText();

   void setText(String var1);
}
