package WayofTime.alchemicalWizardry.book.entries;

import WayofTime.alchemicalWizardry.api.altarRecipeRegistry.AltarRecipe;
import WayofTime.alchemicalWizardry.book.classes.guide.GuiEntry;
import WayofTime.alchemicalWizardry.book.entries.IEntry;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class EntryAltarRecipe implements IEntry {

   public AltarRecipe recipes;
   public ItemStack input;
   public ItemStack output;
   public int essence;
   public ArrayList icons = new ArrayList();


   public EntryAltarRecipe(AltarRecipe recipes) {
      this.recipes = recipes;
      this.populate(recipes);
   }

   public void populate(AltarRecipe recipe) {
      this.input = recipe.requiredItem;
      this.output = recipe.result;
      this.essence = recipe.liquidRequired;
   }

   public void draw(GuiEntry entry, int width, int height, int left, int top, EntityPlayer player, String key, int page, int mX, int mY) {
      GL11.glPushMatrix();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      RenderHelper.enableGUIStandardItemLighting();
      GL11.glEnable('\u803a');
      GL11.glEnable(2929);
      this.renderOverlay(entry, width, height, left, top);
      int x = left + width / 2 - 20;
      int y = height / 2 - 36 + 18;
      this.drawIcon(this.input, x, y);
      x = left + width / 2 - -36;
      y = height / 2 - 36 + 18;
      this.drawIcon(this.output, x, y);
      RenderHelper.disableStandardItemLighting();
      GL11.glDisable(2896);
      GL11.glPopMatrix();
      Iterator i$ = this.icons.iterator();

      while(i$.hasNext()) {
         EntryAltarRecipe.ItemIcon icon = (EntryAltarRecipe.ItemIcon)i$.next();
         if(icon.stack != null) {
            icon.onMouseBetween(mX, mY);
         }
      }

   }

   public void drawIcon(ItemStack stack, int x, int y) {
      RenderItem ri = new RenderItem();
      ri.renderItemAndEffectIntoGUI(Minecraft.getMinecraft().fontRenderer, Minecraft.getMinecraft().getTextureManager(), stack, x, y);
      ri.renderItemOverlayIntoGUI(Minecraft.getMinecraft().fontRenderer, Minecraft.getMinecraft().getTextureManager(), stack, x, y);
      this.icons.add(new EntryAltarRecipe.ItemIcon(stack, x, y));
   }

   public void renderOverlay(GuiEntry entry, int width, int height, int left, int top) {
      TextureManager tm = Minecraft.getMinecraft().getTextureManager();
      tm.bindTexture(new ResourceLocation("bloodutils:textures/gui/altar.png"));
      entry.drawTexturedModalRect(left, height / 2 - 36 + 0 - 17, 0, 0, width, height);
   }

   public void initGui(int width, int height, int left, int top, EntityPlayer player, List buttonList) {}

   public void actionPerformed(GuiButton button) {}

   static class ItemIcon {

      public ItemStack stack;
      public int x;
      public int y;


      public ItemIcon(ItemStack stack, int x, int y) {
         this.stack = stack;
         this.x = x;
         this.y = y;
      }

      public void onMouseBetween(int mX, int mY) {
         int xSize = this.x + 16;
         int ySize = this.y + 16;
         if(mX > this.x && mX < xSize && mY > this.y && mY < ySize) {
            GL11.glDisable(2929);
            if(this.stack != null && this.stack.getDisplayName() != null) {
               Minecraft.getMinecraft().fontRenderer.drawString(this.stack.getDisplayName(), mX + 6, mY, (new Color(139, 137, 137)).getRGB());
            }

            GL11.glEnable(2929);
         }

      }
   }
}
