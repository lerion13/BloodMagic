package WayofTime.alchemicalWizardry.book.entries;

import WayofTime.alchemicalWizardry.book.entries.EntryCraftingRecipe;
import WayofTime.alchemicalWizardry.book.entries.IEntryCustomText;
import net.minecraft.item.crafting.IRecipe;

public class EntryCraftingRecipeCustomText extends EntryCraftingRecipe implements IEntryCustomText {

   public EntryCraftingRecipeCustomText(IRecipe recipes) {
      super(recipes);
   }

   public String getText() {
      return "";
   }

   public void setText(String str) {}
}
