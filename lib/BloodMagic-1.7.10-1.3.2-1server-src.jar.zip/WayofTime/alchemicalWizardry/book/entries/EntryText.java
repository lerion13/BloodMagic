package WayofTime.alchemicalWizardry.book.entries;

import WayofTime.alchemicalWizardry.book.classes.guide.GuiEntry;
import WayofTime.alchemicalWizardry.book.entries.IEntry;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.StatCollector;

public class EntryText implements IEntry {

   public String entryName;


   public EntryText() {}

   public EntryText(String entryName) {
      this.entryName = entryName;
   }

   public void draw(GuiEntry entry, int width, int height, int left, int top, EntityPlayer player, String key, int page, int mX, int mY) {
      if(this.entryName == null) {
         this.entryName = key;
      }

      String s = StatCollector.translateToLocal("aw.entry." + this.entryName + "." + page);
      int x = left + width / 2 - 58;
      int y = top + 15;
      Minecraft.getMinecraft().fontRenderer.setUnicodeFlag(true);
      Minecraft.getMinecraft().fontRenderer.drawSplitString(s, x, y, 110, 0);
      Minecraft.getMinecraft().fontRenderer.setUnicodeFlag(false);
   }

   public void initGui(int width, int height, int left, int top, EntityPlayer player, List buttonList) {}

   public void actionPerformed(GuiButton button) {}
}
