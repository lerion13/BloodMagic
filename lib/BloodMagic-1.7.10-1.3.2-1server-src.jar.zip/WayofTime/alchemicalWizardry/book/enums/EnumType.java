package WayofTime.alchemicalWizardry.book.enums;


public enum EnumType {

   BLOCK("BLOCK", 0),
   ITEM("ITEM", 1);
   // $FF: synthetic field
   private static final EnumType[] $VALUES = new EnumType[]{BLOCK, ITEM};


   private EnumType(String var1, int var2) {}

}
