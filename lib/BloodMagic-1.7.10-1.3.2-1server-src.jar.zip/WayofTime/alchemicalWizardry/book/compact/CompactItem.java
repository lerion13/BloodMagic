package WayofTime.alchemicalWizardry.book.compact;

import net.minecraft.item.Item;

public class CompactItem {

   public Item item1;
   public Item item2;


   public CompactItem(Item item1, Item item2) {
      this.item1 = item1;
      this.item2 = item2;
   }

   public boolean equals(Object obj) {
      if(!(obj instanceof CompactItem)) {
         return false;
      } else {
         CompactItem ci = (CompactItem)obj;
         return ci.item1 == this.item1 && ci.item2 == this.item2;
      }
   }
}
