package WayofTime.alchemicalWizardry.book.classes.guide.elements;

import WayofTime.alchemicalWizardry.book.classes.guide.GuiIndex;
import WayofTime.alchemicalWizardry.book.compact.Category;
import WayofTime.alchemicalWizardry.book.helpers.GuiHelper;
import WayofTime.alchemicalWizardry.book.interfaces.IEntryElement;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.IIcon;
import net.minecraft.util.ResourceLocation;

public class ElementCategory extends GuiScreen implements IEntryElement {

   public Category category;
   public EntityPlayer player;
   public int x;
   public int y;
   public int field_146294_l;
   public int field_146295_m;


   public ElementCategory(Category category, int x, int y, int width, int height, EntityPlayer player) {
      this.category = category;
      this.player = player;
      this.x = x;
      this.y = y;
      this.field_146294_l = width;
      this.field_146295_m = height;
   }

   public void drawElement() {
      IIcon icon = this.category.iconStack.getIconIndex();
      Minecraft.getMinecraft().getTextureManager().bindTexture(new ResourceLocation("bloodutils:textures/misc/tab.png"));
      GuiHelper.drawIconWithoutColor(this.x - 1, this.y - 1, this.field_146294_l + 2, this.field_146295_m + 2, 0.0F);
      GuiHelper.renderIcon(this.x + 3, this.y + 2, 16, 16, icon, this.category.type);
   }

   public boolean isMouseInElement(int mX, int mY) {
      return GuiHelper.isMouseBetween(mX, mY, this.x, this.y, this.field_146294_l, this.field_146295_m);
   }

   public void onMouseEnter(int mX, int mY) {
      Minecraft.getMinecraft().fontRenderer.drawString(this.category.name, mX + 6, mY, 0);
   }

   public void onMouseClick(int mX, int mY, int type) {
      Minecraft.getMinecraft().displayGuiScreen(new GuiIndex(this.category, this.player));
   }
}
