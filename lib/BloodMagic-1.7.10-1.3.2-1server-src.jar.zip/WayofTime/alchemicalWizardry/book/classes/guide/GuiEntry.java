package WayofTime.alchemicalWizardry.book.classes.guide;

import WayofTime.alchemicalWizardry.book.classes.guide.GuiCategories;
import WayofTime.alchemicalWizardry.book.classes.guide.GuiIndex;
import WayofTime.alchemicalWizardry.book.classes.guide.buttons.ButtonNext;
import WayofTime.alchemicalWizardry.book.compact.Category;
import WayofTime.alchemicalWizardry.book.compact.Entry;
import WayofTime.alchemicalWizardry.book.entries.IEntry;
import WayofTime.alchemicalWizardry.book.registries.EntryRegistry;
import java.util.HashMap;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class GuiEntry extends GuiScreen {

   private static final ResourceLocation gui = new ResourceLocation("bloodutils:textures/gui/guide.png");
   int gwidth = 192;
   int gheight = 192;
   int prevPage;
   int left;
   int top;
   String key;
   int currPage = 1;
   GuiButton next;
   GuiButton prev;
   GuiButton back;
   EntityPlayer player;
   Category category;


   public GuiEntry(String key, EntityPlayer player, Category category) {
      this.key = key;
      this.player = player;
      this.category = category;
   }

   public GuiEntry(String key, EntityPlayer player, Category category, int currPage) {
      this.key = key;
      this.player = player;
      this.category = category;
      this.currPage = currPage;
   }

   public void initGui() {
      super.initGui();
      this.left = super.width / 2 - this.gwidth / 2;
      this.top = super.height / 2 - this.gheight / 2;
      super.buttonList.clear();
      int k = (super.width - this.gwidth) / 2;
      super.buttonList.add(this.next = new ButtonNext(500, k + 120, this.top + 160, true));
      super.buttonList.add(this.prev = new ButtonNext(501, k + 38, this.top + 160, false));
      Entry e = (Entry)((HashMap)EntryRegistry.entries.get(this.category)).get(this.key);
      if(e != null) {
         IEntry entry = e.entry[this.currPage - 1];
         if(entry != null) {
            entry.initGui(this.gwidth, this.gheight, this.left, this.top, this.player, super.buttonList);
         }
      } else {
         super.mc.displayGuiScreen(new GuiCategories(this.player));
      }

   }

   public void drawScreen(int mX, int mY, float f1) {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      super.mc.renderEngine.bindTexture(gui);
      this.drawTexturedModalRect(this.left, this.top, 0, 0, this.gwidth, this.gheight);
      Entry e = (Entry)((HashMap)EntryRegistry.entries.get(this.category)).get(this.key);
      String str = e.name;
      this.drawCenteredString(super.fontRendererObj, str, this.left + this.gwidth / 2, this.top - 15, 3368550);
      this.drawCenteredString(super.fontRendererObj, this.currPage + "/" + e.entry.length, this.left + this.gwidth / 2, this.top + 160, 3368550);
      IEntry entry = e.entry[this.currPage - 1];
      if(entry != null) {
         entry.draw(this, this.gwidth, this.gheight, this.left, this.top, this.player, e.name, this.currPage, mX, mY);
      }

      super.drawScreen(mX, mY, f1);
   }

   public void mouseClicked(int mX, int mY, int type) {
      super.mouseClicked(mX, mY, type);
      if(type == 1) {
         super.mc.displayGuiScreen(new GuiIndex(this.category, this.player));
      }

   }

   public void keyTyped(char c, int i) {
      super.keyTyped(c, i);
      if(Keyboard.getEventKeyState() && i == 14) {
         super.mc.displayGuiScreen(new GuiIndex(this.category, this.player));
      }
   }

   public boolean doesGuiPauseGame() {
      return false;
   }

   protected void actionPerformed(GuiButton button) {
      int id = button.id;
      int maxPages = ((Entry)((HashMap)EntryRegistry.entries.get(this.category)).get(this.key)).entry.length;
      if(id == 500) {
         if(this.currPage < maxPages) {
            ++this.currPage;
            this.initGui();
         }
      } else if(id == 501) {
         if(this.currPage > 1) {
            --this.currPage;
            this.initGui();
         }
      } else {
         Entry e = (Entry)((HashMap)EntryRegistry.entries.get(this.category)).get(this.key);
         if(e != null) {
            IEntry entry = e.entry[this.currPage];
            if(entry != null) {
               entry.actionPerformed(button);
            }
         } else {
            super.mc.displayGuiScreen(new GuiCategories(this.player));
         }
      }

   }

   public void onGuiClosed() {
      ItemStack held = this.player.getHeldItem();
      if(held.hasTagCompound()) {
         held.getTagCompound().setString("CATEGORY", this.category.name);
         held.getTagCompound().setString("KEY", this.key);
         held.getTagCompound().setInteger("PAGE", this.currPage);
      }

   }

}
