package WayofTime.alchemicalWizardry.book.classes.guide;

import WayofTime.alchemicalWizardry.book.classes.guide.elements.ElementCategory;
import WayofTime.alchemicalWizardry.book.compact.Category;
import WayofTime.alchemicalWizardry.book.registries.EntryRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class GuiCategories extends GuiScreen {

   private static final ResourceLocation gui = new ResourceLocation("bloodutils:textures/gui/front.png");
   int gwidth = 192;
   int gheight = 192;
   int x;
   int y;
   ElementCategory[] categories;
   EntityPlayer player;


   public GuiCategories(EntityPlayer player) {
      this.categories = new ElementCategory[EntryRegistry.categories.size()];
      this.player = player;
   }

   public void initGui() {
      super.initGui();
      this.x = super.width / 2 - this.gwidth / 2;
      this.y = super.height / 2 - this.gheight / 2;
      super.buttonList.clear();
      int pX = this.x - 1;
      int pY = this.y + 12;
      byte iWidth = 20;
      byte iHeight = 20;

      for(int i = 0; i < EntryRegistry.categories.size(); ++i) {
         Category category = (Category)EntryRegistry.categories.get(i);
         this.categories[i] = new ElementCategory(category, pX, pY + i * iHeight - 2, iWidth, iHeight, this.player);
      }

   }

   public void drawScreen(int mX, int mY, float f1) {
      super.drawScreen(mX, mY, f1);
      int fHeight = Minecraft.getMinecraft().fontRenderer.FONT_HEIGHT;
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      super.mc.renderEngine.bindTexture(gui);
      this.drawTexturedModalRect(this.x, this.y, 0, 0, this.gwidth, this.gheight);
      String str = "Categories";
      this.drawCenteredString(super.fontRendererObj, str, this.x + this.gwidth / 2, this.y - 15, 3368550);

      for(int i = 0; i < EntryRegistry.categories.size(); ++i) {
         ElementCategory category = this.categories[i];
         category.drawElement();
         if(category.isMouseInElement(mX, mY)) {
            category.onMouseEnter(mX, mY);
         }
      }

   }

   public void mouseClicked(int mX, int mY, int type) {
      super.mouseClicked(mX, mY, type);

      for(int i = 0; i < EntryRegistry.categories.size(); ++i) {
         ElementCategory category = this.categories[i];
         if(category.isMouseInElement(mX, mY)) {
            category.onMouseClick(mX, mY, type);
         }
      }

   }

   public boolean doesGuiPauseGame() {
      return false;
   }

}
