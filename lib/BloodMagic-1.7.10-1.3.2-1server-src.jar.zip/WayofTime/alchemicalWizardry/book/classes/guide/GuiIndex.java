package WayofTime.alchemicalWizardry.book.classes.guide;

import WayofTime.alchemicalWizardry.book.classes.guide.GuiCategories;
import WayofTime.alchemicalWizardry.book.classes.guide.GuiEntry;
import WayofTime.alchemicalWizardry.book.classes.guide.buttons.ButtonNext;
import WayofTime.alchemicalWizardry.book.classes.guide.buttons.ButtonPage;
import WayofTime.alchemicalWizardry.book.classes.guide.elements.ElementCategory;
import WayofTime.alchemicalWizardry.book.compact.Category;
import WayofTime.alchemicalWizardry.book.compact.Entry;
import WayofTime.alchemicalWizardry.book.registries.EntryRegistry;
import java.util.HashMap;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class GuiIndex extends GuiScreen {

   private static final ResourceLocation gui = new ResourceLocation("bloodutils:textures/gui/guide.png");
   GuiButton prev;
   GuiButton next;
   GuiButton back;
   Category category;
   EntityPlayer player;
   ElementCategory[] categories;
   int gwidth;
   int gheight;
   int left;
   int top;
   int currPage;


   public GuiIndex(Category category, EntityPlayer player) {
      this.categories = new ElementCategory[EntryRegistry.categories.size()];
      this.gwidth = 192;
      this.gheight = 192;
      this.currPage = 0;
      this.category = category;
      this.player = player;
   }

   public GuiIndex(Category category, EntityPlayer player, int currPage) {
      this.categories = new ElementCategory[EntryRegistry.categories.size()];
      this.gwidth = 192;
      this.gheight = 192;
      this.currPage = 0;
      this.category = category;
      this.player = player;
      this.currPage = currPage;
   }

   public void initGui() {
      super.initGui();
      this.left = super.width / 2 - this.gwidth / 2;
      this.top = super.height / 2 - this.gheight / 2;
      super.buttonList.clear();
      this.populate();
      this.drawCategories();
      int k = (super.width - this.gwidth) / 2;
      super.buttonList.add(this.next = new ButtonNext(500, k + 120, this.top + 160, true));
      super.buttonList.add(this.prev = new ButtonNext(501, k + 38, this.top + 160, false));
   }

   public void drawCategories() {
      int pX = this.left - 1;
      int pY = this.top + 12;
      byte iWidth = 20;
      byte iHeight = 20;

      for(int i = 0; i < EntryRegistry.categories.size(); ++i) {
         Category category = (Category)EntryRegistry.categories.get(i);
         this.categories[i] = new ElementCategory(category, pX, pY + i * iHeight - 2, iWidth, iHeight, this.player);
      }

   }

   public void populate() {
      super.buttonList.clear();
      HashMap entries = (HashMap)EntryRegistry.entries.get(this.category);
      int k;
      if(entries != null && !entries.isEmpty()) {
         k = 0;
         Entry[] entryList = EntryRegistry.getEntriesInOrderForCategory(this.category);

         for(int i = 0; i < entryList.length; ++i) {
            Entry entry = entryList[i];
            if(entry != null && entry.indexPage == this.currPage) {
               int x = this.left + this.gwidth / 2 - 75;
               int y = this.top + 15 + 10 * k;
               super.buttonList.add(new ButtonPage(k, x, y, 110, 10, ""));
               ++k;
            }
         }
      }

      k = (super.width - this.gwidth) / 2;
      super.buttonList.add(this.next = new ButtonNext(500, k + 120, this.top + 160, true));
      super.buttonList.add(this.prev = new ButtonNext(501, k + 38, this.top + 160, false));
   }

   public void drawScreen(int mX, int mY, float f1) {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      super.mc.renderEngine.bindTexture(gui);
      this.drawTexturedModalRect(this.left, this.top, 0, 0, this.gwidth, this.gheight);
      String str = this.category.name;
      this.drawCenteredString(super.fontRendererObj, str, this.left + this.gwidth / 2, this.top - 15, 3368550);
      int i;
      if(this.category != null && EntryRegistry.maxEntries.containsKey(this.category)) {
         i = ((Integer)EntryRegistry.maxEntries.get(this.category)).intValue();
         this.drawCenteredString(super.fontRendererObj, this.currPage + 1 + "/" + (i + 1), this.left + this.gwidth / 2, this.top + 160, 3368550);
         this.registerButtons();
      }

      for(i = 0; i < EntryRegistry.categories.size(); ++i) {
         ElementCategory category = this.categories[i];
         category.drawElement();
         if(category.isMouseInElement(mX, mY)) {
            category.onMouseEnter(mX, mY);
         }
      }

      super.drawScreen(mX, mY, f1);
   }

   public void registerButtons() {
      HashMap entries = (HashMap)EntryRegistry.entries.get(this.category);
      if(entries != null && !entries.isEmpty()) {
         Entry[] entryList = EntryRegistry.getEntriesInOrderForCategory(this.category);
         int j = 0;

         for(int i = 0; i < entryList.length; ++i) {
            Entry entry = entryList[i];
            if(entry != null && entry.indexPage == this.currPage) {
               String title = entry.name;
               if(title != null && super.buttonList.get(j) != null && super.buttonList.get(j) instanceof ButtonPage) {
                  ButtonPage button = (ButtonPage)super.buttonList.get(j);
                  button.displayString = title;
                  ++j;
               }
            }
         }
      }

   }

   public void mouseClicked(int mX, int mY, int type) {
      super.mouseClicked(mX, mY, type);
      if(type == 1) {
         super.mc.displayGuiScreen(new GuiCategories(this.player));
      }

      for(int i = 0; i < EntryRegistry.categories.size(); ++i) {
         ElementCategory category = this.categories[i];
         if(category.isMouseInElement(mX, mY)) {
            category.onMouseClick(mX, mY, type);
         }
      }

   }

   public boolean doesGuiPauseGame() {
      return false;
   }

   protected void actionPerformed(GuiButton button) {
      int id = button.id;
      int size;
      if(EntryRegistry.maxEntries.containsKey(this.category)) {
         size = ((Integer)EntryRegistry.maxEntries.get(this.category)).intValue();
      } else {
         size = 1;
      }

      if(id == 500) {
         if(this.currPage + 1 < size + 1) {
            ++this.currPage;
            this.populate();
            this.registerButtons();
         }
      } else if(id == 501) {
         if(this.currPage > 0) {
            --this.currPage;
            this.populate();
            this.registerButtons();
         }
      } else {
         super.mc.displayGuiScreen(new GuiEntry(button.displayString, this.player, this.category));
      }

   }

   public void keyTyped(char c, int i) {
      super.keyTyped(c, i);
      if(Keyboard.getEventKeyState() && i == 14) {
         super.mc.displayGuiScreen(new GuiCategories(this.player));
      }
   }

   public void onGuiClosed() {
      ItemStack held = this.player.getHeldItem();
      if(held.hasTagCompound()) {
         held.getTagCompound().setString("CATEGORY", this.category.name);
         held.getTagCompound().setString("KEY", "0");
         held.getTagCompound().setInteger("PAGE", this.currPage);
      }

   }

}
