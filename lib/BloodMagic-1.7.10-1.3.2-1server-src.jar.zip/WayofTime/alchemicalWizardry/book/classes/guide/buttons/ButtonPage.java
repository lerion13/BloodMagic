package WayofTime.alchemicalWizardry.book.classes.guide.buttons;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;

public class ButtonPage extends GuiButton {

   int gwidth = 170;
   int gheight = 180;


   public ButtonPage(int id, int xPos, int yPos, int width, int height, String string) {
      super(id, xPos, yPos, width, height, string);
   }

   public void drawButton(Minecraft mc, int x, int y) {
      super.field_146123_n = x >= super.xPosition && y >= super.yPosition && x < super.xPosition + super.width && y < super.yPosition + super.height;
      int state = this.getHoverState(super.field_146123_n);
      x = super.xPosition + super.width / 2 - 30;
      y = super.yPosition + (super.height - 6) / 2;
      mc.fontRenderer.setUnicodeFlag(true);
      mc.fontRenderer.drawString(super.displayString, x + (state == 2?5:0), y, this.calcColor(state));
      mc.fontRenderer.setUnicodeFlag(false);
   }

   public int calcColor(int state) {
      return state == 2?(new Color(155, 155, 155)).getRGB():(new Color(55, 55, 55)).getRGB();
   }
}
