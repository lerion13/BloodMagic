package WayofTime.alchemicalWizardry.book.interfaces;

import net.minecraft.world.World;

public interface IReviving {

   void spawnEntity(World var1, int var2, int var3, int var4);
}
