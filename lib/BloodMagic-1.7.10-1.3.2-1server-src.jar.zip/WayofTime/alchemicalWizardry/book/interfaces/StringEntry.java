package WayofTime.alchemicalWizardry.book.interfaces;

import WayofTime.alchemicalWizardry.book.compact.Entry;

public class StringEntry {

   public String str;
   public Entry entry;


   public StringEntry(String str, Entry ent) {
      this.str = str;
      this.entry = ent;
   }
}
