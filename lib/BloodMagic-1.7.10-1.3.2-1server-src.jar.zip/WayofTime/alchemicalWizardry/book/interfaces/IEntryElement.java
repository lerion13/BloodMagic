package WayofTime.alchemicalWizardry.book.interfaces;


public interface IEntryElement {

   void drawElement();

   boolean isMouseInElement(int var1, int var2);

   void onMouseEnter(int var1, int var2);

   void onMouseClick(int var1, int var2, int var3);
}
