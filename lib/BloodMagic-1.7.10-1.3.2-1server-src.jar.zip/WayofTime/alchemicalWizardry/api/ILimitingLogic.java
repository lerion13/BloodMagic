package WayofTime.alchemicalWizardry.api;


public interface ILimitingLogic {

   int getRoutingLimit();
}
