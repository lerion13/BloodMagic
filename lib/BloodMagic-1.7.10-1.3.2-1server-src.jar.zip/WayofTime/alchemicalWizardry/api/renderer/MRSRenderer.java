package WayofTime.alchemicalWizardry.api.renderer;

import WayofTime.alchemicalWizardry.api.rituals.IMasterRitualStone;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.util.ResourceLocation;

public abstract class MRSRenderer {

   public abstract void renderAt(IMasterRitualStone var1, double var2, double var4, double var6);

   protected void bindTexture(ResourceLocation p_147499_1_) {
      TextureManager texturemanager = TileEntityRendererDispatcher.instance.field_147553_e;
      if(texturemanager != null) {
         texturemanager.bindTexture(p_147499_1_);
      }

   }
}
