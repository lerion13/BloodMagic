package WayofTime.alchemicalWizardry.api.rituals;

import WayofTime.alchemicalWizardry.api.alchemy.energy.ISegmentedReagentHandler;
import WayofTime.alchemicalWizardry.api.rituals.LocalRitualStorage;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public interface IMasterRitualStone extends ISegmentedReagentHandler {

   void performRitual(World var1, int var2, int var3, int var4, String var5);

   String getOwner();

   void setCooldown(int var1);

   int getCooldown();

   void setVar1(int var1);

   int getVar1();

   void setActive(boolean var1);

   int getDirection();

   World getWorld();

   int getXCoord();

   int getYCoord();

   int getZCoord();

   NBTTagCompound getCustomRitualTag();

   void setCustomRitualTag(NBTTagCompound var1);

   boolean areTanksEmpty();

   int getRunningTime();

   LocalRitualStorage getLocalStorage();

   void setLocalStorage(LocalRitualStorage var1);
}
