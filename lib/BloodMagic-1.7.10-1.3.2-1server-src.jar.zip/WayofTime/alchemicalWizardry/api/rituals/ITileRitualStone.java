package WayofTime.alchemicalWizardry.api.rituals;


public interface ITileRitualStone {

   boolean isRuneType(int var1);
}
