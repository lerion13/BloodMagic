package WayofTime.alchemicalWizardry.api.rituals;

import WayofTime.alchemicalWizardry.api.Int3;
import net.minecraft.nbt.NBTTagCompound;

public class LocalRitualStorage {

   public int xCoord;
   public int yCoord;
   public int zCoord;


   public void writeToNBT(NBTTagCompound tag) {
      tag.setInteger("xCoord", this.xCoord);
      tag.setInteger("yCoord", this.yCoord);
      tag.setInteger("zCoord", this.zCoord);
   }

   public void readFromNBT(NBTTagCompound tag) {
      this.xCoord = tag.getInteger("xCoord");
      this.yCoord = tag.getInteger("yCoord");
      this.zCoord = tag.getInteger("zCoord");
   }

   public Int3 getLocation() {
      return new Int3(this.xCoord, this.yCoord, this.zCoord);
   }

   public void setLocation(Int3 location) {
      this.xCoord = location.xCoord;
      this.yCoord = location.yCoord;
      this.zCoord = location.zCoord;
   }
}
