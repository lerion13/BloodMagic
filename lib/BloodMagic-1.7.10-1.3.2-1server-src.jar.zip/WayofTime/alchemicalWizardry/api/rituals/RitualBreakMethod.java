package WayofTime.alchemicalWizardry.api.rituals;


public enum RitualBreakMethod {

   REDSTONE("REDSTONE", 0),
   BREAK_MRS("BREAK_MRS", 1),
   BREAK_STONE("BREAK_STONE", 2),
   ACTIVATE("ACTIVATE", 3),
   DEACTIVATE("DEACTIVATE", 4),
   EXPLOSION("EXPLOSION", 5);
   // $FF: synthetic field
   private static final RitualBreakMethod[] $VALUES = new RitualBreakMethod[]{REDSTONE, BREAK_MRS, BREAK_STONE, ACTIVATE, DEACTIVATE, EXPLOSION};


   private RitualBreakMethod(String var1, int var2) {}

}
