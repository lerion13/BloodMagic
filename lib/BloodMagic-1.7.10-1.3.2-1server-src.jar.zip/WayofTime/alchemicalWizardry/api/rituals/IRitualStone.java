package WayofTime.alchemicalWizardry.api.rituals;

import net.minecraft.world.World;

public interface IRitualStone {

   boolean isRuneType(World var1, int var2, int var3, int var4, int var5, int var6);
}
