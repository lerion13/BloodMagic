package WayofTime.alchemicalWizardry.api.harvest;

import net.minecraft.block.Block;
import net.minecraft.world.World;

public interface IHarvestHandler {

   boolean harvestAndPlant(World var1, int var2, int var3, int var4, Block var5, int var6);
}
