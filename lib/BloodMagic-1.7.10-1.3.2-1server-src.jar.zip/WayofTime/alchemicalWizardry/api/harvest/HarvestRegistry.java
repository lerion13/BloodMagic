package WayofTime.alchemicalWizardry.api.harvest;

import WayofTime.alchemicalWizardry.api.harvest.IHarvestHandler;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.world.World;

public class HarvestRegistry {

   public static List handlerList = new ArrayList();


   public static void registerHarvestHandler(IHarvestHandler handler) {
      handlerList.add(handler);
   }

   public static boolean harvestBlock(World world, int xCoord, int yCoord, int zCoord) {
      Block block = world.getBlock(xCoord, yCoord, zCoord);
      int meta = world.getBlockMetadata(xCoord, yCoord, zCoord);
      Iterator i$ = handlerList.iterator();

      IHarvestHandler handler;
      do {
         if(!i$.hasNext()) {
            return false;
         }

         handler = (IHarvestHandler)i$.next();
      } while(!handler.harvestAndPlant(world, xCoord, yCoord, zCoord, block, meta));

      return true;
   }

}
