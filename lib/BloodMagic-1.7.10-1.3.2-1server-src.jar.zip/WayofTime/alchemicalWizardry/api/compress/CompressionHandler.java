package WayofTime.alchemicalWizardry.api.compress;

import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public abstract class CompressionHandler {

   public abstract ItemStack compressInventory(ItemStack[] var1, World var2);
}
