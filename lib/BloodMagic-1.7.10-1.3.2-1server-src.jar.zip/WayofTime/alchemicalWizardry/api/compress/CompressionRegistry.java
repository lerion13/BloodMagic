package WayofTime.alchemicalWizardry.api.compress;

import WayofTime.alchemicalWizardry.api.compress.CompressionHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class CompressionRegistry {

   public static List compressionRegistry = new ArrayList();
   public static Map thresholdMap = new HashMap();


   public static void registerHandler(CompressionHandler handler) {
      compressionRegistry.add(handler);
   }

   public static void registerItemThreshold(ItemStack stack, int threshold) {
      thresholdMap.put(stack, new Integer(threshold));
   }

   public static ItemStack compressInventory(ItemStack[] inv, World world) {
      Iterator i$ = compressionRegistry.iterator();

      ItemStack stack;
      do {
         if(!i$.hasNext()) {
            return null;
         }

         CompressionHandler handler = (CompressionHandler)i$.next();
         stack = handler.compressInventory(inv, world);
      } while(stack == null);

      return stack;
   }

   public static int getItemThreshold(ItemStack stack) {
      Iterator i$ = thresholdMap.entrySet().iterator();

      Entry entry;
      do {
         if(!i$.hasNext()) {
            return 0;
         }

         entry = (Entry)i$.next();
      } while(!areItemStacksEqual((ItemStack)entry.getKey(), stack));

      return ((Integer)entry.getValue()).intValue();
   }

   public static boolean areItemStacksEqual(ItemStack stack, ItemStack compressedStack) {
      boolean var10000;
      if(stack.isItemEqual(compressedStack)) {
         label25: {
            if(stack.getTagCompound() == null) {
               if(compressedStack.getTagCompound() != null) {
                  break label25;
               }
            } else if(!stack.getTagCompound().equals(compressedStack.getTagCompound())) {
               break label25;
            }

            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

}
