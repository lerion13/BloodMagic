package WayofTime.alchemicalWizardry.api.summoningRegistry;

import WayofTime.alchemicalWizardry.api.summoningRegistry.SummoningHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class SummoningRegistryComponent {

   public ItemStack[] ring1 = new ItemStack[6];
   public ItemStack[] ring2 = new ItemStack[6];
   public ItemStack[] ring3 = new ItemStack[6];
   public SummoningHelper summoningHelper;
   public int summoningCost;
   public int bloodOrbLevel;


   public SummoningRegistryComponent(SummoningHelper s, ItemStack[] newRing1, ItemStack[] newRing2, ItemStack[] newRing3, int amount, int bloodOrbLevel) {
      this.summoningHelper = s;
      this.ring1 = newRing1;
      this.ring2 = newRing2;
      this.ring3 = newRing3;
      this.summoningCost = amount;
      this.bloodOrbLevel = bloodOrbLevel;
      ItemStack[] newRecipe;
      int i;
      if(this.ring1.length != 6) {
         newRecipe = new ItemStack[6];

         for(i = 0; i < 6; ++i) {
            if(i + 1 > this.ring1.length) {
               newRecipe[i] = null;
            } else {
               newRecipe[i] = this.ring1[i];
            }
         }

         this.ring1 = newRecipe;
      }

      if(this.ring2.length != 6) {
         newRecipe = new ItemStack[6];

         for(i = 0; i < 6; ++i) {
            if(i + 1 > this.ring2.length) {
               newRecipe[i] = null;
            } else {
               newRecipe[i] = this.ring2[i];
            }
         }

         this.ring2 = newRecipe;
      }

      if(this.ring3.length != 6) {
         newRecipe = new ItemStack[6];

         for(i = 0; i < 6; ++i) {
            if(i + 1 > this.ring3.length) {
               newRecipe[i] = null;
            } else {
               newRecipe[i] = this.ring3[i];
            }
         }

         this.ring3 = newRecipe;
      }

   }

   public boolean compareRing(int ring, ItemStack[] checkedRingRecipe) {
      if(checkedRingRecipe.length < 6) {
         return false;
      } else {
         ItemStack[] recipe;
         switch(ring) {
         case 1:
            recipe = this.ring1;
            break;
         case 2:
            recipe = this.ring2;
            break;
         case 3:
            recipe = this.ring3;
            break;
         default:
            recipe = this.ring1;
         }

         int i;
         if(recipe.length != 6) {
            ItemStack[] checkList = new ItemStack[6];

            for(i = 0; i < 6; ++i) {
               if(i + 1 > recipe.length) {
                  checkList[i] = null;
               } else {
                  checkList[i] = recipe[i];
               }
            }

            recipe = checkList;
         }

         boolean[] var11 = new boolean[6];

         for(i = 0; i < 6; ++i) {
            var11[i] = false;
         }

         for(i = 0; i < 6; ++i) {
            ItemStack recipeItemStack = recipe[i];
            if(recipeItemStack != null) {
               boolean test = false;

               for(int j = 0; j < 6; ++j) {
                  if(!var11[j]) {
                     ItemStack checkedItemStack = checkedRingRecipe[j];
                     if(checkedItemStack != null) {
                        boolean quickTest = false;
                        if(recipeItemStack.getItem() instanceof ItemBlock) {
                           if(checkedItemStack.getItem() instanceof ItemBlock) {
                              quickTest = true;
                           }
                        } else if(!(checkedItemStack.getItem() instanceof ItemBlock)) {
                           quickTest = true;
                        }

                        if(quickTest && (checkedItemStack.getItemDamage() == recipeItemStack.getItemDamage() || 32767 == recipeItemStack.getItemDamage()) && checkedItemStack.getItem() == recipeItemStack.getItem()) {
                           test = true;
                           var11[j] = true;
                           break;
                        }
                     }
                  }
               }

               if(!test) {
                  return false;
               }
            }
         }

         return true;
      }
   }

   public int getSummoningCost() {
      return this.summoningCost;
   }

   public EntityLivingBase getEntity(World world) {
      return this.summoningHelper.getEntity(world);
   }

   public int getBloodOrbLevel() {
      return this.bloodOrbLevel;
   }

   public ItemStack[] getRingRecipeForRing(int ring) {
      switch(ring) {
      case 1:
         return this.ring1;
      case 2:
         return this.ring2;
      case 3:
         return this.ring3;
      default:
         return null;
      }
   }

   public String getSummoningHelperID() {
      return this.summoningHelper.getSummoningHelperID();
   }
}
