package WayofTime.alchemicalWizardry.api.summoningRegistry;

import WayofTime.alchemicalWizardry.api.summoningRegistry.SummoningHelper;
import WayofTime.alchemicalWizardry.api.summoningRegistry.SummoningRegistryComponent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class SummoningRegistry {

   public static List summoningList = new ArrayList();


   public static void registerSummon(SummoningHelper s, ItemStack[] ring1, ItemStack[] ring2, ItemStack[] ring3, int amountUsed, int bloodOrbLevel) {
      summoningList.add(new SummoningRegistryComponent(s, ring1, ring2, ring3, amountUsed, bloodOrbLevel));
   }

   public static boolean isRecipeValid(int bloodOrbLevel, ItemStack[] test1, ItemStack[] test2, ItemStack[] test3) {
      Iterator i$ = summoningList.iterator();

      SummoningRegistryComponent src;
      do {
         if(!i$.hasNext()) {
            return false;
         }

         src = (SummoningRegistryComponent)i$.next();
      } while(src.getBloodOrbLevel() > bloodOrbLevel || !src.compareRing(1, test1) || !src.compareRing(2, test2) || !src.compareRing(3, test3));

      return true;
   }

   public static SummoningRegistryComponent getRegistryComponent(int bloodOrbLevel, ItemStack[] test1, ItemStack[] test2, ItemStack[] test3) {
      Iterator i$ = summoningList.iterator();

      SummoningRegistryComponent src;
      do {
         if(!i$.hasNext()) {
            return null;
         }

         src = (SummoningRegistryComponent)i$.next();
      } while(src.getBloodOrbLevel() > bloodOrbLevel || !src.compareRing(1, test1) || !src.compareRing(2, test2) || !src.compareRing(3, test3));

      return src;
   }

   public static EntityLivingBase getEntity(World worldObj, int bloodOrbLevel, ItemStack[] test1, ItemStack[] test2, ItemStack[] test3) {
      Iterator i$ = summoningList.iterator();

      SummoningRegistryComponent src;
      do {
         if(!i$.hasNext()) {
            return null;
         }

         src = (SummoningRegistryComponent)i$.next();
      } while(src.getBloodOrbLevel() > bloodOrbLevel || !src.compareRing(1, test1) || !src.compareRing(2, test2) || !src.compareRing(3, test3));

      return src.getEntity(worldObj);
   }

   public static EntityLivingBase getEntityWithID(World worldObj, String id) {
      Iterator i$ = summoningList.iterator();

      SummoningRegistryComponent src;
      do {
         if(!i$.hasNext()) {
            return null;
         }

         src = (SummoningRegistryComponent)i$.next();
      } while(!src.getSummoningHelperID().equals(id));

      return src.getEntity(worldObj);
   }

}
