package WayofTime.alchemicalWizardry.api.bindingRegistry;

import WayofTime.alchemicalWizardry.api.bindingRegistry.BindingRecipe;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.item.ItemStack;

public class BindingRegistry {

   public static List bindingRecipes = new LinkedList();


   public static void registerRecipe(ItemStack output, ItemStack input) {
      bindingRecipes.add(new BindingRecipe(output, input));
   }

   public static boolean isRequiredItemValid(ItemStack testItem) {
      Iterator i$ = bindingRecipes.iterator();

      BindingRecipe recipe;
      do {
         if(!i$.hasNext()) {
            return false;
         }

         recipe = (BindingRecipe)i$.next();
      } while(!recipe.doesRequiredItemMatch(testItem));

      return true;
   }

   public static ItemStack getItemForItemAndTier(ItemStack testItem) {
      Iterator i$ = bindingRecipes.iterator();

      BindingRecipe recipe;
      do {
         if(!i$.hasNext()) {
            return null;
         }

         recipe = (BindingRecipe)i$.next();
      } while(!recipe.doesRequiredItemMatch(testItem));

      return recipe.getResult(testItem).copy();
   }

   public static int getIndexForItem(ItemStack testItem) {
      int i = 0;

      for(Iterator i$ = bindingRecipes.iterator(); i$.hasNext(); ++i) {
         BindingRecipe recipe = (BindingRecipe)i$.next();
         if(recipe.doesRequiredItemMatch(testItem)) {
            return i;
         }
      }

      return -1;
   }

   public static ItemStack getOutputForIndex(int index) {
      return bindingRecipes.size() <= index?null:((BindingRecipe)bindingRecipes.get(index)).getResult();
   }

}
