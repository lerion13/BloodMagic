package WayofTime.alchemicalWizardry.api.altarRecipeRegistry;


public interface IFadedRune {

   int getAltarTierLimit(int var1);
}
