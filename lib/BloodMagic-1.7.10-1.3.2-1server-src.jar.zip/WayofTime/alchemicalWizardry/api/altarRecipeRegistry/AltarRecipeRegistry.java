package WayofTime.alchemicalWizardry.api.altarRecipeRegistry;

import WayofTime.alchemicalWizardry.api.altarRecipeRegistry.AltarRecipe;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import net.minecraft.item.ItemStack;

public class AltarRecipeRegistry {

   public static List altarRecipes = new LinkedList();
   public static Map orbMap = new HashMap();


   public static void registerAltarRecipe(ItemStack result, ItemStack requiredItem, int minTier, int liquidRequired, int consumptionRate, int drainRate, boolean canBeFilled) {
      altarRecipes.add(new AltarRecipe(result, requiredItem, minTier, liquidRequired, consumptionRate, drainRate, canBeFilled));
   }

   public static void registerNBTAltarRecipe(ItemStack result, ItemStack requiredItem, int minTier, int liquidRequired, int consumptionRate, int drainRate, boolean canBeFilled) {
      altarRecipes.add(new AltarRecipe(result, requiredItem, minTier, liquidRequired, consumptionRate, drainRate, canBeFilled, true));
   }

   public static void registerAltarOrbRecipe(ItemStack orbStack, int minTier, int consumptionRate) {
      if(!orbMap.containsKey(Integer.valueOf(minTier))) {
         orbMap.put(Integer.valueOf(minTier), orbStack);
      }

      registerAltarRecipe((ItemStack)null, orbStack, minTier, 0, consumptionRate, 0, true);
   }

   public static boolean isRequiredItemValid(ItemStack testItem, int currentTierAltar) {
      if(testItem == null) {
         return false;
      } else {
         Iterator i$ = altarRecipes.iterator();

         AltarRecipe recipe;
         do {
            if(!i$.hasNext()) {
               return false;
            }

            recipe = (AltarRecipe)i$.next();
         } while(!recipe.doesRequiredItemMatch(testItem, currentTierAltar));

         return true;
      }
   }

   public static ItemStack getItemForItemAndTier(ItemStack testItem, int currentTierAltar) {
      Iterator i$ = altarRecipes.iterator();

      AltarRecipe recipe;
      do {
         if(!i$.hasNext()) {
            return null;
         }

         recipe = (AltarRecipe)i$.next();
      } while(!recipe.doesRequiredItemMatch(testItem, currentTierAltar));

      return ItemStack.copyItemStack(recipe.getResult());
   }

   public static AltarRecipe getAltarRecipeForItemAndTier(ItemStack testItem, int currentTierAltar) {
      Iterator i$ = altarRecipes.iterator();

      AltarRecipe recipe;
      do {
         if(!i$.hasNext()) {
            return null;
         }

         recipe = (AltarRecipe)i$.next();
      } while(!recipe.doesRequiredItemMatch(testItem, currentTierAltar));

      return recipe;
   }

}
