package WayofTime.alchemicalWizardry.api;

import WayofTime.alchemicalWizardry.api.Int3;
import net.minecraftforge.common.util.ForgeDirection;

public class RoutingFocusPosAndFacing {

   public Int3 location;
   public ForgeDirection facing;


   public RoutingFocusPosAndFacing(Int3 location, ForgeDirection facing) {
      this.location = location;
      this.facing = facing;
   }

   public boolean equals(Object obj) {
      return obj instanceof RoutingFocusPosAndFacing?this.facing.equals(((RoutingFocusPosAndFacing)obj).facing) && this.location.equals(((RoutingFocusPosAndFacing)obj).location):false;
   }
}
