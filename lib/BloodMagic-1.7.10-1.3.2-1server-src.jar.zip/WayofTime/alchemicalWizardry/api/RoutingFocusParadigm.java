package WayofTime.alchemicalWizardry.api;

import WayofTime.alchemicalWizardry.api.ILimitingLogic;
import WayofTime.alchemicalWizardry.api.RoutingFocusLogic;
import WayofTime.alchemicalWizardry.api.RoutingFocusPosAndFacing;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.item.ItemStack;

public class RoutingFocusParadigm {

   public List logicList = new LinkedList();
   public List locationList = new LinkedList();
   public int maximumAmount = 0;


   public void addRoutingFocusPosAndFacing(RoutingFocusPosAndFacing facing) {
      this.locationList.add(facing);
   }

   public void addLogic(RoutingFocusLogic logic) {
      if(logic instanceof ILimitingLogic) {
         this.maximumAmount += ((ILimitingLogic)logic).getRoutingLimit();
      }

      this.logicList.add(logic);
   }

   public boolean doesItemMatch(ItemStack keyStack, ItemStack checkedStack) {
      boolean isGood = false;
      boolean isFirst = true;
      Iterator i$ = this.logicList.iterator();

      while(i$.hasNext()) {
         RoutingFocusLogic logic = (RoutingFocusLogic)i$.next();
         if(isFirst) {
            isGood = logic.getDefaultMatch(keyStack, checkedStack);
            isFirst = false;
         } else {
            isGood = logic.doesItemMatch(isGood, keyStack, checkedStack);
         }
      }

      return isGood;
   }

   public void clear() {
      this.logicList.clear();
      this.locationList.clear();
      this.maximumAmount = 0;
   }

   public void setMaximumAmount(int amt) {
      this.maximumAmount = amt;
   }

   public int getMaximumAmount() {
      return this.maximumAmount;
   }
}
