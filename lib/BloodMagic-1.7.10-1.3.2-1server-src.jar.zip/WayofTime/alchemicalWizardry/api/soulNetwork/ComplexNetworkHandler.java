package WayofTime.alchemicalWizardry.api.soulNetwork;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.authlib.GameProfile;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.UUID;
import java.util.Map.Entry;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;

public class ComplexNetworkHandler {

   public static String fileName = "config/BloodMagic/soulnetworkKeys";
   static HashMap keyMap = new HashMap();


   public static UUID getUUIDFromPlayer(EntityPlayer player) {
      return player.getPersistentID();
   }

   public static EntityPlayer getPlayerFromUUID(UUID uuid) {
      MinecraftServer server = MinecraftServer.getServer();
      GameProfile gameProfile = server.func_152358_ax().func_152652_a(uuid);
      String str = uuid.toString();
      UUID.fromString(str);
      return null;
   }

   public static String getKeyForPlayer(EntityPlayer player) {
      return "";
   }

   public static UUID getUUIDForKey(String key) {
      return null;
   }

   public static String assignKeyToPlayer(EntityPlayer player) {
      return "";
   }

   public static void save() {
      keyMap.put(new UUID(0L, 0L), "test");
      Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
      String json = gson.toJson(keyMap);

      try {
         FileWriter writer = new FileWriter(fileName + ".json");
         writer.write(json);
         writer.close();
      } catch (IOException var4) {
         var4.printStackTrace();
      }

   }

   public static void load() {
      File save = new File(fileName + ".json");
      if(save.canRead()) {
         Gson gson = (new GsonBuilder()).setPrettyPrinting().create();

         try {
            BufferedReader br = new BufferedReader(new FileReader(save));
            HashMap e = (HashMap)gson.fromJson(br, keyMap.getClass());
            keyMap = e;
            if(keyMap != null) {
               Iterator i$ = keyMap.entrySet().iterator();

               while(i$.hasNext()) {
                  Entry entry = (Entry)i$.next();
                  System.out.println("" + (String)entry.getValue() + " gave: " + entry.getKey());
               }
            }
         } catch (FileNotFoundException var6) {
            var6.printStackTrace();
         }
      } else {
         keyMap = null;
      }

   }

}
