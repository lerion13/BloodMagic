package WayofTime.alchemicalWizardry.api.soulNetwork;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.WorldSavedData;

public class LifeEssenceNetwork extends WorldSavedData {

   public int currentEssence = 0;
   public int maxOrb = 0;


   public LifeEssenceNetwork(String par1Str) {
      super(par1Str);
   }

   public void readFromNBT(NBTTagCompound nbttagcompound) {
      this.currentEssence = nbttagcompound.getInteger("currentEssence");
      this.maxOrb = nbttagcompound.getInteger("maxOrb");
   }

   public void writeToNBT(NBTTagCompound nbttagcompound) {
      nbttagcompound.setInteger("currentEssence", this.currentEssence);
      nbttagcompound.setInteger("maxOrb", this.maxOrb);
   }
}
