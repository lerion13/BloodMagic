package WayofTime.alchemicalWizardry.api.event;

import cpw.mods.fml.common.eventhandler.Cancelable;
import cpw.mods.fml.common.eventhandler.Event;
import net.minecraft.block.Block;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

@Cancelable
public class TeleposeEvent extends Event {

   public final World initialWorld;
   public final int initialX;
   public final int initialY;
   public final int initialZ;
   public final Block initialBlock;
   public final int initialMetadata;
   public final World finalWorld;
   public final int finalX;
   public final int finalY;
   public final int finalZ;
   public final Block finalBlock;
   public final int finalMetadata;


   public TeleposeEvent(World wi, int xi, int yi, int zi, Block bi, int mi, World wf, int xf, int yf, int zf, Block bf, int mf) {
      this.initialWorld = wi;
      this.initialX = xi;
      this.initialY = yi;
      this.initialZ = zi;
      this.initialBlock = bi;
      this.initialMetadata = mi;
      this.finalWorld = wf;
      this.finalX = xf;
      this.finalY = yf;
      this.finalZ = zf;
      this.finalBlock = bf;
      this.finalMetadata = mf;
   }

   public TileEntity getInitialTile() {
      return this.initialWorld.getTileEntity(this.initialX, this.initialY, this.initialZ);
   }

   public TileEntity getFinalTile() {
      return this.finalWorld.getTileEntity(this.finalX, this.finalY, this.finalZ);
   }
}
