package WayofTime.alchemicalWizardry.api.tile;

import WayofTime.alchemicalWizardry.api.spell.SpellParadigm;
import net.minecraftforge.common.util.ForgeDirection;

public interface ISpellTile {

   void modifySpellParadigm(SpellParadigm var1);

   boolean canInputRecieveOutput(ForgeDirection var1);
}
