package WayofTime.alchemicalWizardry.api.tile;


public interface IBloodAltar {

   int getCapacity();

   int getCurrentBlood();

   int getTier();

   int getProgress();

   float getSacrificeMultiplier();

   float getSelfSacrificeMultiplier();

   float getOrbMultiplier();

   float getDislocationMultiplier();

   int getBufferCapacity();

   void sacrificialDaggerCall(int var1, boolean var2);

   void startCycle();

   void requestPauseAfterCrafting(int var1);

   void addToDemonBloodDuration(int var1);

   boolean hasDemonBlood();

   void decrementDemonBlood();
}
