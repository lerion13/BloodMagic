package WayofTime.alchemicalWizardry.api.tile;

import WayofTime.alchemicalWizardry.api.tile.ISpellTile;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public interface ISpellParadigmTile extends ISpellTile {

   void castSpell(World var1, EntityPlayer var2, ItemStack var3);
}
