package WayofTime.alchemicalWizardry.api.items.interfaces;


public interface IBindable {
}
