package WayofTime.alchemicalWizardry.api.items.interfaces;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public interface ArmourUpgrade {

   void onArmourUpdate(World var1, EntityPlayer var2, ItemStack var3);

   boolean isUpgrade();

   int getEnergyForTenSeconds();
}
