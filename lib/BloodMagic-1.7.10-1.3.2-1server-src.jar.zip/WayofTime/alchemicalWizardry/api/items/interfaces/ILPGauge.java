package WayofTime.alchemicalWizardry.api.items.interfaces;

import net.minecraft.item.ItemStack;

public interface ILPGauge {

   boolean canSeeLPBar(ItemStack var1);
}
