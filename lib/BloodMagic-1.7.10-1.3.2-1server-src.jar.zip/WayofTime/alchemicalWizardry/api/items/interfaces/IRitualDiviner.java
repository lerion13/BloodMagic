package WayofTime.alchemicalWizardry.api.items.interfaces;

import net.minecraft.item.ItemStack;

public interface IRitualDiviner {

   int cycleDirection(ItemStack var1);

   String getCurrentRitual(ItemStack var1);

   int getDirection(ItemStack var1);

   int getMaxRuneDisplacement(ItemStack var1);

   String getNameForDirection(int var1);

   void setCurrentRitual(ItemStack var1, String var2);

   void setDirection(ItemStack var1, int var2);

   void setMaxRuneDisplacement(ItemStack var1, int var2);
}
