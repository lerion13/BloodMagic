package WayofTime.alchemicalWizardry.api.items;

import WayofTime.alchemicalWizardry.api.items.interfaces.IBloodOrb;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.block.Block;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.ShapedRecipes;
import net.minecraft.world.World;
import net.minecraftforge.oredict.OreDictionary;

public class ShapedBloodOrbRecipe implements IRecipe {

   private static final int MAX_CRAFT_GRID_WIDTH = 3;
   private static final int MAX_CRAFT_GRID_HEIGHT = 3;
   private ItemStack output;
   private Object[] input;
   public int width;
   public int height;
   private boolean mirrored;


   public ShapedBloodOrbRecipe(Block result, Object ... recipe) {
      this(new ItemStack(result), recipe);
   }

   public ShapedBloodOrbRecipe(Item result, Object ... recipe) {
      this(new ItemStack(result), recipe);
   }

   public ShapedBloodOrbRecipe(ItemStack result, Object ... recipe) {
      this.output = null;
      this.input = null;
      this.width = 0;
      this.height = 0;
      this.mirrored = true;
      this.output = result.copy();
      String shape = "";
      int idx = 0;
      if(recipe[idx] instanceof Boolean) {
         this.mirrored = ((Boolean)recipe[idx]).booleanValue();
         if(recipe[idx + 1] instanceof Object[]) {
            recipe = (Object[])((Object[])recipe[idx + 1]);
         } else {
            idx = 1;
         }
      }

      int arr$;
      int len$;
      String var13;
      if(recipe[idx] instanceof String[]) {
         String[] itemMap = (String[])((String[])recipe[idx++]);
         String[] x = itemMap;
         arr$ = itemMap.length;

         for(len$ = 0; len$ < arr$; ++len$) {
            String i$ = x[len$];
            this.width = i$.length();
            shape = shape + i$;
         }

         this.height = itemMap.length;
      } else {
         while(recipe[idx] instanceof String) {
            var13 = (String)recipe[idx++];
            shape = shape + var13;
            this.width = var13.length();
            ++this.height;
         }
      }

      if(this.width * this.height != shape.length()) {
         var13 = "Invalid shaped ore recipe: ";
         Object[] var18 = recipe;
         arr$ = recipe.length;

         for(len$ = 0; len$ < arr$; ++len$) {
            Object var23 = var18[len$];
            var13 = var13 + var23 + ", ";
         }

         var13 = var13 + this.output;
         throw new RuntimeException(var13);
      } else {
         HashMap var14;
         for(var14 = new HashMap(); idx < recipe.length; idx += 2) {
            Character var16 = (Character)recipe[idx];
            Object var17 = recipe[idx + 1];
            if(!(var17 instanceof IBloodOrb) && (!(var17 instanceof ItemStack) || !(((ItemStack)var17).getItem() instanceof IBloodOrb))) {
               if(var17 instanceof ItemStack) {
                  var14.put(var16, ((ItemStack)var17).copy());
               } else if(var17 instanceof Item) {
                  var14.put(var16, new ItemStack((Item)var17));
               } else if(var17 instanceof Block) {
                  var14.put(var16, new ItemStack((Block)var17, 1, 32767));
               } else {
                  if(!(var17 instanceof String)) {
                     String var20 = "Invalid shaped ore recipe: ";
                     Object[] var21 = recipe;
                     int chr = recipe.length;

                     for(int i$1 = 0; i$1 < chr; ++i$1) {
                        Object tmp = var21[i$1];
                        var20 = var20 + tmp + ", ";
                     }

                     var20 = var20 + this.output;
                     throw new RuntimeException(var20);
                  }

                  var14.put(var16, OreDictionary.getOres((String)var17));
               }
            } else if(var17 instanceof ItemStack) {
               var14.put(var16, Integer.valueOf(((IBloodOrb)((ItemStack)var17).getItem()).getOrbLevel()));
            } else {
               var14.put(var16, Integer.valueOf(((IBloodOrb)var17).getOrbLevel()));
            }
         }

         this.input = new Object[this.width * this.height];
         int var15 = 0;
         char[] var19 = shape.toCharArray();
         len$ = var19.length;

         for(int var22 = 0; var22 < len$; ++var22) {
            char var24 = var19[var22];
            this.input[var15++] = var14.get(Character.valueOf(var24));
         }

      }
   }

   ShapedBloodOrbRecipe(ShapedRecipes recipe, Map replacements) {
      this.output = null;
      this.input = null;
      this.width = 0;
      this.height = 0;
      this.mirrored = true;
      this.output = recipe.getRecipeOutput();
      this.width = recipe.recipeWidth;
      this.height = recipe.recipeHeight;
      this.input = new Object[recipe.recipeItems.length];

      for(int i = 0; i < this.input.length; ++i) {
         ItemStack ingred = recipe.recipeItems[i];
         if(ingred != null) {
            this.input[i] = recipe.recipeItems[i];
            Iterator i$ = replacements.entrySet().iterator();

            while(i$.hasNext()) {
               Entry replace = (Entry)i$.next();
               if(OreDictionary.itemMatches((ItemStack)replace.getKey(), ingred, true)) {
                  this.input[i] = OreDictionary.getOres((String)replace.getValue());
                  break;
               }
            }
         }
      }

   }

   public ItemStack getCraftingResult(InventoryCrafting var1) {
      return this.output.copy();
   }

   public int getRecipeSize() {
      return this.input.length;
   }

   public ItemStack getRecipeOutput() {
      return this.output;
   }

   public boolean matches(InventoryCrafting inv, World world) {
      for(int x = 0; x <= 3 - this.width; ++x) {
         for(int y = 0; y <= 3 - this.height; ++y) {
            if(this.checkMatch(inv, x, y, false)) {
               return true;
            }

            if(this.mirrored && this.checkMatch(inv, x, y, true)) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean checkMatch(InventoryCrafting inv, int startX, int startY, boolean mirror) {
      for(int x = 0; x < 3; ++x) {
         for(int y = 0; y < 3; ++y) {
            int subX = x - startX;
            int subY = y - startY;
            Object target = null;
            if(subX >= 0 && subY >= 0 && subX < this.width && subY < this.height) {
               if(mirror) {
                  target = this.input[this.width - subX - 1 + subY * this.width];
               } else {
                  target = this.input[subX + subY * this.width];
               }
            }

            ItemStack slot = inv.getStackInRowAndColumn(x, y);
            if(target instanceof Integer) {
               if(slot == null || !(slot.getItem() instanceof IBloodOrb)) {
                  return false;
               }

               IBloodOrb matched = (IBloodOrb)slot.getItem();
               if(matched.getOrbLevel() < ((Integer)target).intValue()) {
                  return false;
               }
            } else if(target instanceof ItemStack) {
               if(!OreDictionary.itemMatches((ItemStack)target, slot, false)) {
                  return false;
               }
            } else if(target instanceof ArrayList) {
               boolean var13 = false;

               for(Iterator itr = ((ArrayList)target).iterator(); itr.hasNext() && !var13; var13 = OreDictionary.itemMatches((ItemStack)itr.next(), slot, false)) {
                  ;
               }

               if(!var13) {
                  return false;
               }
            } else if(target == null && slot != null) {
               return false;
            }
         }
      }

      return true;
   }

   public ShapedBloodOrbRecipe setMirrored(boolean mirror) {
      this.mirrored = mirror;
      return this;
   }

   public Object[] getInput() {
      return this.input;
   }
}
