package WayofTime.alchemicalWizardry.api.items;


public interface IAltarManipulator {
}
