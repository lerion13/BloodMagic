package WayofTime.alchemicalWizardry.api.items;

import WayofTime.alchemicalWizardry.api.soulNetwork.SoulNetworkHandler;
import WayofTime.alchemicalWizardry.api.spell.APISpellHelper;
import WayofTime.alchemicalWizardry.api.spell.SpellEffect;
import WayofTime.alchemicalWizardry.api.spell.SpellParadigmTool;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.common.util.ForgeDirection;

public class ItemSpellMultiTool extends Item {

   private static final String harvestLevelSuffix = "harvestLvl";
   private static final String digLevelSuffix = "digLvl";
   private static final String tagName = "BloodMagicTool";
   private Random rand = new Random();


   public ItemSpellMultiTool() {
      this.setMaxDamage(0);
      this.setMaxStackSize(1);
      this.setFull3D();
   }

   public void registerIcons(IIconRegister iconRegister) {
      super.itemIcon = iconRegister.registerIcon("AlchemicalWizardry:BoundTool");
   }

   public boolean hitEntity(ItemStack par1ItemStack, EntityLivingBase par2EntityLivingBase, EntityLivingBase par3EntityLivingBase) {
      float damage = this.getCustomItemAttack(par1ItemStack);
      SpellParadigmTool parad = this.loadParadigmFromStack(par1ItemStack);
      if(parad != null) {
         parad.onLeftClickEntity(par1ItemStack, par2EntityLivingBase, par3EntityLivingBase);
      }

      damage += parad.getAddedDamageForEntity(par2EntityLivingBase);
      if(this.rand.nextFloat() < this.getCritChance(par1ItemStack)) {
         damage *= 1.75F;
      }

      if(par3EntityLivingBase instanceof EntityPlayer) {
         par2EntityLivingBase.attackEntityFrom(DamageSource.causePlayerDamage((EntityPlayer)par3EntityLivingBase), damage);
      } else {
         par2EntityLivingBase.attackEntityFrom(DamageSource.causeMobDamage(par3EntityLivingBase), damage);
      }

      return true;
   }

   public boolean onLeftClickEntity(ItemStack stack, EntityPlayer player, Entity entity) {
      SpellParadigmTool parad = this.loadParadigmFromStack(stack);
      if(parad != null && entity instanceof EntityLivingBase) {
         parad.onLeftClickEntity(stack, (EntityLivingBase)entity, player);
      }

      return false;
   }

   public boolean onBlockStartBreak(ItemStack stack, int x, int y, int z, EntityPlayer player) {
      if(player.worldObj.isRemote) {
         return false;
      } else if(!stack.hasTagCompound()) {
         return false;
      } else {
         World world = player.worldObj;
         Block block = player.worldObj.getBlock(x, y, z);
         int meta = world.getBlockMetadata(x, y, z);
         if(block != null && block != Blocks.air) {
            int hlvl = -1;
            float blockHardness = block.getBlockHardness(world, x, y, z);
            MovingObjectPosition mop = APISpellHelper.raytraceFromEntity(world, player, true, 5.0D);
            Block localBlock = world.getBlock(x, y, z);
            int localMeta = world.getBlockMetadata(x, y, z);
            String toolClass = block.getHarvestTool(meta);
            if(toolClass != null && this.getHarvestLevel(stack, toolClass) != -1) {
               hlvl = block.getHarvestLevel(meta);
            }

            int toolLevel = this.getHarvestLevel(stack, toolClass);
            float localHardness = localBlock == null?Float.MAX_VALUE:localBlock.getBlockHardness(world, x, y, z);
            if(hlvl <= toolLevel && (double)localHardness - 1.5D <= (double)blockHardness) {
               boolean cancelHarvest = false;
               if(!cancelHarvest && localBlock != null && localHardness >= 0.0F) {
                  boolean isEffective = false;
                  String localToolClass = this.getToolClassForMaterial(localBlock.getMaterial());
                  if(localToolClass != null && this.getHarvestLevel(stack, toolClass) >= localBlock.getHarvestLevel(localMeta)) {
                     isEffective = true;
                  }

                  if(localBlock.getMaterial().isToolNotRequired()) {
                     isEffective = true;
                  }

                  if(!player.capabilities.isCreativeMode) {
                     if(isEffective) {
                        if(localBlock.removedByPlayer(world, player, x, y, z)) {
                           localBlock.onBlockDestroyedByPlayer(world, x, y, z, localMeta);
                        }

                        localBlock.onBlockHarvested(world, x, y, z, localMeta, player);
                        if(blockHardness > 0.0F) {
                           this.onBlockDestroyed(stack, world, localBlock, x, y, z, player);
                        }

                        List items = APISpellHelper.getItemsFromBlock(world, localBlock, x, y, z, localMeta, this.getSilkTouch(stack), this.getFortuneLevel(stack));
                        SpellParadigmTool parad = this.loadParadigmFromStack(stack);
                        List newItems = parad.handleItemList(stack, items);
                        if(!world.isRemote) {
                           APISpellHelper.spawnItemListInWorld(newItems, world, (float)x + 0.5F, (float)y + 0.5F, (float)z + 0.5F);
                        }

                        world.func_147479_m(x, y, z);
                        byte cost = 0;
                        int cost1 = cost + parad.digSurroundingArea(stack, world, player, mop, localToolClass, localHardness, toolLevel, this);
                        cost1 += parad.onBreakBlock(stack, world, player, localBlock, localMeta, x, y, z, ForgeDirection.getOrientation(mop.sideHit));
                        if(cost1 > 0) {
                           SoulNetworkHandler.syphonAndDamageFromNetwork(stack, player, cost1);
                        }
                     } else {
                        world.setBlockToAir(x, y, z);
                        world.func_147479_m(x, y, z);
                     }
                  } else {
                     world.setBlockToAir(x, y, z);
                     world.func_147479_m(x, y, z);
                  }
               }
            }

            if(!world.isRemote) {
               world.playAuxSFX(2001, x, y, z, Block.getIdFromBlock(block) + (meta << 12));
            }

            return true;
         } else {
            return false;
         }
      }
   }

   public Material[] getMaterialsForToolclass(String toolClass) {
      return "pickaxe".equals(toolClass)?new Material[]{Material.rock, Material.iron, Material.ice, Material.glass, Material.piston, Material.anvil, Material.circuits}:("shovel".equals(toolClass)?new Material[]{Material.grass, Material.ground, Material.sand, Material.snow, Material.craftedSnow, Material.clay}:("axe".equals(toolClass)?new Material[]{Material.wood, Material.vine, Material.circuits, Material.cactus}:new Material[0]));
   }

   public String getToolClassForMaterial(Material mat) {
      String testString = "pickaxe";
      Material[] matList = this.getMaterialsForToolclass(testString);

      int i;
      for(i = 0; i < matList.length; ++i) {
         if(matList[i] == mat) {
            return testString;
         }
      }

      testString = "shovel";
      matList = this.getMaterialsForToolclass(testString);

      for(i = 0; i < matList.length; ++i) {
         if(matList[i] == mat) {
            return testString;
         }
      }

      testString = "axe";
      matList = this.getMaterialsForToolclass(testString);

      for(i = 0; i < matList.length; ++i) {
         if(matList[i] == mat) {
            return testString;
         }
      }

      return null;
   }

   public Set getToolClasses(ItemStack stack) {
      HashSet set = new HashSet();
      if(this.getHarvestLevel(stack, "pickaxe") > -1) {
         set.add("pickaxe");
      }

      if(this.getHarvestLevel(stack, "axe") > -1) {
         set.add("axe");
      }

      if(this.getHarvestLevel(stack, "shovel") > -1) {
         set.add("shovel");
      }

      return set;
   }

   public float getDigSpeed(ItemStack stack, Block block, int meta) {
      String toolClass = block.getHarvestTool(meta);
      if(toolClass != null && !toolClass.equals("")) {
         if(stack.hasTagCompound()) {
            NBTTagCompound tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
            return tag.getFloat("digLvl" + toolClass);
         } else {
            stack.setTagCompound(new NBTTagCompound());
            return 1.0F;
         }
      } else {
         return 1.0F;
      }
   }

   public int getHarvestLevel(ItemStack stack, String toolClass) {
      if(stack.hasTagCompound()) {
         NBTTagCompound tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
         return tag.hasKey("harvestLvl" + toolClass)?tag.getInteger("harvestLvl" + toolClass):-1;
      } else {
         stack.setTagCompound(new NBTTagCompound());
         return -1;
      }
   }

   public boolean canHarvestBlock(Block par1Block, ItemStack itemStack) {
      return true;
   }

   public boolean getIsRepairable(ItemStack par1ItemStack, ItemStack par2ItemStack) {
      return false;
   }

   public void onUpdate(ItemStack toolStack, World world, Entity par3Entity, int par4, boolean par5) {
      if(!world.isRemote) {
         SpellParadigmTool parad = this.loadParadigmFromStack(toolStack);
         int cost = parad.onUpdate(toolStack, world, par3Entity, par4, par5);
         if(par3Entity instanceof EntityPlayer && cost > 0) {
            SoulNetworkHandler.syphonAndDamageFromNetwork(toolStack, (EntityPlayer)par3Entity, cost);
         }

         int duration = Math.max(this.getDuration(toolStack, world), 0);
         if(duration <= 0 && par3Entity instanceof EntityPlayer) {
            int banishCost = parad.onBanishTool(toolStack, world, par3Entity, par4, par5);
            SoulNetworkHandler.syphonAndDamageFromNetwork(toolStack, (EntityPlayer)par3Entity, banishCost);
            ((EntityPlayer)par3Entity).inventory.mainInventory[par4] = this.getContainedCrystal(toolStack);
         }

      }
   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      if(par3EntityPlayer.isSneaking()) {
         par3EntityPlayer.setCurrentItemOrArmor(0, this.getContainedCrystal(par1ItemStack));
         return par1ItemStack;
      } else {
         SpellParadigmTool parad = this.loadParadigmFromStack(par1ItemStack);
         MovingObjectPosition mop = this.getMovingObjectPositionFromPlayer(par2World, par3EntityPlayer, false);
         boolean cost = false;
         int cost1;
         if(mop != null && mop.typeOfHit.equals(MovingObjectType.BLOCK)) {
            cost1 = parad.onRightClickBlock(par1ItemStack, par3EntityPlayer, par2World, mop);
         } else {
            cost1 = parad.onRightClickAir(par1ItemStack, par2World, par3EntityPlayer);
         }

         if(cost1 > 0) {
            SoulNetworkHandler.syphonAndDamageFromNetwork(par1ItemStack, par3EntityPlayer, cost1);
         }

         return par1ItemStack;
      }
   }

   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      par3List.add("A mace filled with ancient alchemy");
      if(par1ItemStack.getTagCompound() != null) {
         if(!par1ItemStack.getTagCompound().getString("ownerName").equals("")) {
            par3List.add("Current owner: " + par1ItemStack.getTagCompound().getString("ownerName"));
         }

         Iterator damage = this.getToolListString(par1ItemStack).iterator();

         while(damage.hasNext()) {
            String critChance = (String)damage.next();
            par3List.add(critChance);
         }

         par3List.add("");
         float damage1 = this.getCustomItemAttack(par1ItemStack);
         par3List.add("§9+" + (float)((int)(damage1 * 10.0F)) / 10.0F + " " + "Attack Damage");
         float critChance1 = (float)((int)(this.getCritChance(par1ItemStack) * 1000.0F)) / 10.0F;
         par3List.add("§9+" + critChance1 + "% " + "Crit Chance");
      }

   }

   public void setHarvestLevel(ItemStack stack, String toolClass, int harvestLevel) {
      NBTTagCompound tag;
      if(stack.hasTagCompound()) {
         tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
         tag.setInteger("harvestLvl" + toolClass, Math.max(-1, harvestLevel));
         stack.getTagCompound().setTag("BloodMagicTool", tag);
      } else {
         stack.setTagCompound(new NBTTagCompound());
         tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
         tag.setInteger("harvestLvl" + toolClass, Math.max(-1, harvestLevel));
         stack.getTagCompound().setTag("BloodMagicTool", tag);
      }

   }

   public void setDigSpeed(ItemStack stack, String toolClass, float digSpeed) {
      NBTTagCompound tag;
      if(stack.hasTagCompound()) {
         tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
         tag.setFloat("digLvl" + toolClass, digSpeed);
         stack.getTagCompound().setTag("BloodMagicTool", tag);
      } else {
         stack.setTagCompound(new NBTTagCompound());
         tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
         tag.setFloat("digLvl" + toolClass, digSpeed);
         stack.getTagCompound().setTag("BloodMagicTool", tag);
      }

   }

   public float getDigSpeed(ItemStack stack, String toolClass) {
      if(stack.hasTagCompound()) {
         NBTTagCompound tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
         return tag.getFloat("digLvl" + toolClass);
      } else {
         stack.setTagCompound(new NBTTagCompound());
         return 0.0F;
      }
   }

   public void setItemAttack(ItemStack stack, float damage) {
      NBTTagCompound tag;
      if(stack.hasTagCompound()) {
         tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
         tag.setFloat("itemAttack", Math.max(damage, 0.0F));
         stack.getTagCompound().setTag("BloodMagicTool", tag);
      } else {
         stack.setTagCompound(new NBTTagCompound());
         tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
         tag.setFloat("itemAttack", Math.max(damage, 0.0F));
         stack.getTagCompound().setTag("BloodMagicTool", tag);
      }

   }

   public float getCustomItemAttack(ItemStack stack) {
      if(stack.hasTagCompound()) {
         NBTTagCompound tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
         return tag.getFloat("itemAttack");
      } else {
         stack.setTagCompound(new NBTTagCompound());
         return 0.0F;
      }
   }

   public ItemStack getContainedCrystal(ItemStack container) {
      if(container.hasTagCompound()) {
         NBTTagCompound tag = container.getTagCompound().getCompoundTag("BloodMagicTool").getCompoundTag("heldItem");
         return ItemStack.loadItemStackFromNBT(tag);
      } else {
         container.setTagCompound(new NBTTagCompound());
         return null;
      }
   }

   public void setContainedCrystal(ItemStack container, ItemStack crystal) {
      NBTTagCompound compTag;
      NBTTagCompound tag;
      if(container.hasTagCompound()) {
         compTag = container.getTagCompound().getCompoundTag("BloodMagicTool");
         tag = compTag.getCompoundTag("heldItem");
         crystal.writeToNBT(tag);
         compTag.setTag("heldItem", tag);
         container.getTagCompound().setTag("BloodMagicTool", compTag);
      } else {
         container.setTagCompound(new NBTTagCompound());
         compTag = container.getTagCompound().getCompoundTag("BloodMagicTool");
         tag = compTag.getCompoundTag("heldItem");
         crystal.writeToNBT(tag);
         compTag.setTag("heldItem", tag);
         container.getTagCompound().setTag("BloodMagicTool", compTag);
      }

   }

   public void setDuration(ItemStack container, World world, int duration) {
      if(!world.isRemote) {
         WorldServer overWorld = DimensionManager.getWorld(0);
         long worldtime = overWorld.getTotalWorldTime();
         NBTTagCompound tag;
         if(container.hasTagCompound()) {
            tag = container.getTagCompound().getCompoundTag("BloodMagicTool");
            tag.setLong("duration", Math.max((long)duration + worldtime, worldtime));
            container.getTagCompound().setTag("BloodMagicTool", tag);
         } else {
            container.setTagCompound(new NBTTagCompound());
            tag = container.getTagCompound().getCompoundTag("BloodMagicTool");
            tag.setLong("duration", Math.max((long)duration + worldtime, worldtime));
            container.getTagCompound().setTag("BloodMagicTool", tag);
         }

      }
   }

   public int getDuration(ItemStack container, World world) {
      if(world.isRemote) {
         return 0;
      } else {
         WorldServer overWorld = DimensionManager.getWorld(0);
         long worldtime = overWorld.getTotalWorldTime();
         if(container.hasTagCompound()) {
            NBTTagCompound tag = container.getTagCompound().getCompoundTag("BloodMagicTool");
            return (int)(tag.getLong("duration") - worldtime);
         } else {
            container.setTagCompound(new NBTTagCompound());
            return 0;
         }
      }
   }

   public void loadParadigmIntoStack(ItemStack container, List list) {
      if(!container.hasTagCompound()) {
         container.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tagiest = container.getTagCompound().getCompoundTag("BloodMagicTool");
      NBTTagList effectList = new NBTTagList();
      Iterator i$ = list.iterator();

      while(i$.hasNext()) {
         SpellEffect eff = (SpellEffect)i$.next();
         effectList.appendTag(eff.getTag());
      }

      tagiest.setTag("Effects", effectList);
      container.getTagCompound().setTag("BloodMagicTool", tagiest);
   }

   public SpellParadigmTool loadParadigmFromStack(ItemStack container) {
      if(!container.hasTagCompound()) {
         container.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tagiest = container.getTagCompound().getCompoundTag("BloodMagicTool");
      NBTTagList tagList = tagiest.getTagList("Effects", 10);
      LinkedList spellEffectList = new LinkedList();

      for(int i = 0; i < tagList.tagCount(); ++i) {
         NBTTagCompound tag = tagList.getCompoundTagAt(i);
         SpellEffect eff = SpellEffect.getEffectFromTag(tag);
         if(eff != null) {
            spellEffectList.add(eff);
         }
      }

      return SpellParadigmTool.getParadigmForEffectArray(spellEffectList);
   }

   public void setSilkTouch(ItemStack stack, boolean silkTouch) {
      NBTTagCompound tag;
      if(stack.hasTagCompound()) {
         tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
         tag.setBoolean("silkTouch", silkTouch);
         stack.getTagCompound().setTag("BloodMagicTool", tag);
      } else {
         stack.setTagCompound(new NBTTagCompound());
         tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
         tag.setBoolean("silkTouch", silkTouch);
         stack.getTagCompound().setTag("BloodMagicTool", tag);
      }

   }

   public boolean getSilkTouch(ItemStack stack) {
      if(stack.hasTagCompound()) {
         NBTTagCompound tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
         return tag.getBoolean("silkTouch");
      } else {
         stack.setTagCompound(new NBTTagCompound());
         return false;
      }
   }

   public void setFortuneLevel(ItemStack stack, int fortune) {
      NBTTagCompound tag;
      if(stack.hasTagCompound()) {
         tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
         tag.setInteger("fortuneLevel", Math.max(fortune, 0));
         stack.getTagCompound().setTag("BloodMagicTool", tag);
      } else {
         stack.setTagCompound(new NBTTagCompound());
         tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
         tag.setInteger("fortuneLevel", Math.max(fortune, 0));
         stack.getTagCompound().setTag("BloodMagicTool", tag);
      }

   }

   public int getFortuneLevel(ItemStack stack) {
      if(stack.hasTagCompound()) {
         NBTTagCompound tag = stack.getTagCompound().getCompoundTag("BloodMagicTool");
         return tag.getInteger("fortuneLevel");
      } else {
         stack.setTagCompound(new NBTTagCompound());
         return 0;
      }
   }

   public List getToolListString(ItemStack container) {
      if(!container.hasTagCompound()) {
         container.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tagiest = container.getTagCompound().getCompoundTag("BloodMagicTool");
      NBTTagList tagList = tagiest.getTagList("ToolTips", 10);
      LinkedList toolTipList = new LinkedList();

      for(int i = 0; i < tagList.tagCount(); ++i) {
         NBTTagCompound tag = tagList.getCompoundTagAt(i);
         String str = tag.getString("tip");
         if(str != null) {
            toolTipList.add(str);
         }
      }

      return toolTipList;
   }

   public void setToolListString(ItemStack container, List toolTipString) {
      if(!container.hasTagCompound()) {
         container.setTagCompound(new NBTTagCompound());
      }

      NBTTagCompound tagiest = container.getTagCompound().getCompoundTag("BloodMagicTool");
      NBTTagList stringList = new NBTTagList();
      Iterator i$ = toolTipString.iterator();

      while(i$.hasNext()) {
         String str = (String)i$.next();
         NBTTagCompound tag = new NBTTagCompound();
         tag.setString("tip", str);
         stringList.appendTag(tag);
      }

      tagiest.setTag("ToolTips", stringList);
      container.getTagCompound().setTag("BloodMagicTool", tagiest);
   }

   public void setCritChance(ItemStack container, float chance) {
      NBTTagCompound tag;
      if(container.hasTagCompound()) {
         tag = container.getTagCompound().getCompoundTag("BloodMagicTool");
         tag.setFloat("critChance", Math.max(chance, 0.0F));
         container.getTagCompound().setTag("BloodMagicTool", tag);
      } else {
         container.setTagCompound(new NBTTagCompound());
         tag = container.getTagCompound().getCompoundTag("BloodMagicTool");
         tag.setFloat("critChance", Math.max(chance, 0.0F));
         container.getTagCompound().setTag("BloodMagicTool", tag);
      }

   }

   public float getCritChance(ItemStack container) {
      if(container.hasTagCompound()) {
         NBTTagCompound tag = container.getTagCompound().getCompoundTag("BloodMagicTool");
         return tag.getFloat("critChance");
      } else {
         container.setTagCompound(new NBTTagCompound());
         return 0.0F;
      }
   }
}
