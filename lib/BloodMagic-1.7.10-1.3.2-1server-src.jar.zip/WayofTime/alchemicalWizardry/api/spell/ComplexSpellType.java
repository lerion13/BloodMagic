package WayofTime.alchemicalWizardry.api.spell;


public class ComplexSpellType {

   public static ComplexSpellType FIRE = new ComplexSpellType();
   public static ComplexSpellType ICE = new ComplexSpellType();
   public static ComplexSpellType EARTH = new ComplexSpellType();
   public static ComplexSpellType WIND = new ComplexSpellType();


}
