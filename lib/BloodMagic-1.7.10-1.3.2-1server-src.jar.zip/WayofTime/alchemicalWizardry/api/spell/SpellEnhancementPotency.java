package WayofTime.alchemicalWizardry.api.spell;

import WayofTime.alchemicalWizardry.api.spell.SpellEnhancement;

public class SpellEnhancementPotency extends SpellEnhancement {

   public SpellEnhancementPotency() {
      super(2);
   }
}
