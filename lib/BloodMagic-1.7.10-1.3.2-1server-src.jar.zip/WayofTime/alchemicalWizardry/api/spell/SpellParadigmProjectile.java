package WayofTime.alchemicalWizardry.api.spell;

import WayofTime.alchemicalWizardry.api.soulNetwork.SoulNetworkHandler;
import WayofTime.alchemicalWizardry.api.spell.EntitySpellProjectile;
import WayofTime.alchemicalWizardry.api.spell.IProjectileImpactEffect;
import WayofTime.alchemicalWizardry.api.spell.IProjectileUpdateEffect;
import WayofTime.alchemicalWizardry.api.spell.SpellEffect;
import WayofTime.alchemicalWizardry.api.spell.SpellEnhancement;
import WayofTime.alchemicalWizardry.api.spell.SpellParadigm;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class SpellParadigmProjectile extends SpellParadigm {

   public DamageSource damageSource;
   public float damage;
   public int cost;
   public List impactList;
   public List updateEffectList;
   public boolean penetration;
   public int ricochetMax;
   public boolean isSilkTouch;


   public SpellParadigmProjectile() {
      this.damageSource = DamageSource.generic;
      this.damage = 1.0F;
      this.cost = 0;
      this.impactList = new ArrayList();
      this.updateEffectList = new ArrayList();
      this.penetration = false;
      this.ricochetMax = 0;
      this.isSilkTouch = false;
   }

   public void enhanceParadigm(SpellEnhancement enh) {}

   public void castSpell(World world, EntityPlayer entityPlayer, ItemStack itemStack) {
      int cost = this.getTotalCost();
      if(SoulNetworkHandler.syphonAndDamageFromNetwork(itemStack, entityPlayer, cost)) {
         EntitySpellProjectile proj = new EntitySpellProjectile(world, entityPlayer);
         this.prepareProjectile(proj);
         world.spawnEntityInWorld(proj);
      }
   }

   public static SpellParadigmProjectile getParadigmForEffectArray(List effectList) {
      SpellParadigmProjectile parad = new SpellParadigmProjectile();
      Iterator i$ = effectList.iterator();

      while(i$.hasNext()) {
         SpellEffect eff = (SpellEffect)i$.next();
         parad.addBufferedEffect(eff);
      }

      return parad;
   }

   public void prepareProjectile(EntitySpellProjectile proj) {
      proj.setDamage(this.damage);
      proj.setImpactList(this.impactList);
      proj.setUpdateEffectList(this.updateEffectList);
      proj.setPenetration(this.penetration);
      proj.setRicochetMax(this.ricochetMax);
      proj.setIsSilkTouch(this.isSilkTouch);
      proj.setSpellEffectList(super.bufferedEffectList);
   }

   public void addImpactEffect(IProjectileImpactEffect eff) {
      if(eff != null) {
         this.impactList.add(eff);
      }

   }

   public void addUpdateEffect(IProjectileUpdateEffect eff) {
      if(eff != null) {
         this.updateEffectList.add(eff);
      }

   }

   public int getDefaultCost() {
      return 50;
   }
}
