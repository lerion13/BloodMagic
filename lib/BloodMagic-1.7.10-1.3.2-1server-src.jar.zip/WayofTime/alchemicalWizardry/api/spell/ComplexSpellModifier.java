package WayofTime.alchemicalWizardry.api.spell;


public class ComplexSpellModifier {

   public static ComplexSpellModifier DEFAULT = new ComplexSpellModifier();
   public static ComplexSpellModifier OFFENSIVE = new ComplexSpellModifier();
   public static ComplexSpellModifier DEFENSIVE = new ComplexSpellModifier();
   public static ComplexSpellModifier ENVIRONMENTAL = new ComplexSpellModifier();


}
