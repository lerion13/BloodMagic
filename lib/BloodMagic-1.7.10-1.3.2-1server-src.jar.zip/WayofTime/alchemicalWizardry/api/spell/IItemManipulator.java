package WayofTime.alchemicalWizardry.api.spell;

import java.util.List;
import net.minecraft.item.ItemStack;

public interface IItemManipulator {

   List handleItemsOnBlockBroken(ItemStack var1, List var2);
}
