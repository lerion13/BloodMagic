package WayofTime.alchemicalWizardry.api.spell;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;

public interface IRightClickEffect {

   int onRightClickBlock(ItemStack var1, EntityLivingBase var2, World var3, MovingObjectPosition var4);

   int onRightClickAir(ItemStack var1, EntityLivingBase var2);
}
