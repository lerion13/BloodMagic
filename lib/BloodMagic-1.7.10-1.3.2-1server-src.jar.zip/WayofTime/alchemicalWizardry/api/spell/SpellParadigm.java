package WayofTime.alchemicalWizardry.api.spell;

import WayofTime.alchemicalWizardry.api.spell.ComplexSpellModifier;
import WayofTime.alchemicalWizardry.api.spell.SpellEffect;
import WayofTime.alchemicalWizardry.api.spell.SpellEnhancement;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public abstract class SpellParadigm {

   protected List bufferedEffectList = new LinkedList();


   public void addBufferedEffect(SpellEffect effect) {
      if(effect != null) {
         this.bufferedEffectList.add(effect);
      }

   }

   public void modifyBufferedEffect(ComplexSpellModifier modifier) {
      SpellEffect effect = this.getBufferedEffect();
      if(effect != null) {
         effect.modifyEffect(modifier);
      }

   }

   public void applyEnhancement(SpellEnhancement enh) {
      if(enh != null) {
         if(this.bufferedEffectList.isEmpty()) {
            this.enhanceParadigm(enh);
         } else {
            SpellEffect effect = this.getBufferedEffect();
            if(effect != null) {
               effect.enhanceEffect(enh);
            }
         }
      }

   }

   public abstract void enhanceParadigm(SpellEnhancement var1);

   public abstract void castSpell(World var1, EntityPlayer var2, ItemStack var3);

   public void applySpellEffect(SpellEffect effect) {
      effect.modifyParadigm(this);
   }

   public void applyAllSpellEffects() {
      Iterator i$ = this.bufferedEffectList.iterator();

      while(i$.hasNext()) {
         SpellEffect effect = (SpellEffect)i$.next();
         this.applySpellEffect(effect);
      }

   }

   public SpellEffect getBufferedEffect() {
      return this.bufferedEffectList.isEmpty()?null:(SpellEffect)this.bufferedEffectList.get(this.bufferedEffectList.size() - 1);
   }

   public int getTotalCost() {
      int cost = 0;
      if(this.bufferedEffectList != null && !this.bufferedEffectList.isEmpty()) {
         SpellEffect effect;
         for(Iterator i$ = this.bufferedEffectList.iterator(); i$.hasNext(); cost += effect.getCostOfEffect(this)) {
            effect = (SpellEffect)i$.next();
         }

         return (int)((double)cost * Math.sqrt((double)this.bufferedEffectList.size()));
      } else {
         return this.getDefaultCost();
      }
   }

   public abstract int getDefaultCost();

   public int getBufferedEffectPower() {
      SpellEffect eff = this.getBufferedEffect();
      return eff != null?eff.getPowerEnhancements():0;
   }

   public int getBufferedEffectCost() {
      SpellEffect eff = this.getBufferedEffect();
      return eff != null?eff.getCostEnhancements():0;
   }

   public int getBufferedEffectPotency() {
      SpellEffect eff = this.getBufferedEffect();
      return eff != null?eff.getPotencyEnhancements():0;
   }
}
