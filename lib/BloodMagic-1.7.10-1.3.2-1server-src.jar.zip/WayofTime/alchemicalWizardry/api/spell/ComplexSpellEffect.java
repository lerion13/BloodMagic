package WayofTime.alchemicalWizardry.api.spell;

import WayofTime.alchemicalWizardry.api.spell.ComplexSpellModifier;
import WayofTime.alchemicalWizardry.api.spell.ComplexSpellType;
import WayofTime.alchemicalWizardry.api.spell.SpellParadigm;

public abstract class ComplexSpellEffect {

   public final ComplexSpellType type;
   public final ComplexSpellModifier modifier;
   protected int powerEnhancement;
   protected int costEnhancement;
   protected int potencyEnhancement;


   public ComplexSpellEffect(ComplexSpellType type, ComplexSpellModifier modifier) {
      this.type = type;
      this.modifier = modifier;
   }

   public ComplexSpellEffect(ComplexSpellType type, ComplexSpellModifier modifier, int power, int cost, int potency) {
      this(type, modifier);
      this.powerEnhancement = power;
      this.costEnhancement = cost;
      this.potencyEnhancement = potency;
   }

   public abstract void modifyParadigm(SpellParadigm var1);

   public ComplexSpellType getType() {
      return this.type;
   }

   public ComplexSpellModifier getModifier() {
      return this.modifier;
   }

   public abstract ComplexSpellEffect copy(int var1, int var2, int var3);

   public abstract int getCostOfEffect();
}
