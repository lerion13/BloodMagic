package WayofTime.alchemicalWizardry.api.spell;

import WayofTime.alchemicalWizardry.api.soulNetwork.SoulNetworkHandler;
import WayofTime.alchemicalWizardry.api.spell.IMeleeSpellEntityEffect;
import WayofTime.alchemicalWizardry.api.spell.IMeleeSpellWorldEffect;
import WayofTime.alchemicalWizardry.api.spell.SpellEnhancement;
import WayofTime.alchemicalWizardry.api.spell.SpellParadigm;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class SpellParadigmMelee extends SpellParadigm {

   private List entityEffectList = new ArrayList();
   private List worldEffectList = new ArrayList();


   public void enhanceParadigm(SpellEnhancement enh) {}

   public void castSpell(World world, EntityPlayer entityPlayer, ItemStack itemStack) {
      int cost = this.getTotalCost();
      if(SoulNetworkHandler.syphonAndDamageFromNetwork(itemStack, entityPlayer, cost)) {
         Iterator i$ = this.entityEffectList.iterator();

         while(i$.hasNext()) {
            IMeleeSpellEntityEffect effect = (IMeleeSpellEntityEffect)i$.next();
            effect.onEntityImpact(world, entityPlayer);
         }

         i$ = this.worldEffectList.iterator();

         while(i$.hasNext()) {
            IMeleeSpellWorldEffect effect1 = (IMeleeSpellWorldEffect)i$.next();
            effect1.onWorldEffect(world, entityPlayer);
         }

      }
   }

   public void addEntityEffect(IMeleeSpellEntityEffect eff) {
      if(eff != null) {
         this.entityEffectList.add(eff);
      }

   }

   public void addWorldEffect(IMeleeSpellWorldEffect eff) {
      if(eff != null) {
         this.worldEffectList.add(eff);
      }

   }

   public int getDefaultCost() {
      return 0;
   }
}
