package WayofTime.alchemicalWizardry.api.spell;

import net.minecraft.entity.Entity;

public interface ISpecialDamageEffect {

   float getDamageForEntity(Entity var1);

   String getKey();
}
