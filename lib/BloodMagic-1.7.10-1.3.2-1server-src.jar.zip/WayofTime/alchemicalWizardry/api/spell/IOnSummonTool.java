package WayofTime.alchemicalWizardry.api.spell;

import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public interface IOnSummonTool {

   int onSummonTool(ItemStack var1, World var2, Entity var3);
}
