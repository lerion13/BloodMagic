package WayofTime.alchemicalWizardry.api.spell;

import net.minecraft.entity.Entity;

public interface IProjectileUpdateEffect {

   void onUpdateEffect(Entity var1);
}
