package WayofTime.alchemicalWizardry.api.spell;

import WayofTime.alchemicalWizardry.api.items.ItemSpellMultiTool;
import WayofTime.alchemicalWizardry.api.soulNetwork.SoulNetworkHandler;
import WayofTime.alchemicalWizardry.api.spell.APISpellHelper;
import WayofTime.alchemicalWizardry.api.spell.IDigAreaEffect;
import WayofTime.alchemicalWizardry.api.spell.IItemManipulator;
import WayofTime.alchemicalWizardry.api.spell.ILeftClickEffect;
import WayofTime.alchemicalWizardry.api.spell.IOnBanishTool;
import WayofTime.alchemicalWizardry.api.spell.IOnBreakBlock;
import WayofTime.alchemicalWizardry.api.spell.IOnSummonTool;
import WayofTime.alchemicalWizardry.api.spell.IRightClickEffect;
import WayofTime.alchemicalWizardry.api.spell.ISpecialDamageEffect;
import WayofTime.alchemicalWizardry.api.spell.IToolUpdateEffect;
import WayofTime.alchemicalWizardry.api.spell.SpellEffect;
import WayofTime.alchemicalWizardry.api.spell.SpellEnhancement;
import WayofTime.alchemicalWizardry.api.spell.SpellParadigm;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public class SpellParadigmTool extends SpellParadigm {

   private List leftClickEffectList = new LinkedList();
   private List rightClickEffectList = new LinkedList();
   private List toolUpdateEffectList = new LinkedList();
   private List toolSummonEffectList = new LinkedList();
   private List toolBanishEffectList = new LinkedList();
   private List breakBlockEffectList = new LinkedList();
   private List itemManipulatorEffectList = new LinkedList();
   private List digAreaEffectList = new LinkedList();
   private List specialDamageEffectList = new LinkedList();
   private float maxDamage = 5.0F;
   private HashMap harvestLevel = new HashMap();
   private HashMap digSpeed;
   private HashMap maxDamageHash;
   private HashMap critChanceHash = new HashMap();
   private HashMap durationHash = new HashMap();
   private HashMap toolInfoString = new HashMap();
   private int fortuneLevel;
   private boolean silkTouch;
   private int duration;
   public static Item customTool;


   public SpellParadigmTool() {
      this.harvestLevel.put("pickaxe", Integer.valueOf(-1));
      this.harvestLevel.put("shovel", Integer.valueOf(-1));
      this.harvestLevel.put("axe", Integer.valueOf(-1));
      this.digSpeed = new HashMap();
      this.digSpeed.put("pickaxe", Float.valueOf(1.0F));
      this.digSpeed.put("shovel", Float.valueOf(1.0F));
      this.digSpeed.put("axe", Float.valueOf(1.0F));
      this.maxDamageHash = new HashMap();
      this.maxDamageHash.put("default", Float.valueOf(5.0F));
      this.fortuneLevel = 0;
      this.silkTouch = false;
      this.duration = 0;
      this.durationHash.put("default", Integer.valueOf(2400));
   }

   public void enhanceParadigm(SpellEnhancement enh) {}

   public void castSpell(World world, EntityPlayer entityPlayer, ItemStack crystal) {
      if(!entityPlayer.worldObj.isRemote) {
         int cost = this.getTotalCost();
         if(SoulNetworkHandler.syphonAndDamageFromNetwork(crystal, entityPlayer, cost)) {
            ItemStack toolStack = this.prepareTool(crystal, world);
            entityPlayer.setCurrentItemOrArmor(0, toolStack);
            this.onSummonTool(toolStack, world, entityPlayer);
         }
      }
   }

   public ItemStack prepareTool(ItemStack crystalStack, World world) {
      ItemStack toolStack = new ItemStack(customTool, 1);
      ItemSpellMultiTool itemTool = (ItemSpellMultiTool)customTool;
      itemTool.setItemAttack(toolStack, this.composeMaxDamageFromHash());
      Set harvestLevelSet = this.harvestLevel.entrySet();
      Iterator digSpeedSet = harvestLevelSet.iterator();

      while(digSpeedSet.hasNext()) {
         Entry toolStringList = (Entry)digSpeedSet.next();
         String i$ = (String)toolStringList.getKey();
         int integ = ((Integer)toolStringList.getValue()).intValue();
         itemTool.setHarvestLevel(toolStack, i$, integ);
      }

      Set digSpeedSet1 = this.digSpeed.entrySet();
      Iterator toolStringList1 = digSpeedSet1.iterator();

      String integ1;
      while(toolStringList1.hasNext()) {
         Entry i$2 = (Entry)toolStringList1.next();
         integ1 = (String)i$2.getKey();
         float speed = ((Float)i$2.getValue()).floatValue();
         itemTool.setDigSpeed(toolStack, integ1, speed);
      }

      itemTool.setFortuneLevel(toolStack, this.getFortuneLevel());
      itemTool.setSilkTouch(toolStack, this.getSilkTouch());
      if(this.getSilkTouch()) {
         this.addToolString("SilkTouch", "Silk Touch " + APISpellHelper.getNumeralForInt(1));
      }

      if(this.getFortuneLevel() > 0) {
         this.addToolString("Fortune", "Fortune " + APISpellHelper.getNumeralForInt(this.getFortuneLevel()));
      }

      itemTool.setCritChance(toolStack, this.getCritChance() / 100.0F);
      LinkedList toolStringList2 = new LinkedList();
      Iterator i$1 = this.toolInfoString.values().iterator();

      while(i$1.hasNext()) {
         integ1 = (String)i$1.next();
         toolStringList2.add(integ1);
      }

      itemTool.setToolListString(toolStack, toolStringList2);

      Integer integ2;
      for(i$1 = this.durationHash.values().iterator(); i$1.hasNext(); this.duration += integ2.intValue()) {
         integ2 = (Integer)i$1.next();
      }

      itemTool.setDuration(toolStack, world, this.duration);
      itemTool.loadParadigmIntoStack(toolStack, super.bufferedEffectList);
      SoulNetworkHandler.checkAndSetItemOwner(toolStack, SoulNetworkHandler.getOwnerName(crystalStack));
      itemTool.setContainedCrystal(toolStack, crystalStack);
      return toolStack;
   }

   public int getDefaultCost() {
      return 100;
   }

   public static SpellParadigmTool getParadigmForEffectArray(List effectList) {
      SpellParadigmTool parad = new SpellParadigmTool();
      Iterator i$ = effectList.iterator();

      while(i$.hasNext()) {
         SpellEffect eff = (SpellEffect)i$.next();
         parad.addBufferedEffect(eff);
      }

      parad.applyAllSpellEffects();
      return parad;
   }

   public void addLeftClickEffect(ILeftClickEffect eff) {
      if(eff != null) {
         this.leftClickEffectList.add(eff);
      }

   }

   public void addRightClickEffect(IRightClickEffect eff) {
      if(eff != null) {
         this.rightClickEffectList.add(eff);
      }

   }

   public void addUpdateEffect(IToolUpdateEffect eff) {
      if(eff != null) {
         this.toolUpdateEffectList.add(eff);
      }

   }

   public void addToolSummonEffect(IOnSummonTool eff) {
      if(eff != null) {
         this.toolSummonEffectList.add(eff);
      }

   }

   public void addToolBanishEffect(IOnBanishTool eff) {
      if(eff != null) {
         this.toolBanishEffectList.add(eff);
      }

   }

   public void addBlockBreakEffect(IOnBreakBlock eff) {
      if(eff != null) {
         this.breakBlockEffectList.add(eff);
      }

   }

   public void addItemManipulatorEffect(IItemManipulator eff) {
      if(eff != null) {
         this.itemManipulatorEffectList.add(eff);
      }

   }

   public void addDigAreaEffect(IDigAreaEffect eff) {
      if(eff != null) {
         this.digAreaEffectList.add(eff);
      }

   }

   public void addSpecialDamageEffect(ISpecialDamageEffect eff) {
      if(eff != null) {
         this.specialDamageEffectList.add(eff);
      }

   }

   public int onLeftClickEntity(ItemStack stack, EntityLivingBase attacked, EntityLivingBase weilder) {
      int total = 0;

      ILeftClickEffect effect;
      for(Iterator i$ = this.leftClickEffectList.iterator(); i$.hasNext(); total += effect.onLeftClickEntity(stack, attacked, weilder)) {
         effect = (ILeftClickEffect)i$.next();
      }

      return total;
   }

   public int onRightClickBlock(ItemStack toolStack, EntityLivingBase weilder, World world, MovingObjectPosition mop) {
      int total = 0;

      IRightClickEffect effect;
      for(Iterator i$ = this.rightClickEffectList.iterator(); i$.hasNext(); total += effect.onRightClickBlock(toolStack, weilder, world, mop)) {
         effect = (IRightClickEffect)i$.next();
      }

      return total;
   }

   public int onRightClickAir(ItemStack toolStack, World world, EntityPlayer player) {
      int total = 0;

      IRightClickEffect effect;
      for(Iterator i$ = this.rightClickEffectList.iterator(); i$.hasNext(); total += effect.onRightClickAir(toolStack, player)) {
         effect = (IRightClickEffect)i$.next();
      }

      return total;
   }

   public int onUpdate(ItemStack toolStack, World world, Entity par3Entity, int invSlot, boolean inHand) {
      int total = 0;

      IToolUpdateEffect effect;
      for(Iterator i$ = this.toolUpdateEffectList.iterator(); i$.hasNext(); total += effect.onUpdate(toolStack, world, par3Entity, invSlot, inHand)) {
         effect = (IToolUpdateEffect)i$.next();
      }

      return total;
   }

   public int onSummonTool(ItemStack toolStack, World world, Entity entity) {
      int total = 0;

      IOnSummonTool effect;
      for(Iterator i$ = this.toolSummonEffectList.iterator(); i$.hasNext(); total += effect.onSummonTool(toolStack, world, entity)) {
         effect = (IOnSummonTool)i$.next();
      }

      return total;
   }

   public int onBanishTool(ItemStack toolStack, World world, Entity entity, int invSlot, boolean inHand) {
      int total = 0;

      IOnBanishTool effect;
      for(Iterator i$ = this.toolBanishEffectList.iterator(); i$.hasNext(); total += effect.onBanishTool(toolStack, world, entity, invSlot, inHand)) {
         effect = (IOnBanishTool)i$.next();
      }

      return total;
   }

   public int onBreakBlock(ItemStack container, World world, EntityPlayer player, Block block, int meta, int x, int y, int z, ForgeDirection sideBroken) {
      int total = 0;

      IOnBreakBlock effect;
      for(Iterator i$ = this.breakBlockEffectList.iterator(); i$.hasNext(); total += effect.onBlockBroken(container, world, player, block, meta, x, y, z, sideBroken)) {
         effect = (IOnBreakBlock)i$.next();
      }

      return total;
   }

   public List handleItemList(ItemStack toolStack, List items) {
      List heldList = items;

      List newHeldList;
      for(Iterator i$ = this.itemManipulatorEffectList.iterator(); i$.hasNext(); heldList = newHeldList) {
         IItemManipulator eff = (IItemManipulator)i$.next();
         newHeldList = eff.handleItemsOnBlockBroken(toolStack, heldList);
      }

      return heldList;
   }

   public int digSurroundingArea(ItemStack container, World world, EntityPlayer player, MovingObjectPosition blockPos, String usedToolClass, float blockHardness, int harvestLvl, ItemSpellMultiTool itemTool) {
      int cost = 0;

      IDigAreaEffect effect;
      for(Iterator i$ = this.digAreaEffectList.iterator(); i$.hasNext(); cost += effect.digSurroundingArea(container, world, player, blockPos, usedToolClass, blockHardness, harvestLvl, itemTool)) {
         effect = (IDigAreaEffect)i$.next();
      }

      return cost;
   }

   public int getFortuneLevel() {
      return this.fortuneLevel;
   }

   public void setFortuneLevel(int fortuneLevel) {
      this.fortuneLevel = fortuneLevel;
   }

   public boolean getSilkTouch() {
      return this.silkTouch;
   }

   public void setSilkTouch(boolean silkTouch) {
      this.silkTouch = silkTouch;
   }

   public int getDuration() {
      return this.duration;
   }

   public void setDuration(int duration) {
      this.duration = duration;
   }

   public void setDigSpeed(String toolClass, float digSpeed) {
      this.digSpeed.put(toolClass, Float.valueOf(digSpeed));
   }

   public void setHarvestLevel(String toolClass, int hlvl) {
      this.harvestLevel.put(toolClass, Integer.valueOf(hlvl));
   }

   public float composeMaxDamageFromHash() {
      float damage = 0.0F;

      float f;
      for(Iterator i$ = this.maxDamageHash.values().iterator(); i$.hasNext(); damage += f) {
         f = ((Float)i$.next()).floatValue();
      }

      return damage;
   }

   public void addDamageToHash(String key, float dmg) {
      this.maxDamageHash.put(key, Float.valueOf(dmg));
   }

   public void addToolString(String key, String str) {
      if(str != null && key != null) {
         this.toolInfoString.put(key, str);
      }

   }

   public void addCritChance(String key, float chance) {
      this.critChanceHash.put(key, Float.valueOf(chance));
   }

   public void addDuration(String key, int dur) {
      this.durationHash.put(key, Integer.valueOf(dur));
   }

   public float getCritChance() {
      float chance = 0.0F;

      float fl;
      for(Iterator i$ = this.critChanceHash.values().iterator(); i$.hasNext(); chance += fl) {
         fl = ((Float)i$.next()).floatValue();
      }

      return chance;
   }

   public float getAddedDamageForEntity(Entity entity) {
      HashMap hash = new HashMap();
      Iterator addedDmg = this.specialDamageEffectList.iterator();

      while(addedDmg.hasNext()) {
         ISpecialDamageEffect i$ = (ISpecialDamageEffect)addedDmg.next();
         hash.put(i$.getKey(), Float.valueOf(i$.getDamageForEntity(entity)));
      }

      float addedDmg1 = 0.0F;

      float fl;
      for(Iterator i$1 = hash.values().iterator(); i$1.hasNext(); addedDmg1 += fl) {
         fl = ((Float)i$1.next()).floatValue();
      }

      return addedDmg1;
   }
}
