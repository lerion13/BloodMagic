package WayofTime.alchemicalWizardry.api.spell;

import WayofTime.alchemicalWizardry.api.spell.IMeleeSpellWorldEffect;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

public abstract class MeleeSpellWorldEffect implements IMeleeSpellWorldEffect {

   protected int powerUpgrades;
   protected int potencyUpgrades;
   protected int costUpgrades;


   public MeleeSpellWorldEffect(int power, int potency, int cost) {
      this.powerUpgrades = power;
      this.potencyUpgrades = potency;
      this.costUpgrades = cost;
   }

   public abstract void onWorldEffect(World var1, EntityPlayer var2);
}
