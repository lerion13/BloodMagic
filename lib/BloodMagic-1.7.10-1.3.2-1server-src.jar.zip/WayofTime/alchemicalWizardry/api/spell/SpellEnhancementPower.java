package WayofTime.alchemicalWizardry.api.spell;

import WayofTime.alchemicalWizardry.api.spell.SpellEnhancement;

public class SpellEnhancementPower extends SpellEnhancement {

   public SpellEnhancementPower() {
      super(0);
   }
}
