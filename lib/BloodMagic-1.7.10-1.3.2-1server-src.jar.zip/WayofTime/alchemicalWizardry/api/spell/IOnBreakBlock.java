package WayofTime.alchemicalWizardry.api.spell;

import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;

public interface IOnBreakBlock {

   int onBlockBroken(ItemStack var1, World var2, EntityPlayer var3, Block var4, int var5, int var6, int var7, int var8, ForgeDirection var9);
}
