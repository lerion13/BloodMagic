package WayofTime.alchemicalWizardry.api.spell;

import net.minecraft.entity.Entity;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;

public interface IProjectileImpactEffect {

   void onEntityImpact(Entity var1, Entity var2);

   void onTileImpact(World var1, MovingObjectPosition var2);
}
