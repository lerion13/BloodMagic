package WayofTime.alchemicalWizardry.api.spell;

import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public interface IOnBanishTool {

   int onBanishTool(ItemStack var1, World var2, Entity var3, int var4, boolean var5);
}
