package WayofTime.alchemicalWizardry.api.spell;

import WayofTime.alchemicalWizardry.api.items.ItemSpellMultiTool;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;

public interface IDigAreaEffect {

   int digSurroundingArea(ItemStack var1, World var2, EntityPlayer var3, MovingObjectPosition var4, String var5, float var6, int var7, ItemSpellMultiTool var8);
}
