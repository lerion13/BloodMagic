package WayofTime.alchemicalWizardry.api.spell;

import WayofTime.alchemicalWizardry.api.spell.SpellEnhancement;

public class SpellEnhancementCost extends SpellEnhancement {

   public SpellEnhancementCost() {
      super(1);
   }
}
