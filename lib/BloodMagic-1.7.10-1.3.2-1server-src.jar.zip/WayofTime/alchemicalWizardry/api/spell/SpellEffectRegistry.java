package WayofTime.alchemicalWizardry.api.spell;

import WayofTime.alchemicalWizardry.api.spell.ComplexSpellEffect;
import WayofTime.alchemicalWizardry.api.spell.ComplexSpellModifier;
import WayofTime.alchemicalWizardry.api.spell.ComplexSpellType;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class SpellEffectRegistry {

   public static Map effectRegistry = new HashMap();
   public static Map typeRegistry = new HashMap();
   public static Map modifierRegistry = new HashMap();


   public static void registerSpellEffect(Class paraClass, ComplexSpellEffect effect) {
      if(paraClass != null && effect != null) {
         if(effectRegistry.containsKey(paraClass)) {
            List effectList = (List)effectRegistry.get(paraClass);
            ComplexSpellType type = effect.getType();
            ComplexSpellModifier modifier = effect.getModifier();
            if(type == null || modifier == null) {
               return;
            }

            Iterator i$ = effectList.iterator();

            while(i$.hasNext()) {
               ComplexSpellEffect eff = (ComplexSpellEffect)i$.next();
               if(type.equals(eff.getType()) && modifier.equals(eff.getModifier())) {
                  effectList.remove(eff);
                  effectList.add(effect);
                  return;
               }
            }

            effectList.add(effect);
         } else {
            LinkedList effectList1 = new LinkedList();
            effectList1.add(effect);
            effectRegistry.put(paraClass, effectList1);
         }

      }
   }

   public static ComplexSpellEffect getSpellEffect(Class paraClass, ComplexSpellType type, ComplexSpellModifier mod) {
      return getSpellEffect(paraClass, type, mod, 0, 0, 0);
   }

   public static ComplexSpellEffect getSpellEffect(Class paraClass, ComplexSpellType type, ComplexSpellModifier mod, int power, int potency, int cost) {
      if(paraClass != null && type != null && mod != null) {
         List list = (List)effectRegistry.get(paraClass);
         if(list != null && !list.isEmpty()) {
            Iterator i$ = list.iterator();

            ComplexSpellEffect effect;
            do {
               if(!i$.hasNext()) {
                  return null;
               }

               effect = (ComplexSpellEffect)i$.next();
            } while(effect == null || !type.equals(effect.type) || !mod.equals(effect.modifier));

            return effect.copy(power, cost, potency);
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   public static void registerSpellType(String key, ComplexSpellType type) {
      typeRegistry.put(key, type);
   }

   public static void registerSpellModifier(String key, ComplexSpellModifier modifier) {
      modifierRegistry.put(key, modifier);
   }

   public static ComplexSpellType getTypeForKey(String key) {
      return (ComplexSpellType)typeRegistry.get(key);
   }

   public static String getKeyForType(ComplexSpellType type) {
      if(type == null) {
         return "";
      } else {
         Iterator i$ = typeRegistry.entrySet().iterator();

         Entry entry;
         do {
            if(!i$.hasNext()) {
               return "";
            }

            entry = (Entry)i$.next();
         } while(!type.equals(entry.getValue()));

         return (String)entry.getKey();
      }
   }

   public static ComplexSpellModifier getModifierForKey(String key) {
      return (ComplexSpellModifier)modifierRegistry.get(key);
   }

   public static String getKeyForModifier(ComplexSpellModifier modifier) {
      if(modifier == null) {
         return "";
      } else {
         Iterator i$ = modifierRegistry.entrySet().iterator();

         Entry entry;
         do {
            if(!i$.hasNext()) {
               return "";
            }

            entry = (Entry)i$.next();
         } while(!modifier.equals(entry.getValue()));

         return (String)entry.getKey();
      }
   }

   public static void initiateRegistry() {
      registerSpellType("FIRE", ComplexSpellType.FIRE);
      registerSpellType("ICE", ComplexSpellType.ICE);
      registerSpellType("EARTH", ComplexSpellType.EARTH);
      registerSpellType("WIND", ComplexSpellType.WIND);
      registerSpellModifier("DEFAULT", ComplexSpellModifier.DEFAULT);
      registerSpellModifier("OFFENSIVE", ComplexSpellModifier.OFFENSIVE);
      registerSpellModifier("DEFENSIVE", ComplexSpellModifier.DEFENSIVE);
      registerSpellModifier("ENVIRONMENTAL", ComplexSpellModifier.ENVIRONMENTAL);
   }

}
