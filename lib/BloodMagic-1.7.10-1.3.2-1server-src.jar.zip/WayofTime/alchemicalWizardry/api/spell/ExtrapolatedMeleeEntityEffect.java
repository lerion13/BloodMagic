package WayofTime.alchemicalWizardry.api.spell;

import WayofTime.alchemicalWizardry.api.spell.IMeleeSpellEntityEffect;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public abstract class ExtrapolatedMeleeEntityEffect implements IMeleeSpellEntityEffect {

   protected float range;
   protected float radius;
   protected int powerUpgrades;
   protected int potencyUpgrades;
   protected int costUpgrades;
   protected int maxHit;


   public ExtrapolatedMeleeEntityEffect(int power, int potency, int cost) {
      this.powerUpgrades = power;
      this.potencyUpgrades = potency;
      this.costUpgrades = cost;
      this.range = 0.0F;
      this.radius = 0.0F;
      this.maxHit = 1;
   }

   public void onEntityImpact(World world, EntityPlayer entityPlayer) {
      Vec3 lookVec = entityPlayer.getLook(this.range);
      double x = entityPlayer.posX + lookVec.xCoord;
      double y = entityPlayer.posY + (double)entityPlayer.getEyeHeight() + lookVec.yCoord;
      double z = entityPlayer.posZ + lookVec.zCoord;
      List entities = world.getEntitiesWithinAABB(Entity.class, AxisAlignedBB.getBoundingBox(x - 0.5D, y - 0.5D, z - 0.5D, x + 0.5D, y + 0.5D, z + 0.5D).expand((double)this.radius, (double)this.radius, (double)this.radius));
      int hit = 0;
      if(entities != null) {
         Iterator i$ = entities.iterator();

         while(i$.hasNext()) {
            Entity entity = (Entity)i$.next();
            if(hit < this.maxHit && !entity.equals(entityPlayer) && this.entityEffect(world, entity, entityPlayer)) {
               ++hit;
            }
         }
      }

   }

   protected abstract boolean entityEffect(World var1, Entity var2, EntityPlayer var3);

   public void setRange(float range) {
      this.range = range;
   }

   public void setRadius(float radius) {
      this.radius = radius;
   }

   public void setMaxNumberHit(int maxHit) {
      this.maxHit = maxHit;
   }
}
