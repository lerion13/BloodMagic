package WayofTime.alchemicalWizardry.api.alchemy.energy;

import WayofTime.alchemicalWizardry.api.alchemy.energy.IReagentHandler;
import WayofTime.alchemicalWizardry.api.alchemy.energy.Reagent;
import java.util.Map;

public interface ISegmentedReagentHandler extends IReagentHandler {

   int getNumberOfTanks();

   int getTanksTunedToReagent(Reagent var1);

   void setTanksTunedToReagent(Reagent var1, int var2);

   Map getAttunedTankMap();
}
