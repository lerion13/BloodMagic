package WayofTime.alchemicalWizardry.api.alchemy.energy;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public interface IAlchemyGoggles {

   boolean showIngameHUD(World var1, ItemStack var2, EntityPlayer var3);
}
