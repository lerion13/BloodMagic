package WayofTime.alchemicalWizardry.api.alchemy.energy;

import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentContainerInfo;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentStack;

public interface IReagentContainer {

   ReagentStack getReagent();

   int getReagentStackAmount();

   int getCapacity();

   int fill(ReagentStack var1, boolean var2);

   ReagentStack drain(int var1, boolean var2);

   ReagentContainerInfo getInfo();
}
