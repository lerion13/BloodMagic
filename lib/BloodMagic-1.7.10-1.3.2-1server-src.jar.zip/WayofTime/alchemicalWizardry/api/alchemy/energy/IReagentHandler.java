package WayofTime.alchemicalWizardry.api.alchemy.energy;

import WayofTime.alchemicalWizardry.api.alchemy.energy.Reagent;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentContainerInfo;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentStack;
import net.minecraftforge.common.util.ForgeDirection;

public interface IReagentHandler {

   int fill(ForgeDirection var1, ReagentStack var2, boolean var3);

   ReagentStack drain(ForgeDirection var1, ReagentStack var2, boolean var3);

   ReagentStack drain(ForgeDirection var1, int var2, boolean var3);

   boolean canFill(ForgeDirection var1, Reagent var2);

   boolean canDrain(ForgeDirection var1, Reagent var2);

   ReagentContainerInfo[] getContainerInfo(ForgeDirection var1);
}
