package WayofTime.alchemicalWizardry.api.alchemy.energy;

import WayofTime.alchemicalWizardry.api.alchemy.energy.ISegmentedReagentHandler;
import WayofTime.alchemicalWizardry.api.alchemy.energy.Reagent;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentContainer;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentContainerInfo;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentRegistry;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentStack;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.tileentity.TileEntity;
import net.minecraftforge.common.util.ForgeDirection;

public class TileSegmentedReagentHandler extends TileEntity implements ISegmentedReagentHandler {

   protected ReagentContainer[] tanks;
   protected Map attunedTankMap;


   public TileSegmentedReagentHandler() {
      this(1);
   }

   public TileSegmentedReagentHandler(int numberOfTanks) {
      this(numberOfTanks, 1000);
   }

   public TileSegmentedReagentHandler(int numberOfTanks, int tankSize) {
      this.attunedTankMap = new HashMap();
      this.tanks = new ReagentContainer[numberOfTanks];

      for(int i = 0; i < numberOfTanks; ++i) {
         this.tanks[i] = new ReagentContainer(tankSize);
      }

   }

   public void readFromNBT(NBTTagCompound tag) {
      super.readFromNBT(tag);
      NBTTagList tagList = tag.getTagList("reagentTanks", 10);
      int size = tagList.tagCount();
      this.tanks = new ReagentContainer[size];

      for(int attunedTagList = 0; attunedTagList < size; ++attunedTagList) {
         NBTTagCompound i = tagList.getCompoundTagAt(attunedTagList);
         this.tanks[attunedTagList] = ReagentContainer.readFromNBT(i);
      }

      NBTTagList var8 = tag.getTagList("attunedTankMap", 10);

      for(int var9 = 0; var9 < var8.tagCount(); ++var9) {
         NBTTagCompound savedTag = var8.getCompoundTagAt(var9);
         Reagent reagent = ReagentRegistry.getReagentForKey(savedTag.getString("reagent"));
         this.attunedTankMap.put(reagent, Integer.valueOf(savedTag.getInteger("amount")));
      }

   }

   public void writeToNBT(NBTTagCompound tag) {
      super.writeToNBT(tag);
      NBTTagList tagList = new NBTTagList();

      for(int attunedTagList = 0; attunedTagList < this.tanks.length; ++attunedTagList) {
         NBTTagCompound i$ = new NBTTagCompound();
         if(this.tanks[attunedTagList] != null) {
            this.tanks[attunedTagList].writeToNBT(i$);
         }

         tagList.appendTag(i$);
      }

      tag.setTag("reagentTanks", tagList);
      NBTTagList var7 = new NBTTagList();
      Iterator var8 = this.attunedTankMap.entrySet().iterator();

      while(var8.hasNext()) {
         Entry entry = (Entry)var8.next();
         NBTTagCompound savedTag = new NBTTagCompound();
         savedTag.setString("reagent", ReagentRegistry.getKeyForReagent((Reagent)entry.getKey()));
         savedTag.setInteger("amount", ((Integer)entry.getValue()).intValue());
         var7.appendTag(savedTag);
      }

      tag.setTag("attunedTankMap", var7);
   }

   public int fill(ForgeDirection from, ReagentStack resource, boolean doFill) {
      int totalFill = 0;
      boolean useTankLimit = !this.attunedTankMap.isEmpty();
      if(resource != null) {
         int totalTanksFillable = useTankLimit?this.getTanksTunedToReagent(resource.reagent):this.tanks.length;
         int tanksFilled = 0;
         int maxFill = resource.amount;

         int i;
         ReagentStack remainingStack;
         boolean isTankEmpty;
         for(i = this.tanks.length - 1; i >= 0; --i) {
            remainingStack = resource.copy();
            remainingStack.amount = maxFill - totalFill;
            isTankEmpty = this.tanks[i].getReagent() == null?false:this.tanks[i].getReagent().isReagentEqual(remainingStack);
            if(isTankEmpty) {
               totalFill += this.tanks[i].fill(remainingStack, doFill);
               ++tanksFilled;
               if(totalFill >= maxFill || tanksFilled >= totalTanksFillable) {
                  return totalFill;
               }
            }
         }

         if(tanksFilled >= totalTanksFillable) {
            return totalFill;
         }

         for(i = this.tanks.length - 1; i >= 0; --i) {
            remainingStack = resource.copy();
            remainingStack.amount = maxFill - totalFill;
            isTankEmpty = this.tanks[i].getReagent() == null;
            if(isTankEmpty) {
               totalFill += this.tanks[i].fill(remainingStack, doFill);
               ++tanksFilled;
               if(totalFill >= maxFill || tanksFilled >= totalTanksFillable) {
                  return totalFill;
               }
            }
         }
      }

      return totalFill;
   }

   public ReagentStack drain(ForgeDirection from, ReagentStack resource, boolean doDrain) {
      if(resource == null) {
         return null;
      } else {
         int maxDrain = resource.amount;
         Reagent reagent = resource.reagent;
         int drained = 0;

         for(int i = 0; i < this.tanks.length && drained < maxDrain; ++i) {
            if(resource.isReagentEqual(this.tanks[i].getReagent())) {
               ReagentStack drainStack = this.tanks[i].drain(maxDrain - drained, doDrain);
               if(drainStack != null) {
                  drained += drainStack.amount;
               }
            }
         }

         return new ReagentStack(reagent, drained);
      }
   }

   public ReagentStack drain(ForgeDirection from, int maxDrain, boolean doDrain) {
      for(int i = 0; i < this.tanks.length; ++i) {
         ReagentStack stack = this.tanks[i].drain(maxDrain, doDrain);
         if(stack != null) {
            return stack;
         }
      }

      return null;
   }

   public boolean canFill(ForgeDirection from, Reagent reagent) {
      return true;
   }

   public boolean canDrain(ForgeDirection from, Reagent reagent) {
      return true;
   }

   public ReagentContainerInfo[] getContainerInfo(ForgeDirection from) {
      ReagentContainerInfo[] info = new ReagentContainerInfo[this.getNumberOfTanks()];

      for(int i = 0; i < this.getNumberOfTanks(); ++i) {
         info[i] = this.tanks[i].getInfo();
      }

      return info;
   }

   public int getNumberOfTanks() {
      return this.tanks.length;
   }

   public int getTanksTunedToReagent(Reagent reagent) {
      return this.attunedTankMap.containsKey(reagent) && this.attunedTankMap.get(reagent) != null?((Integer)this.attunedTankMap.get(reagent)).intValue():0;
   }

   public void setTanksTunedToReagent(Reagent reagent, int total) {
      if(total == 0 && this.attunedTankMap.containsKey(reagent)) {
         this.attunedTankMap.remove(reagent);
      } else {
         this.attunedTankMap.put(reagent, new Integer(total));
      }
   }

   public Map getAttunedTankMap() {
      return this.attunedTankMap;
   }

   public boolean areTanksEmpty() {
      for(int i = 0; i < this.tanks.length; ++i) {
         if(this.tanks[i] != null && this.tanks[i].reagentStack != null) {
            return false;
         }
      }

      return true;
   }
}
