package WayofTime.alchemicalWizardry.api.alchemy.energy;

import WayofTime.alchemicalWizardry.api.alchemy.energy.IReagentContainer;
import WayofTime.alchemicalWizardry.api.alchemy.energy.Reagent;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentContainerInfo;
import WayofTime.alchemicalWizardry.api.alchemy.energy.ReagentStack;
import net.minecraft.nbt.NBTTagCompound;

public class ReagentContainer implements IReagentContainer {

   protected ReagentStack reagentStack;
   protected int capacity;


   public ReagentContainer(int capacity) {
      this((ReagentStack)null, capacity);
   }

   public ReagentContainer(ReagentStack stack, int capacity) {
      this.reagentStack = stack;
      this.capacity = capacity;
   }

   public ReagentContainer(Reagent reagent, int amount, int capacity) {
      this(new ReagentStack(reagent, amount), capacity);
   }

   public static ReagentContainer readFromNBT(NBTTagCompound nbt) {
      ReagentStack reagent = ReagentStack.loadReagentStackFromNBT(nbt);
      int capacity = nbt.getInteger("capacity");
      return reagent != null?new ReagentContainer(reagent, capacity):new ReagentContainer((ReagentStack)null, capacity);
   }

   public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
      if(this.reagentStack != null) {
         this.reagentStack.writeToNBT(nbt);
      }

      nbt.setInteger("capacity", this.capacity);
      return nbt;
   }

   public ReagentStack getReagent() {
      return this.reagentStack;
   }

   public int getReagentStackAmount() {
      return this.reagentStack == null?0:this.reagentStack.amount;
   }

   public int getCapacity() {
      return this.capacity;
   }

   public int fill(ReagentStack resource, boolean doFill) {
      if(resource == null) {
         return 0;
      } else if(!doFill) {
         return this.reagentStack == null?Math.min(this.capacity, resource.amount):(!this.reagentStack.isReagentEqual(resource)?0:Math.min(this.capacity - this.reagentStack.amount, resource.amount));
      } else if(this.reagentStack == null) {
         this.reagentStack = new ReagentStack(resource, Math.min(this.capacity, resource.amount));
         return this.reagentStack.amount;
      } else if(!this.reagentStack.isReagentEqual(resource)) {
         return 0;
      } else {
         int filled = this.capacity - this.reagentStack.amount;
         if(resource.amount < filled) {
            this.reagentStack.amount += resource.amount;
            filled = resource.amount;
         } else {
            this.reagentStack.amount = this.capacity;
         }

         return filled;
      }
   }

   public ReagentStack drain(int maxDrain, boolean doDrain) {
      if(this.reagentStack == null) {
         return null;
      } else {
         int drained = maxDrain;
         if(this.reagentStack.amount < maxDrain) {
            drained = this.reagentStack.amount;
         }

         ReagentStack stack = new ReagentStack(this.reagentStack, drained);
         if(doDrain) {
            this.reagentStack.amount -= drained;
            if(this.reagentStack.amount <= 0) {
               this.reagentStack = null;
            }
         }

         return stack;
      }
   }

   public ReagentContainerInfo getInfo() {
      return new ReagentContainerInfo(this);
   }
}
