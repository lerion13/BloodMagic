package WayofTime.alchemicalWizardry.api.alchemy;

import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;

public class AlchemyPotionHandlerComponent {

   private ItemStack itemStack;
   private int potionID;
   private int tickDuration;


   public AlchemyPotionHandlerComponent(ItemStack itemStack, int potionID, int tickDuration) {
      this.itemStack = itemStack;
      this.potionID = potionID;
      this.tickDuration = tickDuration;
   }

   public boolean compareItemStack(ItemStack comparedStack) {
      if(comparedStack != null && this.itemStack != null) {
         if(comparedStack.getItem() instanceof ItemBlock) {
            if(this.itemStack.getItem() instanceof ItemBlock) {
               return comparedStack.getItem().equals(this.itemStack.getItem()) && comparedStack.getItemDamage() == this.itemStack.getItemDamage();
            }
         } else if(!(this.itemStack.getItem() instanceof ItemBlock)) {
            return comparedStack.getItem().equals(this.itemStack.getItem()) && comparedStack.getItemDamage() == this.itemStack.getItemDamage();
         }
      }

      return false;
   }

   public ItemStack getItemStack() {
      return this.itemStack;
   }

   public int getPotionID() {
      return this.potionID;
   }

   public int getTickDuration() {
      return this.tickDuration;
   }
}
