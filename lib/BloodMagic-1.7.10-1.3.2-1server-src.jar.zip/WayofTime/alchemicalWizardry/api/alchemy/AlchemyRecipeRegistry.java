package WayofTime.alchemicalWizardry.api.alchemy;

import WayofTime.alchemicalWizardry.api.alchemy.AlchemyRecipe;
import WayofTime.alchemicalWizardry.api.items.interfaces.IBloodOrb;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.item.ItemStack;

public class AlchemyRecipeRegistry {

   public static List recipes = new ArrayList();


   public static void registerRecipe(ItemStack output, int amountNeeded, ItemStack[] recipe, int bloodOrbLevel) {
      recipes.add(new AlchemyRecipe(output, amountNeeded, recipe, bloodOrbLevel));
   }

   public static ItemStack getResult(ItemStack[] recipe, ItemStack bloodOrb) {
      if(bloodOrb == null) {
         return null;
      } else if(!(bloodOrb.getItem() instanceof IBloodOrb)) {
         return null;
      } else {
         int bloodOrbLevel = ((IBloodOrb)bloodOrb.getItem()).getOrbLevel();
         Iterator i$ = recipes.iterator();

         AlchemyRecipe ar;
         do {
            if(!i$.hasNext()) {
               return null;
            }

            ar = (AlchemyRecipe)i$.next();
         } while(!ar.doesRecipeMatch(recipe, bloodOrbLevel));

         return ar.getResult();
      }
   }

   public static int getAmountNeeded(ItemStack[] recipe, ItemStack bloodOrb) {
      if(bloodOrb == null) {
         return 0;
      } else if(!(bloodOrb.getItem() instanceof IBloodOrb)) {
         return 0;
      } else {
         int bloodOrbLevel = ((IBloodOrb)bloodOrb.getItem()).getOrbLevel();
         Iterator i$ = recipes.iterator();

         AlchemyRecipe ar;
         do {
            if(!i$.hasNext()) {
               return 0;
            }

            ar = (AlchemyRecipe)i$.next();
         } while(!ar.doesRecipeMatch(recipe, bloodOrbLevel));

         return ar.getAmountNeeded();
      }
   }

   public static ItemStack[] getRecipeForItemStack(ItemStack itemStack) {
      Iterator i$ = recipes.iterator();

      AlchemyRecipe ar;
      ItemStack result;
      do {
         if(!i$.hasNext()) {
            return null;
         }

         ar = (AlchemyRecipe)i$.next();
         result = ar.getResult();
      } while(result == null || !result.isItemEqual(itemStack));

      return ar.getRecipe();
   }

}
