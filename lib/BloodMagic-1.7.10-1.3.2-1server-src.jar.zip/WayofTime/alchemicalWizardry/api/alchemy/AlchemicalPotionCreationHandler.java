package WayofTime.alchemicalWizardry.api.alchemy;

import WayofTime.alchemicalWizardry.api.alchemy.AlchemyPotionHandlerComponent;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.item.ItemStack;

public class AlchemicalPotionCreationHandler {

   public static ArrayList registeredPotionEffects = new ArrayList();


   public static void addPotion(ItemStack itemStack, int potionID, int tickDuration) {
      registeredPotionEffects.add(new AlchemyPotionHandlerComponent(itemStack, potionID, tickDuration));
   }

   public static int getPotionIDForStack(ItemStack itemStack) {
      Iterator i$ = registeredPotionEffects.iterator();

      AlchemyPotionHandlerComponent aphc;
      do {
         if(!i$.hasNext()) {
            return -1;
         }

         aphc = (AlchemyPotionHandlerComponent)i$.next();
      } while(!aphc.compareItemStack(itemStack));

      return aphc.getPotionID();
   }

   public static int getPotionTickDurationForStack(ItemStack itemStack) {
      Iterator i$ = registeredPotionEffects.iterator();

      AlchemyPotionHandlerComponent aphc;
      do {
         if(!i$.hasNext()) {
            return -1;
         }

         aphc = (AlchemyPotionHandlerComponent)i$.next();
      } while(!aphc.compareItemStack(itemStack));

      return aphc.getTickDuration();
   }

   public static boolean containsRegisteredPotionIngredient(ItemStack[] stackList) {
      ItemStack[] arr$ = stackList;
      int len$ = stackList.length;
      int i$ = 0;

      label21:
      while(i$ < len$) {
         ItemStack is = arr$[i$];
         Iterator i$1 = registeredPotionEffects.iterator();

         AlchemyPotionHandlerComponent aphc;
         do {
            if(!i$1.hasNext()) {
               ++i$;
               continue label21;
            }

            aphc = (AlchemyPotionHandlerComponent)i$1.next();
         } while(!aphc.compareItemStack(is));

         return true;
      }

      return false;
   }

   public static int getRegisteredPotionIngredientPosition(ItemStack[] stackList) {
      int i = 0;
      ItemStack[] arr$ = stackList;
      int len$ = stackList.length;
      int i$ = 0;

      label21:
      while(i$ < len$) {
         ItemStack is = arr$[i$];
         Iterator i$1 = registeredPotionEffects.iterator();

         AlchemyPotionHandlerComponent aphc;
         do {
            if(!i$1.hasNext()) {
               ++i;
               ++i$;
               continue label21;
            }

            aphc = (AlchemyPotionHandlerComponent)i$1.next();
         } while(!aphc.compareItemStack(is));

         return i;
      }

      return -1;
   }

}
