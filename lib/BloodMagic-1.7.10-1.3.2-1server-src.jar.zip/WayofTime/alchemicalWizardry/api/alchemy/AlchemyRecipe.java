package WayofTime.alchemicalWizardry.api.alchemy;

import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;

public class AlchemyRecipe {

   private ItemStack output;
   private ItemStack[] recipe;
   private int bloodOrbLevel;
   private int amountNeeded;


   public AlchemyRecipe(ItemStack output, int amountNeeded, ItemStack[] recipe, int bloodOrbLevel) {
      this.output = output;
      this.recipe = recipe;
      this.amountNeeded = amountNeeded;
      this.bloodOrbLevel = bloodOrbLevel;
   }

   public boolean doesRecipeMatch(ItemStack[] items, int slottedBloodOrbLevel) {
      if(slottedBloodOrbLevel < this.bloodOrbLevel) {
         return false;
      } else {
         ItemStack[] recipe = new ItemStack[5];
         if(items.length < 5) {
            return false;
         } else {
            int i;
            if(this.recipe.length != 5) {
               ItemStack[] checkList = new ItemStack[5];

               for(i = 0; i < 5; ++i) {
                  if(i + 1 > this.recipe.length) {
                     checkList[i] = null;
                  } else {
                     checkList[i] = this.recipe[i];
                  }
               }

               recipe = checkList;
            } else {
               recipe = this.recipe;
            }

            boolean[] var11 = new boolean[5];

            for(i = 0; i < 5; ++i) {
               var11[i] = false;
            }

            for(i = 0; i < 5; ++i) {
               ItemStack recipeItemStack = recipe[i];
               if(recipeItemStack != null) {
                  boolean test = false;

                  for(int j = 0; j < 5; ++j) {
                     if(!var11[j]) {
                        ItemStack checkedItemStack = items[j];
                        if(checkedItemStack != null) {
                           boolean quickTest = false;
                           if(recipeItemStack.getItem() instanceof ItemBlock) {
                              if(checkedItemStack.getItem() instanceof ItemBlock) {
                                 quickTest = true;
                              }
                           } else if(!(checkedItemStack.getItem() instanceof ItemBlock)) {
                              quickTest = true;
                           }

                           if(quickTest && (checkedItemStack.getItemDamage() == recipeItemStack.getItemDamage() || 32767 == recipeItemStack.getItemDamage()) && checkedItemStack.getItem() == recipeItemStack.getItem()) {
                              test = true;
                              var11[j] = true;
                              break;
                           }
                        }
                     }
                  }

                  if(!test) {
                     return false;
                  }
               }
            }

            return true;
         }
      }
   }

   public ItemStack getResult() {
      return this.output.copy();
   }

   public int getAmountNeeded() {
      return this.amountNeeded;
   }

   public ItemStack[] getRecipe() {
      return this.recipe;
   }

   public int getOrbLevel() {
      return this.bloodOrbLevel;
   }
}
